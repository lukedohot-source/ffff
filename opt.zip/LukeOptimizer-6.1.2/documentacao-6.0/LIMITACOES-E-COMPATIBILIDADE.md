# Limitações conhecidas e condições de uso

Esta entrega é uma evolução executável do projeto, com funções preservadas e módulos novos. Não representa validação de todas as combinações de hardware e Windows nem conclusão integral de todos os recursos ambiciosos do pedido. Os pontos abaixo são explícitos para não confundir implementação, diagnóstico e validação.

| Área | Situação desta versão | Motivo / consequência |
|---|---|---|
| Plataforma | x64; Windows 10/11 detectado por build/edição | ARM64 não possui binário nativo. Depende de emulação x64 no Windows 11; não validado em ARM64. |
| Testes de sistema | Backend simulado para Registro, serviços, energia, permissões e rollback | Nenhuma VM Win10/Win11 com administrador estava disponível nesta execução. UAC real, políticas empresariais, antivírus, reinício e perfis de hardware precisam do plano manual. |
| GPU / sensores | Identificação/driver por WMI quando acessível; sem uso de GPU ou temperatura estimados | Não há provedor de sensores/GPU busy integrado. Na máquina de revisão, WMI negou acesso. |
| Memória | Total, disponível, usada, cache e commit por API; livre/standby opcionais | Comprimida não é integrada; o provedor opcional de livre/standby pode negar acesso. Working set não equivale a desempenho. |
| Processos | Maiores working sets com amostra de CPU | Não há ranking de disco/rede por processo. Use Monitor de Recursos; seria necessário provedor/ETW adicional para atribuição confiável. |
| Inicialização | Contagem de Run HKCU/HKLM e pastas Inicializar | Tarefas agendadas e todas as formas de startup não estão incluídas na contagem. Gerenciamento de tarefas agendadas não ganhou motor novo. |
| Rede | Diagnóstico, comparação existente e exportação complementar antes de ajustes relacionados | Não foi criado aplicador genérico de DNS/MTU/RSS/offloads/Winsock. Sem identificação completa e restauração confiável de cada driver/adaptador, esses casos ficam nas ferramentas oficiais/recomendações. Nenhum ping menor é prometido. |
| Limpeza | Oito escopos, prévia, idade, simulação, exclusão permanente e abertura da Lixeira | Não há envio automático para a Lixeira, esvaziamento automático, limpeza de todos os navegadores/perfis nem rollback de exclusão permanente. Windows Update, WinSxS e cache de update não são apagados manualmente. |
| Memória automática | Processos selecionados, identidade validada, intervalo ≥1 min | Não persiste autorização automática entre reinícios do app. Não usa limpeza global de standby nem drivers. |
| Jogos | Perfis e prioridade existentes preservados | Não foi acrescentado supervisor genérico de lançamento/afinidade com restauração ao fechar qualquer jogo. Prioridades efêmeras terminam com o processo; mudanças persistentes usam histórico. |
| Cancelamento | Perfil para entre ações; comandos supervisionados têm timeout e Job Object | Não se mata uma API transacional no meio da escrita. O timeout do perfil é uma fronteira entre ações, não uma garantia de interrupção de qualquer chamada nativa bloqueada. |
| Interface | Sete telas novas, 27 no total; 2/3 colunas, filtros, recolhimento e perfis | Escala de layout 125% foi ensaiada; DPI real em múltiplos monitores 100–200% ainda precisa de teste. Telas históricas extensas continuam com rolagem. |
| Catálogo externo | 408 referências sem payload no ZIP original permanecem ausentes | Textos, IDs e avaliações foram preservados; não há download automático nem promessa de que scripts/executáveis ausentes funcionarão. |
| Serviço/política/proteção | Erros de acesso são explícitos e não há bypass | Um acesso negado não permite afirmar sozinho se a causa é antivírus, GPO ou Tamper Protection; o aplicativo orienta investigar, sem atribuir causa falsa. |
| Backups | Registro, preferências nativas, serviços, prioridade e energia existentes; anexos de rede/.pow em ajustes principais | Nem toda ação é reversível. Limpeza, remoção de apps e working set têm limites específicos. Não há restauração automática irrestrita de todos os arquivos/configurações do Windows. |
| Garantia de estabilidade | Testes e tratamento de erros adicionados | Nenhum software pode assegurar ausência absoluta de crash, falha de disco, travamento de API ou incompatibilidade futura. Não foi executado soak test prolongado de horas/dias. |

Não use Alto Desempenho ou ajustes de boost indiscriminadamente em notebooks, bateria, refrigeração limitada ou máquinas que já sofrem throttling. Não desligue IPv6, adaptadores, compressão, indexação ou serviços sem necessidade concreta e comparação controlada. Não desative proteção para tentar resolver acesso negado. Preserve shaders se o objetivo for evitar recompilação/stutter. Preferências de mouse e aparência não constituem redução medida de input lag.

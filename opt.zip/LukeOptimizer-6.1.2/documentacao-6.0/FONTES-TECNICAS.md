# Fontes técnicas dos módulos novos

- Working sets: [EmptyWorkingSet — Microsoft](https://learn.microsoft.com/en-us/windows/win32/api/psapi/nf-psapi-emptyworkingset). A API solicita remoção de páginas residentes; isso não constitui comprovação de ganho de desempenho.
- Métricas e unidades: [PERFORMANCE_INFORMATION — Microsoft](https://learn.microsoft.com/en-us/windows/win32/api/psapi/ns-psapi-performance_information). O código converte páginas em bytes e distingue disponível, cache e commit.
- Exclusão pelo handle: [FILE_DISPOSITION_INFO — Microsoft](https://learn.microsoft.com/en-us/windows/win32/api/winbase/ns-winbase-file_disposition_info). A implementação mantém a identidade validada e não fecha o arquivo antes de marcar a exclusão.
- Processos filhos: [Job Objects — Microsoft](https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects). O processo é criado suspenso, associado ao job e só então retomado; fechar o job encerra seus processos.
- Rede e exportação: [Netsh interface — Microsoft](https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/netsh-interface). Dumps são referências; não são aplicados automaticamente.
- Diagnóstico de imagem: [Repair a Windows Image — Microsoft](https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/repair-a-windows-image?view=windows-11). Foram integrados CheckHealth e ScanHealth; não RestoreHealth/ResetBase automáticos.
- Componentes: [Clean Up the WinSxS Folder — Microsoft](https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/clean-up-the-winsxs-folder?view=windows-11). O módulo de arquivos não apaga WinSxS nem componentes de atualização.
- DPI: [High DPI support in Windows Forms — Microsoft](https://learn.microsoft.com/en-us/dotnet/desktop/winforms/high-dpi-support-in-windows-forms?view=netframeworkdesktop-4.8). O pacote inclui configuração PerMonitorV2 para .NET Framework 4.8; validação em múltiplos monitores está no plano manual.

Cada diagnóstico oficial também leva seu link de origem no catálogo e no resultado. As opções históricas continuam com seus links e revisões originais. Não foi feita nova comprovação empírica de benefício de cada um dos 780 itens da biblioteca.

# Compilação e arquitetura

O produto ativo permanece C# / .NET Framework / Windows Forms, com P/Invoke de APIs oficiais. `native/LukeOptimizer-v5.exe`, `native/LukeOptimizer-Engine.exe` e `codigo-fonte/LukeOptimizer/LukeOptimizer-Engine.exe` devem ter o mesmo SHA256. Cada executável de UI deve manter seu `.exe.config` ao lado para DPI. Não existe dependência de NuGet ou download de biblioteca para compilar a parte gerenciada.

Use `codigo-fonte/RECOMPILAR.cmd`, `codigo-fonte/LukeOptimizer/COMPILAR.cmd` ou `VALIDAR-6.0.ps1`. O script chama `%WINDIR%/Microsoft.NET/Framework64/v4.0.30319/csc.exe` com `compilacao.rsp`, C# 5, x64, referências do Framework e recursos JSON embutidos. A configuração de runtime requer .NET Framework 4.8. Compile em uma pasta extraída limpa para evitar confundir binários antigos. A validação recria executáveis de teste e evidências; nunca copia um binário de produção que não passou pelos testes.

| Responsabilidade | Implementação |
|---|---|
| Catálogo/compatibilidade | CatalogIds, Builtins, V5Options, V5InputItems, ImportedOptions, ExtraSettings, ReviewedFeatures; JSONs originais preservados |
| Gravação/verificação/rollback | Profile, IsolatedTransactions, ChangeAudit, SelectionRestore, AtomicStore |
| Contrato de resultados | ExecutionHub: DTO aditivo no Record, TXT/JSON e logs |
| Solicitações controladas | ExecutionControl: GUID, SID, validade, confirmação, replay, cancelamento entre itens |
| Processos externos | ManagedCommand em CommandTools: CreateProcess suspenso, Job Object, timeout/cancelamento, saída em arquivo |
| Backups complementares | BackupBundle: dumps IPv4/IPv6 e exportação do plano nos ajustes correspondentes |
| Telemetria/memória | SystemTelemetry e MemoryManager: API PSAPI, consultas opcionais, validação de identidade |
| Arquivos | StorageManager: categorias fixas, prévia limitada, revalidação, handles dos diretórios, exclusão pelo handle |
| UI | Interface/UnifiedInterface e ProductInterface; demais arquivos parciais preservados |
| Ponte histórica | LiquidProtocol e V5Bridge preservados; C++ Dear ImGui em codigo-fonte/native permanece histórico |

`ExecutionReport` inclui versão, plataforma, total e quantidade concluída. `ActionOutcome` inclui nome/categoria/estado, descrição, detalhe, código, erro amigável, log, backup, reversão, privilégio e sugestão de reinício. O `Record` original continua sendo a autoridade de rollback. A rotação nunca remove backups.

## Modo silencioso controlado

A UI cria solicitações sob `%LOCALAPPDATA%/LukeOptimizer/fila/<GUID>.json` contendo Id, UserSid, Created ISO-8601, ItemIds, Simulation, Confirmed, AdvancedConfirmed e TimeoutSeconds (10–3600). A validade é dez minutos e uma solicitação iniciada não pode ser reapresentada. O CLI `--silent-execute <GUID> <SID>` somente aceita esse contrato, a mesma conta e privilégios previamente concedidos; não abre ou contorna UAC silenciosamente. `--execute-profile` é a rota interativa do worker. Código 0 indica conclusão sem itens pendentes; 2 indica cancelamento/itens ignorados ou parciais; 1 indica erro de execução/validação. Sempre consulte os resultados por item. Não use o modo silencioso para ocultar uma alteração de risco do usuário.

Crie requests por integração deliberada com o formato e as validações de `ExecutionControl`, não por downloads ou scripts fornecidos por terceiros. A geração de uma solicitação não autoriza ignorar confirmações de risco.

## Empacotamento

Atualize a documentação, compile/teste, exporte o catálogo, confira equivalência dos IDs e dos três executáveis, execute `ATUALIZAR-HASHES.ps1`, depois `VERIFICAR-PACOTE.ps1` e `node codigo-fonte/LukeOptimizer/tests/verify-package.mjs`. Comprima a pasta inteira e gere SHA256 do ZIP. Verifique CRC e todos os hashes depois de abrir o ZIP. Não assine com certificado que não seja do proprietário; esta entrega não adiciona assinatura Authenticode.

Fontes e avisos de terceiros do pacote original permanecem incluídos. Os módulos novos usam APIs do Windows/.NET e a fonte Segoe UI instalada pelo sistema; não acrescentam drivers, DLLs baixadas ou fontes externas. O relatório de licença do cliente C++ contém referências históricas e não descreve novas dependências do executável gerenciado.

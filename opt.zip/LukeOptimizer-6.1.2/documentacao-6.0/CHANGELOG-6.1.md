# LukeOptimizer 6.1 — ações rápidas

A versão 6.1 mantém o catálogo e os módulos transacionais da versão 6.0, mas reduz a quantidade de cliques na experiência principal.

## Novas ações na tela de otimizações

A tela principal agora oferece **Otimizar agora**, **Limpar temporários**, **Liberar memória**, **Reduzir processos**, **Central de ferramentas**, **Remover apps** e **Otimização Ultra**. As checkboxes e o modo detalhado continuam disponíveis para seleção individual.

**Otimizar agora** executa apenas os itens marcados como padrão, automáticos, de baixo risco e compatíveis. **Otimização Ultra** reúne as seleções elegíveis do perfil avançado e continua exibindo a revisão e a confirmação antes de aplicar alterações.

## Central de Ferramentas

Os 14 BATs recebidos são exibidos em uma única página, com status, integração, achados, hash e conteúdo preservado. O aplicativo não executa BAT desconhecido automaticamente; essa limitação evita que scripts sem payload validado alterem o sistema sem controle.

## Limpeza e memória

**Limpar temporários** marca os escopos permitidos, analisa os arquivos com idade mínima de um dia e solicita confirmação antes da exclusão permanente. Caminhos pessoais, arquivos protegidos e arquivos em uso continuam fora do escopo.

**Liberar memória** atualiza os processos, seleciona apenas processos elegíveis e solicita a remoção de working sets. A ação não encerra processos e não limpa globalmente a lista standby; o resultado informa essa limitação.

## Redução de processos

**Reduzir processos** analisa os processos atuais e solicita o fechamento normal de até 50 aplicativos autorizados com janela, identidade verificada e sem marca de proteção. Processos do Windows, jogos, serviços, drivers, outras sessões, usuários diferentes e aplicativos não autorizados são excluídos. O fechamento forçado não é usado pelo botão rápido.

## Segurança

As ações rápidas continuam usando UAC legítimo, confirmação, logs e os mecanismos existentes de histórico. SmartScreen, Defender, Firewall, UAC, VBS/HVCI, Secure Boot, Windows Update e SMB2 não são desativados automaticamente por esses botões.

 Essas ações reduzem cliques, mas não prometem ganho universal de FPS, ping ou RAM. Os resultados reais são registrados no histórico quando o Windows consegue medi-los.

## Integração do LIMPAR_TEMPORARIOS.bat

O BAT enviado foi incorporado como referência em `LIMPAR_TEMPORARIOS-original.bat`. Suas áreas seguras foram adicionadas ao catálogo visual de Temporários: Temp legado, Temp na raiz do disco, cache Internet do Windows, cache RDP, cache Opera e cache Vivaldi, além das categorias já existentes para Temp, WER, Edge e Chrome.

O BAT original não é executado diretamente. Cookies, `INetCookies`, perfis completos do Firefox e dados de usuário permanecem fora da limpeza, pois a remoção dessas pastas pode apagar sessões, favoritos, senhas, extensões e configurações. Todas as áreas integradas usam prévia, idade mínima, validação de caminho, proteção contra links/junções, confirmação e registro no Histórico.

# Testes e plano manual

## Execuções realizadas

- Compilação C# 5 / x64 com .NET Framework; produção sem erros e sem warnings. A configuração de execução requer .NET Framework 4.8.
- 981 verificações: 921 anteriores + 60 novas. Incluem transações, rollback, idempotência, compatibilidade simulada, falha parcial, ordem de restauração, proteção de processos, erros classificados, cancelamento, perfis, logs e prévias.
- Interface: todas as rotas anteriores, 131 checkboxes, confirmações, seleção/restauração e exportação; novas telas em 1080×720, 1920×1080 e 2560×1440; layout escalado em 125%; construção, fechamento e Dispose repetido. Isso não equivale a mudar o DPI físico do monitor.
- Testes reais restritos a arquivos e processos descartáveis: exclusão de fixtures, arquivo bloqueado, processo próprio de 32 MiB para EmptyWorkingSet, timeout, cancelamento, encerramento de descendente e repetição de comandos com contagem de handles.
- Leitura real em Windows 11 Pro build 26200.9168, x64, sem administrador: CPU, RAM, commit, rede, disco, plano, contagem de startup e amostras de processos. WMI de GPU e contadores opcionais retornou acesso negado; o resultado registra indisponibilidade. Nenhum registro de alteração foi criado.
- Executável de produção inspecionado por harness separado: versão, 27 páginas, 673 itens, navegação/renderização e zero alterações.

Evidências em `verificacao/atual`: `build.log`, `tests-build.log`, `tests.log`, `ui-build.log`, `ui.log`, `interface/`, `readonly-v6.json`, `readonly-v6.log`, `executavel-final.log` e exportação de catálogo. Warnings das compilações TESTS referem-se a hooks não usados por certos harnesses; não são warnings da produção.

## Reproduzir a suíte

Execute `codigo-fonte/LukeOptimizer/VALIDAR-6.0.ps1`. O script compila produção, fixture de processo, motor de testes e UI; só atualiza os três executáveis de produção se ambos os conjuntos passarem. `-OnlyTest` preserva os executáveis distribuídos. Os testes usam `%TEMP%/LukeOptimizer-Tests/<GUID>` e não modificam configurações reais do Windows. O fixture próprio de memória é a única aplicação de working set dos testes. O teste de timeout usa ping em loopback, sem servidor externo.

Para a prova de leitura real, compile `tests/ReadOnlyV6.cs` com `/define:TESTS /main:ReadOnlyV6 @compilacao.rsp` e passe o caminho JSON de saída. `tests/ReleaseExport54.cs` continua exportando o catálogo da versão atual; seu nome foi preservado. O verificador Node `tests/verify-package.mjs` ou `VERIFICAR-PACOTE.ps1` confere os hashes.

## Plano manual pendente — somente em VMs / máquinas de teste

Crie snapshot da VM e exporte os valores antes de cada cenário. Registre versão, edição, arquitetura, conta, DPI, seleção, relatório JSON e estado depois. Compare com o snapshot e repita. Não marque uma linha aprovada sem a evidência correspondente.

| Caso | Preparação e ação | Critério de aprovação |
|---|---|---|
| Windows 10/11 | Win10 22H2 e Win11 23H2/24H2/25H2; Home, Pro e Enterprise | Interface abre, detecção correta, itens incompatíveis ignorados e nenhum valor inventado. |
| Conta padrão | Perfil misto HKCU + HKLM, sem elevação prévia | HKCU aplicado; UAC solicitado apenas para o grupo elevado. |
| UAC cancelado | Cancelar a solicitação do grupo HKLM | Grupo anterior preservado, cancelamento registrado, sem alegar aplicação dos pendentes. |
| Administrador | Mesma conta, confirmar UAC | Snapshots antes de escrever, leitura de confirmação e rollback exato. |
| Outra conta | Informar credenciais de outro usuário na elevação | Rejeição por SID; nenhuma preferência aplicada ao usuário errado. |
| GPO / Tamper Protection | Máquina de domínio e proteção ativa | Acesso negado tratado; nenhuma mudança de ACL, bypass ou desligamento de proteção. |
| Serviço ausente/dependente | Remover recurso opcional da VM ou usar serviço com dependentes | Ignorado/descrito, sem criar serviço e sem quebrar dependências. |
| Falha no meio do lote | Negar escrita em um alvo após snapshot em VM | Etapa revertida, próximas continuam quando possível; restauração incompleta aparece como pendente. |
| Cancelar lote | Cancelar após primeira ação | Item atual conclui com resultado, seguintes não iniciam; desfazer recupera as etapas concluídas. |
| Reinício | Aplicar ajuste que exige nova sessão/reinício | Indicação coerente; medir depois de reiniciar. App não reinicia sozinho. |
| Arquivos | Arquivo aberto, protegido, link, hard link, ausente e modificado após prévia | Preservados/ignorados com motivo. Documento e arquivo fora da raiz intactos. |
| Rede offline | Desconectar adaptador; DNS/rota indisponíveis | Erros descritivos, UI responde; sem reset automático. |
| Adaptadores distintos | Wi-Fi/Ethernet/VPN, DHCP/estático, IPv4/IPv6 | Snapshot complementar legível; nenhum dump reaplicado automaticamente. |
| Energia | Desktop, notebook em bateria/AC, Modern Standby | Compatibilidade respeitada; `.pow` quando aplicável; retorno ao GUID e valores anteriores. |
| Memória | App elegível, processo encerrado, PID reutilizado e processo protegido | Só seleção válida recebe EmptyWorkingSet; nenhuma finalização; antes/depois sem promessa de desempenho. |
| Memória automática | Intervalo configurado, trocar de tela, encerrar processo, reabrir app | Sem sobreposição; identidade revalidada; reabertura deixa automação desligada. |
| Remoção de apps | VM com app de teste, app ausente/protegido e WinGet indisponível | Seleção individual e reconsulta; cancelamento e timeout sem confirmação falsa de remoção. |
| DPI / teclado | 1080p/1440p/4K, 100/125/150/200%, dois monitores | Sem controles inacessíveis; Tab/Espaço/Esc funcionam; fontes legíveis após mudança de monitor. |
| Responsividade | Limpeza de 10 mil fixtures + diagnóstico lento | Janela move/redimensiona; progresso por itens ou indicador indeterminado; botão cancelar acessível. |
| Repetição | Aplicar duas vezes, desfazer em ordem inversa | Sem corrupção; valores posteriores do usuário preservados; resultados honestos. |
| Queda / recuperação | Encerrar worker na VM depois do backup; reiniciar app | Histórico durável permite conferir/recuperar; nenhum novo lote começa sem revisar falha pendente. |
| Recursos | Executar ciclos por 1–8 h, monitorar handles/GDI/CPU/RAM/filhos/logs | Crescimento limitado, filhos encerrados, rotação conforme configurado; sem polling excessivo. |
| ARM64 | Windows 11 ARM64 com emulação x64 | Marcar como suportado somente após testes de todas as APIs usadas; atualmente não validado. |
| Antes/depois | Mesma carga, jogo, servidor, resolução, energia e temperatura; várias amostras | Comparação repetível; não atribuir variação de ruído à otimização. |

## Problemas encontrados durante esta evolução

Foram corrigidos erro de compilação de identidade de processo, classificação de arquivo já removido, perda potencial de seleção ao atualizar processos com PID reutilizado, timeout sem supervisão completa dos filhos, descarte repetido de CancellationTokenSource ao fechar o formulário e corte/rolagem excessiva na seleção das categorias de limpeza. As suítes foram repetidas após as correções. Nenhum ganho de FPS, ping ou benchmark de aplicação real é alegado.

# LukeOptimizer 6.0 — manual de uso

Extraia o ZIP inteiro e abra `ABRIR.cmd` ou `native/LukeOptimizer-v5.exe`. O nome v5 foi mantido por compatibilidade; a versão interna é 6.0.0. Requer Windows 10/11 x64 e .NET Framework 4.8. O código distribuído e a interface ativa são C# / Windows Forms; o cliente C++ histórico continua incluído.

## Começar

1. Abra **Painel** e veja as leituras reais. CPU, RAM, rede e disco refletem amostras curtas. O plano aparece pelo GUID. Dados indisponíveis não significam zero. Não existe benchmark automático de FPS.
2. Em **Otimizações**, busque uma opção, filtre risco ou favoritos, expanda/recolha uma categoria e abra **Detalhes**. A busca preserva a seleção, inclusive itens ocultos pelo filtro.
3. Use **Simular seleção** antes de aplicar. A simulação lê compatibilidade e valores; não testa o efeito de uma gravação, UAC, política ou reinicialização.
4. **Aplicar selecionadas** abre a revisão. Ajustes que não precisam de administrador são processados primeiro. O Windows solicita UAC para o restante. Cancelar UAC não desfaz as etapas já concluídas.
5. Em **Resultados**, **Ler último histórico** permite exportar o resultado estruturado em TXT ou JSON. **Histórico** continua oferecendo conferir, desfazer e restaurar os valores anteriores. Para grupos separados por privilégio, restaure os registros na ordem inversa de execução.

**Cancelar entre itens** aguarda a ação transacional atual terminar e impede as próximas. Nunca mate o worker para apressar um rollback. O limite do perfil é verificado entre ações; chamadas do Registro e APIs nativas não são interrompidas no meio de uma gravação.

## Painel e memória

RAM disponível inclui páginas que o Windows pode reutilizar. Livre é apenas uma parte; cache não é desperdício. Commit é memória virtual comprometida, e não RAM física usada. Cache do sistema e standby se sobrepõem: não some esses números. Comprimida não possui provedor integrado; livre/standby dependem dos contadores opcionais e podem estar indisponíveis.

O indicador de saúde parte de 100: subtrai 30 quando a RAM disponível é inferior a 10%, ou 15 quando inferior a 20%; subtrai 20 se CPU >90%; subtrai 10 se houver reinício pendente. Só é calculado quando essas leituras existem. Não mede segurança, hardware, vida útil de SSD, FPS ou latência. Temperatura, uso de GPU e disco/rede por processo não são estimados.

Em **Memory Manager**, atualize os processos, marque somente aplicativos elegíveis e simule. **Liberar working sets** pede ao Windows para remover páginas residentes dos processos escolhidos. Eles não são encerrados. O Windows pode recarregar as páginas imediatamente; pode haver mais I/O e atraso. O relatório contém antes/depois e não chama redução de RAM de aumento de desempenho. Não existe rollback das páginas removidas. A lista de standby global permanece como orientação, sem API não documentada ou driver.

Automação é opcional, exige confirmação e usa a seleção atual e um intervalo de 1 a 1440 minutos. Sempre começa desativada ao abrir o app. Identidade, proprietário, início, sessão e caminho são revalidados antes de cada tentativa. Processos protegidos, outros usuários, componentes Windows e jogos fora da lista permitida ficam excluídos.

## Temporários

As oito categorias aparecem em duas colunas. Cada botão **Pasta** abre o local; passe o ponteiro sobre o nome para ler o caminho e o impacto. Nenhuma categoria vem marcada. O módulo usa a pasta conhecida de temporários do usuário, e não aceita uma raiz arbitrária vinda de variável de ambiente ou texto digitado.

Escolha idade mínima (1 a 3650 dias), clique **Analisar prévia**, revise caminhos, quantidades, bytes e data, desmarque o que deseja preservar e simule. A prévia vence em 15 minutos. Há limites de 20 segundos, 50 mil entradas, 10 mil candidatos e profundidade de oito subpastas; a interface informa quando a análise é parcial.

**Apagar selecionados é exclusão permanente**, com confirmação e sem desfazer. Os arquivos não são enviados à Lixeira. **Abrir Lixeira** abre a ferramenta do Windows para revisão manual; não esvazia a Lixeira. Arquivos bloqueados, recentes, alterados desde a prévia, links, hard links, arquivos protegidos e caminhos fora das categorias são preservados. No diretório temporário geral, somente `.tmp` e `.temp` são elegíveis; caches dedicados têm escopo separado. Não são selecionados Documentos, Downloads, saves, cookies, senhas ou perfis completos.

Limpar shaders pode causar recompilação e stutter. Relatórios de crash podem ser importantes para suporte. Considere manter essas categorias desmarcadas. A idade mínima considera criação, escrita e último acesso.

## Avançado, jogos, rede e ferramentas preservadas

**Avançado / Alto Impacto** reúne opções condicionais e de risco. Leia alteração, benefício, efeito colateral, compatibilidade, privilégio, reinício, fonte e reversão. A existência de uma opção histórica não é recomendação de uso. Ajustes que reduzem proteção não entram nos padrões ou no perfil extremo revisado.

Em **Diagnósticos oficiais**, DISM CheckHealth/ScanHealth e SFC verifyonly somente verificam; não reparam, removem WinSxS nem usam ResetBase. IPConfig, Netsh, PnPUtil e Powercfg consultam os recursos descritos. Cada execução tem limite, log e supervisão de processos filhos. Gerenciador de Dispositivos e Otimizar Unidades são abertos como ferramentas oficiais. Não há instalação automática de drivers.

**Ferramentas** preserva telas de rede/latência, perfis de jogos, energia avançada, inicialização/serviços, remoção individual de apps, ajustes manuais, biblioteca, BATs revisados, diagnósticos e comparações de FPS. Use o destino de rede desejado e compare medições equivalentes. Distância, provedor, Wi-Fi e servidor podem limitar a latência. Não são forçados DNS, MTU, IPv6, offloads ou configurações de anti-cheat.

## Perfis, escala e recuperação

Em **Configurações**, escolha densidade compacta ou confortável. Salve a seleção com um nome e use esse mesmo nome para carregar. Perfis não são executados automaticamente. Favoritos existentes continuam no Catálogo e no filtro da tela principal. Restaurar padrões redefine preferências/intervalos do aplicativo e preserva os perfis; para restaurar o Windows, use os backups reais no Histórico.

Tab/Shift+Tab percorrem controles, Espaço marca opções, Ctrl+F abre a busca completa e F5 atualiza o diagnóstico. A configuração de DPI por monitor acompanha o pacote; a troca física entre monitores deve ser validada no ambiente de destino.

Estado local: `%LOCALAPPDATA%\LukeOptimizer`. `historico` contém backups transacionais; `backups-complementares` contém dumps de rede e exportação `.pow` quando usados; `relatorios` contém JSON; `logs` contém logs. O log geral gira em 2 MiB, com cinco cópias anteriores; são conservados os 50 logs de comandos mais recentes. Histórico e backups não são apagados pela rotação.

Snapshots de Registro incluem tipos e ausência original. A reversão recusa sobrescrever uma mudança posterior. Exportações de rede servem como referência complementar: não são reaplicadas cegamente. Em falha de restauração, leia a etapa pendente e tente novamente após resolver a causa. O ponto de restauração opcional continua em Diagnóstico e depende do recurso estar disponível no Windows; não substitui os backups individuais.

Os relatórios podem conter nomes de processos, caminhos, endereços e consultas DNS. Revise o conteúdo antes de compartilhar com suporte.

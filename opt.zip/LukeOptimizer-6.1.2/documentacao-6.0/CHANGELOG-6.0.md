# Alterações da versão 6.0

- Tema grafite/amarelo, controles compactos, busca, risco/favoritos, categorias recolhíveis e perfis.
- Sete telas novas e todos os 673 itens / 127 ajustes / 131 seleções anteriores preservados.
- Resultados estruturados, simulação, fila de solicitações, cancelamento entre ações e grupos por privilégio.
- Logs com rotação, relatórios TXT/JSON e anexos de backup de rede/energia.
- Painel com métricas reais, Memory Manager seletivo e limpeza com oito categorias/idade/prévia.
- Processos suspensos associados a Job Object antes de rodar; timeout e encerramento de descendentes.
- Diagnósticos oficiais de sistema, rede, drivers e energia, sem reparos/downloads cegos.
- Cache do catálogo importado, redução de trabalho no polling e correção de descarte repetido ao fechar.
- 60 verificações novas, testes de interface, fixtures de arquivos/processos e plano manual.

## Arquivos de código/teste alterados

- `codigo-fonte/LukeOptimizer/source/app.config` — novo
- `codigo-fonte/LukeOptimizer/source/app.manifest` — alterado
- `codigo-fonte/LukeOptimizer/source/AppRemoval.cs` — alterado
- `codigo-fonte/LukeOptimizer/source/BackupBundle.cs` — novo
- `codigo-fonte/LukeOptimizer/source/CommandTools.cs` — novo
- `codigo-fonte/LukeOptimizer/source/ExecutionControl.cs` — novo
- `codigo-fonte/LukeOptimizer/source/ExecutionHub.cs` — novo
- `codigo-fonte/LukeOptimizer/source/ImportedOptions.cs` — alterado
- `codigo-fonte/LukeOptimizer/source/Interface.cs` — alterado
- `codigo-fonte/LukeOptimizer/source/IsolatedTransactions.cs` — alterado
- `codigo-fonte/LukeOptimizer/source/LukeOptimizer.cs` — alterado
- `codigo-fonte/LukeOptimizer/source/Maintenance.cs` — alterado
- `codigo-fonte/LukeOptimizer/source/ProductInterface.cs` — novo
- `codigo-fonte/LukeOptimizer/source/Profile.cs` — alterado
- `codigo-fonte/LukeOptimizer/source/StorageManager.cs` — novo
- `codigo-fonte/LukeOptimizer/source/SystemTelemetry.cs` — novo
- `codigo-fonte/LukeOptimizer/source/UnifiedInterface.cs` — alterado
- `codigo-fonte/LukeOptimizer/tests/EngineTests.cs` — alterado
- `codigo-fonte/LukeOptimizer/tests/ProcessFixture.cs` — novo
- `codigo-fonte/LukeOptimizer/tests/ProductUiTests.cs` — novo
- `codigo-fonte/LukeOptimizer/tests/ReadOnlyV6.cs` — novo
- `codigo-fonte/LukeOptimizer/tests/UiSmoke.cs` — alterado
- `codigo-fonte/LukeOptimizer/tests/UnifiedUiTests.cs` — alterado
- `codigo-fonte/LukeOptimizer/tests/V6Tests.cs` — novo

A lista integral, incluindo documentação, binários e evidências, está em auditoria/arquivos-alterados.json. Documentos de versões anteriores permanecem como histórico, não como relatório da validação 6.0.

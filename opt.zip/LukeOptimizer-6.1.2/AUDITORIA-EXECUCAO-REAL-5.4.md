> Documento histórico do pacote recebido. Para a revisão atual, consulte CORRECOES-5.4.1.md.

# Auditoria de execução real — LukeOptimizer 5.4

## Conclusão

A auditoria estática confirma que as opções de ação `native`, `v5-*`, `power` e as opções com `Operations` de Registro possuem caminhos de leitura, escrita e conferência. O motor não considera uma alteração concluída apenas pela mudança visual: ele lê o valor anterior, salva backup, escreve pela API/Registro e lê novamente o valor solicitado.

A auditoria não pode provar o comportamento em um Windows real neste ambiente Linux. A validação final deve executar `COMPILAR.cmd` e os testes em Windows 10/11.

## Ações que realmente alteram o Windows

| Tipo | Caminho de alteração | Conferência |
|---|---|---|
| Registro | `WriteValue` para `RegOp` em HKCU/HKLM, com backup e restauração | `Capture` após a gravação |
| Preferências de interface | `SystemParametersInfoW` para janela, menus, animações, cursor e mouse | `NativeSettings.Read` |
| Input V5 | `InputTuning.Write` | `InputTuning.Read` |
| Plano de energia | `powercfg` via `PowerTuning.Write` | leitura do plano ativo |
| Serviços | alteração de estado e inicialização pelas rotinas de serviço | leitura do estado e do valor Start |

Opções como Modo Jogo, captura, transparência, animações, mouse e teclado podem ter efeito visual ou de preferência, mas não são “apenas visuais”: quando selecionadas, alteram os valores do Windows e o histórico registra a mudança. Isso não significa ganho garantido de FPS ou input lag.

## Itens que não são otimizações automáticas

Entradas `page`, `link`, `settings` e `system` apenas abrem uma tela, guia, URL ou ferramenta do Windows. Elas não devem ser apresentadas como se aplicassem otimização. A biblioteca 5.4 contém várias dessas entradas, incluindo diagnósticos e tópicos avançados.

Os itens `v5-advanced-*` são páginas manuais/educacionais e não aplicam Defender, UAC, Windows Update, BCD, HPET, VBS, TPM ou Firewall automaticamente. BATs e EXEs importados permanecem como material de revisão e não são executados pelo perfil nativo.

## Pontos que exigem teste no Windows

A compilação e os testes lógicos foram executados no Mono/Linux. O cenário de lock de arquivo não reproduz a semântica esperada nesse ambiente. Em Windows, executar `codigo-fonte\\LukeOptimizer\\COMPILAR.cmd` como usuário normal e conferir no Histórico:

`Antes → Tentativa de gravação → Lido depois → Status`

Uma opção só deve aparecer como aplicada/conferida quando o valor real lido depois coincidir com o solicitado.

## Critério de aceitação

Uma opção é considerada funcional somente se possuir: implementação de ação, leitura anterior, backup, escrita real, leitura posterior e desfazer. Itens somente de navegação devem permanecer rotulados como manual, diagnóstico ou abrir configurações, nunca como aplicação automática.

**Limitação:** sem executar o binário dentro do Windows, não é possível afirmar que cada política específica é aceita pela edição, build, antivírus ou permissões do computador do usuário. O histórico do próprio app é a prova operacional para cada máquina.

Data: 13/09/2026

SHA do binário auditado: `5a5a3a7c91bb85f3584eddbe894de75b53c9ae019ddc91e59c0f4485ec3b0401`

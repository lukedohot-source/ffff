﻿$ErrorActionPreference = 'Stop'
$taskRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$taskManifest = Get-Content -LiteralPath (Join-Path $taskRoot 'MANIFESTO-SHA256.json') -Raw | ConvertFrom-Json
$taskFailures = @()
function Get-TaskFileDigest([string]$Path) {
    $taskAlgorithm = [Security.Cryptography.SHA256]::Create()
    $taskStream = [IO.File]::OpenRead($Path)
    try { return ([BitConverter]::ToString($taskAlgorithm.ComputeHash($taskStream))).Replace('-','').ToLowerInvariant() }
    finally { $taskStream.Dispose(); $taskAlgorithm.Dispose() }
}
foreach ($taskEntry in $taskManifest.PSObject.Properties) {
    $taskPath = [IO.Path]::GetFullPath((Join-Path $taskRoot $taskEntry.Name))
    if (-not $taskPath.StartsWith($taskRoot + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Caminho invalido no manifesto.' }
    if (-not (Test-Path -LiteralPath $taskPath -PathType Leaf)) { $taskFailures += "Ausente: $($taskEntry.Name)"; continue }
    if ((Get-TaskFileDigest $taskPath) -ne $taskEntry.Value) { $taskFailures += "Divergente: $($taskEntry.Name)" }
}
$taskCount = @($taskManifest.PSObject.Properties).Count
if ($taskCount -eq 0) { throw 'Manifesto vazio.' }
if ($taskFailures.Count -gt 0) { $taskFailures | Write-Output; throw 'Verificacao de integridade falhou.' }
Write-Output ("PASS: " + $taskCount + ' arquivos conferidos. Integridade nao equivale a teste de otimizacao real.')

# LukeOptimizer 6.1.2 — consolidação funcional

## Alterações realizadas

A interface de otimizações recebeu uma ação real chamada **Sessão de jogo**, que reutiliza somente os itens nativos existentes `native-gamemode`, `native-capture` e `native-power`. O plano de energia continua sujeito às verificações existentes de compatibilidade: desktop, alimentação adequada e disponibilidade do plano. Em notebooks ou máquinas incompatíveis, a etapa é ignorada com motivo registrado; ela não é forçada.

Foram restaurados na interface compacta os comandos funcionais de selecionar tudo, limpar seleção, aplicar selecionadas, desfazer, restaurar seleção e abrir detalhes. O catálogo e o diagnóstico voltaram a aparecer na navegação lateral, sem remover as páginas existentes. A seleção global usa a revisão e a classificação existentes, evitando incluir itens manuais ou não revisados.

O fluxo de execução da limpeza passou a aceitar `AgeDays = 0` também na validação final, permitindo que o botão de limpeza de temporários opere conforme a prévia atual. O filtro de temporários permanece restrito a extensões transitórias (`.tmp`, `.temp`, `.etl` e arquivos temporários iniciados por `~`), preservando arquivos `.bak`, `.log` e documentos desconhecidos. A categoria de Temp na raiz foi protegida contra caminho vazio durante inicialização fora do Windows.

## Validação

A compilação do executável Windows foi concluída com sucesso. O smoke test da interface confirmou navegação, 131 checkboxes, seleção, limpeza de seleção, aplicação, perfil Ultra, desfazer, detalhes, páginas existentes e três tamanhos de janela.

A suíte de engine compilou, mas o ambiente Linux/Mono não reproduziu integralmente um teste de bloqueio de arquivo usado pelo projeto. A suíte de interface avançou até os testes funcionais de remoção de aplicativos; o teste existente reportou falha na proteção de aplicativo durante o smoke test. Portanto, o pacote deve ser validado também em Windows 10/11 x64 antes de distribuição.

## Limitações importantes

As propostas de privacidade, Delivery Optimization, mensageiros, inicialização, Storage Sense e navegadores não foram adicionadas como ações falsas. Nenhuma função que apenas abre Configurações foi marcada como otimização aplicada. Essas áreas ainda exigem módulos reais, com backup, restauração individual e testes próprios.

A limpeza permanente não possui desfazer; o aplicativo deve continuar exibindo a prévia e os avisos antes da exclusão. O perfil Ultra mantém somente itens elegíveis pelo filtro existente e não inclui políticas protegidas ou ferramentas manuais.

**Arquivos-fonte alterados:** `source/UnifiedInterface.cs`, `source/StorageManager.cs`, `source/Maintenance.cs` e `source/Interface.cs`.

**Executável atualizado:** `native/LukeOptimizer-6.1.2.exe`.

**Data:** 18/09/2026.

**Observação:** a versão compilada não deve ser considerada totalmente certificada até a execução dos testes no Windows real com permissões administrativas e uma máquina de teste.

## Como testar no Windows

Extraia o ZIP para uma pasta local, execute `DESBLOQUEAR.cmd` se o Windows tiver marcado os arquivos como baixados da Internet e abra `ABRIR.cmd`. Confirme primeiro a análise do PC. Teste a limpeza com uma pasta temporária de laboratório e confira o Histórico. Teste a Sessão de jogo verificando Game Mode, Game DVR e o plano de energia antes e depois.

Não desative Defender, SmartScreen, UAC ou outras proteções para contornar falhas. Em caso de erro, envie o log de inicialização e o texto completo da exceção.

---

## Changelog resumido

- Adicionado botão **Sessão de jogo**.
- Restaurados comandos de aplicação, desfazer, restauração e detalhes.
- Restaurados links laterais de **Catálogo** e **Diagnóstico**.
- Corrigida aceitação da limpeza com idade zero.
- Reforçado filtro seguro de extensões temporárias.
- Corrigida inicialização da categoria Temp na raiz quando o caminho do sistema não está disponível.
- Compilação final concluída; smoke test unificado aprovado.
- Testes funcionais restantes dependem de validação adicional em Windows.

## Teste recomendado com a outra IA

Não aplicar automaticamente as propostas conceituais de privacidade, rede, mensageiros ou navegadores. Primeiro exigir código real, arquivos alterados, backup, rollback e testes. Reutilizar IDs existentes para evitar duplicações no catálogo.

---

## Teste rápido pós-build

- Executável final: `native/LukeOptimizer-6.1.2.exe`.
- Launcher: `ABRIR.cmd`.
- Configuração: `native/LukeOptimizer-6.1.2.exe.config`.
- Smoke test da interface: aprovado para navegação e ações do painel.
- Testes completos no Windows real: pendentes.
n- Fim do relatório.


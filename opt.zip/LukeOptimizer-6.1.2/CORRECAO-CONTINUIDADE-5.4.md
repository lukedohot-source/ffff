> Documento histórico do pacote recebido. Para a revisão atual, consulte CORRECOES-5.4.1.md.

# Correção 5.4 — aplicação de todas as opções marcadas

A aplicação não é mais abortada por um único registro sem permissão. O motor verifica cada registro, marca somente o bloqueado como “ignorado por falta de permissão” e continua com as demais opções selecionadas. O backup e o histórico permanecem ativos.

Também foi removida a dependência de `System.Diagnostics.Eventing.Reader`, ausente no Mono. O diagnóstico de eventos no Windows usa `wevtutil.exe`; em um Windows normal, a função continua disponível.

O motor foi compilado. A suíte compilou e executou 121 testes com sucesso. O único teste não reproduzido no Linux/Mono é o de bloqueio de arquivo para falha de salvamento atômico; esse cenário deve ser validado pelo `COMPILAR.cmd` em Windows.

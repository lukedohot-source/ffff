> Documento histórico do pacote recebido. Para a revisão atual, consulte CORRECOES-5.4.1.md.

# Changelog da expansão — 13/09/2026

A biblioteca avançada passou de 11 para 39 entradas, com 28 novas opções pesquisadas em fontes oficiais e documentação técnica. O foco foi ampliar cobertura de processos, inicialização, input lag, FPS, frame pacing, GPU, rede, energia, armazenamento e diagnóstico sem transformar ajustes específicos em promessas universais.

As novas entradas são manuais ou diagnósticas quando dependem de jogo, driver, periférico, roteador ou medição. O botão de otimização extrema não executa essas ações externas automaticamente.

Foram adicionados quatro helpers CMD somente leitura ou de abertura de configurações oficiais. A validação confirmou 138 IDs únicos nas duas bibliotecas JSON, todos os campos essenciais presentes e os quatro arquivos CMD não vazios. A compilação precisa ser executada no Windows com .NET Framework 4.x usando `codigo-fonte/LukeOptimizer/COMPILAR.cmd`.

> Documento histórico do pacote recebido. Para a revisão atual, consulte CORRECOES-5.4.1.md.

# Pesquisa de opções adicionais — LukeOptimizer

**Data:** 13/09/2026

A pesquisa cobriu cinco áreas: processos do Windows, input lag, FPS/apresentação, rede e energia/armazenamento. Foram priorizadas fontes oficiais da Microsoft, NVIDIA, AMD, Intel, Logitech, Razer, OpenWrt e ferramentas técnicas reconhecidas.

## Opções adicionadas ao catálogo

Foram adicionadas **28 entradas** à biblioteca avançada, elevando o catálogo de referência para **138 entradas combinadas**: 99 na biblioteca de performance e 39 na biblioteca avançada. As novas entradas incluem inicialização por aplicativo, tarefas agendadas específicas, atividade em segundo plano, Não Incomodar, Game Mode, otimizações de jogos em janela do Windows 11, NVIDIA Reflex e Ultra Low Latency, AMD Anti-Lag e Chill, polling de mouse/teclado condicionado, USB nativo, G-SYNC/VRR, limite de FPS por perfil, upscaling, modo de energia, TRIM, indexação granular, baseline de rede, pathping, bufferbloat, SQM no roteador e comparação de DNS.

Essas entradas são classificadas como **manual documentado** ou **diagnóstico** quando dependem de jogo, GPU, driver, periférico, roteador ou medição. Elas não são apresentadas como chaves globais mágicas nem são aplicadas automaticamente pelo botão extremo.

## Helpers CMD adicionados

Foram incluídos quatro helpers locais em `ferramentas-pesquisadas/`. `DIAGNOSTICO-REDE.cmd` mede gateway e resolução DNS; `RELATORIO-ENERGIA.cmd` gera um relatório `powercfg /energy`; `AUDITAR-INICIALIZACAO.cmd` exporta entradas de inicialização para revisão; e `ABRIR-CONTROLES-GAMING.cmd` abre as páginas oficiais de Game Mode e gráficos. Eles são somente leitura ou abrem configurações oficiais e não desativam entradas, serviços ou segurança.

## Limites importantes

Não foram adicionados scripts para desativar Defender, Firewall, Windows Update, UAC, TPM, VBS, Task Scheduler, serviços críticos, BCD, HPET, timers, USB selective suspend ou parâmetros TCP arbitrários. A pesquisa encontrou documentação para diagnóstico e ajustes condicionais, mas não sustenta essas alterações como otimizações universais.

DNS não reduz automaticamente o ping de uma partida já conectada. Polling alto pode aumentar uso de CPU e reduzir FPS. Frame generation aumenta frames exibidos, mas não substitui frames renderizados. SQM/CAKE é configuração de roteador e pode reduzir throughput. Melhor desempenho aumenta consumo e temperatura. Cada alteração deve ser medida em A/B com o mesmo jogo e cenário.

## Fontes principais

- [Microsoft — Startup applications](https://support.microsoft.com/en-us/windows/experience/startup-boot/configure-startup-applications-in-windows)
- [Microsoft — Scheduled Tasks](https://learn.microsoft.com/en-us/powershell/module/scheduledtasks/get-scheduledtask)
- [Microsoft — Background activity](https://support.microsoft.com/en-us/windows/experience/performance-optimization/manage-background-activity-for-apps-in-windows)
- [Microsoft — Game Mode](https://support.xbox.com/en-US/help/games-apps/game-setup-and-play/use-game-mode-gaming-on-pc)
- [Microsoft — Windowed game optimizations](https://support.microsoft.com/en-us/windows/hardware/display-graphics/optimizations-for-windowed-games-in-windows-11)
- [NVIDIA — Reflex](https://developer.nvidia.com/performance-rendering-tools/reflex)
- [NVIDIA — System latency guide](https://www.nvidia.com/en-us/geforce/guides/gfecnt/202010/system-latency-optimization-guide/)
- [AMD — Radeon Anti-Lag](https://www.amd.com/en/products/software/adrenalin/radeon-software-anti-lag.html)
- [AMD — Radeon Chill](https://www.amd.com/en/resources/support-articles/faqs/DH-033.html)
- [Logitech — High report rate and FPS](https://support.logi.com/hc/articles/28423889488407-Using-a-higher-report-rate-sometimes-causes-FPS-drops-while-gaming)
- [Microsoft — Test-Connection](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.management/test-connection)
- [Microsoft — Pathping](https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/pathping)
- [OpenWrt — SQM](https://openwrt.org/docs/guide-user/network/traffic-shaping/sqm)
- [Microsoft — Powercfg](https://learn.microsoft.com/en-us/windows-hardware/design/device-experiences/powercfg-command-line-options)
- [Microsoft — Optimize-Volume](https://learn.microsoft.com/en-us/powershell/module/storage/optimize-volume)

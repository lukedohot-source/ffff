> Documento histórico do pacote recebido. Para a revisão atual, consulte CORRECOES-5.4.1.md.

# Luke Optimizer 5.3 — revisão final

Compilação C#/.NET Framework x64 e frontend C++/ImGui/DX11 concluídas. Abra ABRIR.cmd após extrair o ZIP inteiro.

## Correções verificadas

- A aplicação individual de itens importados caía no perfil antigo de oito opções. Agora --apply, --apply-many e o comando legado --max usam o mesmo resolvedor e a transação com backup. --max recebe uma seleção explícita; --extreme é o perfil automático restrito.
- IDs da biblioteca como v5-option-* agora são aliases apenas quando existe uma implementação real. Prefixos desconhecidos e duplicatas após conversão são recusados. Há 38 conversões conhecidas, listadas em ALIASES.json.
- A tela principal reúne ajustes e referências, busca por ID/nome/efeito, risco, compatibilidade, aplicar, restaurar seleção e desfazer. O menu lateral foi substituído por quatro destinos simples na mesma janela.
- Fazer tudo analisa novamente, apresenta grupos e lista de ignorados, verifica conflitos e usa uma única transação. O histórico registra também os itens excluídos do plano. Não remove apps/arquivos, não fecha processos nem executa scripts remotos.
- Restaurar seleção recupera os valores salvos dos itens marcados da última aplicação. A restauração tem seu próprio backup. Valores compartilhados ou alterados posteriormente são protegidos com mensagem explícita.
- Leituras após aplicar/desfazer, evidências antes/solicitado/depois, erros de permissão, rollback, temas conflitantes e remoção seletiva continuam preservados.
- Ferramentas: rota IPv4 limitada a 20 saltos, comparação manual repouso/carga, FPS mínimo instantâneo, inventário USB/HID, clock WMI e amostra dos motores GPU.

## Preservação

| Item | Antes | Depois | Status |
|---|---:|---:|---|
| Entradas do catálogo da engine | 671 | 671 | Preservadas; inclui arquivos de apoio |
| Entradas acessíveis na biblioteca principal | 200 | 746 | 546 entradas originais adicionadas à busca principal |
| IDs nativos | 125 | 125 | Preservados; 38 aliases aceitos |
| Scripts BAT/CMD/PowerShell catalogados | 193 | 193 | Corpos/referências e hashes preservados nos JSONs |
| Opções nativas de Registro | 116 | 116 | Mesmas operações e IDs |
| Opções de rede | 7 | 7 | Preservadas; rota e repouso/carga adicionados à ferramenta |
| Opções de input lag/entrada | 10 | 10 | Preservadas/classificadas |
| Opções de FPS/stutter/medição | 13 | 13 | Preservadas; FPS mínimo acrescentado |
| Opções de energia | 8 | 8 | Preservadas |
| Opções de processos/memória | 13 | 13 | Preservadas |
| Fluxo transacional de backup | 1 | 1 | Mantido e reutilizado |
| Fluxos de restauração da tela principal | 1 | 2 | Desfazer conjunto + restaurar seleção |
| Histórico detalhado | 1 | 1 | Acrescentados aliases e motivos de itens ignorados |
| Catálogo de remoção de apps | 141 | 141 | Preservado |

Método: catálogo da engine = 532 originais + 14 BATs revisados + 125 nativos. A biblioteca tinha 200 entradas e agora também expõe os 546 originais. Arquivos de apoio e referências não são contados como otimizações automáticas. Os 193 scripts são entradas/corpos/referências preservados nos JSONs, não 193 executáveis validados. A pasta auditoria/scripts-em-texto contém cópias adicionais de leitura; os JSONs originais permanecem byte a byte.

## Testes e verificação

TOTAL: 818 checks passed (logic only; not an FPS or live Windows mutation test)

- Testes de aliases, IDs existentes/inexistentes, destinos da interface, duplicatas e conflitos.
- Perfil extremo e desfazer em cenários simulados de Windows 10/11, Home, Pro, Enterprise e Education; presença/ausência de componentes.
- Backup anterior à primeira gravação, leitura independente, gravação ignorada, rollback, falhas e restauração seletiva sem sobrescrever escolhas posteriores.
- Interface nativa renderizada em 1080×800 e 1360×920; dez ferramentas embutidas verificadas em dois tamanhos, incluindo confirmação/cancelamento na própria janela.
- Leitura real de 125 opções neste Windows, sem aplicar ajustes. O JSON em verificacao mostra versão, estados e aplicativos encontrados; MMAgent requer administrador neste ambiente.
- JSONs de origem validados e hashes comparados. Manifesto de todos os arquivos do pacote e CRC do ZIP conferidos após a montagem.

## Limitações reais

Os testes de alteração usam Registro, APIs, energia e serviços simulados. Não executamos o perfil no PC do usuário nem medimos ganho de FPS. Windows/anticheat/edição/aplicativo podem ignorar uma preferência mesmo quando o valor foi gravado; o log distingue gravação confirmada de efeito percebido.

Temperatura, frequência real da GPU, throttling e input lag físico não são medidos universalmente. Consulte telemetria do fabricante ou PresentMon. O app não instala drivers de sensores nem injeta DLLs. WMI não substitui sensores do hardware e a amostra dos motores GPU não é somada como uso global.

O teste de filas/bufferbloat usa carga criada pelo próprio usuário e duas amostras ICMP; não isola a causa nem gera nota universal. A rota ICMP pode diferir do jogo. DNS e velocidade negociada não são promessa de menor ping.

Nem todos os arquivos externos existem no pacote executável. Os catálogos, conteúdos incorporados, mapas e referências recebidos estão preservados; anexos criptografados, downloads remotos e EXEs de terceiros não foram executados nem certificados. Opções incompatíveis/manuais/experimentais continuam visíveis. Remover apps não tem desfazer automático.

Os backups guardam os valores anteriores, não uma imagem completa do Windows. Serviços do perfil alteram a inicialização; o efeito requer reiniciar. Política de trabalho/escola ou proteção do Windows pode impedir uma alteração, e isso deve aparecer como falha/ignorado.

## Referências consultadas

A seleção de reduzir atividade de inicialização/segundo plano segue a orientação de desempenho da [Microsoft](https://support.microsoft.com/en-us/windows/experience/performance-optimization/tips-to-improve-pc-performance-in-windows). As políticas dos navegadores têm efeitos documentados em [Edge StartupBoostEnabled](https://learn.microsoft.com/en-us/deployedge/microsoft-edge-policies/startupboostenabled) e [Chrome BackgroundModeEnabled](https://chromeenterprise.google/policies/background-mode-enabled/).

As ferramentas usam a API de [Ping do .NET](https://learn.microsoft.com/en-us/dotnet/api/system.net.networkinformation.ping.sendpingasync) e importam intervalos de captura do [PresentMon](https://github.com/GameTechDev/PresentMon). Desativar pré-carregamento pode atrasar a primeira abertura do navegador; isso é um efeito esperado, não prova de FPS maior.

Lista exata de arquivos alterados: CHANGELOG.md e auditoria/ARQUIVOS-ALTERADOS.json. Inventário: INVENTARIO.html e auditoria/INVENTARIO.json. Fontes e builds: codigo-fonte.

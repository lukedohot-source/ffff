> Documento histórico do pacote recebido. Para a revisão atual, consulte CORRECOES-5.4.1.md.

# Changelog 5.3

- **codigo-fonte/LukeOptimizer/compilacao.rsp** — Build/testes/geração ajustados para a revisão; fonte completa incluída.
- **codigo-fonte/LukeOptimizer/COMPILAR.cmd** — Build/testes/geração ajustados para a revisão; fonte completa incluída.
- **codigo-fonte/native/dashboard_ui.h** — Tela única pesquisável, categorias e revisão de todo o plano extremo.
- **codigo-fonte/native/library.generated.h** — Gerada novamente a partir da engine, incluindo todos os originais.
- **codigo-fonte/native/main.cpp** — Tema e testes de renderização/navegação atualizados.
- **codigo-fonte/native/runtime.h** — Leitura de metadados, plano extremo e restauração da seleção no protocolo.
- **codigo-fonte/native/ui.h** — Tela principal sem sidebar; detalhes de risco e ações claras.
- **codigo-fonte/LukeOptimizer/source/CatalogIds.cs** — Resolução geral de aliases conhecidos, validação de IDs e destinos.
- **codigo-fonte/LukeOptimizer/source/ChangeAudit.cs** — Registra conversões de IDs e preserva evidências de aplicação/restauração.
- **codigo-fonte/LukeOptimizer/source/EasyInterface.cs** — Tabelas com cabeçalhos escuros e caixas preservadas.
- **codigo-fonte/LukeOptimizer/source/ExtremeProfile.cs** — Plano de otimização automática com grupos, lista permitida e registro de todos os ignorados.
- **codigo-fonte/LukeOptimizer/source/FrameAnalysis.cs** — FPS mínimo instantâneo com definição explícita.
- **codigo-fonte/LukeOptimizer/source/HardwareLab.cs** — Inventário USB/HID, clock WMI e motores GPU sem inferir temperatura/throttling.
- **codigo-fonte/LukeOptimizer/source/ImportedScripts.cs** — Valida IDs e catálogo sem limite de quantidade fixado em 14.
- **codigo-fonte/LukeOptimizer/source/Interface.cs** — Remove cabeçalho repetido do conteúdo embutido, ajusta tabelas e busca por ID.
- **codigo-fonte/LukeOptimizer/source/LiquidProtocol.cs** — Novos verbos e metadados; mantém atualização de estados após aplicar/restaurar/falhar.
- **codigo-fonte/LukeOptimizer/source/LukeOptimizer.cs** — Comando individual corrigido; --max compatível, --extreme dedicado, versão 5.3.
- **codigo-fonte/LukeOptimizer/source/NetworkWorkbench.cs** — Rota ICMP IPv4 e comparação de latência repouso/carga com condições verificadas.
- **codigo-fonte/LukeOptimizer/source/OptionInfo.cs** — Classificação, risco, reinicialização, administrador e motivos de seleção automática.
- **codigo-fonte/LukeOptimizer/source/PerformanceInterface.cs** — Ferramentas mais compactas; comparação A/B explicada; catálogo original acessível.
- **codigo-fonte/LukeOptimizer/source/PerformanceLibrary.cs** — Todos os originais ficam acessíveis na biblioteca, com IDs próprios de interface e destino original.
- **codigo-fonte/LukeOptimizer/source/Profile.cs** — Comandos nativos usam o mesmo fluxo transacional; suporta restauração seletiva e aliases.
- **codigo-fonte/LukeOptimizer/source/SelectionRestore.cs** — Restauração dos itens marcados a partir do backup, com proteção contra alterações posteriores.
- **codigo-fonte/LukeOptimizer/source/V5Bridge.cs** — Compatibilidade de aliases também na navegação da interface.
- **codigo-fonte/LukeOptimizer/tests/EngineTests.cs** — Build/testes/geração ajustados para a revisão; fonte completa incluída.
- **codigo-fonte/LukeOptimizer/tests/ExportCatalog.cs** — Build/testes/geração ajustados para a revisão; fonte completa incluída.
- **codigo-fonte/LukeOptimizer/tests/UiSmoke.cs** — Build/testes/geração ajustados para a revisão; fonte completa incluída.
- **codigo-fonte/LukeOptimizer/tests/V4Tests.cs** — Build/testes/geração ajustados para a revisão; fonte completa incluída.
- **codigo-fonte/LukeOptimizer/tests/V53Tests.cs** — Build/testes/geração ajustados para a revisão; fonte completa incluída.
- **codigo-fonte/LukeOptimizer/tests/V5Tests.cs** — Build/testes/geração ajustados para a revisão; fonte completa incluída.
- **codigo-fonte/LukeOptimizer/tests/verify-package.mjs** — Build/testes/geração ajustados para a revisão; fonte completa incluída.

Nenhum ID nativo, definição de Registro, catálogo original ou corpo de BAT dos JSONs anteriores foi removido. Os 38 aliases não renomeiam os IDs canônicos; acrescentam caminhos de compatibilidade e são registrados no histórico quando usados.
A classificação automática usa 20 ajustes, sujeitos à compatibilidade; Alto desempenho é uma 21ª opção adicional marcada somente pelo usuário. O controle global antigo de apps em segundo plano permanece experimental e fora do perfil, pois a leitura da chave não comprova a adoção por todos os apps/versões do Windows.
Scripts/arquivos antigos permanecem com a classificação e as restrições existentes. Os novos cartões de originais abrem a revisão do catálogo; não transformam programas externos em ações automáticas.
As contagens por área usam as categorias da biblioteca anterior e não somam arquivos de apoio como se fossem novos ajustes de FPS.

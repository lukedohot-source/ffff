﻿# Luke Optimizer 5.4.1 — correções e validação

Revisão de `LukeOptimizer-5.4-corrigido (9).zip`. SHA256 do ZIP recebido: `cc01a252e72a0c6a4e50a0874847ee0567da396221101e7f5c43f1f479165960`.

## Corrigido

- Permissão negada sem nenhuma gravação agora produz “sem alterações” e preserva o alvo correto de Desfazer. Registros antigos vazios também são ignorados pelo desfazer.
- O log mantém o valor originalmente solicitado; um valor bloqueado aparece como ignorado, sem falso “já estava assim”.
- Aplicações individuais, seleções e protocolo Liquid seguem a mesma regra por valor: ignorar somente o bloqueado; falha durante a gravação restaura o ajuste que falhou e preserva seus irmãos bem-sucedidos.
- A interface principal inclui Remover apps (141 definições), Ajustes manuais, Restaurar ajustes marcados, Conferir agora e Salvar log TXT.
- A remoção pede confirmação da seleção, bloqueia componentes protegidos, relê o estado e permite parar antes do próximo app. Os dois campos manuais exigem seleção explícita.
- Selecionar Alto desempenho no perfil extremo pede elevação quando necessária.
- O diagnóstico de estabilidade consulta os eventos mais recentes primeiro, informa ausência de eventos corretamente e lê os dois fluxos do processo sem bloquear antes do timeout.
- A compilação oficial valida lógica e interface e publica o mesmo motor Windows Forms nos caminhos usados por ABRIR.cmd. Não substitui a interface atual por uma versão C++ antiga.
- Scripts de verificação e manifestos SHA256 foram refeitos para os arquivos entregues.

## Verificado

- Compilação C#/.NET Framework x64 sem erros e **921 verificações de lógica aprovadas**: consulte `verificacao/atual/tests.log`.
- Interface com loop de mensagens real, cliques, confirmações, cancelamentos, seleção e exportação: `verificacao/atual/ui.log`; imagens em `verificacao/atual/interface` são dados de teste.
- A consulta real no Windows build 26200 retornou os 127 ajustes nativos e as 141 definições de apps. 138 consultas Appx foram confirmadas; três consultas WinGet ficaram indisponíveis neste ambiente. Um ajuste teve falha de leitura e o diagnóstico de solicitações de energia teve acesso parcial. As limitações foram registradas, não convertidas em sucesso: `verificacao/atual/release-readonly.log`.
- O executável final versão 5.4.1.0 foi inspecionado em modo somente leitura, com dados redirecionados para uma pasta de teste. As 20 páginas, incluindo as funções reintegradas, foram confirmadas sem criar registros de alteração: `verificacao/atual/executavel-final.log`.

## Limites

O teste de aplicação, restauração e desinstalação é isolado: nenhuma otimização/desinstalação real foi executada, nenhum serviço foi desligado e não houve benchmark de FPS ou input lag. O resultado depende da versão do Windows, das permissões e do hardware.

Há 408 entradas históricas com arquivos externos não fornecidos no ZIP original. O código-fonte, textos e revisões disponíveis foram preservados. O pacote não recupera binários, instaladores ou planos externos ausentes. A lista exata está em `verificacao/atual/arquivos-externos-nao-fornecidos.json`.

Os relatórios e inventários anteriores do pacote são históricos; os logs em `verificacao/atual` descrevem esta revisão.

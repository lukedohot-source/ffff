# Auditoria dos arquivos recebidos

Inspeção estática; nenhum script, registro ou executável recebido foi executado. Hashes preservam identificação, não certificam segurança. Inventário binário não equivale à validação de comportamento.

O RAR Windows e o ZIP 1Trilhão compartilham todos os23scripts, byte a byte. Foram inventariados76e77arquivos, respectivamente, com74hashes comuns. Não são dois conjuntos diferentes de otimizações.

As rotinas úteis foram associadas a funções nativas ou a opções do Windows. As classificações distinguem adaptação proposta, equivalente existente e exclusão. Elas não afirmam ganho de FPS medido no computador do usuário.

## Mapa dos scripts

| Arquivo | Decisão | O que faz e substituição |
|---|---|---|
| 5 Desativar UAC.reg | Excluído | Desativa UAC (EnableLUA=0). Reduz uma proteção do Windows sem demonstrar ganho de FPS. Manter UAC e elevar somente operações selecionadas. |
| 6 Desative as atualizações automáticas do Windows.cmd | Excluído | Interrompe Windows Update/UsoSvc, mata Configurações e impõe políticas de bloqueio; rd s q está sem barras e não corresponde ao comando recursivo pretendido. Horário ativo, pausa temporária e limites de downloads no painel do Windows. |
| BCD Tweaks.cmd | Excluído | Força disabledynamictick=yes e useplatformtick=yes na inicialização. São opções de depuração segundo Microsoft, sem benefício universal de jogos. Medir frametime e investigar o causador do stutter. |
| Registro Tweaks.reg | Adaptado parcialmente | Mistura gravação Game DVR, menu, MMCSS, energia e desligamento; inclui medidas sem efeito documentado e perda de recursos. Captura, menu e perfil por jogo com snapshot; conservar manutenção, hibernação, timers e prioridades globais. |
| Otimize TODAS as configurações do Windows.reg | Adaptado parcialmente | Mistura 46 valores de sincronização, Game Mode/captura, transparência, HAGS, VRR, acessibilidade, privacidade e apps em segundo plano. Separar preferências visuais, captura e Game Mode; abrir painéis para gráficos, permissões e atividade por app. |
| M2 Correção do mouse MarkC Windows 10.reg | Adaptado parcialmente | Sobrescreve curvas do mouse e sensibilidade; altera aceleração do perfil DEFAULT, não apenas o usuário atual. Não reduz polling físico. Controle nativo de aceleração, preservando sensibilidade e curvas; Raw Input no jogo. |
| 1 Excluir arquivos temporários.cmd | Adaptado parcialmente | Remove árvores inteiras de Temp e toma posse das pastas, incluindo arquivos recentes/em uso; %temp% aparece sem aspas. Limpeza nativa revisada: candidatos temporários antigos, caminho fixo, sem links ou troca de permissões. |
| 2 Excluir arquivos de log.cmd | Excluído | Vai à raiz da unidade e apaga recursivamente todo *.log, inclusive registros de diagnóstico/aplicativos. Armazenamento do Windows; não apagar logs indiscriminadamente. |
| 3 Excluir Cache do Windows Update.cmd | Excluído | Para Windows Update/UsoSvc e apaga SoftwareDistribution; não reinicia os serviços ao final. Usar solução de problemas do Windows Update quando houver falha, não como boost recorrente. |
| Desativar serviços de diagnóstico e telemetria.reg | Adaptado parcialmente | Desabilita sete serviços de telemetria/diagnóstico; serviços sob demanda podem já estar parados e a contagem de serviços não mede FPS. DiagTrack opcional existente com snapshot; conservar diagnóstico de rede e sistema. |
| Desativar serviços extras desnecessários.reg | Adaptado parcialmente | Desabilita biometria, cache de fontes, coleta gráfica, scanners, relatórios, compatibilidade e coletor de eventos. WerSvc opcional existente; conservar FontCache/compatibilidade/biometria e diagnóstico. |
| OPCIONAL Desativar o Gerenciador de mapas.reg | Opcional com perda de recurso | Desabilita MapsBroker: perde download/atualização de mapas offline. Ganho depende de o serviço estar consumindo recursos. Controle de MapsBroker com estado original e desfazer. |
| OPCIONAL Desativar serviços Bluetooth.reg | Guia/painel | Desabilita áudio e suporte Bluetooth; pode desconectar mouse, teclado, controle e headset. Painel Bluetooth por dispositivo; sem desativação global. |
| OPCIONAL Desativar serviços de impressora.reg | Adaptado parcialmente | Desabilita Spooler e PrintNotify; impressão e recursos de impressoras deixam de funcionar. Spooler opcional existente para quem não imprime; não incluir em máximo automático. |
| OPCIONAL Desative os serviços do Xbox.reg | Guia/painel | Desabilita saves, rede, autenticação e acessórios Xbox, afetando jogos/Game Pass e controles. Controlar captura e inicialização por app; manter serviços usados pelo jogo. |
| Ativar Download do Gerenciador de Mapas.reg | Excluído | Reverte MapsBroker para um valor fixo, sem saber a configuração anterior. Desfazer pelo snapshot real, com verificação de conflito. |
| Ativar o Windows Defender.reg | Guia/painel | Tenta reativar cinco serviços e remover políticas de Defender/notificações; não prova que toda a segurança foi recuperada. Segurança do Windows para diagnóstico; o app não altera Defender. |
| Ativar serviços Bluetooth.reg | Excluído | Define início automático dos dois serviços Bluetooth, em vez de restaurar configuração real. Desfazer pelo snapshot ou painel Bluetooth. |
| Ativar serviços da impressora.reg | Excluído | Define padrões fixos de Spooler/PrintNotify sem snapshot. Desfazer pelo snapshot real. |
| Ativar serviços de diagnóstico e telemetria.reg | Excluído | Define padrões fixos de sete serviços de diagnóstico/telemetria sem snapshot. Desfazer pelo snapshot real. |
| Ativar serviços do Xbox.reg | Excluído | Define padrões fixos de quatro serviços Xbox sem snapshot. Painel de jogos; desfazer alterações do app por snapshot. |
| Ativar serviços extras desnecessários.reg | Excluído | Define padrões fixos de nove serviços; inclui hidserv, que nem aparecia no arquivo de desativação correspondente. Desfazer somente as alterações registradas pelo app. |
| Desativar Anti Malware Service Executable.reg | Excluído | Desabilita serviços do Defender, proteção em tempo real, inspeção de rede e notificações de segurança. Manter as proteções; investigar CPU/disco por processo em vez de desligar antivírus. |
| ATV_MODO_TURBO(1).BAT | Alto risco | O original cria regras BLOCK CHROME/BLOCK EDGE, força o fechamento de navegadores e executa um loop permanente. Essas ações não foram copiadas para o perfil. O processo com maior CPU acumulada e janela não é necessariamente o jogo em primeiro plano. WMI setpriority 256 pede Realtime; isso pode prejudicar a resposta do sistema. A pasta C:\TurboJogos criada no início não participa da seleção de processos. WMIC é uma dependência legada que pode estar ausente. A nova função de foco identifica PID, início e caminho; funciona apenas com apps/jogos da lista, é opcional e não altera afinidade. Modo fácil + foco opcional AboveNormal; energia existente, com backup. |
| DSTV_MODO_TURBO(1).BAT | Substituído | O original seleciona Equilibrado e escreve valores fixos sem saber o estado anterior. Matar wmic.exe não encerra o cmd.exe que mantém o loop do turbo. O loop pode continuar alterando prioridades. Não restaura todos os parâmetros de CPU/TCP, nem a prioridade já alterada. O v3 desfaz apenas alterações feitas e salvas por ele; não promete desfazer BATs executados fora do app. Desfazer pelo histórico restaura o valor real salvo, não um padrão inventado. |
| LIMPA_RAM(1).BAT | Erro no original | [GC]::Collect() atua no processo .NET que o chamou; não limpa a memória de todos os apps. Alocar/liberar 1 byte dentro do PowerShell não limpa a standby list. A linha de ProcessIdleTasks é apenas echo, não executa a função. Limpar DNS não é limpar RAM. EmptyWorkingSet em todos os processos retira páginas residentes que podem precisar ser carregadas novamente. Não foi integrado como limpador periódico. O original também encerra componentes do Windows, limpa a área de transferência e apaga Prefetch. O v3 não faz isso. Apps e RAM: fechamento selecionado + RAM disponível e CPU antes/depois. |
| MODO_ARQUITETO(1).BAT | Alto risco | O GUID de Alto desempenho termina em 635e no original; o identificador padrão termina em 635c. Com erros ocultos, pode anunciar ativação sem aplicar. Apaga backups/autosalvamentos de projetos (*.bak, *.sv$, *.ac$) e arquivos Autodesk sem backup. Isso foi excluído da limpeza. Força paginação 16–32 GB, encerra Explorer/OneDrive e pede Realtime para renderizadores. Nenhuma dessas ações integra o preset revisado. Limitação de integração: o v3 não ajusta configurações internas do AutoCAD/Revit/Lumion nem arquivos de projeto. Preset Trabalho/CAD + foco AboveNormal + seleção explícita de apps para fechar. |
| MOLOTOVY_OTI(1).BAT | Erro no original | GUID de energia termina em 635e (não é o Alto desempenho padrão). Muitos comandos ocultam erros e ainda imprimem OK. Remove inicialização sem guardar valores e desativa uma tarefa do Windows Update. A nova inicialização é selecionada por app, com backup; Update fica preservado. DISM /ResetBase remove a possibilidade de desinstalar atualizações incorporadas. Não será executado pelo botão máximo. SFC em um único arquivo e limpeza DNS não comprovam aceleração do PC. Limpeza revisada, inicialização com backup e ajustes visuais existentes. |
| NET_CPU_100%_FOCADA(1).BAT | Não comprovado | Força mínimo de CPU em 100%, muda configurações globais de energia/rede e reinicia a pilha de rede. Isso não prova menor latência e pode interromper conexões. Contém opções legadas/incompatíveis conforme a versão do Windows (processor-throttle-ac/dc, chimney, dca, netdma). Erros não são verificados por etapa. NetworkThrottlingIndex=10 conflita com 70 no NET200%; ECN também diverge. Executar ambos não soma benefícios. A alegação de recuperar uma reserva fixa de internet não demonstra aumento na conexão contratada. O v3 não promete NET 100%/200%. Diagnóstico/Configurações de rede e escolha de plano sem alterar TCP global. |
| NET200%_OTIMIZADA(1).BAT | Não comprovado | Configura DNS usando nomes fixos Wi-Fi/Ethernet, que podem não existir; troca DNS afeta privacidade e resolução de nomes, não duplica a banda. ipconfig /release e resets derrubam conexões; parâmetros antigos e incompatíveis podem falhar sem impedir a mensagem de sucesso. Valores NetworkThrottlingIndex=70 e ECN enabled conflitam com os outros BATs. Não há benchmark que sustente o nome 200%. O app não altera DNS, Winsock, firewall, offloads ou políticas de atualização no modo máximo. Rede: leitura de adaptadores e acesso às configurações oficiais, sem troca automática de DNS. |
| OTIMIZADOR_ARMAZENAMENTO(1).BAT | Alto risco | A detecção usa Get-PhysicalDisk -DeviceNumber, que não é o mapeamento documentado de volumes para discos; não confiar no tipo anunciado sem conferir. Desativa ScheduledDefrag se houver qualquer SSD, afetando também a manutenção de outros discos. O agendamento do Windows deve ser preservado. As alterações fsutil/Registro são globais, não por unidade. O texto promete cache individual, mas modifica parâmetros globais de NTFS/memória. Ao final desativa SysMain mesmo na configuração só com HD. O v3 não copia cache gigante, MFT, Prefetch, SysMain ou alterações de driver. Otimizar Unidades é aberto como ferramenta manual; TRIM/defrag não são anunciados como executados pelo app. Limpeza de temporários revisados + ferramenta Otimizar Unidades do Windows. |
| PLANO_DE_ENERGIA_40_88(1).BAT | Fora do perfil | Os valores mínimo/máximo são estados de desempenho do processador, não limites de utilização da CPU em 40% e 88%. Limitar estado máximo a 88% pode reduzir frequência/boost e desempenho, dependendo do hardware e driver. Não é um plano para extrair o máximo. Duplica planos a cada execução e não guarda o plano anterior. O v3 preserva o esquema ativo e não cria duplicatas repetidas. Energia opcional: plano existente; 40–88 fica documentado como economia, não desempenho máximo. |
| BONUS_1K(1).BAT | Alto risco | O original apaga dados sem confirmação por arquivo: lixeira, histórico, cookies, cache de navegador, Prefetch, logs, temporários recentes e downloads de atualização. A limpeza de cache é repetida nos demais BATs; executar tudo aumenta trabalho de recarga, não soma FPS. No v3, exclusão de temporários é opcional, separada do botão máximo e explicitamente sem desfazer. Arquivos em uso/alterados, links e pastas de projeto são preservados. A medição informa o resultado real das remoções, não imprime LIMPO após qualquer erro. Limpeza com análise prévia de .tmp/.temp do usuário, antigos há mais de 7 dias. |
| CAÇA_MINE(1).BAT | Alto risco | Nome, localização e argumentos são indícios, não prova de malware. A afirmação 100% minerador é injustificada; mineradores também podem ser instalados deliberadamente. O filtro por comando pode incluir o próprio PowerShell que contém os padrões no texto da consulta. Excluir tarefas por nomes aproximados e sobrescrever HOSTS pode remover configurações legítimas. Isso não entra na otimização. O v3 não se apresenta como antivírus e não remove processos/arquivos suspeitos automaticamente; a análise de ameaças cabe ao software de segurança. Lista de consumo de processos + acesso à Segurança do Windows para análise de ameaças. |
| CORREÇÃO_WINDOWNS10_11(1).BAT | Condicional | SFC e DISM são ferramentas reais de reparo, mas não comprovam aumento de desempenho em um sistema íntegro. O original mistura reset de Update/Store/rede, CHKDSK /f /r /x e reinício forçado em 10 segundos. Essas operações podem levar muito tempo e interromper o trabalho. O v3 não reinicia, desmonta discos, reseta conexões ou re-registra todos os apps no modo máximo. A opção do app abre um guia oficial de reparo; não afirma que executou SFC/DISM ou corrigiu o Windows. Acesso ao guia de reparo do Windows; reparo não é rotina de ganho de FPS. |
| DEBLOAT(1).BAT | Alto risco | Remove pacotes/provisionamento, desinstala OneDrive e desativa funções globais sem capturar o estado original. O botão desfazer não garante reinstalar pacotes removidos ou recuperar preferências. Há pausas e caminhos call/goto encadeados; erros são ocultados. A mensagem Windows original de fábrica não é uma validação. Desativa SysMain, Search, ReadyBoot, hibernação e remove Prefetch indiscriminadamente. O v3 não desinstala apps em massa. WSearch, Spooler e DiagTrack ficam em controles separados, desmarcados, com descrição da função perdida. Defender, Windows Update, áudio, rede e drivers não estão nessa lista. Inicialização selecionada, serviços opcionais com desfazer e acesso a Apps instalados. |
| DSTV_RELATORIO_WINDOWNS(1).BAT | Condicional | Checkpoint-Computer tem saída ocultada: o script não comprova a criação de um ponto de restauração. AllowTelemetry=0 e políticas Copilot/Recall variam com edição/build; gravar um valor não comprova desativação total da coleta. Desliga relatórios/diagnósticos e toma posse/permissões das pastas WER para apagar registros. Isso prejudica investigação de erros e não tem ganho de FPS demonstrado. O v3 não altera permissões, apaga WER, desativa tarefas em massa ou remove mecanismos de segurança. Privacidade no Windows + DiagTrack opcional, com estado e inicialização restauráveis. |
| GPU_Priority.reg | Excluído | MCSS GPU Priority e SFIO Priority não usados; Priority6 em High é tratado como2. Sem registro placebo; usar perfil de jogo e comparação. |
| Diminuir_MsTeclado_1.reg | Adaptado parcialmente | Flags59 liga FilterKeys. Repetição de texto não é taxa de polling nem latência física do teclado. Três controles nativos independentes: repetição, FilterKeys, atalho StickyKeys. |

## Análise por comando/valor

O arquivo `inputs-map.json` contém cada valor REG e cada linha executável/decontrole dos BAT/CMD legíveis, seus caminhos, hash, efeito, decisão e alternativa. Os14BATs anteriores preservam as revisões existentes.

## Personalização recebida

`customizaçao.zip` contém133arquivos de GTA/FiveM. Seus9arquivos aninhados foram listados, incluindo props otimizada.rar (531entradas); não há BAT/CMD/REG/PS1 nesses9arquivos. Os vídeos e o conteúdo interno RPF foram inventariados, não reproduzidos ou interpretados.

- **agua transparente**: Reduz reflexos e ajusta parâmetros de água no timecycle; substitui water.xml/watertune.xml.
- **arvore custom**: Somente referência visual e link externo para modelo de árvore; payload externo não auditado.
- **boneco brilhante.txt**: Altera SSAO/iluminação de personagens; preferência de visibilidade, não otimização global.
- **ceu**: Substitui timecycle_mods_1..4.xml para aparência do céu.
- **custom render**: Trecho de timecycle com névoa e distância de renderização; modifica cena do jogo.
- **deixar citizen leve.txt**: Instrui apagar streaming_surrogate.prf do FiveM; efeito interno não validado.
- **explosao**: Substitui metadados de explosão; pode alterar lógica/efeitos, não configuração Windows.
- **explosao nao dar dano**: Nome e instrução propõem retirar dano de explosão; arquivo explosion.ymt; não é desempenho.
- **kill effect padrao.rar**: Mesmo conteúdo timecycle do removedor de céu; alteração visual de jogo.
- **low render**: Propõe far_clip500/1000 em EXTRASUNNY; perda de distância visível.
- **luz do poste**: Substitui visualsettings.dat/tcinstbox_types.meta, afetando iluminação da cena.
- **massinha**: Texturas e timecycle para aspecto simplificado; incompatibilidades não verificadas.
- **massinha 2**: Substitui configurações de renderização/oclusão/instâncias; texto condiciona à tesselação alta.
- **moita baixa**: Imagem de referência e link externo; modelo externo não presente.
- **Motion Blur.rar**: Quatro variantes Low/Medium/No/Strong de timecycle_mods_2.xml.
- **nao renderizar props de longe**: Substitui fragment.xml para reduzir objetos à distância; reduz visibilidade.
- **no props**: Texto aponta remoção de elementos da cidade e payload externo não presente.
- **no props (high)**: 36 arquivos RPF de mapas/props com versões high/medium; vários placeholders de512bytes.
- **no time**: Substitui time.xml para hora fixa; texto relata falhas em algumas instalações.
- **nofog**: Zera parâmetros de névoa do timecycle, alterando visibilidade.
- **nofog sem alterar citizen.txt**: Zera densidade volumétrica de névoa e time_offset em EXTRASUNNY.
- **noite clara.txt**: Muda cores/intensidade de iluminação noturna; preferência visual.
- **noite limpa**: Substitui w_extrasunny.xml; alteração do clima/timecycle.
- **props otimizada.rar**: Pacote aninhado de substituições de arquivos/objetos GTA/FiveM, 531 entradas; não ajustes Windows.
- **reflexo sol**: Zera raios de luz/lensflare do timecycle; pode ser reproduzido por ajustes gráficos suportados.
- **render arvore**: 11 shaders substituídos por arquivos de0/2bytes; destrói dados de shaders em vez de configurar qualidade.
- **sangue**: 11 arquivos de efeitos/decals; o texto relata crash com combinação parcial.
- **sem massinha**: Substitui configurações de jogo; instruções alertam cenário preto com tesselação alta.
- **tirar folhas arvore**: 35 shaders de árvores, veículos e água vazios/quase vazios; não apenas folhas.
- **tirar grama**: Substitui grasslodsettings/grassshadowlodsettings.xml; qualidade/distância de vegetação.
- **tirar neve e chuva**: Variantes weather.xml que alteram clima/precipitação.
- **tirar nuvem**: Substitui clouds.xml/cloudkeyframes.xml; aparência do céu.
- **tirar particulas.txt**: Define no_weather_fx=3 no timecycle; remove efeitos climáticos.
- **tirar reflexo**: Texto sugere reflection_mipblur off em configuração de GTA; não há BAT ou configuração Windows.

O pacote modifica modelos, shaders, clima, visibilidade e até metadados de dano. Alguns shaders estão vazios e os textos relatam crashes/cenário preto. Esse conteúdo não é um tema do Windows. Controles nativos de qualidade gráfica são a alternativa apropriada para reduzir carga sem substituir arquivos internos arbitrariamente.

## Wcree

Métodos IL chamam DownloadFile e Process.Start para payloads Discord em C:\Windows\apppatch\Custom\Custom64; sem validação de hash/assinatura no fluxo observado. Os scripts não estão embutidos.

Foram identificados 40endereços remotos. A auditoria não atribui efeito aos payloads ausentes nem baixa/executa os scripts. Cada endereço/nome está registrado no JSON.

## Team Ram Cleaner

O RAR contém um EXE x86 de7.262.477bytes. O EXE é SFX com ZIP interno no offset499932, e seus118payloads usam criptografia ZipCrypto. O diretório lista `AutoPlay/Docs/Clean RAM.bat` (13.751bytes) e `Compact RAM Cleaner.exe` (93.184bytes), além de autorun, Lua e imagens. Sem senha, seus comandos não puderam ser lidos. Não foi executado.

O nome de um limpador de RAM não demonstra redução de stutter. O aplicativo utiliza medição de CPU/RAM e fechamento selecionado, sem esvaziar working sets periodicamente.

## GPU e teclado

GPU_Priority.reg configura campos MMCSS. Microsoft documenta GPU Priority e SFIO Priority como não usados, e Priority na categoria High é tratado como2. Diminuir_MsTeclado_1.reg grava Flags59 em Keyboard Response, que inclui FILTERKEYSON; isso não modifica polling do hardware. Repetição e acessibilidade são preferências separadas.

## Fontes técnicas

- [bcd](https://learn.microsoft.com/en-us/windows-hardware/drivers/devtest/bcdedit--set)
- [mmcss](https://learn.microsoft.com/en-us/windows/win32/procthread/multimedia-class-scheduler-service)
- [perf](https://support.microsoft.com/en-gb/windows/tips-to-improve-pc-performance-in-windows-b3b3ef5b-5953-fb6a-2528-4bbed82fba96)
- [startup](https://support.microsoft.com/en-us/windows/experience/startup-boot/configure-startup-applications-in-windows)
- [mouse](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-systemparametersinfow)
- [filterkeys](https://learn.microsoft.com/en-us/windows/win32/api/winuser/ns-winuser-filterkeys)
- [memory](https://learn.microsoft.com/en-us/windows/win32/memory/working-set)
- [fullscreen](https://devblogs.microsoft.com/directx/demystifying-full-screen-optimizations/)
- [hags](https://devblogs.microsoft.com/directx/hardware-accelerated-gpu-scheduling/)

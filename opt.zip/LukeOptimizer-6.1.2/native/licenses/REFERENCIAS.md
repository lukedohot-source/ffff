# Projetos de referência auditados

Quatro projetos foram auditados como **especificação de comportamento** para descobrir
quais valores do Windows correspondem a quais funções. O que este pacote aproveitou deles
é fato técnico — qual chave do Registro o Windows lê para um determinado comportamento —
e não expressão criativa. Cada configuração implementada aponta para a documentação da
Microsoft, não para o projeto onde a pista foi encontrada.

Auditoria completa e situação item a item: `REFERENCE_PARITY_REPORT.md`.

Este pacote se distribui sob **GPLv3** (ver `INTEGRACAO.txt`). É essa a licença contra a
qual a compatibilidade de cada projeto abaixo foi avaliada.

---

## Sophia Script for Windows — MIT
Copyright (c) 2023 farag2 · https://github.com/farag2/Sophia-Script-for-Windows

Licença MIT, compatível com GPLv3. Lido: `src/Sophia_Script_for_Windows_11/Module/Sophia.psm1`.
Nenhum trecho de código foi copiado; as implementações deste pacote são próprias.

## Win11Debloat — MIT
Copyright (c) 2020 Raphire · https://github.com/Raphire/Win11Debloat

Licença MIT, compatível com GPLv3. Texto completo em `Win11Debloat-MIT.txt`.
O catálogo de aplicativos já havia sido integrado numa fase anterior (ver `INTEGRACAO.txt`).
Nesta fase foram lidos os 93 arquivos de `Regfiles/` como especificação.

## optimizerNXT — GPL-3.0
https://github.com/… (projeto entregue como referência)

Mesma licença deste pacote, portanto compatível. Foram lidos os 28 arquivos de `yaml/`.
Ainda assim as implementações são próprias, para não ampliar a superfície copyleft do
produto — e porque várias funções daquele projeto (desligar Microsoft Defender, desligar
SmartScreen, desligar Restauração do Sistema) foram **deliberadamente não integradas**.

## Winhance — PolyForm Shield License 1.0.0 — CÓDIGO NÃO UTILIZÁVEL
Copyright (c) 2025 Marco du Plessis

**Nenhum código, recurso gráfico ou texto do Winhance foi usado neste pacote, e nenhum
pode ser.** A PolyForm Shield é licença *fonte-disponível*, não open source: ela proíbe
usar o software para competir com o licenciante. Um otimizador de Windows concorre
diretamente com o Winhance. Além disso, uma licença com restrição de uso é **incompatível
com a GPLv3**, sob a qual este pacote é distribuído — a GPL não admite restrições
adicionais.

O projeto foi lido apenas para entender QUAIS comportamentos do Windows valia a pena
expor, da mesma forma que se lê a documentação de um produto concorrente. Os modelos
`SettingDefinition`/`RegistrySetting` em `src/Winhance.Core/Features/**` foram tratados
como uma lista de nomes de valores do Registro — informação factual, verificável na
documentação da Microsoft e confirmada de forma independente nos outros três projetos.

## AtlasOS e ReviOS
Excluídos por decisão explícita do titular do produto. Não foram lidos nem consultados.

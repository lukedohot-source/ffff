@echo off
setlocal EnableExtensions
pushd "%~dp0" >nul 2>&1
if errorlevel 1 (
  echo ERRO: nao foi possivel acessar a pasta do aplicativo.
  pause
  exit /b 1
)
set "EXE=native\LukeOptimizer-6.1.2.exe"
if not exist "%EXE%" goto missing

rem O executavel do pacote so muda quando COMPILAR.cmd e executado. Se o codigo-fonte
rem for mais recente que o binario, abrir aqui mostraria a versao antiga sem avisar --
rem que foi exatamente o que ja aconteceu. Compara as datas e avisa antes de abrir.
set "STALE="
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='SilentlyContinue'; $e=Get-Item -LiteralPath 'native\LukeOptimizer-6.1.2.exe'; if (-not $e) { exit 0 }; $m=[datetime]::MinValue; foreach ($f in Get-ChildItem -Path 'codigo-fonte\LukeOptimizer' -Recurse -File) { if (('.cs','.json','.rsp') -contains $f.Extension -and $f.LastWriteTimeUtc -gt $m) { $m=$f.LastWriteTimeUtc } }; if ($m -gt $e.LastWriteTimeUtc) { exit 3 }; exit 0" >nul 2>&1
if errorlevel 3 set "STALE=1"
if defined STALE (
  echo.
  echo AVISO: o codigo-fonte deste pacote e mais recente que o executavel.
  echo Abrir agora mostraria a versao ANTIGA, sem as correcoes.
  echo.
  echo Feche esta janela e execute primeiro:
  echo     codigo-fonte\LukeOptimizer\COMPILAR.cmd
  echo.
  echo Pressione uma tecla para abrir a versao antiga assim mesmo, ou feche a janela.
  pause >nul
)


echo Iniciando Luke Optimizer 6.1.2...
"%EXE%"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" goto failed
popd
exit /b 0

:missing
echo ERRO: executavel nao encontrado: %EXE%
echo Extraia o ZIP completo antes de executar.
pause
popd
exit /b 1

:failed
echo.
echo O aplicativo foi encerrado pelo Windows com o codigo %RC%.
echo Verifique o .NET Framework 4.8, o Windows 10/11 x64 e consulte o log de inicializacao; nao desative protecoes.
pause
popd
exit /b %RC%

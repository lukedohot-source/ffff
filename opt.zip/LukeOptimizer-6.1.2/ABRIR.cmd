@echo off
setlocal EnableExtensions
pushd "%~dp0" >nul 2>&1
if errorlevel 1 (
  echo ERRO: nao foi possivel acessar a pasta do aplicativo.
  pause
  exit /b 1
)
set "EXE=native\LukeOptimizer-6.1.2.exe"
if not exist "%EXE%" goto missing

echo Iniciando Luke Optimizer 6.1.2...
"%EXE%"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" goto failed
popd
exit /b 0

:missing
echo ERRO: executavel nao encontrado: %EXE%
echo Extraia o ZIP completo antes de executar.
pause
popd
exit /b 1

:failed
echo.
echo O aplicativo foi encerrado pelo Windows com o codigo %RC%.
echo Verifique o .NET Framework 4.8, o Windows 10/11 x64 e consulte o log de inicializacao; nao desative protecoes.
pause
popd
exit /b %RC%

@echo off
setlocal EnableExtensions
pushd "%~dp0" >nul 2>&1
if errorlevel 1 (
  echo ERRO: nao foi possivel acessar a pasta do aplicativo.
  pause
  exit /b 1
)
set "EXE=native\LukeOptimizer-6.1.2.exe"
if not exist "%EXE%" goto missing

rem O executavel do pacote so muda quando COMPILAR.cmd e executado. Para saber se o
rem binario e o que passou nos testes, compara o hash dele com o carimbo que a
rem compilacao grava. Comparar DATAS nao funciona: o ZIP guarda horario local sem
rem fuso, entao extrair num fuso diferente deixa os fontes com data no futuro e o
rem executavel recem-compilado parece antigo -- falso alarme a cada abertura.
set "STALE="
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='SilentlyContinue'; $exe='native\LukeOptimizer-6.1.2.exe'; $stamp=$exe + '.sha256'; if (-not (Test-Path -LiteralPath $exe)) { exit 0 }; if (-not (Test-Path -LiteralPath $stamp)) { exit 3 }; $expected=(Get-Content -LiteralPath $stamp -Raw).Trim(); $actual=(Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash; if ($expected -ne $actual) { exit 3 }; exit 0" >nul 2>&1
if errorlevel 3 set "STALE=1"
if defined STALE (
  echo.
  echo AVISO: este executavel nao e o que a ultima compilacao validada publicou.
  echo Provavelmente o pacote ainda nao foi compilado neste PC.
  echo.
  echo Feche esta janela e execute primeiro:
  echo     codigo-fonte\LukeOptimizer\COMPILAR.cmd
  echo.
  echo Pressione uma tecla para abrir a versao antiga assim mesmo, ou feche a janela.
  pause >nul
)


echo Iniciando Luke Optimizer 6.1.2...
"%EXE%"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" goto failed
popd
exit /b 0

:missing
echo ERRO: executavel nao encontrado: %EXE%
echo Extraia o ZIP completo antes de executar.
pause
popd
exit /b 1

:failed
echo.
echo O aplicativo foi encerrado pelo Windows com o codigo %RC%.
echo Verifique o .NET Framework 4.8, o Windows 10/11 x64 e consulte o log de inicializacao; nao desative protecoes.
pause
popd
exit /b %RC%

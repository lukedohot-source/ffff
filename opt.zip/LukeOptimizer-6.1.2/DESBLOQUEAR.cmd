@echo off
setlocal
pushd "%~dp0" >nul 2>&1
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%CD%' -Recurse -File | Unblock-File"
if errorlevel 1 (
  echo Nao foi possivel desbloquear os arquivos automaticamente.
  echo Clique com o botao direito no ZIP, abra Propriedades e marque Desbloquear.
  pause
  popd
  exit /b 1
)
echo Arquivos do pacote desbloqueados.
echo Agora execute ABRIR.cmd.
pause
popd
exit /b 0

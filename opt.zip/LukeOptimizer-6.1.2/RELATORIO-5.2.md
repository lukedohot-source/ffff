> Documento histórico do pacote recebido. Para a revisão atual, consulte CORRECOES-5.4.1.md.

# Luke Optimizer 5.2 — relatório de entrega

## O que está implementado

- 125 opções nativas com seleção individual: 35 anteriores, 68 adaptações da source Optimizer, 21 preferências dos novos packs e o controle de compressão de memória.
- 2 campos manuais de Registro: SystemResponsiveness e Win32PrioritySeparation. Nenhum valor foi presumido para os campos enviados sem número.
- As 141 entradas de remoção do Win11Debloat: 138 Appx e 3 WinGet, com todas as identidades alternativas da source. A seleção consulta a instalação antes e depois; ausência, proteção, falha e leitura indisponível aparecem separadas.
- Interface na mesma janela; busca e filtro de categorias. A remoção tem revisão explícita e parada entre apps.
- Logs persistentes com antes, solicitado, observado, horário UTC, tentativa, diagnóstico, etapa e restauração. Exportação TXT e conferência atual independente.
- Estado dos cartões atualizado depois de aplicar/desfazer, inclusive quando a transação falha. Seleções de temas conflitantes se excluem na interface e são recusadas pelo motor.
- Permissão de Registro solicitada conforme o destino, incluindo políticas HKCU. O diagnóstico agora identifica o caminho e o erro; não troca proprietário ou permissões das chaves protegidas.

## Verificação executada

TOTAL: 508 checks passed (logic only; not an FPS or live Windows mutation test)

Testes simulam mudança, no-op, acesso negado, gravação ignorada, erro de leitura, rollback, restauração exata, identidade de pacote, app protegido, cancelamento e remoção não confirmada.
Consulta real sem alterações: Windows 11 Pro, build 26200; 117 pacotes Appx visíveis para a conta, 25 correspondências instaladas no catálogo de remoção. MMAgent exigiu administrador para leitura; a interface oferece verificação elevada.
As desinstalações e gravações de otimização NÃO foram executadas no PC do usuário durante os testes. A versão/edição, políticas, drivers e proteções ainda podem impedir a aplicação real de uma opção.

## Mapeamento e limites

A source Optimizer teve 133 métodos de OptimizeHelper mapeados por corpo e alvo de Registro. O inventário também inclui os arquivos extraídos e os ajustes adicionais identificados em Utilities. As funções de restauração da source não são executadas: o Luke usa o estado real salvo antes.
Nos oito novos envios foram inventariados 35 arquivos compactados incluindo arquivos internos e duplicados; 518 entradas selecionadas foram lidas. Foram mapeados 170 arquivos BAT/CMD/REG/PS1 (113 conteúdos únicos incluindo o BAT do Cursed), com 6.940 ocorrências de operações de Registro nos conteúdos únicos. Isso não equivale a 6.940 otimizações úteis ou independentes.
O Cursed Tweaker foi aberto como contêiner PyInstaller para extrair metadados e sources/a.bat; seu executável não foi iniciado. A análise estática não certifica que todo binário seja livre de malware.
O mapa JSON/HTML registra a origem, linha, alvo, destino no app e comandos sem execução direta. Uma opção mapeada não é automaticamente uma função implementada. Nem todos os comandos dos arquivos foram incorporados.
Ficaram fora da execução automática: limpeza que apaga árvores inteiras/dados de navegadores, mudanças de ACL/proprietário, prioridade extrema de processos críticos, alterações extensas de boot, desativação indiscriminada de serviços, comandos remotos e binários sem comportamento completamente identificado. Ajustes de drivers/FiveM e valores sem efeito estabelecido ficam como referência no mapa.
Defender global, UAC, HPET/BCD e scripts desconhecidos continuam sem botão de execução irrestrita. VBS/HVCI e SmartScreen têm apenas as políticas explicitadas nas respectivas opções; gravar um valor não prova desativação efetiva. TPMCheck corresponde a sinalizadores do instalador, não a desligar o TPM.
Nenhum driver, programa de terceiros ou comando baixado de Discord é iniciado pelo mapeamento. Não há promessa de FPS, ping ou latência garantidos.

## Onde conferir

- Abrir: ABRIR.cmd.
- Uso: COMO-USAR.txt.
- Mapa navegável: native/MAPA-DOS-ARQUIVOS.html (também em Mais ferramentas > Seus arquivos).
- Fontes, catálogos, testes e compilação: codigo-fonte.
- Evidência técnica: verificacao e auditoria.
- Licenças/atribuições: native/licenses.

## Ampliação pesquisada — 13/09/2026

A biblioteca avançada recebeu 28 entradas adicionais: 24 opções documentadas por jogo, driver, periférico, rede, energia e diagnóstico, além de quatro helpers locais. As opções incluem Game Mode, otimizações de jogos em janela no Windows 11, NVIDIA Reflex/Ultra Low Latency, AMD Anti-Lag/Chill, polling rate condicionado, G-SYNC/VRR, limites de FPS por perfil, upscaling, modo de energia, TRIM, indexação granular, baseline de rede, pathping, bufferbloat, SQM no roteador e comparação de DNS. Elas são classificadas como manuais/diagnósticas quando exigem jogo, driver, dispositivo ou roteador; não entram como alterações globais automáticas.

Os helpers `DIAGNOSTICO-REDE.cmd`, `RELATORIO-ENERGIA.cmd`, `AUDITAR-INICIALIZACAO.cmd` e `ABRIR-CONTROLES-GAMING.cmd` são somente leitura ou abrem configurações oficiais. Não foram adicionados BATs para desligar Defender, Firewall, Windows Update, UAC, TPM, VBS, serviços críticos, BCD ou parâmetros TCP arbitrários.

### Validação da ampliação

Os catálogos JSON foram validados com BOM UTF-8 aceito, os IDs da biblioteca de performance foram verificados sem duplicatas e os quatro helpers CMD foram conferidos como arquivos não vazios. O pacote contém 99 entradas na biblioteca de performance e 39 na biblioteca avançada. A recompilação Windows não foi executada no sandbox Linux; `COMPILAR.cmd` exige o compilador .NET Framework 4.x em Windows x64.

## Correção de permissão HKLM — 13/09/2026

O pré-teste de Registro foi reforçado. Para chaves existentes, o motor verifica acesso de `SetValue`; para chaves de política ausentes, testa a permissão real de criação no pai e remove imediatamente apenas a chave vazia criada pelo teste. Assim, uma opção como `HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Dsh\\AllowNewsAndInterests` falha antes da primeira gravação, com mensagem clara para abrir como administrador ou desmarcar a opção, em vez de iniciar uma transação que depois precisa restaurar dezenas de valores.

## Correção do perfil extremo e clareza da interface — 13/09/2026

O perfil extremo deixou de incluir políticas de computador de navegador, Widgets, Notícias e destaques da Busca. A política `HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Dsh\\AllowNewsAndInterests` permanece disponível no Catálogo como ajuste manual, mas não é mais enviada pelo botão Fazer tudo. Isso impede que uma política protegida interrompa a transação inteira.

A tela de seleção foi reformulada para exibir em cada cartão: o que a opção faz, o impacto possível, a classificação, a necessidade de reiniciar/reabrir e a existência de desfazer pelo Histórico. Também foram removidas contagens fixas antigas e adicionadas instruções explicando que o backup é criado antes da aplicação e que o conjunto pode ser restaurado em caso de falha.

O pré-teste de permissão continua validando chaves ausentes antes da primeira gravação. O teste de criação usa uma chave temporária vazia e a remove imediatamente; não sobrescreve valores existentes.

## Build final corrigido — 13/09/2026

O executável `native/LukeOptimizer-Engine.exe` foi recompilado com Mono/C# após as correções de políticas protegidas, interface, caminhos Windows e namespace WMI. A compilação do motor passou com um aviso não crítico de campo visual não utilizado. A suíte funcional compilou e executou 121 verificações com sucesso; o teste restante, sobre falha de bloqueio de arquivo, depende da semântica de locks do Windows e não reproduz o comportamento esperado no Linux/Mono. A validação desse cenário deve ser feita pelo `TESTAR.cmd` em Windows.

O `ABRIR.cmd` inicia `native/LukeOptimizer-v5.exe`; por isso ambos os executáveis nativos foram atualizados para o build corrigido. O Engine e o v5 agora têm o mesmo hash.

﻿# Revisão atual: 5.4.1

Abra `ABRIR.cmd` após extrair o ZIP. Consulte `CORRECOES-5.4.1.md` e `COMO-USAR.txt` para as correções, validações e limitações atuais.

A execução automática mantém políticas protegidas fora do perfil revisado. Os testes não aplicam otimizações reais.

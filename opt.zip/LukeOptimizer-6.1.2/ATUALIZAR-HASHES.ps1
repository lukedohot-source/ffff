﻿$ErrorActionPreference = 'Stop'
$taskRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$taskHashes = [ordered]@{}
$taskLines = @()
function Get-TaskFileDigest([string]$Path) {
    $taskAlgorithm = [Security.Cryptography.SHA256]::Create()
    $taskStream = [IO.File]::OpenRead($Path)
    try { return ([BitConverter]::ToString($taskAlgorithm.ComputeHash($taskStream))).Replace('-','').ToLowerInvariant() }
    finally { $taskStream.Dispose(); $taskAlgorithm.Dispose() }
}
foreach ($taskFile in Get-ChildItem -LiteralPath $taskRoot -Recurse -File | Sort-Object FullName) {
    $taskRelative = $taskFile.FullName.Substring($taskRoot.Length + 1).Replace('\','/')
    if ($taskRelative -eq 'MANIFESTO-SHA256.json' -or $taskRelative -eq 'SHA256SUMS.txt') { continue }
    $taskHash = Get-TaskFileDigest $taskFile.FullName
    $taskHashes[$taskRelative] = $taskHash
    $taskLines += "$taskHash  $taskRelative"
}
$taskUtf8 = New-Object Text.UTF8Encoding($false)
[IO.File]::WriteAllText((Join-Path $taskRoot 'MANIFESTO-SHA256.json'), ($taskHashes | ConvertTo-Json -Depth 4), $taskUtf8)
[IO.File]::WriteAllLines((Join-Path $taskRoot 'SHA256SUMS.txt'), $taskLines, $taskUtf8)
Write-Output ("Manifestos atualizados: " + $taskHashes.Count + ' arquivos.')

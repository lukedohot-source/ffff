# LukeOptimizer 6.0

Abra ABRIR.cmd após extrair todo o ZIP. Fonte e executáveis estão incluídos.

Comece por documentacao-6.0/MANUAL-PT-BR.md e documentacao-6.0/RELATORIO-FINAL.md. Limitações e validações pendentes estão explicitadas. Documentos com versões 5.x são históricos. Nenhum ganho de FPS/ping foi inventado.

# Auditoria funcional do LukeOptimizer 6.1.2

**Data:** 14 de setembro de 2026  
**Escopo:** código-fonte e recursos empacotados, incluindo interface, catálogos, perfis, limpeza, memória, processos, apps, rede, diagnósticos, histórico e arquivos importados.

## Conclusão executiva

O LukeOptimizer é um utilitário Windows Forms em C# para Windows 10/11 x64. Ele lê recursos do computador, altera algumas preferências do Windows com histórico, limpa arquivos em escopos definidos, libera working sets, fecha aplicativos autorizados, remove apps Appx/WinGet, mede rede e executa diagnósticos oficiais.

O aplicativo **não é um benchmark**. Ele não comprova aumento de FPS, redução universal de input lag ou redução permanente de processos. Muitas opções mudam aparência, políticas ou preferências do Windows, e não o desempenho do hardware.

Há um problema técnico importante na versão auditada: o botão de limpeza configura idade mínima zero, mas `StorageManager.Execute` ainda rejeita prévias com `AgeDays < 1`. Portanto, a limpeza de um clique pode analisar arquivos e falhar antes de excluir. É necessário corrigir essa validação antes de considerar a função concluída.

## 1. Telas e comandos principais

| Tela ou ação | Efeito real | Limite |
|---|---|---|
| Painel | Lê CPU, RAM, rede, armazenamento, energia, inicialização, processos grandes e alguns dados de driver/GPU. | Não faz benchmark de FPS, não mede vida útil do SSD e não atribui disco/rede por processo. |
| Otimização Ultra | Aplica itens nativos revisados e compatíveis, com histórico e resolução de conflitos. | Não limpa arquivos, não libera RAM global, não mata processos, não remove apps e não executa todos os BATs. |
| Limpar temporários | Analisa categorias autorizadas e solicita exclusão permanente dos candidatos validados. | Não remove arquivos em uso, protegidos, alterados, links/junctions ou fora do escopo. |
| Liberar RAM | Usa `EmptyWorkingSet` em processos elegíveis. | Não limpa toda a RAM, não esvazia standby global e não garante desempenho. |
| Reduzir processos | Solicita fechamento normal de aplicativos autorizados; a opção forçada termina após confirmação. | Não atua em serviços, drivers, jogos, componentes do Windows ou processos não autorizados. |
| Remover apps | Consulta Appx/WinGet, remove itens catalogados e confirma o estado depois. | Não remove componentes protegidos e não tem desfazer automático. |
| Ferramentas | Reúne rede, jogos, energia, diagnósticos, revisão de arquivos e referências importadas. | Referência catalogada não significa payload presente ou execução automática. |
| Histórico/Resultados | Guarda mudanças, estados anteriores, etapas, erros, logs e relatórios. | Não desfaz exclusões, desinstalações, encerramentos ou working sets. |

## 2. Otimização Ultra

A Ultra seleciona itens que atendem a `ExtremeProfile.IsReviewed`: item nativo, permitido manualmente, não bloqueado, não protegido por política, sem operação fora de `HKEY_CURRENT_USER` e sem a ação de compressão. Assim, “fazer tudo” significa **tudo dentro do subconjunto revisado e reversível**, não todos os itens catalogados.

| Grupo | O que altera | Efeito e limite |
|---|---|---|
| Modo Jogo | Ativa Modo Jogo e desativa gravação de clipes em segundo plano. | Reduz captura em segundo plano; não garante FPS maior. |
| Interface | Reduz animações, transparência, Peek, espera de menus e redesenho de janelas. | Pode parecer mais responsivo; não mede input lag nem FPS. |
| Windows leve | Reduz sugestões e conteúdos locais revisados. | Menos conteúdo dinâmico; não desativa todo Windows Update, Widgets ou telemetria. |
| Energia | Pode selecionar Alto desempenho quando compatível. | Pode aumentar calor e consumo; o plano anterior deve ser restaurado pelo Histórico. |
| Entrada/jogos | Aplica itens nativos compatíveis do catálogo quando revisados. | Não existe prova automática de redução de input lag. |
| Rede/disco | Só aplica itens nativos que passarem na revisão. | Não força genericamente DNS, MTU, RSS, offloads, IPv6 ou TRIM. |

Itens manuais, políticas `HKLM`, serviços protegidos, scripts, arquivos de referência e opções sem adaptador transacional ficam como ignorados no relatório.

## 3. Opções nativas do Registro

| Opção | Alteração | Resultado |
|---|---|---|
| Edge: apps em segundo plano | `BackgroundModeEnabled=0`. | Extensões e apps web podem parar após fechar o Edge. |
| Edge: inicialização acelerada | `StartupBoostEnabled=0`. | Evita pré-carregamento; primeira abertura pode ficar mais lenta. |
| Chrome: apps em segundo plano | `BackgroundModeEnabled=0`. | Apps/extensões podem parar após fechar o Chrome. |
| Windows 11: Widgets | Política de Widgets para todos os usuários. | Oculta Widgets; depende de edição e permissões. |
| Windows 10: Notícias e interesses | Desativa o recurso da barra. | Remove o recurso visual, sem ganho de FPS. |
| Destaques da Busca | Desliga conteúdo dinâmico. | Mantém pesquisa local e indexação. |
| Busca na barra | Oculta a entrada visual no Windows 11 compatível. | Aparência; a busca do menu Iniciar continua. |
| Indexação sob carga | Permite recuo do indexador. | Pode reduzir atividade; geralmente já é o padrão. |
| Delivery Optimization | Desliga compartilhamento entre PCs. | Reduz compartilhamento local, mas pode aumentar download externo. |
| Tema escuro/claro | Altera `AppsUseLightTheme` e `SystemUsesLightTheme`. | Muda tema do Windows/apps; sem ganho de FPS. São opções conflitantes. |
| Extensões do Explorer | Define `HideFileExt=0`. | Exibe extensões; não renomeia arquivos. |
| Explorer compacto | Define `UseCompactMode=1` quando suportado. | Reduz espaçamento; áreas de toque ficam menores. |
| Sugestões Spotlight | Bloqueia sugestões de terceiros. | Menos sugestões; não desinstala apps. |
| Conteúdo Spotlight | Desliga conteúdo em edições compatíveis. | Remove imagens/sugestões dinâmicas. |
| Firefox telemetria | Define `DisableTelemetry=1`. | Reduz dados de diagnóstico enviados à Mozilla. |
| Microsoft 365 diagnóstico | Define `SendTelemetry=3`. | Reduz diagnóstico do Office; não acelera jogos. |
| Reparar Executar | Remove `NoRun` do usuário. | Pode devolver acesso à caixa Executar. |
| Reparar Painel de Controle | Remove `NoControlPanel`. | Pode devolver acesso ao Painel. |
| Reparar Opções de Pasta | Remove `NoFolderOptions`. | Pode devolver acesso às opções do Explorer. |
| Reparar menu de contexto | Remove `NoViewContextMenu`. | Pode devolver o menu de contexto. |
| Reparar Gerenciador de Tarefas | Remove `DisableTaskMgr`. | Pode devolver o Gerenciador de Tarefas. |
| Reparar Regedit | Remove `DisableRegistryTools`. | Pode devolver o Editor do Registro. |
| Reparar CMD | Remove `DisableCMD`. | Pode devolver o Prompt de Comando. |

Políticas de empresa/escola, antivírus e `HKLM` podem impedir ou reaplicar alterações. O Histórico guarda os valores anteriores quando a alteração é transacional.

## 4. Temporários e caches

As categorias implementadas são: temporários do usuário, temporários do Windows, despejos de falha, relatórios WER, cache de shaders DirectX, miniaturas, cache do Edge, cache do Chrome, Temp legado, Temp na raiz do disco, INetCache, cache RDP, cache Opera e cache Vivaldi.

A varredura usa raízes fixas. Ela rejeita caminhos fora do escopo, links simbólicos e junctions. Existem limites de tempo, quantidade de entradas e profundidade. Antes da exclusão, tamanho, data de criação, data de alteração, atributos e número de links são comparados com a prévia.

A exclusão é permanente e não usa a Lixeira. Arquivos em uso, protegidos, ocultos/sistema, alterados desde a análise ou fora do escopo são preservados. A alteração recente ampliou o filtro de `.tmp`/`.temp` para qualquer arquivo com nome, mas ainda existe a inconsistência de idade zero indicada na conclusão: `Scan` aceita zero e `Execute` ainda rejeita valores menores que um.

Mesmo corrigida, a função não pode excluir “todos” os arquivos do Windows. Ela exclui os candidatos elegíveis dentro das categorias. Arquivos bloqueados pelo sistema ou usados por programas devem permanecer.

## 5. Memory Manager

O botão **Liberar RAM** usa a API `EmptyWorkingSet` nos processos elegíveis. Working set é a memória residente associada a um processo. Liberá-lo não encerra o app nem apaga seus dados, mas pode fazer o Windows recarregar páginas depois, aumentando I/O e causando atraso temporário.

O app protege o próprio processo, componentes do Windows, outras sessões, outros usuários, processos sem identidade verificável e nomes fora da lista permitida. Não usa driver, não limpa o standby global e não executa `EmptyStandbyList.exe`.

A variação de RAM disponível também depende do Windows e de outros processos. Portanto, liberar working sets não equivale a aumentar desempenho real.

## 6. Reduzir processos

A lista autorizada inclui navegadores, Spotify, Discord, Telegram, Slack, Teams, Zoom, OBS, Overwolf, VLC, gerenciadores de download, apps de produtividade e outros aplicativos de usuário.

O modo normal chama `CloseMainWindow`, permitindo diálogos de salvamento. O modo forçado usa `Kill` somente após confirmação explícita. O app valida PID, hora de início, sessão, usuário, nome e caminho antes de agir, evitando matar por engano outro processo que reutilizou um PID.

Não são encerrados serviços, drivers, jogos, componentes do Windows ou processos fora da lista. A ação não fica ativa depois da operação e não reduz processos permanentemente.

## 7. Remover apps

Para Appx, o app consulta `Get-AppxPackage`, recusa frameworks e componentes marcados como não removíveis e usa `Remove-AppxPackage`. Para WinGet, consulta o ID exato e executa `winget uninstall` silencioso.

O catálogo inclui itens como Clipchamp, 3D Builder, Cortana, componentes Bing antigos, Bing Weather, Microsoft Copilot, Copilot+ AI Hub, Microsoft PC Manager, Get Started, Messaging, 3D Viewer, Journal, Office Hub, Power BI, Solitaire, Sticky Notes, Mixed Reality Portal e Network Speed Test, além de outros itens de consumo. O estado real precisa ser conferido no PC: um item pode não estar instalado, ter mudado de nome ou ser protegido pela edição do Windows.

A remoção é confirmada por nova leitura. Não há restauração automática. Para recuperar um item pode ser necessário reinstalar pela Microsoft Store, WinGet ou instalador original. Dados locais do aplicativo podem ser apagados conforme o pacote.

## 8. Painel e memória

O Painel usa APIs do Windows para medir CPU, RAM total/disponível/usada, rede, armazenamento e quantidade de processos. O indicador de saúde considera principalmente RAM disponível, CPU muito alta e reinicialização pendente. Ele não avalia segurança, vida útil do SSD, temperatura, FPS ou latência.

RAM disponível inclui páginas que o Windows pode reutilizar. Cache e standby não são automaticamente desperdício. Commit é memória virtual comprometida e não equivale à RAM física usada. Os contadores opcionais de livre, standby e comprimida podem ficar indisponíveis.

## 9. Rede e latência

| Ferramenta | Efeito |
|---|---|
| Medir antes/depois | Faz 24 pings ICMP ao mesmo destino e mede perda, RTT médio, p95, variação e DNS. |
| Ver minha conexão | Lista adaptadores, estado, link, IP, gateway, DNS, bytes e erros acumulados. |
| Rota até destino | Envia ping com TTL crescente por até 20 saltos. Roteadores podem ocultar respostas. |
| Repouso x carga | Compara captura sem tráfego com captura durante uso habitual de upload/download. Não gera carga automática. |
| Conexões do Windows | Abre `ncpa.cpl`. |
| Exportar resultado | Salva o relatório de rede em texto. |

Ping é RTT ICMP. Não é input lag, tempo de renderização, latência de ida ou desempenho de servidor de jogo. O app não aplica genericamente DNS, MTU, RSS, offloads, IPv6 ou Winsock.

## 10. Diagnósticos oficiais

| Diagnóstico | O que acontece |
|---|---|
| DISM CheckHealth | Consulta se a imagem foi marcada como corrompida; não repara. |
| DISM ScanHealth | Procura corrupção no repositório; pode usar CPU/disco; não repara e não usa ResetBase. |
| SFC verifyonly | Verifica arquivos protegidos; não executa reparo. |
| DNS display | Mostra o cache DNS local; pode revelar nomes consultados. |
| IPConfig all | Mostra adaptadores, IP, DHCP e DNS; não altera nada. |
| TCP show global | Consulta autotuning, RSS e estado TCP; não força configurações. |
| PnPUtil problems | Consulta dispositivos com problemas; não instala drivers. |
| PowerCfg requests | Mostra bloqueadores de suspensão; não remove bloqueadores. |
| Contadores TCP | Mede uma amostra de segmentos enviados, recebidos e retransmitidos; não mede UDP nem ping do jogo. |
| Espaço em disco | Consulta espaço disponível; não executa TRIM nem avalia saúde física do SSD. |
| Energia | Consulta plano e solicitações de energia; não muda o plano. |
| Eventos recentes | Lê erros/críticos recentes dos logs System/Application. Um evento não prova a causa de travamento ou stutter. |

## 11. BATs e arquivos importados

O pacote possui referências a scripts e programas para TRIM, desfragmentação, navegador, Windows, Prefetch/Superfetch, memória, arquivo de paginação, CPU parking, throttling, GPU scheduling, tarefas agendadas, indexação, atualizações, Defender, hibernação, Hyper-V, serviços, telemetria e outros temas.

Nome catalogado não significa função executável. Alguns itens são texto, suporte, atalho externo, script sem payload, programa ausente ou item bloqueado. A integração executa somente adaptadores revisados quando disponíveis. Scripts que desativam Defender, atualizações, serviços, indexação ou Hyper-V podem reduzir proteção, quebrar recursos, aumentar consumo ou dificultar recuperação.

## 12. Histórico e recuperação

Alterações transacionais de Registro, energia, prioridade e preferências guardam o estado anterior. O histórico registra etapas e erros e pode recusar uma restauração quando detecta uma alteração posterior.

Exclusão de arquivos, remoção de apps, encerramento de processos e liberação de working sets não possuem desfazer automático. Cancelar impede etapas futuras, mas não desfaz a etapa concluída.

O estado local fica em `%LOCALAPPDATA%\\LukeOptimizer`, incluindo histórico, backups complementares, relatórios e logs. Os relatórios podem conter nomes de processos, caminhos, endereços e consultas DNS.

## 13. Itens catalogados versus efetivamente executáveis

O pacote contém aproximadamente 532 entradas no catálogo geral, 89 opções auxiliares, 99 entradas na biblioteca de desempenho, 39 entradas V5 e 14 revisões importadas. Essas entradas incluem referências e avaliações, não apenas ações executáveis.

A classificação correta é:

| Estado | Significado |
|---|---|
| Implementado | Existe código executável e caminho de interface. |
| Catalogado | Existe nome/descrição, mas isso não prova payload ou execução. |
| Diagnóstico | Apenas consulta e relata. |
| Revisado | Passou pelas regras de compatibilidade e escopo. |
| Aplicado | O relatório confirmou término da operação. |
| Medido | Uma amostra foi coletada; não é benchmark universal. |

## 14. Problemas e validações necessárias

1. Corrigir `StorageManager.Execute` para aceitar `AgeDays=0`, ou voltar o botão para idade mínima de um dia.
2. Atualizar os nomes e avisos das categorias, que ainda citam `.tmp`/`.temp` embora o filtro tenha sido ampliado.
3. Testar em Windows 10 e 11 x64 com UAC, antivírus, usuário comum e administrador.
4. Conferir o conjunto real selecionado pelo Ultra, porque políticas e hives fora de `HKEY_CURRENT_USER` são excluídos.
5. Testar remoção de cada app em máquina de teste; “recomendado” não significa instalado ou reversível.
6. Validar a interface em DPI 100%, 125%, 150% e 200%.
7. Fazer teste prolongado de inicialização, aplicação, cancelamento, rollback e fechamento.

## Referências

[1]: https://learn.microsoft.com/en-us/windows/win32/api/psapi/nf-psapi-emptyworkingset "EmptyWorkingSet function"
[2]: https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/repair-a-windows-image "Repair a Windows Image"
[3]: https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/sfc "System File Checker"
[4]: https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig "ipconfig command"
[5]: https://learn.microsoft.com/en-us/windows-hardware/design/device-experiences/powercfg-command-line-options "PowerCfg command-line options"
[6]: https://learn.microsoft.com/en-us/windows/hardware/drivers/devtest/pnputil-command-syntax "PnPUtil command syntax"
[7]: https://learn.microsoft.com/en-us/windows/package-manager/winget/ "Windows Package Manager WinGet"
[8]: https://learn.microsoft.com/en-us/powershell/module/appx/get-appxpackage "Get-AppxPackage"
[9]: https://learn.microsoft.com/en-us/powershell/module/appx/remove-appxpackage "Remove-AppxPackage"
[10]: https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-setfileinformationbyhandle "SetFileInformationByHandle function"
[11]: https://learn.microsoft.com/en-us/deployedge/microsoft-edge-policies/BackgroundModeEnabled "Microsoft Edge BackgroundModeEnabled policy"
[12]: https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-search "Windows Search policy CSP"
[13]: https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-experience "Windows Experience policy CSP"
[14]: https://firefox-admin-docs.mozilla.org/reference/policies/disabletelemetry/ "Firefox DisableTelemetry policy"
[15]: https://learn.microsoft.com/en-us/microsoft-365-apps/privacy/manage-privacy-controls "Microsoft 365 privacy controls"
[16]: https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-newsandinterests "News and Interests policy CSP"
[17]: https://learn.microsoft.com/en-us/windows/deployment/do/waas-delivery-optimization-reference "Delivery Optimization reference"
[18]: https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects "Job Objects"
[19]: https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-globalmemorystatusex "GlobalMemoryStatusEx function"
[20]: https://learn.microsoft.com/en-us/windows/win32/api/winsock2/ "Winsock 2"
[21]: https://learn.microsoft.com/en-us/windows/win32/api/winreg/ "Windows Registry API"
[22]: https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/ "Process and thread APIs"
[23]: https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfile "CreateFile function"
[24]: https://learn.microsoft.com/en-us/windows/security/operating-system-security/ "Windows security overview"

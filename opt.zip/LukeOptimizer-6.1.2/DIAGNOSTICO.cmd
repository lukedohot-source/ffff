@echo off
setlocal EnableExtensions
pushd "%~dp0" >nul 2>&1
set "EXE=native\LukeOptimizer-diagnostico.exe"
echo === LukeOptimizer diagnostico ===
echo Pasta atual: %CD%
echo Executavel: %EXE%
if not exist "%EXE%" (
  echo ERRO: executavel diagnostico nao encontrado.
  pause
  exit /b 1
)
for %%F in ("%EXE%") do (
  echo Caminho completo: %%~fF
  echo Tamanho: %%~zF bytes
  echo Data: %%~tF
)
echo.
echo A executar. Copie qualquer texto ou erro exibido abaixo.
"%EXE%"
set "RC=%ERRORLEVEL%"
echo.
echo Codigo de saida: %RC%
echo.
echo Se nao houver texto, envie uma foto desta janela e da pasta native.
pause
popd
exit /b %RC%

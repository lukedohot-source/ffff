# Ferramentas pesquisadas

Estes arquivos `.cmd` são auxiliares opcionais e não fazem parte do botão de otimização extrema. Eles foram incluídos para ampliar o diagnóstico do PC sem aplicar alterações ocultas.

| Arquivo | Função | Altera o sistema? |
|---|---|---|
| `DIAGNOSTICO-REDE.cmd` | Mede gateway, consulta DNS e executa `nslookup` | Não; somente leitura |
| `RELATORIO-ENERGIA.cmd` | Gera relatório `powercfg /energy` de 30 segundos | Não; gera um relatório na Área de Trabalho |
| `AUDITAR-INICIALIZACAO.cmd` | Exporta aplicativos de inicialização e atalhos do usuário | Não; não desativa entradas |
| `ABRIR-CONTROLES-GAMING.cmd` | Abre Game Mode, gráficos e configurações de jogos | Não; o usuário decide nas telas oficiais |

Não execute BATs/CMDs desconhecidos obtidos da internet. O pacote não inclui scripts que desativem Defender, Firewall, Windows Update, UAC, TPM, VBS, serviços críticos, BCD ou configurações TCP arbitrárias.

@echo off
setlocal EnableExtensions
chcp 65001 >nul
for /f "tokens=2 delims=:" %%G in ('ipconfig ^| findstr /R /C:"Default Gateway" /C:"Gateway Padrão"') do if not "%%~G"=="" set "GW=%%~G"
set "GW=%GW: =%"
echo Luke Optimizer - diagnostico somente leitura
if defined GW (echo Gateway detectado: %GW% & ping -n 20 %GW%) else echo Gateway nao detectado; execute ipconfig manualmente.
echo.
echo DNS configurado:
ipconfig /all | findstr /I /C:"DNS Servers" /C:"Servidores DNS"
echo.
echo Resolucao de nomes:
nslookup example.com
nslookup cloudflare.com
pause
endlocal
exit /b 0

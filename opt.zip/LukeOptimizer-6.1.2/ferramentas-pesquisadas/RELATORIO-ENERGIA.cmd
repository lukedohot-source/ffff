@echo off
setlocal
chcp 65001 >nul
set "OUT=%USERPROFILE%\Desktop\Luke-energy-report.html"
echo Gerando relatorio somente leitura por 30 segundos...
powercfg /energy /duration 30 /output "%OUT%"
echo.
echo Relatorio salvo em: %OUT%
echo Nenhuma configuracao foi alterada.
start "" "%OUT%"
pause
endlocal
exit /b 0

@echo off
setlocal
chcp 65001 >nul
echo Abrindo controles oficiais do Windows; nenhuma alteracao automatica sera feita.
start "" ms-settings:gaming-gamemode
start "" ms-settings:display-advancedgraphics
start "" ms-settings:gaming
exit /b 0

@echo off
setlocal
chcp 65001 >nul
set "OUT=%USERPROFILE%\Desktop\Luke-startup-inventory.txt"
echo Inventario somente leitura > "%OUT%"
echo Data: %DATE% %TIME% >> "%OUT%"
echo. >> "%OUT%"
echo === Win32_StartupCommand === >> "%OUT%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_StartupCommand | Sort-Object Location,Name | Format-List Name,Command,Location,User" >> "%OUT%"
echo. >> "%OUT%"
echo === Startup do usuario === >> "%OUT%"
dir /b "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup" >> "%OUT%" 2^>nul
echo.
echo Inventario salvo em: %OUT%
echo Nenhuma entrada foi desativada.
start "" notepad.exe "%OUT%"
pause
endlocal
exit /b 0

> Documento histórico do pacote recebido. Para a revisão atual, consulte CORRECOES-5.4.1.md.

| Item | Antes | Depois | Status |
|---|---:|---:|---|
| Entradas do catálogo da engine | 671 | 671 | Preservadas; inclui arquivos de apoio |
| Entradas acessíveis na biblioteca principal | 200 | 746 | 546 entradas originais adicionadas à busca principal |
| IDs nativos | 125 | 125 | Preservados; 38 aliases aceitos |
| Scripts BAT/CMD/PowerShell catalogados | 193 | 193 | Corpos/referências e hashes preservados nos JSONs |
| Opções nativas de Registro | 116 | 116 | Mesmas operações e IDs |
| Opções de rede | 7 | 7 | Preservadas; rota e repouso/carga adicionados à ferramenta |
| Opções de input lag/entrada | 10 | 10 | Preservadas/classificadas |
| Opções de FPS/stutter/medição | 13 | 13 | Preservadas; FPS mínimo acrescentado |
| Opções de energia | 8 | 8 | Preservadas |
| Opções de processos/memória | 13 | 13 | Preservadas |
| Fluxo transacional de backup | 1 | 1 | Mantido e reutilizado |
| Fluxos de restauração da tela principal | 1 | 2 | Desfazer conjunto + restaurar seleção |
| Histórico detalhado | 1 | 1 | Acrescentados aliases e motivos de itens ignorados |
| Catálogo de remoção de apps | 141 | 141 | Preservado |
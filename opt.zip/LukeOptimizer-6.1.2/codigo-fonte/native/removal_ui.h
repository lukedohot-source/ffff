#pragma once
static char appSearch[180]="";
static bool installedOnly=false,removalReview=false;
static void removalPage(){
 heading("Remover apps", "1. Confira a lista  •  2. Marque os apps que não usa  •  3. Revise e remova");
 muted("Catálogo Win11Debloat: 141 entradas. Nenhum app é selecionado automaticamente. A remoção pode apagar dados do app.");
 ImGui::BeginDisabled(busy());if(ImGui::Button("Atualizar apps instalados",ImVec2(240,38)))startJob("apps");ImGui::SameLine();if(ImGui::Button("Limpar seleção",ImVec2(160,38)))removalSelection.clear();ImGui::EndDisabled();
 ImGui::SetNextItemWidth(-1);ImGui::InputTextWithHint("##apps-search","Buscar pelo nome ou identificador do app…",appSearch,sizeof(appSearch));
 ImGui::Checkbox("Mostrar somente instalados",&installedOnly);ImGui::SameLine();muted(appsChecked.empty()?"Aguardando consulta ao Windows":("Leitura: "+appsChecked));
 ImGui::BeginChild("apps-list",ImVec2(0,-155),true);
 if(!appsScanned)muted(busy()?"Consultando os apps. Esta etapa não desinstala nada.":"Clique em Atualizar apps instalados.");
 int visible=0;
 for(auto& a:removalApps){if(installedOnly&&!a.installed||!contains(a.name+" "+a.packages,appSearch))continue;visible++;ImGui::PushID(a.id.c_str());bool selected=removalSelection.count(a.id)>0;
  ImGui::BeginDisabled(busy()||!a.canRemove);if(ImGui::Checkbox("##remove",&selected)){if(selected)removalSelection.insert(a.id);else removalSelection.erase(a.id);}ImGui::EndDisabled();ImGui::SameLine();ImGui::TextWrapped("%s",a.name.c_str());
  badge(a.state,a.canRemove?ImVec4(.45f,.85f,.73f,1):ImVec4(.75f,.68f,.53f,1));
  if(a.risk=="unsafe")badge("Componente importante: confira o impacto antes de remover",ImVec4(1,.63f,.5f,1));
  if(ImGui::TreeNode("Detalhes do app")){muted(a.packages);textWrap(a.method=="Appx"?"Remoção na sua conta do Windows; não apaga o pacote provisionado para contas futuras.":"Desinstalação pelo WinGet. O instalador pode exigir administrador e afetar todos os usuários.");muted("Descrição fornecida pelo catálogo: "+a.description);textWrap(a.detail);ImGui::TreePop();}
  ImGui::Separator();ImGui::PopID();
 }
 if(appsScanned&&!visible)muted("Nenhum app corresponde a este filtro.");ImGui::EndChild();
 badge(std::to_string(removalSelection.size())+" app(s) marcado(s) • "+std::to_string(visible)+" exibido(s)",ImVec4(.78f,.73f,.99f,1));
 ImGui::BeginDisabled(busy()||removalSelection.empty());if(primary("Revisar remoção"))removalReview=true;ImGui::EndDisabled();ImGui::SameLine();if(ImGui::Button("Ver histórico",ImVec2(150,42)))changePage(10);
 if(busy()&&jobVerb=="remove-apps"){ImGui::SameLine();if(ImGui::Button("Parar após app atual",ImVec2(205,42))){std::error_code ec;std::filesystem::create_directories(std::filesystem::path(responseFile).parent_path(),ec);std::ofstream cancel(std::filesystem::path(responseFile+L".cancel"));cancel<<"1";notice="Pedido de parada enviado. A remoção atual terminará e será conferida.";}}
 statusBar();
 if(removalReview){ImGui::OpenPopup("Confirmar remoção dos apps");removalReview=false;}
 ImGui::SetNextWindowSize(ImVec2(690,520),ImGuiCond_Appearing);
 if(ImGui::BeginPopupModal("Confirmar remoção dos apps",nullptr,ImGuiWindowFlags_NoResize)){
  textWrap("Somente estes apps serão desinstalados. Dados locais do app podem ser apagados. Não há desfazer automático; é necessário reinstalar o programa.");
  ImGui::BeginChild("selected-apps",ImVec2(0,-90),true);std::string ids;bool valid=true;
  for(auto& a:removalApps)if(removalSelection.count(a.id)){if(!ids.empty())ids+=",";ids+=a.id;valid&=a.canRemove;ImGui::TextWrapped("• %s",a.name.c_str());muted(a.method=="Appx"?"Conta atual":"WinGet: pode afetar o PC inteiro");if(a.risk=="unsafe")textWrap("Atenção: remover este componente pode afetar recursos do Windows ou outros aplicativos.");}
  ImGui::EndChild();ImGui::BeginDisabled(!valid||ids.empty()||busy());if(primary("Confirmar e remover")){startJob("remove-apps",ids);ImGui::CloseCurrentPopup();}ImGui::EndDisabled();ImGui::SameLine();if(ImGui::Button("Voltar",ImVec2(130,42)))ImGui::CloseCurrentPopup();ImGui::EndPopup();
 }
}

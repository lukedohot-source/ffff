#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include <windows.h>
#include <d3d11.h>
#include <shellapi.h>
#include <sddl.h>
#include <wincodec.h>
#include <string>
#include <vector>
#include <algorithm>
#include "library.generated.h"
#include "runtime.h"

static ID3D11Device* device=nullptr;
static ID3D11DeviceContext* context=nullptr;
static IDXGISwapChain* swapChain=nullptr;
static ID3D11RenderTargetView* target=nullptr;
static UINT resizeW=0,resizeH=0;
static bool selfTest=false;
static void createTarget(){ID3D11Texture2D* back=nullptr;if(SUCCEEDED(swapChain->GetBuffer(0,IID_PPV_ARGS(&back)))){device->CreateRenderTargetView(back,nullptr,&target);back->Release();}}
static void clearTarget(){if(target){target->Release();target=nullptr;}}
static bool createDevice(HWND window){DXGI_SWAP_CHAIN_DESC s={};s.BufferCount=2;s.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;s.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;s.OutputWindow=window;s.SampleDesc.Count=1;s.Windowed=TRUE;s.SwapEffect=DXGI_SWAP_EFFECT_DISCARD;D3D_FEATURE_LEVEL level;const D3D_FEATURE_LEVEL levels[]={D3D_FEATURE_LEVEL_11_0,D3D_FEATURE_LEVEL_10_0};
 HRESULT hr=D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,levels,2,D3D11_SDK_VERSION,&s,&swapChain,&device,&level,&context);
 if(FAILED(hr))hr=D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_WARP,nullptr,0,levels,2,D3D11_SDK_VERSION,&s,&swapChain,&device,&level,&context);
 if(FAILED(hr))return false;createTarget();return target!=nullptr;
}
static void cleanup(){clearTarget();if(swapChain)swapChain->Release();if(context)context->Release();if(device)device->Release();}
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND,UINT,WPARAM,LPARAM);
static LRESULT CALLBACK windowProc(HWND h,UINT m,WPARAM w,LPARAM l){
 if(ImGui_ImplWin32_WndProcHandler(h,m,w,l))return 1;
 if(m==WM_APP+42){DWORD pid=0;auto child=(HWND)w;GetWindowThreadProcessId(child,&pid);if(pid==toolPid&&GetParent(child)==h){toolWindow=child;}return 0;}
 switch(m){
 case WM_SIZE:if(w!=SIZE_MINIMIZED){resizeW=LOWORD(l);resizeH=HIWORD(l);}return 0;
 case WM_GETMINMAXINFO:((MINMAXINFO*)l)->ptMinTrackSize={1024,760};return 0;
 case WM_SYSCOMMAND:if((w&0xfff0)==SC_KEYMENU)return 0;break;
 case WM_CLOSE:if(busy()||embeddedBusy()){notice="Aguarde terminar para fechar. Seu backup está sendo preservado.";return 0;}if(toolWindow)SendMessageW(toolWindow,WM_CLOSE,0,0);DestroyWindow(h);return 0;
 case WM_DESTROY:PostQuitMessage(0);return 0;
 }return DefWindowProcW(h,m,w,l);
}
#include "ui.h"

// Render-test capture reads only our application's DX11 target, never the desktop.
static bool saveRender(const std::wstring& path){
 ID3D11Texture2D *back=nullptr,*copy=nullptr;D3D11_TEXTURE2D_DESC d={};D3D11_MAPPED_SUBRESOURCE map={};bool ok=false;
 if(FAILED(swapChain->GetBuffer(0,IID_PPV_ARGS(&back))))return false;back->GetDesc(&d);d.Usage=D3D11_USAGE_STAGING;d.BindFlags=0;d.CPUAccessFlags=D3D11_CPU_ACCESS_READ;d.MiscFlags=0;
 if(SUCCEEDED(device->CreateTexture2D(&d,nullptr,&copy))){context->CopyResource(copy,back);if(SUCCEEDED(context->Map(copy,0,D3D11_MAP_READ,0,&map))){
  IWICImagingFactory *factory=nullptr;IWICStream *stream=nullptr;IWICBitmapEncoder *encoder=nullptr;IWICBitmapFrameEncode *frame=nullptr;
  HRESULT hr=CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory));
  std::vector<BYTE> pixels(d.Width*d.Height*4);for(UINT y=0;y<d.Height;y++)for(UINT x=0;x<d.Width;x++){auto from=(BYTE*)map.pData+y*map.RowPitch+x*4;auto to=pixels.data()+(y*d.Width+x)*4;to[0]=from[2];to[1]=from[1];to[2]=from[0];to[3]=from[3];}
  if(SUCCEEDED(hr))hr=factory->CreateStream(&stream);if(SUCCEEDED(hr))hr=stream->InitializeFromFilename(path.c_str(),GENERIC_WRITE);if(SUCCEEDED(hr))hr=factory->CreateEncoder(GUID_ContainerFormatPng,nullptr,&encoder);if(SUCCEEDED(hr))hr=encoder->Initialize(stream,WICBitmapEncoderNoCache);if(SUCCEEDED(hr))hr=encoder->CreateNewFrame(&frame,nullptr);if(SUCCEEDED(hr))hr=frame->Initialize(nullptr);if(SUCCEEDED(hr))hr=frame->SetSize(d.Width,d.Height);WICPixelFormatGUID format=GUID_WICPixelFormat32bppBGRA;if(SUCCEEDED(hr))hr=frame->SetPixelFormat(&format);if(SUCCEEDED(hr))hr=frame->WritePixels(d.Height,d.Width*4,(UINT)pixels.size(),pixels.data());if(SUCCEEDED(hr))hr=frame->Commit();if(SUCCEEDED(hr))hr=encoder->Commit();ok=SUCCEEDED(hr);
  if(frame)frame->Release();if(encoder)encoder->Release();if(stream)stream->Release();if(factory)factory->Release();context->Unmap(copy,0);
 }copy->Release();}back->Release();return ok;
}
static void theme(){
 ImGui::StyleColorsDark();auto& s=ImGui::GetStyle();s.WindowPadding=ImVec2(18,18);s.FramePadding=ImVec2(12,8);s.ItemSpacing=ImVec2(10,9);s.ChildRounding=14;s.FrameRounding=8;s.PopupRounding=14;s.ScrollbarSize=13;s.ScrollbarRounding=10;s.Colors[ImGuiCol_WindowBg]=ImVec4(.045f,.052f,.082f,1);s.Colors[ImGuiCol_ChildBg]=ImVec4(.064f,.073f,.108f,1);s.Colors[ImGuiCol_Text]=ImVec4(.92f,.93f,.98f,1);s.Colors[ImGuiCol_Border]=ImVec4(.17f,.18f,.26f,1);s.Colors[ImGuiCol_Button]=ImVec4(.12f,.16f,.23f,1);s.Colors[ImGuiCol_ButtonHovered]=ImVec4(.26f,.21f,.38f,1);s.Colors[ImGuiCol_ButtonActive]=ImVec4(.4f,.28f,.64f,1);s.Colors[ImGuiCol_CheckMark]=ImVec4(.73f,.61f,1,1);s.Colors[ImGuiCol_FrameBg]=ImVec4(.12f,.14f,.2f,1);s.Colors[ImGuiCol_Header]=ImVec4(.12f,.19f,.26f,1);s.Colors[ImGuiCol_PopupBg]=ImVec4(.08f,.087f,.13f,1);
 wchar_t windows[260];GetWindowsDirectoryW(windows,260);auto fontPath=utf8(std::wstring(windows)+L"\\Fonts\\segoeui.ttf");auto boldPath=utf8(std::wstring(windows)+L"\\Fonts\\segoeuib.ttf");auto& io=ImGui::GetIO();bodyFont=io.Fonts->AddFontFromFileTTF(fontPath.c_str(),17);headingFont=io.Fonts->AddFontFromFileTTF(boldPath.c_str(),26);if(!bodyFont)bodyFont=io.Fonts->AddFontDefault();io.FontDefault=bodyFont;
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,PWSTR,int){
 CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED);int argc=0;auto argv=CommandLineToArgvW(GetCommandLineW(),&argc);std::wstring testDir;bool embedTest=false;int width=1320,height=900;
 if((argc==3||argc==5)&&std::wstring(argv[1])==L"--render-tests"){selfTest=true;testDir=argv[2];std::filesystem::create_directories(testDir);if(argc==5){width=std::max(1024,_wtoi(argv[3]));height=std::max(760,_wtoi(argv[4]));}}if(argc==2&&std::wstring(argv[1])==L"--embed-test"){selfTest=true;embedTest=true;}LocalFree(argv);
 WNDCLASSEXW wc={sizeof(wc),CS_CLASSDC,windowProc,0,0,instance,nullptr,LoadCursor(nullptr,IDC_ARROW),nullptr,nullptr,L"LukeOptimizerLiquid",nullptr};RegisterClassExW(&wc);
 mainWindow=CreateWindowW(wc.lpszClassName,L"Luke Optimizer 5.3",WS_OVERLAPPEDWINDOW|WS_CLIPCHILDREN,60,40,width,height,nullptr,nullptr,instance,nullptr);
 if(!createDevice(mainWindow)){cleanup();return 1;}ShowWindow(mainWindow,selfTest?SW_HIDE:SW_SHOWNORMAL);
 IMGUI_CHECKVERSION();ImGui::CreateContext();auto& io=ImGui::GetIO();io.ConfigFlags|=ImGuiConfigFlags_NavEnableKeyboard;io.IniFilename=nullptr;io.LogFilename=nullptr;theme();ImGui_ImplWin32_Init(mainWindow);ImGui_ImplDX11_Init(device,context);
 bool done=false;int testFrame=0,testIndex=0,result=0;const int testPages[]={0,0,0,0,0,12,10,11,0,0,0};auto started=GetTickCount64();
 if(embedTest){page=7;toolChoice=0;beginTool(0);}else if(!selfTest)startJob("scan");
 else {scanned=true;pcName="PRÉVIA DE TESTE · nenhuma configuração do Windows é alterada";for(const auto& e:library)if(nativeEntry(e))states[e.target]={"Não configurado","Leitura simulada para teste de interface.","",false,false};recommended();
  extremeGroups={{"games","Priorizar o jogo","Modo Jogo e gravação em segundo plano.","Clipes da Game Bar serão desativados.",true,{"native-gamemode","native-capture"}},{"background","Menos apps em segundo plano","Navegadores fechados e Widgets.","Notificações podem parar com o navegador fechado.",true,{"v5-native-edge-background","v5-native-edge-startupboost","v5-native-widgets-off"}},{"visual","Interface mais leve","Animações e transparência.","O Windows fica visualmente mais simples.",true,{"native-window","native-effects","native-transparency"}}};
  for(const auto& e:library)if(nativeEntry(e))metadata[e.target]={"Condicional","Baixo",false,"Preferência individual — dados de teste","Pode exigir nova sessão","Backup no Histórico","Compatibilidade simulada"};
  appsScanned=true;appsChecked="PRÉVIA — dados simulados";
  removalApps={{"demo-1","Microsoft Clipchamp","Editor de vídeo","safe","Appx","Clipchamp.Clipchamp","Instalado","Leitura simulada",true,true},{"demo-2","Microsoft Solitaire Collection","Jogos de cartas","safe","Appx","Microsoft.MicrosoftSolitaireCollection","Instalado","Leitura simulada",true,true},{"demo-3","Microsoft Store","Loja de aplicativos","unsafe","Appx","Microsoft.WindowsStore","Protegido pelo Windows","Exemplo de componente não removível",false,true},{"demo-4","LinkedIn","Aplicativo LinkedIn","safe","Appx","7EE7776C.LinkedInforWindows","Não instalado","Não encontrado na consulta simulada",false,false}};
  removalSelection.insert("demo-1");lastOperation="demo";
  backups.push_back({"demo","Ajustes escolhidos (1)","PRÉVIA DE TESTE","aplicado","LOG DE TESTE — nenhuma configuração real foi alterada.\nRegistro: HKCU / exemplo\nAntes: Ausente\nSolicitado: DWord = 0\nLido depois: DWord = 0\nResultado: Mudou e foi conferido",false,false});
  for(auto& m:manualFields){m.current="DWord = 20 (simulado)";m.value=20;m.ready=true;}
 }
 while(!done){MSG msg;while(PeekMessageW(&msg,nullptr,0,0,PM_REMOVE)){TranslateMessage(&msg);DispatchMessageW(&msg);if(msg.message==WM_QUIT)done=true;}if(done)break;
  if(resizeW&&resizeH){clearTarget();swapChain->ResizeBuffers(0,resizeW,resizeH,DXGI_FORMAT_UNKNOWN,0);resizeW=resizeH=0;createTarget();}if(!target){result=2;break;}
  if(selfTest&&!embedTest){page=testPages[testIndex];areaFilter=testIndex==1?1:testIndex==2||testIndex==8?2:testIndex==3?10:testIndex==4?4:0;manualPreview=testIndex==8;if(testIndex==10&&testFrame==0)extremeRequested=true;if(testIndex==9&&testFrame==0)reviewRequested=true;}
  ImGui_ImplDX11_NewFrame();ImGui_ImplWin32_NewFrame();ImGui::NewFrame();draw();ImGui::Render();const float clear[]={.04f,.05f,.08f,1};context->OMSetRenderTargets(1,&target,nullptr);context->ClearRenderTargetView(target,clear);ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
  if(selfTest&&!embedTest&&++testFrame==4){if(!saveRender(testDir+L"\\page-"+std::to_wstring(testIndex)+L".png")){result=3;break;}testFrame=0;if(++testIndex==sizeof(testPages)/sizeof(testPages[0]))break;}
  if(embedTest){if(toolWindow&&!embeddedBusy()){
    // Navigation acknowledgements: a loaded embedded child remains owned by this one window.
    if(GetParent(toolWindow)!=mainWindow){result=4;break;}RECT r;GetClientRect(toolWindow,&r);if(r.right<500){result=5;break;}
    if(SendMessageW(toolWindow,WM_APP+44,0,0)!=toolChoice){result=7;break;}
    RECT at;GetWindowRect(toolWindow,&at);POINT top={at.left,at.top};ScreenToClient(mainWindow,&top);if(top.x<0||top.y<60){result=8;break;}
    if(toolChoice>=9)break;toolChoice++;SendMessageW(toolWindow,WM_APP+41,toolChoice,0);
   }if(GetTickCount64()-started>45000){result=6;break;}}
  HRESULT hr=swapChain->Present(1,0);if(hr==DXGI_STATUS_OCCLUDED||IsIconic(mainWindow))Sleep(40);
 }
 if(toolWindow)SendMessageW(toolWindow,WM_CLOSE,0,0);if(toolProcess){WaitForSingleObject(toolProcess,2000);CloseHandle(toolProcess);}if(jobProcess)CloseHandle(jobProcess);
 ImGui_ImplDX11_Shutdown();ImGui_ImplWin32_Shutdown();ImGui::DestroyContext();cleanup();if(IsWindow(mainWindow))DestroyWindow(mainWindow);UnregisterClassW(wc.lpszClassName,instance);CoUninitialize();return result;
}

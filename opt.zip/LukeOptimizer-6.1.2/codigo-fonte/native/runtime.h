#pragma once
#include <shlobj.h>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <map>
#include <set>

static HWND mainWindow=nullptr,toolWindow=nullptr;
static HANDLE toolProcess=nullptr,jobProcess=nullptr;
static DWORD toolPid=0;
static int toolPage=-1;
static std::string notice="Escolha os ajustes. Nenhuma alteração foi feita pelo app nesta sessão.",jobVerb;
static bool noticeError=false,scanned=false;
static std::wstring responseFile;
static ULONGLONG jobStarted=0;
struct State {std::string text,detail,issue;bool admin=false,verified=false;};
struct Backup {std::string id,name,time,status,detail;bool undo=false,admin=false;};
static std::map<std::string,State> states;
static std::vector<Backup> backups;
struct OptionMeta{std::string classification,risk;bool automatic;std::string autoReason,restart,undo,compatibility;};
struct ExtremeGroup{std::string id,title,effect,tradeoff;bool selected;std::vector<std::string> items;};
static std::map<std::string,OptionMeta> metadata;
static std::vector<ExtremeGroup> extremeGroups;
static std::string pcName="Clique em Verificar ajustes para consultar este PC.";
static std::string checkedAt,lastOperation,verification,exportedLog;
static bool resultRequested=false;
struct RemovalApp {std::string id,name,description,risk,method,packages,state,detail;bool canRemove=false,installed=false;};
static std::vector<RemovalApp> removalApps;
static std::set<std::string> removalSelection;
static std::string appsChecked;
static bool appsScanned=false;
struct ManualField {const char* id;const char* name;int value;bool selected,ready;std::string current;};
static ManualField manualFields[]={{"responsiveness","SystemResponsiveness",0,false,false,"Não lido"},{"priority","Win32PrioritySeparation",0,false,false,"Não lido"}};
static std::wstring wide(const std::string& s){if(s.empty())return L"";int n=MultiByteToWideChar(CP_UTF8,0,s.data(),(int)s.size(),nullptr,0);std::wstring w(n,0);MultiByteToWideChar(CP_UTF8,0,s.data(),(int)s.size(),w.data(),n);return w;}
static std::string utf8(const std::wstring& s){if(s.empty())return "";int n=WideCharToMultiByte(CP_UTF8,0,s.data(),(int)s.size(),nullptr,0,nullptr,nullptr);std::string v(n,0);WideCharToMultiByte(CP_UTF8,0,s.data(),(int)s.size(),v.data(),n,nullptr,nullptr);return v;}
static std::wstring exeDirectory(){wchar_t path[32768];DWORD n=GetModuleFileNameW(nullptr,path,32768);return std::filesystem::path(std::wstring(path,n)).parent_path().wstring();}
static std::wstring dataDirectory(){PWSTR p=nullptr;if(FAILED(SHGetKnownFolderPath(FOLDERID_LocalAppData,0,nullptr,&p)))return L"";std::wstring r=p;CoTaskMemFree(p);return r+L"\\LukeOptimizer\\liquid";}
static std::wstring sid(){HANDLE token=nullptr;if(!OpenProcessToken(GetCurrentProcess(),TOKEN_QUERY,&token))return L"";DWORD bytes=0;GetTokenInformation(token,TokenUser,nullptr,0,&bytes);std::vector<unsigned char>b(bytes);std::wstring r;if(bytes&&GetTokenInformation(token,TokenUser,b.data(),bytes,&bytes)){LPWSTR s=nullptr;if(ConvertSidToStringSidW(((TOKEN_USER*)b.data())->User.Sid,&s)){r=s;LocalFree(s);}}CloseHandle(token);return r;}
static std::wstring quoteArgument(const std::wstring& value){return L"\""+value+L"\"";}
static std::string decoded(const std::string& s){std::string r;for(size_t i=0;i<s.size();i++){if(s[i]=='%'&&i+2<s.size()){char hex[]={s[i+1],s[i+2],0};r+=(char)strtoul(hex,nullptr,16);i+=2;}else r+=s[i];}return r;}
static std::vector<std::string> fields(const std::string& s){std::vector<std::string> r;size_t start=0;for(size_t i=0;i<=s.size();i++)if(i==s.size()||s[i]=='\t'){r.push_back(decoded(s.substr(start,i-start)));start=i+1;}return r;}
static bool busy(){return jobProcess!=nullptr;}
static bool embeddedBusy(){if(!toolWindow||!IsWindow(toolWindow))return false;DWORD_PTR r=1;return !SendMessageTimeoutW(toolWindow,WM_APP+43,0,0,SMTO_ABORTIFHUNG,150,&r)||r!=0;}
static bool startJob(const std::string& verb,const std::string& payload="-",bool admin=false){
 if(busy()||embeddedBusy()){notice="Aguarde a operação atual terminar.";return false;}
 auto directory=exeDirectory(),file=directory+L"\\LukeOptimizer-Engine.exe",user=sid(),data=dataDirectory();
 if(user.empty()||data.empty()||GetFileAttributesW(file.c_str())==INVALID_FILE_ATTRIBUTES){notice="Motor do app não encontrado. Extraia o ZIP completo e abra ABRIR.cmd.";noticeError=true;return false;}
 GUID g;if(FAILED(CoCreateGuid(&g)))return false;wchar_t guid[40];StringFromGUID2(g,guid,40);std::wstring id;for(auto c:std::wstring(guid))if(iswxdigit(c))id+=c;
 responseFile=data+L"\\"+id+L".txt";
 auto args=L"--liquid "+wide(verb)+L" "+quoteArgument(wide(payload))+L" "+user+L" "+id;
 if(admin){SHELLEXECUTEINFOW si={sizeof(si)};si.fMask=SEE_MASK_NOCLOSEPROCESS|SEE_MASK_FLAG_NO_UI;si.hwnd=mainWindow;si.lpVerb=L"runas";si.lpFile=file.c_str();si.lpParameters=args.c_str();si.lpDirectory=directory.c_str();si.nShow=SW_HIDE;
  if(!ShellExecuteExW(&si)){notice=GetLastError()==ERROR_CANCELLED?"Permissão cancelada. Nenhum ajuste desta seleção foi aplicado.":"Não foi possível iniciar a operação. Código do Windows: "+std::to_string(GetLastError());noticeError=true;return false;}jobProcess=si.hProcess;
 }else{auto command=quoteArgument(file)+L" "+args;STARTUPINFOW si={sizeof(si)};si.dwFlags=STARTF_USESHOWWINDOW;si.wShowWindow=SW_HIDE;PROCESS_INFORMATION pi={};if(!CreateProcessW(file.c_str(),command.data(),nullptr,nullptr,FALSE,CREATE_NO_WINDOW,nullptr,directory.c_str(),&si,&pi)){notice="Falha ao iniciar o motor. Código: "+std::to_string(GetLastError());noticeError=true;return false;}jobProcess=pi.hProcess;CloseHandle(pi.hThread);}
 if(verb=="apply"||verb=="apply-custom"||verb=="extreme"||verb=="restore-selection"||verb=="undo"||verb=="remove-apps")lastOperation.clear();jobVerb=verb;jobStarted=GetTickCount64();noticeError=false;notice=verb=="apps"?"Consultando os apps instalados; aguarde também a resposta do WinGet…":verb=="remove-apps"?"Removendo somente os apps escolhidos e conferindo cada resultado…":verb=="scan"?"Verificando ajustes disponíveis neste PC…":verb=="history"?"Carregando alterações anteriores…":verb=="verify"?"Conferindo os valores atuais, sem alterar configurações…":verb=="export"?"Salvando o log de configurações…":verb=="undo"?"Restaurando os valores salvos…":"Aplicando e conferindo os ajustes escolhidos…";return true;
}
static void pollJob(){
 if(!jobProcess)return;DWORD exitCode;if(!GetExitCodeProcess(jobProcess,&exitCode)||exitCode==STILL_ACTIVE)return;
 CloseHandle(jobProcess);jobProcess=nullptr;std::ifstream in(std::filesystem::path(responseFile),std::ios::binary);std::string line;bool protocol=false,ok=false,sawStatus=false,resultFailure=false;std::vector<Backup> history;std::map<std::string,State> scannedStates;std::string result;std::vector<RemovalApp> appRows;
 while(std::getline(in,line)){if(!line.empty()&&line.back()=='\r')line.pop_back();auto f=fields(line);if(f.empty())continue;
  if(f[0]=="protocol"&&f.size()>1)protocol=f[1]=="1";
  if(f[0]=="ok"&&f.size()>1){sawStatus=true;ok=f[1]=="1";if(f.size()>2)result=f[2];}
  if(f[0]=="result"&&f.size()>2){result=f[1]+". "+f[2];resultFailure=f[1]=="remoção com pendências";}
  if(f[0]=="metadata"&&f.size()==9)metadata[f[1]]={f[2],f[3],f[4]=="1",f[5],f[6],f[7],f[8]};
  if(f[0]=="extreme"&&f.size()==7){auto found=std::find_if(extremeGroups.begin(),extremeGroups.end(),[&](auto& g){return g.id==f[1];});if(found==extremeGroups.end()){ExtremeGroup g={f[1],f[2],f[3],f[4],f[5]=="1",{}};std::stringstream list(f[6]);std::string id;while(std::getline(list,id,','))g.items.push_back(id);extremeGroups.push_back(g);}}
  if(f[0]=="manual"&&f.size()==4)for(auto& m:manualFields)if(f[1]==m.id){m.current=f[3];if(!m.selected&&!f[2].empty()){try{m.value=std::stoi(f[2]);m.ready=true;}catch(...){m.ready=false;}}}
  if(f[0]=="app"&&f.size()==11)appRows.push_back({f[1],f[2],f[3],f[4],f[5],f[6],f[7],f[8],f[9]=="1",f[10]=="1"});
  if(f[0]=="apps_checked"&&f.size()>1)appsChecked=f[1];
  if(f[0]=="refresh_error"&&f.size()>1)result+=" "+f[1];
  if(f[0]=="pc"&&f.size()>5)pcName=f[1]+"  •  "+f[4]+" de RAM";
  if(f[0]=="state"&&f.size()==7)scannedStates[f[1]]={f[2],f[3],f[4],f[5]=="1",f[6]=="1"};
  if(f[0]=="history"&&f.size()==8)history.push_back({f[1],f[2],f[3],f[4],f[5],f[6]=="1",f[7]=="1"});
  if(f[0]=="checked_at"&&f.size()>1)checkedAt=f[1];
  if(f[0]=="operation"&&f.size()>1)lastOperation=f[1];
  if(f[0]=="verification"&&f.size()>2){verification=f[2];result="Conferência atual concluída. Veja o resultado abaixo.";}
  if(f[0]=="exported"&&f.size()>1){exportedLog=f[1];result="Log salvo em: "+exportedLog;}
 }
 if(protocol&&sawStatus){if(!appRows.empty()){removalApps=appRows;appsScanned=true;for(auto& a:removalApps)if(!a.canRemove)removalSelection.erase(a.id);}backups=history;if(!scannedStates.empty()){states=scannedStates;scanned=true;}else if(jobVerb=="scan"||jobVerb=="apply"||jobVerb=="apply-custom"||jobVerb=="extreme"||jobVerb=="restore-selection"||jobVerb=="undo")scanned=false;noticeError=!ok||exitCode!=0||resultFailure;notice=result.empty()?(noticeError?"A operação falhou. Consulte o histórico.":jobVerb=="scan"?"Verificação concluída. Marque as opções e clique em Aplicar selecionadas.":"Histórico atualizado."):result;
 }else{noticeError=true;notice="O motor não retornou um resultado válido. Nenhuma conclusão de sucesso foi presumida. Consulte o histórico antes de repetir.";}
 // Readback in cards must not outlive a mutation. The persisted result remains in history.
 if(jobVerb=="apply"||jobVerb=="apply-custom"||jobVerb=="extreme"||jobVerb=="restore-selection"||jobVerb=="undo"||jobVerb=="remove-apps"){resultRequested=true;verification.clear();}
 in.close();DeleteFileW(responseFile.c_str());DeleteFileW((responseFile+L".cancel").c_str());
}
static bool beginTool(int index){
 if(busy()||embeddedBusy()){notice="Aguarde a operação atual terminar antes de mudar de ferramenta.";return false;}
 if(toolWindow&&IsWindow(toolWindow)){PostMessageW(toolWindow,WM_APP+41,index,0);toolPage=index;return true;}
 if(toolProcess){DWORD code;if(GetExitCodeProcess(toolProcess,&code)&&code==STILL_ACTIVE)return false;CloseHandle(toolProcess);toolProcess=nullptr;}
 auto dir=exeDirectory(),file=dir+L"\\LukeOptimizer-Engine.exe",args=quoteArgument(file)+L" --embedded "+std::to_wstring((intptr_t)mainWindow)+L" "+std::to_wstring(index);STARTUPINFOW si={sizeof(si)};si.dwFlags=STARTF_USESHOWWINDOW;si.wShowWindow=SW_HIDE;PROCESS_INFORMATION pi={};
 if(!CreateProcessW(file.c_str(),args.data(),nullptr,nullptr,FALSE,CREATE_NO_WINDOW,nullptr,dir.c_str(),&si,&pi)){notice="Não foi possível carregar a ferramenta. Extraia o pacote completo.";noticeError=true;return false;}
 toolProcess=pi.hProcess;toolPid=pi.dwProcessId;CloseHandle(pi.hThread);toolPage=index;return true;
}
static bool contains(const std::string& text,const std::string& query){if(query.empty())return true;auto t=wide(text),q=wide(query);CharLowerBuffW(t.data(),(DWORD)t.size());CharLowerBuffW(q.data(),(DWORD)q.size());return t.find(q)!=std::wstring::npos;}
static void openWindowsReference(const LibraryEntry& entry){
 std::wstring file,args;const std::string action=entry.action,key=entry.target;
 if(action=="settings"&&key.rfind("ms-settings:",0)==0)file=wide(key);
 if(action=="system"){
  static const std::map<std::string,std::pair<const wchar_t*,const wchar_t*>> commands={
   {"SystemPropertiesPerformance.exe",{L"SystemPropertiesPerformance.exe",L""}},{"mdsched.exe",{L"mdsched.exe",L""}},
   {"dfrgui.exe",{L"dfrgui.exe",L""}},{"devmgmt.msc",{L"mmc.exe",L"devmgmt.msc"}},
   {"reliability",{L"perfmon.exe",L"/rel"}},{"resmon.exe",{L"resmon.exe",L""}}};
  auto c=commands.find(key);if(c!=commands.end()){wchar_t folder[MAX_PATH];GetSystemDirectoryW(folder,MAX_PATH);file=std::wstring(folder)+L"\\"+c->second.first;args=c->second.second;}
 }
 if(file.empty()){notice="Atalho do Windows não reconhecido.";noticeError=true;return;}
 auto result=(INT_PTR)ShellExecuteW(mainWindow,L"open",file.c_str(),args.empty()?nullptr:args.c_str(),nullptr,SW_SHOWNORMAL);
 noticeError=result<=32;notice=noticeError?"O Windows não conseguiu abrir essa ferramenta neste PC.":"Ferramenta do Windows aberta. Escolha as mudanças nela; abrir o atalho não aplica um ajuste.";
}

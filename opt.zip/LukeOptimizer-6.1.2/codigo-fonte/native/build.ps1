param([string]$Configuration = 'Release')
$ErrorActionPreference = 'Stop'
$nativeRoot = $PSScriptRoot
$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio/Installer/vswhere.exe'
$vsRoot = & $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if (-not $vsRoot) { throw 'Instale a carga C++ do Visual Studio Build Tools e o Windows SDK para recompilar a interface.' }
$msvcVersion = (Get-Content -LiteralPath (Join-Path $vsRoot 'VC/Auxiliary/Build/Microsoft.VCToolsVersion.default.txt')).Trim()
$msvcRoot = Join-Path $vsRoot ('VC/Tools/MSVC/' + $msvcVersion)
$sdkRoot = Join-Path ${env:ProgramFiles(x86)} 'Windows Kits/10'
$sdkVersion = (Get-ChildItem -LiteralPath (Join-Path $sdkRoot 'Include') -Directory | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'um/Windows.h') } | Sort-Object Name -Descending | Select-Object -First 1).Name
if (-not $sdkVersion) { throw 'Windows SDK ausente.' }
$env:PATH = (Join-Path $msvcRoot 'bin/Hostx64/x64') + ';' + (Join-Path $sdkRoot "bin/$sdkVersion/x64") + ';' + $env:PATH
$env:INCLUDE = (Join-Path $msvcRoot 'include') + ';' + (Join-Path $sdkRoot "Include/$sdkVersion/ucrt") + ';' + (Join-Path $sdkRoot "Include/$sdkVersion/shared") + ';' + (Join-Path $sdkRoot "Include/$sdkVersion/um") + ';' + (Join-Path $sdkRoot "Include/$sdkVersion/winrt")
$env:LIB = (Join-Path $msvcRoot 'lib/x64') + ';' + (Join-Path $sdkRoot "Lib/$sdkVersion/ucrt/x64") + ';' + (Join-Path $sdkRoot "Lib/$sdkVersion/um/x64")
New-Item -ItemType Directory -Path (Join-Path $nativeRoot 'bin'),(Join-Path $nativeRoot 'obj') -Force | Out-Null
$buildArgs = @('/nologo','/std:c++17','/EHsc','/utf-8','/W3','/O2','/MT','/DUNICODE','/D_UNICODE','/DNOMINMAX','/DWIN32_LEAN_AND_MEAN','/D_CRT_SECURE_NO_WARNINGS','/Ivendor','/Ivendor/backends','/Ivendor/glass','/Foobj/','/Febin/LukeOptimizer-v5.exe','main.cpp','vendor/imgui.cpp','vendor/imgui_draw.cpp','vendor/imgui_tables.cpp','vendor/imgui_widgets.cpp','vendor/backends/imgui_impl_dx11.cpp','vendor/backends/imgui_impl_win32.cpp','vendor/glass/glass.cpp','/link','/SUBSYSTEM:WINDOWS','/DYNAMICBASE','/NXCOMPAT','/HIGHENTROPYVA','/MANIFEST:EMBED','/MANIFESTINPUT:app.manifest','d3d11.lib','d3dcompiler.lib','dxgi.lib','dwmapi.lib','windowscodecs.lib','ole32.lib','winmm.lib','user32.lib','gdi32.lib','shell32.lib','comdlg32.lib','advapi32.lib','psapi.lib')
Push-Location $nativeRoot
try {
    & (Join-Path $msvcRoot 'bin/Hostx64/x64/cl.exe') @buildArgs 2>&1 | Tee-Object -FilePath 'native-build.log'
    if ($LASTEXITCODE -ne 0) { throw "Falha C++: $LASTEXITCODE" }
    Copy-Item -LiteralPath (Join-Path $nativeRoot 'assets') -Destination (Join-Path $nativeRoot 'bin') -Recurse -Force
} finally { Pop-Location }

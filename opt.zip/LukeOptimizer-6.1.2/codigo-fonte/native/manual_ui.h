#pragma once
static bool manualReview=false;
static bool manualPreview=false;
static void manualPanel(){
 if(manualPreview)ImGui::SetNextItemOpen(true,ImGuiCond_Once);
 if(ImGui::CollapsingHeader("Valores manuais: CPU / MMCSS")){
  muted("Sem preset automático. Valores decimais. SystemResponsiveness: 0–100; Win32PrioritySeparation: 0–63. Podem piorar resposta e áudio; não representam porcentagem de FPS.");
  muted("MMCSS: valores abaixo de 10 são tratados como 20; múltiplos incompletos de 10 são arredondados para baixo. O valor 100 desativa o MMCSS.");
  ImGui::BeginDisabled(busy());for(auto& m:manualFields){ImGui::PushID(m.id);ImGui::BeginDisabled(!m.ready);ImGui::Checkbox("##manual",&m.selected);ImGui::EndDisabled();ImGui::SameLine();ImGui::SetNextItemWidth(145);if(ImGui::InputInt(m.name,&m.value))m.ready=true;muted("Valor lido: "+m.current);ImGui::PopID();}
  bool any=false;for(auto& m:manualFields)any|=m.selected&&m.ready;ImGui::BeginDisabled(!any||!scanned);if(ImGui::Button("Revisar valores manuais"))manualReview=true;ImGui::EndDisabled();ImGui::EndDisabled();
 }
 if(manualReview){ImGui::OpenPopup("Confirmar valores manuais");manualReview=false;}
 ImGui::SetNextWindowSize(ImVec2(600,300),ImGuiCond_Appearing);
 if(ImGui::BeginPopupModal("Confirmar valores manuais",nullptr,ImGuiWindowFlags_NoResize)){
  std::string payload;bool valid=true;for(auto& m:manualFields)if(m.selected){ImGui::TextWrapped("%s: %s → %d (decimal)",m.name,m.current.c_str(),m.value);valid&=m.ready&&m.value>=0&&m.value<=(std::string(m.id)=="priority"?63:100);if(!payload.empty())payload+=",";payload+=std::string(m.id)+"="+std::to_string(m.value);}
  muted("O app salva o valor anterior e confere após gravar. Pode exigir reiniciar. Não há promessa de ganho de desempenho.");ImGui::BeginDisabled(!valid||payload.empty()||busy());if(primary("Confirmar e aplicar")){startJob("apply-custom",payload,true);ImGui::CloseCurrentPopup();}ImGui::EndDisabled();ImGui::SameLine();if(ImGui::Button("Voltar",ImVec2(120,42)))ImGui::CloseCurrentPopup();ImGui::EndPopup();
 }
}

#pragma once
static int page=0,toolChoice=6;
static bool picked[libraryCount]={};
static char searchText[180]="";
static int categoryFilter=0;
static const char* categoryNames[]={"Todas as categorias","Windows leve","Personalização","Privacidade","Avançado","Rede","Apps e processos","Reparos"};
static std::string undoId,undoName;
static bool undoAdmin=false,reviewRequested=false;
static ImFont *bodyFont=nullptr,*headingFont=nullptr;
static const char* pageNames[]={"Começar","Otimizar Windows","Otimizar Registro","Mouse e teclado","Personalizar","Todas as opções","Rede","FPS e travamentos","Apps e memória","Mais ferramentas","Histórico e desfazer","Remover apps"};
static const char* toolNames[]={"FPS e travamentos","Apps e memória","Inicialização e serviços","Energia","Perfis de jogos","Hardware","Rede e latência","Seus arquivos","BATs revisados","Catálogo original"};
static void textWrap(const std::string& text){ImGui::TextWrapped("%s",text.c_str());}
static void muted(const std::string& text){ImGui::PushStyleColor(ImGuiCol_Text,ImVec4(.62f,.65f,.73f,1));textWrap(text);ImGui::PopStyleColor();}
static void heading(const char* title,const char* subtitle){if(headingFont)ImGui::PushFont(headingFont);ImGui::TextUnformatted(title);if(headingFont)ImGui::PopFont();muted(subtitle);ImGui::Spacing();}
static void badge(const std::string& label,ImVec4 color){ImGui::TextColored(color,"%s",label.c_str());}
static bool primary(const char* label,float width=230){ImGui::PushStyleColor(ImGuiCol_Button,ImVec4(.32f,.38f,.86f,1));ImGui::PushStyleColor(ImGuiCol_ButtonHovered,ImVec4(.42f,.49f,.99f,1));bool hit=ImGui::Button(label,ImVec2(width,42));ImGui::PopStyleColor(2);return hit;}
static bool nativeEntry(const LibraryEntry& e){return std::string(e.action)=="native";}
static bool advancedEntry(const LibraryEntry& e){return std::string(e.id).find("v5-advanced-")==0;}
static bool entryEnabled(int i){auto s=states.find(library[i].target);return scanned&&s!=states.end()&&s->second.issue.empty()&&s->second.text!="Falha na leitura";}
static bool inPage(const LibraryEntry& e,int p){
 const std::string id=e.target,cat=e.category;
 if(p==0)return id=="native-window"||id=="native-effects"||id=="native-menu"||id=="native-capture"||id=="native-gamemode"||id=="native-transparency";
 if(p==1)return nativeEntry(e)&&(id.find("native-")==0&&id!="native-mouse"||cat=="Windows leve");
 if(p==2)return nativeEntry(e)&&(id.find("v5-native-")==0||id.find("opt-")==0||id.find("pack-")==0||id=="extra-memory-compression")&&id!="v5-native-keyrepeat"&&id!="v5-native-filter"&&id!="v5-native-sticky";
 if(p==3)return nativeEntry(e)&&(id=="native-mouse"||id=="v5-native-keyrepeat"||id=="v5-native-filter"||id=="v5-native-sticky");
 if(p==4)return nativeEntry(e)&&(cat=="Personalização"||id=="native-transparency");
 return true;
}
static int selectedCount(){int n=0;for(int i=0;i<libraryCount;i++)if(picked[i]&&nativeEntry(library[i]))n++;return n;}
static void clearConflictingTheme(const char* target){
 for(auto& conflict:optionConflicts){const char* other=std::string(target)==conflict.a?conflict.b:std::string(target)==conflict.b?conflict.a:nullptr;if(other)for(int i=0;i<libraryCount;i++)if(std::string(library[i].target)==other)picked[i]=false;}
 const char* other=std::string(target)=="v5-native-theme-dark"?"v5-native-theme-light":std::string(target)=="v5-native-theme-light"?"v5-native-theme-dark":nullptr;
 if(!other)return;
 for(int i=0;i<libraryCount;i++)if(std::string(library[i].target)==other)picked[i]=false;
}
static void recommended(){for(int i=0;i<libraryCount;i++)picked[i]=inPage(library[i],0)&&entryEnabled(i);}
static void changePage(int p){if(embeddedBusy()){notice="A ferramenta ainda está trabalhando. Aguarde terminar.";return;}if(busy()&&p>=6&&p<=9)return;
 if(p<6&&page>=6&&page<=9&&!busy())startJob("scan");
 page=p;searchText[0]=0;
 if(p>=6&&p<=9){int index=p==6?6:p==7?0:p==8?1:toolChoice;beginTool(index);}
 if(p==10&&!busy())startJob("history");
 if(p==11&&!busy()&&!appsScanned)startJob("apps");
}
static void statusBar(){
 ImGui::Separator();if(busy()){ImGui::ProgressBar(-1.0f*(float)ImGui::GetTime(),ImVec2(-1,4),"");}
 ImGui::PushStyleColor(ImGuiCol_Text,noticeError?ImVec4(1,.57f,.58f,1):ImVec4(.7f,.76f,.86f,1));textWrap(notice);ImGui::PopStyleColor();
 if(busy()&&GetTickCount64()-jobStarted>12000)muted("O Windows ainda está respondendo. A janela continua disponível; aguarde o resultado.");
}
static void optionRow(int i){const auto& e=library[i];ImGui::PushID(i);
 const bool active=nativeEntry(e);auto found=states.find(e.target);bool allowed=active&&entryEnabled(i);
 ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing,ImVec2(9,5));ImGui::BeginGroup();
 if(active){ImGui::BeginDisabled(!allowed||busy());bool changed=ImGui::Checkbox("##pick",&picked[i]);ImGui::EndDisabled();if(changed&&picked[i])clearConflictingTheme(e.target);ImGui::SameLine();}
 ImGui::PushTextWrapPos(0);ImGui::TextUnformatted(e.title);ImGui::PopTextWrapPos();
 if(active){std::string label=!scanned?"Verifique o PC para consultar este ajuste":found==states.end()?"Leitura indisponível":!found->second.issue.empty()?"Não disponível neste PC":found->second.verified?"Já configurado":found->second.text=="Falha na leitura"?"Não foi possível ler":"Disponível para aplicar";
  badge(label+(metadata.count(e.target)?"  ·  Risco "+metadata[e.target].risk:""),allowed?ImVec4(.45f,.85f,.73f,1):ImVec4(.85f,.72f,.48f,1));
 }else badge(advancedEntry(e)?"Orientação / arquivo não executado":std::string(e.action)=="page"?"Ferramenta do app":"Guia ou configuração do Windows",ImVec4(.73f,.64f,.95f,1));
 auto info=metadata.find(e.target);
 
 muted(e.effect);
 if(ImGui::TreeNode("O que muda?")){
  textWrap(e.tradeoff);ImGui::Spacing();muted(e.steps);
  if(info!=metadata.end()){muted(info->second.classification+". "+info->second.compatibility);muted(info->second.restart);muted(info->second.undo);}
  muted(std::string("ID da interface: ")+e.id+"  |  Ação: "+e.target);
  if(std::string(e.action)=="catalog"&&ImGui::Button("Ver arquivo e revisão")){toolChoice=9;changePage(9);}
  if(found!=states.end()&&!found->second.issue.empty())textWrap(found->second.issue);
  if(found!=states.end()&&ImGui::TreeNode("Ver leitura do Windows")){muted(found->second.detail);ImGui::TreePop();}
  if(!active&&std::string(e.action)=="page"){
   static const char* target[]={"FPS e stutter","Apps e RAM","Manutenção","Energia avançada","Perfis de jogos","Hardware e rede","Rede e latência","Arquivos e referências","Seus 14 BATs","Catálogo"};
   for(int j=0;j<10;j++)if(std::string(e.target)==target[j]){if(ImGui::Button("Usar ferramenta aqui")){toolChoice=j;changePage(9);}break;}
  }
  if(std::string(e.action)=="settings"||std::string(e.action)=="system")if(ImGui::Button("Abrir ferramenta do Windows"))openWindowsReference(e);
  if(std::string(e.source).find("https://")==0&&ImGui::SmallButton("Ler referência (navegador)")){auto url=wide(e.source);ShellExecuteW(mainWindow,L"open",url.c_str(),nullptr,nullptr,SW_SHOWNORMAL);}
  ImGui::TreePop();
 }
 ImGui::EndGroup();ImGui::Spacing();ImGui::Separator();ImGui::Spacing();ImGui::PopStyleVar();ImGui::PopID();
}
#include "manual_ui.h"
static void optionsPage(){
 const char* title=page==0?"Deixe o PC mais leve, passo a passo":pageNames[page];
 heading(title,page==0?"1. Verifique  •  2. Escolha  •  3. Aplique":"Marcar uma caixa só seleciona. A mudança acontece ao clicar em Aplicar selecionadas.");
 if(page==0){muted("Comece com seis preferências do Windows. Desligar a captura impede os clipes em segundo plano da Game Bar.");}
 ImGui::BeginDisabled(busy());
 if(ImGui::Button(scanned?"Verificar novamente":"1. Verificar ajustes",ImVec2(205,38)))startJob("scan");ImGui::SameLine();
 ImGui::BeginDisabled(!scanned);if(ImGui::Button("Selecionar básicos",ImVec2(176,38)))recommended();ImGui::EndDisabled();ImGui::SameLine();
 if(ImGui::Button("Limpar seleção",ImVec2(155,38)))std::fill(std::begin(picked),std::end(picked),false);ImGui::EndDisabled();
 ImGui::BeginDisabled(busy());if(ImGui::GetContentRegionAvail().x>850)ImGui::SameLine();if(ImGui::Button("Verificar como administrador",ImVec2(246,38)))startJob("scan","-",true);ImGui::EndDisabled();
 if(page!=0){ImGui::SetNextItemWidth(-1);ImGui::InputTextWithHint("##search","Buscar opção pelo nome…",searchText,sizeof(searchText));}
 if(page==2||page==5){ImGui::SetNextItemWidth(260);ImGui::Combo("Categoria",&categoryFilter,categoryNames,8);}
 muted(pcName+(checkedAt.empty()?"":"  •  Leitura: "+checkedAt));
 ImGui::BeginChild("options",ImVec2(0,-159),true);if(page==2)manualPanel();int shown=0;
 bool columns=page==0&&ImGui::GetContentRegionAvail().x>760;
 if(columns)ImGui::BeginTable("basics",2,ImGuiTableFlags_SizingStretchSame);
 for(int i=0;i<libraryCount;i++)if(inPage(library[i],page)&&contains(std::string(library[i].title)+" "+library[i].category,searchText)&&((page!=2&&page!=5)||!categoryFilter||contains(library[i].category,categoryNames[categoryFilter]))){
  if(columns)ImGui::TableNextColumn();optionRow(i);shown++;
 }
 if(columns)ImGui::EndTable();
 if(!shown)muted("Nada encontrado. Apague a busca e tente uma palavra mais curta.");ImGui::EndChild();
 int count=selectedCount();badge(std::to_string(count)+" opção(ões) selecionada(s) no app",ImVec4(.78f,.73f,.99f,1));
 ImGui::BeginDisabled(busy()||!scanned||!count);if(primary("Aplicar selecionadas"))reviewRequested=true;ImGui::EndDisabled();ImGui::SameLine();if(ImGui::Button("Histórico e desfazer",ImVec2(204,42)))changePage(10);statusBar();
}
static void historyPage(){heading("Histórico e desfazer","Veja o resultado real de cada aplicação. Desfazer recupera os valores salvos antes da mudança.");
 ImGui::BeginDisabled(busy());if(ImGui::Button("Atualizar histórico",ImVec2(195,38)))startJob("history");ImGui::EndDisabled();
 ImGui::SameLine();if(ImGui::Button("Voltar às opções",ImVec2(190,38)))changePage(0);
 ImGui::BeginChild("backups",ImVec2(0,-145),true);
 if(!verification.empty()){heading("Conferência atual","Leitura feita agora; o log original continua preservado.");textWrap(verification);if(ImGui::Button("Fechar conferência"))verification.clear();ImGui::Separator();}
 if(backups.empty())muted(busy()?"Carregando…":"Ainda não há alterações registradas. Depois de aplicar, o resultado aparece aqui.");
 for(auto& b:backups){ImGui::PushID(b.id.c_str());ImGui::TextUnformatted(b.name.c_str());badge(b.status,ImVec4(.73f,.68f,.98f,1));muted(b.time);
  ImGui::BeginDisabled(busy());if(ImGui::Button("Conferir agora"))startJob("verify",b.id);ImGui::SameLine();if(ImGui::Button("Salvar log TXT"))startJob("export",b.id);ImGui::SameLine();if(ImGui::Button("Copiar log"))ImGui::SetClipboardText(b.detail.c_str());ImGui::EndDisabled();
  if(b.id==lastOperation)badge("Resultado desta operação",ImVec4(.4f,.85f,.78f,1));
  if(ImGui::TreeNode("Antes / solicitado / lido depois")){textWrap(b.detail);ImGui::TreePop();}
  if(b.undo){ImGui::BeginDisabled(busy());if(ImGui::Button("Desfazer esta alteração",ImVec2(235,38))){undoId=b.id;undoName=b.name;undoAdmin=b.admin;}ImGui::EndDisabled();}
  ImGui::Separator();ImGui::PopID();
 }ImGui::EndChild();statusBar();
}
#include "removal_ui.h"
#include "dashboard_ui.h"
static void toolPageView(){
 int index=page==6?6:page==7?0:page==8?1:toolChoice;
 ImGui::BeginDisabled(embeddedBusy());if(ImGui::Button("< Todas as ferramentas",ImVec2(228,34)))changePage(12);ImGui::EndDisabled();ImGui::SameLine();ImGui::TextUnformatted(toolNames[index]);
 muted(toolDescriptions[index]);
 ImVec2 origin=ImGui::GetCursorScreenPos(),area=ImGui::GetContentRegionAvail();area.y-=8;
 if(toolWindow&&IsWindow(toolWindow))SetWindowPos(toolWindow,HWND_TOP,(int)origin.x,(int)origin.y,(int)area.x,(int)area.y,SWP_NOACTIVATE|SWP_SHOWWINDOW);
 else{muted("Carregando ferramenta…");if(ImGui::Button("Tentar carregar novamente"))beginTool(index);statusBar();}ImGui::Dummy(area);
}
static void reviewDialogs(){
 if(reviewRequested){ImGui::OpenPopup("Conferir seleção");reviewRequested=false;}
 ImGui::SetNextWindowSize(ImVec2(650,540),ImGuiCond_Appearing);
 if(ImGui::BeginPopupModal("Conferir seleção",nullptr,ImGuiWindowFlags_NoResize)){
  muted("Confira o que você marcou. O app salva os valores anteriores para permitir desfazer.");bool valid=scanned,admin=false;std::string ids;
  ImGui::BeginChild("review",ImVec2(0,-75),true);
  for(int i=0;i<libraryCount;i++)if(picked[i]&&nativeEntry(library[i])){if(!ids.empty())ids+=",";ids+=library[i].target;valid&=entryEnabled(i);auto state=states.find(library[i].target);if(state!=states.end())admin|=state->second.admin;ImGui::TextWrapped("• %s",library[i].title);muted(library[i].tradeoff);ImGui::Separator();}
  ImGui::EndChild();muted(admin?"O Windows pedirá permissão de administrador para esta seleção.":"As preferências são aplicadas nesta conta do Windows.");
  ImGui::BeginDisabled(!valid||ids.empty()||busy());if(primary("Confirmar e aplicar")){startJob("apply",ids,admin);ImGui::CloseCurrentPopup();}ImGui::EndDisabled();ImGui::SameLine();if(ImGui::Button("Voltar",ImVec2(125,42)))ImGui::CloseCurrentPopup();ImGui::EndPopup();
 }
 if(!undoId.empty()&&!ImGui::IsPopupOpen("Desfazer alteração"))ImGui::OpenPopup("Desfazer alteração");
 ImGui::SetNextWindowSize(ImVec2(580,240),ImGuiCond_Appearing);
 if(ImGui::BeginPopupModal("Desfazer alteração",nullptr,ImGuiWindowFlags_NoResize)){
  textWrap("Restaurar os valores anteriores de: "+undoName+"?");muted("A restauração para se detectar uma mudança posterior. Nenhum padrão é inventado.");ImGui::Spacing();
  if(primary("Sim, desfazer")){startJob("undo",undoId,undoAdmin);undoId.clear();ImGui::CloseCurrentPopup();}ImGui::SameLine();if(ImGui::Button("Cancelar",ImVec2(135,42))){undoId.clear();ImGui::CloseCurrentPopup();}ImGui::EndPopup();
 }
}
static void draw(){
 pollJob();if(resultRequested){page=10;resultRequested=false;}if(scanned)for(int i=0;i<libraryCount;i++)if(picked[i]&&!entryEnabled(i))picked[i]=false;
 if((page<6||page>9)&&toolWindow&&IsWindow(toolWindow))ShowWindow(toolWindow,SW_HIDE);
 ImGui::SetNextWindowPos(ImVec2(0,0));ImGui::SetNextWindowSize(ImGui::GetIO().DisplaySize);
 ImGui::Begin("Luke",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings);
 ImGui::TextColored(ImVec4(.48f,.83f,.95f,1),"LUKE  /  OPTIMIZER");ImGui::SameLine();muted("5.3   ·   Desempenho sob seu controle");
 ImGui::SameLine(ImGui::GetWindowWidth()-310);muted("(21) 97247-0407");ImGui::SameLine();if(ImGui::SmallButton("Discord"))ShellExecuteW(mainWindow,L"open",L"https://discord.com/users/1344439142850760816",nullptr,nullptr,SW_SHOWNORMAL);
 const char* labels[]={"Otimizações","Remover apps","Ferramentas e diagnóstico","Histórico"};const int destinations[]={0,11,12,10};
 for(int n=0;n<4;n++){if(n)ImGui::SameLine();bool active=n==0?page<6:n==2?page==12||(page>=6&&page<=9):page==destinations[n];ImGui::PushStyleColor(ImGuiCol_Button,active?ImVec4(.16f,.23f,.32f,1):ImVec4(.07f,.09f,.13f,1));if(ImGui::Button(labels[n],ImVec2(n==2?250:177,36)))changePage(destinations[n]);ImGui::PopStyleColor();}
 ImGui::Separator();ImGui::BeginChild("workspace",ImVec2(0,0),false);
 if(page<=5)dashboard();else if(page<=9)toolPageView();else if(page==11)removalPage();else if(page==12)toolChooser();else historyPage();
 ImGui::EndChild();ImGui::End();reviewDialogs();extraDialogs();
}

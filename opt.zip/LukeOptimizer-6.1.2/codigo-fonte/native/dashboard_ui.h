#pragma once
static int areaFilter=0,kindFilter=0;
static bool extremeRequested=false,extremeAfterScan=false,restoreRequested=false;
static const char* areas[]={"Todas as áreas","Windows","Registro e ajustes avançados","Rede e downloads","Mouse, teclado e USB","Energia","Apps e processos","Personalizar","Privacidade","FPS, GPU e hardware","Arquivos originais"};
static int areaOf(const LibraryEntry& e){
 std::string id=e.target,c=e.category;if(std::string(e.action)=="catalog")return 10;
 if(contains(c,"Privacidade"))return 8;if(contains(c,"Personaliza"))return 7;
 if(contains(c,"Rede")||contains(c,"DNS"))return 3;if(contains(c,"Mouse")||contains(c,"Input")||contains(c,"USB")||contains(c,"teclado")||id=="native-mouse"||id.find("v5-native-key")==0||id=="v5-native-filter"||id=="v5-native-sticky")return 4;
 if(contains(c,"Energia")||id=="native-power"||contains(c,"CPU"))return 5;
 if(contains(c,"Apps")||contains(c,"process")||contains(c,"Memória")||contains(c,"Manutenção"))return 6;
 if(contains(c,"Windows")||id.find("native-")==0)return 1;
 if(contains(c,"Registro")||contains(c,"Reparos")||contains(c,"Avançado")||nativeEntry(e))return 2;
 return 9;
}
static std::string selectedIds(){std::string ids;for(int i=0;i<libraryCount;i++)if(picked[i]&&nativeEntry(library[i])){if(!ids.empty())ids+=",";ids+=library[i].target;}return ids;}
static const Backup* latestBackup(){for(auto& b:backups)if(b.undo)return &b;return nullptr;}
static void requestUndo(){auto b=latestBackup();if(b){undoId=b->id;undoName=b->name;undoAdmin=b->admin;}else{notice="Nenhuma aplicação com backup está disponível para desfazer.";noticeError=false;}}
static void miniStat(const std::string& value,const char* label){ImGui::TextColored(ImVec4(.40f,.83f,.91f,1),"%s",value.c_str());ImGui::SameLine();muted(label);}
static void dashboard(){
 ImGui::BeginChild("overview",ImVec2(0,143),true,ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoScrollWithMouse);
 float width=ImGui::GetContentRegionAvail().x,buttonWidth=std::min(402.f,width*.48f);
 ImGui::BeginGroup();heading("Menos trabalho para o Windows.","Mais espaço para o seu jogo.");
 muted(scanned?pcName:"A primeira leitura está consultando o seu PC.");
 int verified=0,total=0;for(int i=0;i<libraryCount;i++)if(nativeEntry(library[i])){total++;auto s=states.find(library[i].target);if(s!=states.end()&&s->second.verified)verified++;}
 miniStat(scanned?std::to_string(verified)+" / "+std::to_string(total):"—","ajustes já configurados");ImGui::EndGroup();
 ImGui::SameLine();ImGui::SetCursorPos(ImVec2(width-buttonWidth+18,29));ImGui::BeginGroup();
 ImGui::BeginDisabled(busy());if(primary("OTIMIZAÇÃO EXTREMA — FAZER TUDO",buttonWidth)){extremeAfterScan=startJob("scan");}ImGui::EndDisabled();
 ImGui::PushTextWrapPos(ImGui::GetCursorPosX()+buttonWidth);muted("Analisa o PC, mostra o plano e pede sua confirmação.");ImGui::PopTextWrapPos();ImGui::EndGroup();ImGui::EndChild();
 ImGui::BeginDisabled(busy());if(ImGui::Button("Analisar este PC",ImVec2(168,35)))startJob("scan");ImGui::SameLine();if(ImGui::Button("Analisar como administrador",ImVec2(254,35)))startJob("scan","-",true);ImGui::SameLine();
 if(ImGui::Button("Limpar caixas",ImVec2(142,35)))std::fill(std::begin(picked),std::end(picked),false);ImGui::EndDisabled();
 ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x*.47f);ImGui::InputTextWithHint("##find","Buscar nome, efeito, categoria ou ID…",searchText,sizeof(searchText));ImGui::SameLine();ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x*.54f);ImGui::Combo("##area",&areaFilter,areas,11);ImGui::SameLine();ImGui::SetNextItemWidth(-1);const char* kinds[]={"Ajustes e referências","Ajustes aplicáveis","Manuais e arquivos"};ImGui::Combo("##kind",&kindFilter,kinds,3);
 ImGui::BeginChild("all-options",ImVec2(0,-145),true);
 if(areaFilter==2)manualPanel();
 int shown=0;for(int group=1;group<11;group++){
  if(areaFilter&&areaFilter!=group)continue;std::vector<int> entries;
  for(int i=0;i<libraryCount;i++){auto& e=library[i];if(areaOf(e)!=group||(kindFilter==1&&!nativeEntry(e))||(kindFilter==2&&nativeEntry(e)))continue;
   if(!contains(std::string(e.title)+" "+e.effect+" "+e.category+" "+e.id+" "+e.target,searchText))continue;entries.push_back(i);}
  if(entries.empty())continue;shown+=(int)entries.size();
  std::string title=std::string(areas[group])+"  /  "+std::to_string(entries.size())+" opções";
  bool expand=areaFilter!=0||searchText[0]!=0||group==1;ImGui::SetNextItemOpen(expand,ImGuiCond_Once);
  if(ImGui::CollapsingHeader(title.c_str())){if(group==2&&areaFilter!=2)manualPanel();if(ImGui::BeginTable(title.c_str(),ImGui::GetContentRegionAvail().x>=850?2:1,ImGuiTableFlags_SizingStretchSame)){for(int i:entries){ImGui::TableNextColumn();optionRow(i);}ImGui::EndTable();}}
 }
 if(!shown)muted("Nenhum resultado. Experimente outra palavra ou Todas as áreas.");ImGui::EndChild();
 badge(std::to_string(selectedCount())+" selecionadas  •  "+std::to_string(shown)+" opções neste filtro  •  Nada muda só por marcar uma caixa",ImVec4(.54f,.82f,.86f,1));
 ImGui::BeginDisabled(busy()||!scanned||!selectedCount());if(primary("Aplicar selecionadas",218))reviewRequested=true;ImGui::SameLine();if(ImGui::Button("Restaurar seleção",ImVec2(180,42)))restoreRequested=true;ImGui::EndDisabled();ImGui::SameLine();
 ImGui::BeginDisabled(busy()||!latestBackup());if(ImGui::Button("Desfazer última aplicação",ImVec2(238,42)))requestUndo();ImGui::EndDisabled();ImGui::SameLine();if(ImGui::Button("Abrir histórico",ImVec2(157,42)))changePage(10);statusBar();
}
static const char* toolDescriptions[]={
 "Compare capturas do mesmo jogo para saber se os ajustes melhoraram FPS e travamentos. Esta ferramenta mede; não aplica otimizações.",
 "Veja quais apps usam memória e escolha o que pode fechar. Salve seu trabalho antes de confirmar.",
 "Escolha apps que iniciam com o Windows, serviços opcionais e tarefas de manutenção. Cada ação explica seu efeito antes de aplicar.",
 "Consulte e ajuste o plano de energia. Mais consumo e calor nem sempre trazem mais FPS.",
 "Guarde configurações para cada jogo e prepare uma sessão com escolhas próprias.",
 "Consulte CPU, RAM, GPU, discos e rede para investigar a causa da lentidão.",
 "Teste a resposta da conexão e perdas. Ping mede a rede; DNS normalmente não muda o ping de uma partida já conectada.",
 "Consulte os arquivos enviados e suas revisões. Referências continuam preservadas.",
 "Leia o conteúdo e a revisão de cada BAT recebido. As adaptações aplicáveis também estão na tela Otimizações.",
 "Catálogo completo dos arquivos recebidos, incluindo alternativas, limitações e opções manuais."
};
static void toolChooser(){
 heading("Ferramentas e diagnóstico","Escolha pelo que você quer descobrir ou fazer. Tudo continua nesta janela.");
 const int order[]={1,2,0,6,3,4,5,8,7,9};
 ImGui::BeginChild("tool-cards",ImVec2(0,0),false);
 if(ImGui::BeginTable("tools",2,ImGuiTableFlags_SizingStretchSame)){
 for(int index:order){ImGui::TableNextColumn();ImGui::PushID(index);ImGui::BeginChild("card",ImVec2(0,150),true);ImGui::TextUnformatted(toolNames[index]);muted(toolDescriptions[index]);if(ImGui::Button("Abrir ferramenta",ImVec2(175,32))){toolChoice=index;changePage(9);}ImGui::EndChild();ImGui::PopID();}
 ImGui::EndTable();}ImGui::EndChild();
}
static void extraDialogs(){
 if(extremeAfterScan&&!busy()){extremeAfterScan=false;if(!noticeError&&scanned)extremeRequested=true;}
 if(extremeRequested){ImGui::OpenPopup("Otimização extrema — revisar plano");extremeRequested=false;}
 ImGui::SetNextWindowSize(ImVec2(std::min(920.f,ImGui::GetIO().DisplaySize.x-42),std::min(695.f,ImGui::GetIO().DisplaySize.y-42)),ImGuiCond_Appearing);
 if(ImGui::BeginPopupModal("Otimização extrema — revisar plano",nullptr,ImGuiWindowFlags_NoResize)){
  muted("Todos os ajustes automáticos permitidos estão nos grupos abaixo. Desmarque um grupo se usa os recursos que ele desliga.");
  std::string ids;bool admin=false;int pending=0,already=0,ignored=0;
  std::set<std::string> targets;for(auto& g:extremeGroups)if(g.selected)for(auto& id:g.items)targets.insert(id);
  std::vector<std::pair<int,std::string>> skip;
  for(int i=0;i<libraryCount;i++)if(nativeEntry(library[i])){auto id=std::string(library[i].target);auto state=states.find(id);auto meta=metadata.find(id);std::string reason;
   if(!targets.count(id))reason=meta==metadata.end()?"Escolha individual ou grupo desmarcado":meta->second.autoReason;
   else if(!entryEnabled(i))reason=state==states.end()?"Leitura indisponível":state->second.issue;
   else {if(!ids.empty())ids+=",";ids+=id;admin|=state->second.admin;if(state->second.verified)already++;else pending++;}
   if(!reason.empty()){skip.push_back({i,reason});ignored++;}
  }
  badge(std::to_string(pending)+" ajustes a aplicar  •  "+std::to_string(already)+" já configurados  •  "+std::to_string(ignored)+" nativos ignorados",ImVec4(.45f,.85f,.8f,1));
  ImGui::BeginChild("extreme-plan",ImVec2(0,-108),true);
  for(auto& g:extremeGroups){ImGui::PushID(g.id.c_str());ImGui::Checkbox(g.title.c_str(),&g.selected);muted(g.effect);textWrap(g.tradeoff);
   if(ImGui::TreeNode("Ver ajustes deste grupo")){for(auto& id:g.items)for(int i=0;i<libraryCount;i++)if(std::string(library[i].target)==id){auto s=states.find(id);textWrap(std::string(library[i].title)+" — "+(s==states.end()?"Sem leitura":s->second.verified?"Já configurado":s->second.issue.empty()?"Aplicar":s->second.issue));}ImGui::TreePop();}ImGui::Separator();ImGui::PopID();}
  if(ImGui::TreeNode("Opções ignoradas e motivos")){for(auto& s:skip){textWrap(library[s.first].title);muted(s.second);}for(int i=0;i<libraryCount;i++)if(!nativeEntry(library[i])){textWrap(library[i].title);muted("Manual, diagnóstico ou arquivo de referência. Não executado pelo Fazer tudo.");}ImGui::TreePop();}
  ImGui::EndChild();muted("Backup antes da gravação e leitura depois. Apps abertos não são fechados. Para concluir os efeitos, reinicie quando puder. Ganho de FPS depende do PC.");
  ImGui::BeginDisabled(ids.empty()||busy());if(primary("Confirmar e fazer tudo",257)){startJob("extreme",ids,admin);ImGui::CloseCurrentPopup();}ImGui::EndDisabled();ImGui::SameLine();if(ImGui::Button("Voltar sem aplicar",ImVec2(210,42)))ImGui::CloseCurrentPopup();ImGui::EndPopup();
 }
 if(restoreRequested){ImGui::OpenPopup("Restaurar seleção do backup");restoreRequested=false;}
 ImGui::SetNextWindowSize(ImVec2(630,320),ImGuiCond_Appearing);
 if(ImGui::BeginPopupModal("Restaurar seleção do backup",nullptr,ImGuiWindowFlags_NoResize)){
  auto b=latestBackup();muted("Restaura somente os ajustes marcados que pertencem à última aplicação. O estado atual também é salvo, permitindo desfazer esta restauração.");
  if(b)textWrap("Backup: "+b->name);else textWrap("Não há um backup gerenciado disponível.");muted("Valores alterados por outro programa depois do backup interrompem a restauração. Ajustes que compartilham um valor devem ser restaurados juntos.");
  ImGui::BeginDisabled(!b||busy()||selectedIds().empty());if(primary("Restaurar valores salvos",262)){startJob("restore-selection",b->id+"|"+selectedIds(),b->admin);ImGui::CloseCurrentPopup();}ImGui::EndDisabled();ImGui::SameLine();if(ImGui::Button("Voltar",ImVec2(124,42)))ImGui::CloseCurrentPopup();ImGui::EndPopup();
 }
}

@echo off
setlocal
call "%~dp0LukeOptimizer\COMPILAR.cmd"
exit /b %ERRORLEVEL%

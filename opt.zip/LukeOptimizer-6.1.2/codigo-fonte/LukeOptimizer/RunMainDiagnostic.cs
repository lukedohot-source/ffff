using System;
using System.IO;
using System.Reflection;
using System.Threading;

class RunMainDiagnostic {
 [STAThread]
 static int Main(string[] args){
  try{
   string exe=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"LukeOptimizer-6.1.2.exe");
   Console.WriteLine("Executando Main real de: "+exe);
   var asm=Assembly.LoadFrom(exe);
   var entry=asm.EntryPoint;
   Console.WriteLine("EntryPoint: "+entry);
   object result=entry.GetParameters().Length==0?entry.Invoke(null,null):entry.Invoke(null,new object[]{new string[0]});
   Console.WriteLine("Main terminou com: "+(result??"null"));
   return result is int?(int)result:0;
  }catch(TargetInvocationException e){Console.WriteLine("EXCECAO DO MAIN:");Console.WriteLine((e.InnerException??e).ToString());return 1;}
  catch(Exception e){Console.WriteLine("EXCECAO DO DIAGNOSTICO:");Console.WriteLine(e.ToString());return 2;}
 }
}

using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;

class StartupDiagnostic {
 static string Hash(string path){using(var sha=SHA256.Create())using(var stream=File.OpenRead(path))return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-","").ToLowerInvariant();}
 static int Main(string[] args){
  try{
   string root=AppDomain.CurrentDomain.BaseDirectory;
   string exe=Path.Combine(root,"LukeOptimizer-6.1.2.exe");
   Console.WriteLine("LukeOptimizer diagnostico");
   Console.WriteLine("Pasta: "+root);
   Console.WriteLine("EXE: "+exe);
   if(!File.Exists(exe)){Console.WriteLine("ERRO: EXE nao encontrado.");return 2;}
   Console.WriteLine("Tamanho: "+new FileInfo(exe).Length);
   Console.WriteLine("SHA256: "+Hash(exe));
   var asm=Assembly.LoadFrom(exe);
   Console.WriteLine("Assembly: "+asm.FullName);
   Console.WriteLine("EntryPoint: "+asm.EntryPoint);
   var names=asm.GetManifestResourceNames();
   Console.WriteLine("Recursos: "+String.Join(", ",names));
   foreach(string resource in new[]{"catalog.json","imported-reviews.json"}){
    using(var s=asm.GetManifestResourceStream(resource)){
     Console.WriteLine(resource+": "+(s==null?"AUSENTE":"OK ("+s.Length+" bytes)"));
    }
   }
   Console.WriteLine("Carregamento do assembly concluido sem excecao.");
   return 0;
  }catch(Exception e){Console.WriteLine("EXCECAO:");Console.WriteLine(e.ToString());return 1;}
 }
}

﻿param([switch]$OnlyTest)
& (Join-Path $PSScriptRoot 'VALIDAR-5.4.ps1') -OnlyTest:$OnlyTest

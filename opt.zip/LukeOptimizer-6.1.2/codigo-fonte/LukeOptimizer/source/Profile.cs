using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Windows.Forms;

public class NativeSaved {public string Code {get;set;} public string Before {get;set;} public string After {get;set;}}
public class StepResult {public string Id {get;set;} public string Name {get;set;} public string Status {get;set;} public string Message {get;set;}}
public class ProgressState {public int Percent {get;set;} public string Stage {get;set;} public string Detail {get;set;} public string Time {get;set;}}
public class Observed {public string State {get;set;} public string Detail {get;set;} public int Match {get;set;} public int Total {get;set;} public bool Verified {get;set;}}
public class Machine {
 public string Cpu="Não consultado",Gpu="Não consultado",OS="Windows",Ram="—",Disk="—",Power="Não consultado",Edition="",Error="";
 public string ActiveGuid="",Plans="";public int Build;public bool Windows,OnAC,NoBattery,PowerKnown;
 public string Pagefile="Não consultado";public string Boot="";
}
static class Builtins {
 static Item Make(string code,string name,string reason,bool selected) {
  return new Item {Id="native-"+code,Name=name,ReviewTitle=name,Category="-1 - Ajustes revisados",Path="Implementação nativa / "+name,
   Mode="Nativo",Type="Nativo",Native=true,ActionCode=code,Available=true,ManualAllowed=true,MaxEligible=true,DefaultSelected=selected,
   Notes=new string[0],Operations=new RegOp[0],ReviewLevel="Revisado",Review=new[]{reason},Conflicts=new string[0],SameTargets=new string[0],
   Asset="",Hash="",Text="",Url="https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-systemparametersinfow",Blocked=""};
 }
 static RegOp Reg(string key,string name,string data) {return new RegOp {Hive="HKEY_CURRENT_USER",Key=key,Name=name,Data=data,Kind="DWord"};}
 internal static List<Item> Create() {
  var list=new List<Item>();
  list.Add(Make("window","Janelas mais diretas","Reduz a animação de minimizar e maximizar. Consulta e aplica pela API do Windows; salva a preferência anterior.",true));
  list.Add(Make("effects","Menos animações na interface","Desativa animações de menus, listas, caixas de seleção e dicas pela API. Mantém suavização de fontes e recursos de acessibilidade.",true));
  list.Add(Make("menu","Submenus mais rápidos","Reduz a espera dos submenus para até 100 ms. Uma espera já menor é preservada. Não altera a taxa de atualização da tela.",true));
  var capture=Make("capture","Desativar captura de jogos","Desliga preferências de captura e gravação em segundo plano do Game DVR para este usuário. Afeta os clipes da Game Bar. O app confirma os valores; confira o comportamento em Capturas após entrar novamente no Windows.",true);
  capture.Operations=new[]{Reg(@"System\GameConfigStore","GameDVR_Enabled","0"),Reg(@"Software\Microsoft\Windows\CurrentVersion\GameDVR","AppCaptureEnabled","0"),Reg(@"Software\Microsoft\Windows\CurrentVersion\GameDVR","HistoricalCaptureEnabled","0")};
  capture.Url="https://learn.microsoft.com/en-us/windows/uwp/launch-resume/launch-settings-app#gaming";list.Add(capture);
  var game=Make("gamemode","Ativar preferência do Modo Jogo","Ativa AllowAutoGameMode e AutoGameModeEnabled. São preferências do usuário, com verificação de gravação; confirme o Modo Jogo nas Configurações. Ganho de FPS não é medido pelo app.",true);
  game.Url="https://blogs.windows.com/windowsexperience/2017/05/01/windows-10-tip-get-power-windows-10-pc-game-mode/";game.Operations=new[]{Reg(@"Software\Microsoft\GameBar","AllowAutoGameMode","1"),Reg(@"Software\Microsoft\GameBar","AutoGameModeEnabled","1")};list.Add(game);
  var transparency=Make("transparency","Reduzir transparência","Define EnableTransparency=0 para este usuário. O app verifica a preferência gravada; alguns componentes podem exigir nova sessão para atualizar a aparência.",true);
  transparency.Url="https://support.microsoft.com/en-us/windows/experience/performance-optimization/tips-to-improve-pc-performance-in-windows";transparency.Operations=new[]{Reg(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize","EnableTransparency","0")};list.Add(transparency);
  var power=Make("power","Usar plano Alto desempenho (opcional)","Seleciona Alto desempenho se existir, em desktop na tomada. Aumenta consumo e calor; compare com Equilibrado no seu jogo. Não força CPU mínima em 100%.",false);
  power.Url="https://learn.microsoft.com/en-us/windows-hardware/design/device-experiences/powercfg-command-line-options";list.Add(power);
  list.Add(Make("mouse","Desativar aceleração do ponteiro","Opção pessoal: usa a API de mouse e mantém a velocidade do ponteiro. Pode mudar sua sensação de mira; jogos com entrada direta podem ignorar essa preferência.",false));
  return list;
 }
}

static class NativeSettings {
 [DllImport("user32.dll",EntryPoint="SystemParametersInfoW",SetLastError=true)]
 static extern bool Spi(uint action,uint param,IntPtr value,uint flags);
 static readonly Dictionary<string,uint[]> Flags=new Dictionary<string,uint[]> {
  {"client",new uint[]{0x1042,0x1043}}, {"cursorshadow",new uint[]{0x101A,0x101B}}, {"dragoutline",new uint[]{0x0026,0x0025}}, {"menuanim",new uint[]{0x1002,0x1003}},
  {"combo",new uint[]{0x1004,0x1005}}, {"list",new uint[]{0x1006,0x1007}},
  {"tooltip",new uint[]{0x1016,0x1017}}, {"selection",new uint[]{0x1014,0x1015}}
 };
 internal static string[] Codes(string action) {
  if(action=="dragoutline"||action=="cursorshadow")return new[]{action};
  if(action==ExtraSettings.Compression)return new[]{action};
  if(PowerTuning.IsCode(action))return new[]{action};
  if(action!=null&&action.StartsWith("v5-",StringComparison.Ordinal))return InputTuning.Codes(action);
  if(action=="effects")return new[]{"client","menuanim","combo","list","tooltip","selection"};
  if(action=="window"||action=="menu"||action=="mouse")return new[]{action};return new string[0];
 }
 internal static string Read(string code) {
  if(PowerTuning.IsCode(code))return PowerTuning.Read(code);
#if TESTS
  if(App.TestNativeRead!=null)return App.TestNativeRead(code);
#endif
  if(InputTuning.IsCode(code))return InputTuning.Read(code);
  if(code==ExtraSettings.Compression)return ExtraSettings.Read();
  if(!App.IsWindows)throw new Exception("Leitura disponível no Windows.");
  int bytes=code=="window"?8:code=="mouse"?12:4;IntPtr ptr=Marshal.AllocHGlobal(bytes);
  try {
   for(int n=0;n<bytes;n+=4)Marshal.WriteInt32(ptr,n,0);
   uint get=code=="window"?0x0048u:code=="mouse"?0x0003u:code=="menu"?0x006Au:Flags[code][0];
   if(code=="window")Marshal.WriteInt32(ptr,8);
   if(!Spi(get,code=="window"?8u:0u,ptr,0))throw new Win32Exception(Marshal.GetLastWin32Error(),"Não foi possível ler "+code);
   if(code=="mouse")return Marshal.ReadInt32(ptr,0)+","+Marshal.ReadInt32(ptr,4)+","+Marshal.ReadInt32(ptr,8);
   return Marshal.ReadInt32(ptr,code=="window"?4:0).ToString(System.Globalization.CultureInfo.InvariantCulture);
  } finally {Marshal.FreeHGlobal(ptr);}
 }
 internal static string Desired(string code,string before) {if(PowerTuning.IsCode(code))return PowerTuning.Desired(code);if(InputTuning.IsCode(code))return InputTuning.Desired(code,before);return code=="mouse"?"0,0,0":code=="menu"?Math.Min(Int32.Parse(before),100).ToString():"0";}
 internal static void Write(string code,string value) {
  if(PowerTuning.IsCode(code)){PowerTuning.Write(code,value);return;}
#if TESTS
  if(App.TestNativeWrite!=null){App.TestNativeWrite(code,value);return;}
#endif
  if(InputTuning.IsCode(code)){InputTuning.Write(code,value);return;}
  if(code==ExtraSettings.Compression){ExtraSettings.Write(value);return;}
  bool ok;
  if(code=="window"||code=="mouse") {
   IntPtr p=Marshal.AllocHGlobal(code=="window"?8:12);
   try {
    if(code=="window"){Marshal.WriteInt32(p,0,8);Marshal.WriteInt32(p,4,Int32.Parse(value));}
    else {var a=value.Split(new[]{','});if(a.Length!=3)throw new Exception("Backup do mouse inválido.");for(int n=0;n<3;n++)Marshal.WriteInt32(p,n*4,Int32.Parse(a[n]));}
    ok=Spi(code=="window"?0x0049u:0x0004u,code=="window"?8u:0u,p,3);
   } finally{Marshal.FreeHGlobal(p);}
  } else if(code=="dragoutline"){BoolParameter(value);ok=Spi(0x0025,UInt32.Parse(value),IntPtr.Zero,3);}
  else if(code=="menu")ok=Spi(0x006B,UInt32.Parse(value),IntPtr.Zero,3);
  else {
   // GET takes a BOOL pointer; these SET actions take FALSE/TRUE as pvParam itself.
   // A nonzero allocated address would enable effects even when its content is 0.
   ok=Spi(Flags[code][1],0,BoolParameter(value),3);
  }
  if(!ok)throw new Win32Exception(Marshal.GetLastWin32Error(),"O Windows recusou a preferência "+code);
 }
 internal static IntPtr BoolParameter(string value) {
  if(value!="0"&&value!="1")throw new ArgumentException("Preferência booleana inválida.");
  return value=="1"?new IntPtr(1):IntPtr.Zero;
 }
}

static partial class App {
 internal const string HighPlan="8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c";
#if TESTS
 internal static Func<RegOp,SavedValue> TestCapture;
 internal static Action<RegOp> TestAccess;
 internal static Action<RegOp> TestWrite;
 internal static Func<string,string> TestNativeRead;
 internal static Action<string,string> TestNativeWrite;
 internal static Func<string> TestPlanGet;
 internal static Action<string> TestPlanSet;
 internal static Machine TestMachine;
#endif
 internal static bool EqualGuid(string a,string b) {return String.Equals(a,b,StringComparison.OrdinalIgnoreCase);}
 internal static void SetPlan(string guid) {
  Guid parsed;if(!Guid.TryParse(guid,out parsed))throw new Exception("Plano de energia inválido.");
#if TESTS
  if(TestPlanSet!=null){TestPlanSet(guid);return;}
#endif
  RunCapture(SystemExe("powercfg.exe"),"/setactive "+guid,true);
  if(!EqualGuid(ActivePlan(),guid))throw new Exception("O Windows não manteve o plano selecionado.");
 }
 static void DeleteImportedPlan(Record rec) {
  if(rec.PlanReused||String.IsNullOrEmpty(rec.NewPlan))return;
  string plans=RunCapture(SystemExe("powercfg.exe"),"/list",true);
  if(plans.IndexOf(rec.NewPlan,StringComparison.OrdinalIgnoreCase)>=0)RunCapture(SystemExe("powercfg.exe"),"/delete "+rec.NewPlan,true);
 }
 internal static string ProgressFile {get{return Path.Combine(DataRoot,"progresso-v2.json");}}
 internal static void WriteProgress(int percent,string stage,string detail) {
  try {
   AtomicStore.Write(ProgressFile,Json.Serialize(new ProgressState {Percent=percent,Stage=stage,Detail=detail,Time=DateTime.UtcNow.ToString("o")}));
  }catch{} // A progress display failure must never prevent backup/rollback.
 }
 internal static string Compatibility(Item item,Machine machine) {
  if(!machine.Windows||machine.Build<10240)return "Requer Windows 10/11 de 64 bits.";
  string v5Issue=V5Options.Compatibility(item,machine);if(v5Issue!=null)return v5Issue;
  string importedIssue=ImportedOptions.Compatibility(item,machine);if(importedIssue!=null)return importedIssue;
  if(PowerTuning.IsCode(item.ActionCode))return PowerTargetIssue(item.ActionCode);
  if(item.ActionCode=="power"&&item.RestorePlan==null) {
   if(!machine.PowerKnown||!machine.NoBattery||!machine.OnAC)return "Ignorado: energia automática exige desktop sem bateria/UPS, ligado à tomada e reconhecido pelo Windows.";
   if(machine.Plans.IndexOf(HighPlan,StringComparison.OrdinalIgnoreCase)<0)return "Ignorado: este PC não disponibiliza o plano Alto desempenho. O plano atual será mantido.";
  }
  if(!item.Native) {
   string source=(item.Text??"").ToLowerInvariant();
   if(source.Contains("wmic ")&&!File.Exists(SystemExe("wbem\\wmic.exe")))return "WMIC ausente. Este script não poderá concluir seus comandos.";
   string path=(item.Path??"").ToLowerInvariant(),gpu=machine.Gpu.ToLowerInvariant();
   if(path.Contains("/amd/")&&!gpu.Contains("amd")&&!gpu.Contains("radeon"))return "Nenhuma GPU AMD foi identificada para este item.";
   if(path.Contains("/nvidia/")&&!gpu.Contains("nvidia"))return "Nenhuma GPU NVIDIA foi identificada para este item.";
   foreach(var o in item.Operations??new RegOp[0]) {
    if(o.Hive=="HKEY_LOCAL_MACHINE"&&o.Key.StartsWith(@"SYSTEM\CurrentControlSet\Services\",StringComparison.OrdinalIgnoreCase)) {
     using(var h=Hive(o.Hive))using(var k=h.OpenSubKey(o.Key,false))if(k==null)return "Serviço/driver não encontrado: "+o.Key.Split(new[]{'\\'}).Last();
    }
   }
  }
  return null;
 }
 internal static List<RegOp> UniqueOperations(IEnumerable<Item> items) {
  var map=new Dictionary<string,RegOp>(StringComparer.OrdinalIgnoreCase);
  foreach(var i in items)foreach(var o in i.Operations??new RegOp[0]) {
   string key=o.Hive+"\\"+o.Key+"\0"+o.Name;RegOp previous;
   if(map.TryGetValue(key,out previous)){if(!Same(previous,o)){
    string label=o.Name=="AppsUseLightTheme"?"tema dos aplicativos (claro ou escuro)":o.Name=="SystemUsesLightTheme"?"tema do Windows (claro ou escuro)":o.Name;
    throw new Exception("As opções escolhidas alteram "+label+" com valores diferentes. Escolha somente uma das opções conflitantes e tente novamente.");
   }}
   else map.Add(key,o);
  }
  return map.Values.ToList();
 }
 internal static void ApplyMaximum(string[] ids) { ApplyMany(ids); }
 internal static void ApplyMany(string[] ids) {
  var chosen=LiquidProtocol.Resolve(String.Join(",",ids));
  if(chosen.Count==1)ApplyTransaction(chosen,"Nativo",chosen[0].Name,CatalogIds.Migrations(String.Join(",",ids)));
  else ApplyIsolated(chosen,"Seleção personalizada",CatalogIds.Migrations(String.Join(",",ids)),null);
 }
 internal static void ApplyTransaction(IEnumerable<Item> selected,string kind,string name,string[] aliases=null,List<StepResult> skipped=null,Record transaction=null,Action<Record> persistRecord=null) {
  var chosen=selected.ToList();if(chosen.Count==0)throw new Exception("Nenhuma opção foi selecionada.");var machine=ScanHardware();
  Action<Record> persist=persistRecord??Save;
  var rec=transaction??NewRecord(name,chosen[0].Id,kind);rec.Schema=4;rec.IdMigrations=aliases;rec.Evidence=new List<SettingEvidence>();rec.ItemIds=chosen.Select(x=>x.Id).ToArray();if(skipped!=null)rec.Steps.AddRange(skipped);persist(rec);
  string stage="Conferindo compatibilidade",activeItem=null;SettingEvidence activeEvidence=null;
  var eligible=new List<Item>();
  try {
   WriteProgress(3,"Conferindo compatibilidade",name);
   foreach(var i in chosen) {
    string reason=Compatibility(i,machine);
    rec.Steps.Add(new StepResult {Id=i.Id,Name=i.ReviewTitle,Status=reason==null?"preparando":"ignorado",Message=reason??""});
    if(reason==null)eligible.Add(i);
   }
   if(eligible.Count==0){rec.Status="sem alterações";rec.Message="Nenhum ajuste compatível foi selecionado.";persist(rec);WriteProgress(100,"Sem alterações",rec.Message);return;}
   BackupBundle.Capture(rec,eligible);persist(rec);
   var allOps=UniqueOperations(eligible);
   // Capture every value before writing any value, including defaults returned by native APIs.
   foreach(var o in allOps){
    var owner=eligible.First(i=>(i.Operations??new RegOp[0]).Any(x=>SameTarget(x,o)));activeItem=owner.Id;stage="Lendo valor anterior: "+o.Hive+"\\"+o.Key+" | "+o.Name;
    activeEvidence=ChangeAudit.Add(rec,owner,"Registro",o.Hive+"\\"+o.Key+" | "+o.Name,ChangeAudit.Value(o),o);var saved=Capture(o);ChangeAudit.Before(activeEvidence,ChangeAudit.Value(saved.Before));
    var expected=eligible.SelectMany(i=>i.Expected??new RegOp[0]).FirstOrDefault(v=>SameTarget(v,o));
    if(expected!=null&&!Same(saved.Before,expected))throw new Exception("Configuração mudou desde a preparação: "+o.Name);
    if(eligible.Any(i=>i.ActionCode=="startup")&&(saved.Before.Delete||saved.Before.Kind!=o.Kind||saved.Before.Data!=o.Data))throw new Exception("Inicialização mudou desde a seleção. Analise novamente.");
    if(!Same(saved.Before,saved.After))rec.Values.Add(saved);
   }
   foreach(var code in eligible.SelectMany(i=>CodesFor(i)).Distinct()) {
    var owner=eligible.First(i=>CodesFor(i).Contains(code));activeItem=owner.Id;stage="Lendo API: "+code;activeEvidence=ChangeAudit.Add(rec,owner,"API do Windows",code,null,null,code);
    string before=NativeSettings.Read(code);var restore=(owner.RestoreNative??new NativeSaved[0]).FirstOrDefault(v=>v.Code==code);if(restore!=null&&before!=restore.Before)throw new Exception("Preferência mudou antes de restaurar: "+code);string after=restore!=null?restore.After:NativeSettings.Desired(code,before);
    ChangeAudit.Before(activeEvidence,before);activeEvidence.Requested=after;
    if(before!=after)rec.NativeValues.Add(new NativeSaved {Code=code,Before=before,After=after});
   }
   if(eligible.Any(x=>x.ActionCode=="power")) {
    var owner=eligible.First(x=>x.ActionCode=="power");activeItem=owner.Id;stage="Lendo plano de energia";string desiredPlan=owner.RestorePlan??HighPlan;activeEvidence=ChangeAudit.Add(rec,owner,"Plano de energia","Plano ativo",desiredPlan);
    string before=ActivePlan();if(!EqualGuid(before,desiredPlan)){rec.PreviousPlan=before;rec.NewPlan=desiredPlan;rec.PlanReused=true;}
    ChangeAudit.Before(activeEvidence,before);
   }
   bool hasChanges=rec.Values.Count>0||rec.NativeValues.Count>0||!String.IsNullOrEmpty(rec.NewPlan);
   persist(rec);WriteProgress(12,"Backup salvo",rec.Values.Count+" valores · "+rec.NativeValues.Count+" preferências nativas");
   if(!hasChanges){ChangeAudit.Readback(rec);foreach(var e in rec.Evidence)if(!e.ObservedKnown||e.Observed!=e.Requested)throw new Exception("O estado mudou durante a conferência: "+e.Target);foreach(var step in rec.Steps.Where(x=>x.Status=="preparando")){step.Status="já configurado";step.Message="Consulta atual coincide com o perfil.";}rec.Status="sem alterações";rec.Message="Os ajustes selecionados já estavam configurados. Nenhum valor foi regravado.";persist(rec);WriteProgress(100,"Tudo já configurado",rec.Message);return;}
   var permissionSkipped=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
   foreach(var v in rec.Values.ToList()){
    activeEvidence=rec.Evidence.First(x=>x.Registry!=null&&SameTarget(x.Registry,v.After));activeItem=activeEvidence.ItemId;stage="Verificando permissão: "+activeEvidence.Target;
    try{CheckWriteAccess(v.After);}
    catch(UnauthorizedAccessException e){
     permissionSkipped.Add(activeItem);activeEvidence.Error="Ignorado por falta de permissão: "+e.Message;activeEvidence.PermissionSkipped=true;activeEvidence.WriteAttempted=false;rec.Values.Remove(v);
     var blocked=rec.Steps.FirstOrDefault(x=>x.Id==activeItem);if(blocked!=null){blocked.Status="ignorado";blocked.Message="Ignorado por falta de permissão neste registro; as outras opções marcadas continuam.";}
     persist(rec);
    }
   }
   if(rec.Values.Count==0&&rec.NativeValues.Count==0&&String.IsNullOrEmpty(rec.NewPlan)){
    ChangeAudit.Readback(rec);
    foreach(var e in rec.Evidence.Where(e=>!e.PermissionSkipped))if(!e.ObservedKnown||e.Observed!=e.Requested)throw new Exception("O estado mudou durante a conferência: "+e.Target);
    foreach(var step in rec.Steps.Where(s=>s.Status=="preparando")){step.Status="já configurado";step.Message="O valor já coincide com o solicitado.";}
    rec.Status="sem alterações";rec.ChangesStarted=false;rec.Message="Nenhuma gravação realizada. "+permissionSkipped.Count+" opção(ões) ignorada(s) por falta de permissão. O último backup com alterações permanece disponível.";persist(rec);WriteProgress(100,rec.Status,rec.Message);return;
   }
   foreach(var v in rec.Values)if(!Same(Capture(v.After).Before,v.Before))throw new Exception("Configuração mudou antes de aplicar: "+v.After.Name);
   foreach(var v in rec.NativeValues)if(NativeSettings.Read(v.Code)!=v.Before)throw new Exception("Preferência mudou antes de aplicar: "+v.Code);
   if(!String.IsNullOrEmpty(rec.NewPlan)&&!EqualGuid(ActivePlan(),rec.PreviousPlan))throw new Exception("Plano mudou antes de aplicar.");
   rec.Status="aplicando";rec.ChangesStarted=true;persist(rec);
   for(int n=0;n<eligible.Count;n++) {
    var i=eligible[n];activeItem=i.Id;var step=rec.Steps.Single(x=>x.Id==i.Id);step.Status="aplicando";int changed=0;
    if(PowerTuning.IsCode(i.ActionCode)){string why=PowerTargetIssue(i.ActionCode);if(why!=null)throw new Exception(why);}
    WriteProgress(15+n*65/eligible.Count,"Aplicando "+(n+1)+" de "+eligible.Count,i.Name);
    foreach(var op in i.Operations??new RegOp[0]) {
     if(rec.Values.Any(v=>SameTarget(v.After,op))){activeEvidence=rec.Evidence.First(x=>x.Registry!=null&&SameTarget(x.Registry,op));stage="Gravando: "+activeEvidence.Target;activeEvidence.WriteAttempted=true;persist(rec);WriteValue(op);changed++;}
    }
    foreach(string code in CodesFor(i)) {var v=rec.NativeValues.FirstOrDefault(x=>x.Code==code);if(v!=null){activeEvidence=rec.Evidence.First(x=>x.Code==code);stage="Aplicando API: "+code;activeEvidence.WriteAttempted=true;persist(rec);NativeSettings.Write(code,v.After);changed++;}}
    if(i.ActionCode=="power"&&!String.IsNullOrEmpty(rec.NewPlan)){activeEvidence=rec.Evidence.First(x=>x.Kind=="Plano de energia");stage="Ativando plano de energia";activeEvidence.WriteAttempted=true;persist(rec);SetPlan(rec.NewPlan);changed++;}
    stage="Conferindo leitura após aplicar: "+i.Name;ChangeAudit.Readback(rec);
    foreach(var op in (i.Operations??new RegOp[0]).Where(op=>rec.Values.Any(v=>SameTarget(v.After,op))))if(!Same(Capture(op).Before,op))throw new Exception("Valor não mantido: "+op.Name);
    foreach(var code in CodesFor(i)){var v=rec.NativeValues.FirstOrDefault(x=>x.Code==code);if(v!=null&&NativeSettings.Read(code)!=v.After)throw new Exception("Preferência não mantida: "+code);}
    if(permissionSkipped.Contains(i.Id)){if(changed>0)step.Status="valores conferidos";else step.Status="ignorado";step.Message=changed>0?"Parte aplicada; outro registro foi ignorado por falta de permissão.":"Ignorado por falta de permissão; nenhuma gravação foi feita nesta opção.";}
    else {step.Status=changed==0?"já configurado":(i.Operations!=null&&i.Operations.Length>0?"valores conferidos":"conferido");step.Message=i.Operations!=null&&i.Operations.Length>0?"Gravação confirmada. Valide o comportamento no Windows; o efeito pode exigir nova sessão.":"Configuração consultada novamente após aplicar.";}
    persist(rec);
   }
   WriteProgress(90,"Conferindo o conjunto","Consultando novamente cada alteração");
   foreach(var v in rec.Values)if(!Same(Capture(v.After).Before,v.After))throw new Exception("O valor mudou durante a aplicação: "+v.After.Name);
   foreach(var v in rec.NativeValues)if(NativeSettings.Read(v.Code)!=v.After)throw new Exception("A preferência mudou durante a aplicação: "+v.Code);
   foreach(var i in eligible.Where(i=>PowerTuning.IsCode(i.ActionCode))){string why=PowerTargetIssue(i.ActionCode);if(why!=null)throw new Exception(why);}
   if(!String.IsNullOrEmpty(rec.NewPlan)&&!EqualGuid(ActivePlan(),rec.NewPlan))throw new Exception("O plano não permaneceu ativo.");
   ChangeAudit.Readback(rec);foreach(var e in rec.Evidence.Where(e=>!e.PermissionSkipped))if(!e.ObservedKnown||e.Observed!=e.Requested)throw new Exception("Conferência final falhou: "+e.Target);
   rec.Status="aplicado";rec.Message=ChangeAudit.Summary(rec)+" "+rec.Steps.Count(x=>x.Status=="ignorado")+" etapa(s) ignorada(s). Algumas preferências precisam de nova sessão para aparecer.";persist(rec);
   WriteProgress(100,"Otimização concluída","Resultados disponíveis no histórico. Desfazer restaura este conjunto.");
  }catch(Exception e) {
   rec.FailureStage=stage;rec.FailureDetail=e.ToString();if(activeEvidence!=null)activeEvidence.Error=ChangeAudit.Error(e);ChangeAudit.Readback(rec);
   var failed=rec.Steps.FirstOrDefault(x=>x.Id==activeItem);if(failed!=null){failed.Status="falhou";failed.Message=stage+". "+ChangeAudit.Error(e);}
   string detail=stage+". "+ChangeAudit.Error(e);
   if(rec.ChangesStarted) {
    try {RestoreTransaction(rec,persistRecord);rec.Status="falhou e foi desfeito";rec.Message=detail+"\r\nOs valores anteriores do conjunto foram conferidos após a restauração. "+ChangeAudit.Summary(rec);}
    catch(Exception rollback){rec.Status="falha na restauração";rec.Message=detail+"\r\nRestauração incompleta: "+rollback.Message+". Use Desfazer para tentar novamente.";}
   } else {rec.Status="falhou antes de alterar";rec.Message=detail+" Nenhuma gravação foi iniciada.";}
   foreach(var step in rec.Steps.Where(x=>x.Status=="preparando")){step.Status="não executado";step.Message=e.Message;}
   persist(rec);WriteProgress(100,rec.Status,rec.Message);throw new Exception(rec.Message,e);
  }
 }
 internal static bool SameTarget(RegOp a,RegOp b){return String.Equals(a.Hive,b.Hive,StringComparison.OrdinalIgnoreCase)&&String.Equals(a.Key,b.Key,StringComparison.OrdinalIgnoreCase)&&String.Equals(a.Name,b.Name,StringComparison.OrdinalIgnoreCase);}
 internal static void RestoreTransaction(Record rec,Action<Record> persistRecord=null) {
  Action<Record> persist=persistRecord??Save;
  if(rec.Values==null)rec.Values=new List<SavedValue>();if(rec.NativeValues==null)rec.NativeValues=new List<NativeSaved>();
  // Preflight all current settings before touching anything, including recovery after interrupted undo.
  foreach(var v in rec.Values){var current=Capture(v.After).Before;if(!Same(current,v.Before)&&!Same(current,v.After))throw new Exception("Mudança posterior detectada em "+v.After.Name+". O backup foi preservado.");}
  foreach(var v in rec.NativeValues){string current=NativeSettings.Read(v.Code);if(current!=v.Before&&current!=v.After)throw new Exception("A preferência "+v.Code+" foi alterada depois. O backup foi preservado.");}
  if(!String.IsNullOrEmpty(rec.NewPlan)){string current=ActivePlan();if(!EqualGuid(current,rec.PreviousPlan)&&!EqualGuid(current,rec.NewPlan))throw new Exception("O plano ativo mudou após o perfil. O backup foi preservado.");}
  try {
   rec.Status="restaurando";persist(rec);WriteProgress(20,"Restaurando backup",rec.Name);
   if(!String.IsNullOrEmpty(rec.NewPlan)&&!EqualGuid(ActivePlan(),rec.PreviousPlan))SetPlan(rec.PreviousPlan);
   foreach(var v in rec.NativeValues.AsEnumerable().Reverse())if(NativeSettings.Read(v.Code)!=v.Before)NativeSettings.Write(v.Code,v.Before);
   RestoreValues(rec.Values);
   foreach(var v in rec.Values)if(!Same(Capture(v.Before).Before,v.Before))throw new Exception("Não foi possível conferir a restauração de "+v.Before.Name);
   foreach(var v in rec.NativeValues)if(NativeSettings.Read(v.Code)!=v.Before)throw new Exception("Não foi possível conferir a restauração de "+v.Code);
   foreach(var step in rec.Steps??new List<StepResult>())if(step.Status=="conferido"||step.Status=="valores conferidos"){step.Status="desfeito";step.Message="Estado anterior restaurado e conferido.";}
   if(!String.IsNullOrEmpty(rec.PreviousPlan)&&!EqualGuid(ActivePlan(),rec.PreviousPlan))throw new Exception("Plano anterior não conferido.");
   ChangeAudit.Readback(rec,true);rec.Status="desfeito";rec.Message="Configurações anteriores restauradas e conferidas. Preferências do shell podem exigir nova sessão.";
   foreach(var child in rec.IsolatedSteps??new List<Record>())if(child.ChangesStarted&&child.Status!="falhou e foi desfeito")child.Status="desfeito";
   persist(rec);WriteProgress(100,"Backup restaurado",rec.Name);
  }catch(Exception e){ChangeAudit.Readback(rec,true);rec.Status="falha na restauração";rec.Message=e.Message;persist(rec);throw;}
 }
}

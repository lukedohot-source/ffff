using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Win32;

// Optional V5 preferences. Register Items() in App.Items and call Compatibility
// from App.Compatibility before ApplyTransaction captures or changes any values.
// All writes/undo remain in the existing transaction engine; no script execution.
static class V5Options {
 const string Prefix="v5-native-";
 const string SearchKey=@"SOFTWARE\Policies\Microsoft\Windows\Windows Search";
 const string ExplorerKey=@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced";
 const string ThemeKey=@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize";
 const string DevSource="https://github.com/microsoft/WindowsDeveloperConfig/blob/main/windows-dev-config/dev-config.winget";
 const string SearchSource="https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-search";
 const string ExperienceSource="https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-experience";
 sealed class Rule {
  internal string Code,Title,Category,Effect,Tradeoff,Source,Product;
  internal int Minimum=10240,Maximum=Int32.MaxValue,Edition,ProductMinimum;
  internal RegOp[] Operations;
 }
 static RegOp User(string key,string name,string value){return new RegOp{Hive="HKEY_CURRENT_USER",Key=key,Name=name,Kind="DWord",Data=value};}
 static RegOp Device(string key,string name,string value){return new RegOp{Hive="HKEY_LOCAL_MACHINE",Key=key,Name=name,Kind="DWord",Data=value};}
 static Rule Repair(string code,string title,string key,string value,string source){return new Rule{Code=code,Title=title,Category="Reparos de acesso",Product="repair",
  Effect="Remove somente a restrição "+value+" do usuário atual, preservando o valor anterior no Histórico.",
  Tradeoff="Reparo de acesso, não otimização de FPS. Não remove políticas de computador nem outras restrições. Políticas de trabalho/escola podem reaplicar o bloqueio; confirme após nova sessão.",
  Source=source,Operations=new[]{new RegOp{Hive="HKEY_CURRENT_USER",Key=key,Name=value,Kind="DWord",Data="",Delete=true}}};}
 static readonly Rule[] Rules={
  new Rule{Code="edge-background",Title="Edge: encerrar apps em segundo plano",Category="Apps e processos",Product="edge",ProductMinimum=77,
   Effect="Desativa o modo de apps em segundo plano depois de fechar as janelas do Edge.",Tradeoff="Extensões e apps web podem deixar de receber tarefas/notificações com o navegador fechado. Reabra o Edge e confira edge://policy. A política fica bloqueada no navegador até desfazer; não encerra janelas abertas.",
   Source="https://learn.microsoft.com/en-us/deployedge/microsoft-edge-policies/BackgroundModeEnabled",Operations=new[]{Device(@"SOFTWARE\Policies\Microsoft\Edge","BackgroundModeEnabled","0")}},
  new Rule{Code="edge-startupboost",Title="Edge: desligar inicialização acelerada",Category="Apps e processos",Product="edge",ProductMinimum=88,
   Effect="Evita pré-carregar processos do Edge no login e reativá-los para acelerar a abertura.",Tradeoff="A primeira abertura do navegador pode demorar mais. Modo de segundo plano é outra opção independente. Reabra o Edge e confira edge://policy; afeta todos os usuários do PC.",
   Source="https://learn.microsoft.com/en-us/deployedge/microsoft-edge-policies/StartupBoostEnabled",Operations=new[]{Device(@"SOFTWARE\Policies\Microsoft\Edge","StartupBoostEnabled","0")}},
  new Rule{Code="chrome-background",Title="Chrome: encerrar apps em segundo plano",Category="Apps e processos",Product="chrome",ProductMinimum=19,
   Effect="Impede o modo de apps em segundo plano que permanece após fechar a última janela.",Tradeoff="Apps/extensões em segundo plano podem parar. Tarefas já iniciadas podem exigir fechar e reabrir o Chrome. Confira chrome://policy; a política vale para todos os usuários e bloqueia esta preferência até desfazer.",
   Source="https://chromeenterprise.google/policies/background-mode-enabled/",Operations=new[]{Device(@"SOFTWARE\Policies\Google\Chrome","BackgroundModeEnabled","0")}},
  new Rule{Code="widgets-off",Title="Windows 11: desativar Widgets (manual)",Category="Windows leve",Minimum=22000,Edition=1,
   Effect="Desativa o painel de Widgets e o conteúdo relacionado da barra de tarefas.",Tradeoff="Não é uma otimização de FPS. Usa uma política HKEY_LOCAL_MACHINE para todos os usuários; pode ser bloqueada por permissões, edição do Windows ou política de trabalho/escola. O botão Otimização extrema não aplica esta opção. Pode exigir nova sessão.",
   Source="https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-newsandinterests#allownewsandinterests",Operations=new[]{Device(@"SOFTWARE\Policies\Microsoft\Dsh","AllowNewsAndInterests","0")}},
  new Rule{Code="news-off",Title="Windows 10: desativar Notícias e interesses",Category="Windows leve",Minimum=19045,Maximum=21999,Edition=1,
   Effect="Desativa Notícias e interesses na barra de tarefas do Windows 10.",Tradeoff="Remove também a configuração desse recurso no menu da barra. Vale para todos os usuários; nova sessão pode ser necessária. Não se aplica ao Windows 11.",
   Source="https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-feeds",Operations=new[]{Device(@"SOFTWARE\Policies\Microsoft\Windows\Windows Feeds","EnableFeeds","0")}},
  new Rule{Code="search-highlights-off",Title="Busca: ocultar destaques e conteúdo dinâmico",Category="Windows leve",Minimum=22621,Edition=1,
   Effect="Retira destaques da busca. Mantém pesquisa local e indexação.",Tradeoff="Política global; Windows 11 22H2 ou posterior. Não altera os resultados de busca na web. Confira após nova sessão.",
   Source=SearchSource+"#allowsearchhighlights",Operations=new[]{Device(SearchKey,"EnableDynamicContentInWSB","0")}},
  new Rule{Code="search-taskbar-hide",Title="Windows 11: ocultar busca na barra",Category="Personalização",Minimum=26100,Edition=1,
   Effect="Oculta a entrada visual de busca da barra de tarefas.",Tradeoff="Aparência, sem promessa de FPS. Política global no Windows 11 24H2+; bloqueia a escolha na barra até desfazer. A busca pelo menu Iniciar continua disponível.",
   Source=SearchSource+"#configuresearchontaskbarmode",Operations=new[]{Device(SearchKey,"SearchOnTaskbarMode","0")}},
  new Rule{Code="indexer-backoff",Title="Busca: permitir reduzir indexação sob carga",Category="Windows leve",Minimum=14393,Edition=1,
   Effect="Permite ao indexador reduzir atividade quando o PC está ocupado.",Tradeoff="Pode ajudar se um ajuste anterior desativou esse recuo. Já é o comportamento padrão; indexação completa pode levar mais tempo.",
   Source=SearchSource+"#disablebackoff",Operations=new[]{Device(SearchKey,"DisableBackoff","0")}},
  new Rule{Code="delivery-no-peers",Title="Atualizações: desligar compartilhamento entre PCs",Category="Rede e downloads",Minimum=19041,Edition=1,
   Effect="Desativa envio/recebimento de conteúdo por pares no Delivery Optimization; mantém downloads da fonte HTTP/cache configurado.",Tradeoff="Pode reduzir tráfego de compartilhamento, mas cada PC poderá baixar mais da internet. Não limita o download de atualizações nem de jogos; política para todos os usuários.",
   Source="https://learn.microsoft.com/en-us/windows/deployment/do/waas-delivery-optimization-reference#download-mode",Operations=new[]{Device(@"SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization","DODownloadMode","0")}},
  new Rule{Code="theme-dark",Title="Tema escuro para Windows e apps",Category="Personalização",Minimum=18362,
   Effect="Define a preferência de cores escuras para o sistema e apps compatíveis.",Tradeoff="Personalização, sem ganho de FPS. Apps podem usar tema próprio; confira após reabri-los ou entrar novamente. Mantém papel de parede, fontes e suavização.",
   Source=DevSource,Operations=new[]{User(ThemeKey,"AppsUseLightTheme","0"),User(ThemeKey,"SystemUsesLightTheme","0")}},
  new Rule{Code="theme-light",Title="Tema claro para Windows e apps",Category="Personalização",Minimum=18362,
   Effect="Define a preferência de cores claras para o sistema e apps compatíveis.",Tradeoff="Alternativa ao tema escuro, sem ganho de FPS. Apps podem usar tema próprio; confira após reabri-los ou entrar novamente. O histórico restaura inclusive combinações diferentes de tema.",
   Source=DevSource,Operations=new[]{User(ThemeKey,"AppsUseLightTheme","1"),User(ThemeKey,"SystemUsesLightTheme","1")}},
  new Rule{Code="file-extensions",Title="Explorer: mostrar extensões de arquivos",Category="Personalização",
   Effect="Exibe extensões como .exe, .zip e .reg para identificar melhor os arquivos.",Tradeoff="Preferência visual sem ganho de FPS. Não renomeia nem modifica arquivos. Pode exigir reabrir o Explorer ou nova sessão.",
   Source=DevSource,Operations=new[]{User(ExplorerKey,"HideFileExt","0")}},
  new Rule{Code="explorer-compact",Title="Windows 11: Explorer compacto",Category="Personalização",Minimum=22000,Product="compact",
   Effect="Reduz o espaço entre itens nas listas do Explorer.",Tradeoff="Personalização sem ganho de FPS; áreas de toque ficam menores. Aplicável apenas quando o próprio Windows expõe o mapeamento de Compact view. Reabra o Explorer ou entre novamente.",
   Source="https://support.microsoft.com/en-US/Windows/Experience/FileExplorer/file-explorer-in-windows",Operations=new[]{User(ExplorerKey,"UseCompactMode","1")}},
  new Rule{Code="third-party-suggestions-off",Title="Spotlight: reduzir sugestões de terceiros",Category="Windows leve",Minimum=14393,Edition=1,
   Effect="Impede sugestões de apps e conteúdo de terceiros nos recursos Spotlight.",Tradeoff="Sugestões da Microsoft podem continuar. Política do usuário; não desinstala apps nem altera Windows Update. Confira após nova sessão.",
   Source=ExperienceSource+"#allowthirdpartysuggestionsinwindowsspotlight",Operations=new[]{User(@"Software\Policies\Microsoft\Windows\CloudContent","DisableThirdPartySuggestions","1")}},
  new Rule{Code="spotlight-off",Title="Enterprise/Education: desligar conteúdo Spotlight",Category="Windows leve",Minimum=14393,Edition=2,
   Effect="Desliga os recursos de conteúdo Spotlight para reduzir esse tráfego e sugestões.",Tradeoff="Perde imagens e sugestões dinâmicas do Spotlight. Política do usuário, suportada em Enterprise/Education/IoT Enterprise; não aplicável em Home/Pro.",
   Source=ExperienceSource+"#allowwindowsspotlight",Operations=new[]{User(@"Software\Policies\Microsoft\Windows\CloudContent","DisableWindowsSpotlightFeatures","1")}},
  new Rule{Code="firefox-telemetry",Title="Firefox: não enviar telemetria (privacidade)",Category="Privacidade opcional",Product="firefox",ProductMinimum=60,
   Effect="Configura a política DisableTelemetry do Firefox.",Tradeoff="Escolha de privacidade, sem ganho de FPS comprovado. Reduz dados disponíveis à Mozilla para diagnóstico. Reabra e confira about:policies; atualizações, proteção e sincronização ficam preservadas.",
   Source="https://firefox-admin-docs.mozilla.org/reference/policies/disabletelemetry/",Operations=new[]{Device(@"SOFTWARE\Policies\Mozilla\Firefox","DisableTelemetry","1")}},
  new Rule{Code="office-telemetry",Title="Microsoft 365: não enviar diagnóstico (privacidade)",Category="Privacidade opcional",Product="office365",
   Effect="Define SendTelemetry=3 para diagnóstico do cliente Office compatível.",Tradeoff="Não acelera jogos. Reduz informações para solucionar falhas; dados necessários dos serviços ainda podem ser enviados. Preserva licenciamento, atualizações e recursos conectados. Reabra os apps e confirme em Conta > Privacidade.",
   Source="https://learn.microsoft.com/en-us/microsoft-365-apps/privacy/manage-privacy-controls#control-privacy-settings-by-editing-the-registry",Operations=new[]{User(@"Software\Policies\Microsoft\office\common\clienttelemetry","SendTelemetry","3")}},
  Repair("repair-run","Reparar acesso ao Executar",@"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer","NoRun","https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-admx-startmenu#norun"),
  Repair("repair-controlpanel","Reparar acesso ao Painel de Controle",@"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer","NoControlPanel","https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-admx-controlpanel#nocontrolpanel"),
  Repair("repair-folderoptions","Reparar acesso às Opções de Pasta",@"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer","NoFolderOptions","https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-admx-windowsexplorer#nofolderoptions"),
  Repair("repair-contextmenu","Reparar menu de contexto do Explorer",@"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer","NoViewContextMenu","https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-admx-windowsexplorer#noviewcontextmenu"),
  Repair("repair-taskmgr","Reparar acesso ao Gerenciador de Tarefas",@"Software\Microsoft\Windows\CurrentVersion\Policies\System","DisableTaskMgr","https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-admx-ctrlaltdel#disabletaskmgr"),
  Repair("repair-regedit","Reparar acesso ao Editor do Registro",@"Software\Microsoft\Windows\CurrentVersion\Policies\System","DisableRegistryTools","https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-admx-shellcommandpromptregedittools#disableregedit"),
  Repair("repair-cmd","Reparar acesso ao Prompt de Comando",@"Software\Policies\Microsoft\Windows\System","DisableCMD","https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-admx-shellcommandpromptregedittools#disablecmd")
 };

 internal static List<Item> Items(){
  return Rules.Select(r=>new Item{Id=Prefix+r.Code,Name=r.Title,ReviewTitle=r.Title,Category="-3 - "+r.Category,
   Path="Preferência revisada V5 / "+r.Title,Mode="Nativo",Type="Nativo",Native=true,ActionCode="v5registry",Available=true,
   ManualAllowed=true,MaxEligible=false,DefaultSelected=false,ReviewLevel=r.Operations.Any(App.IsPolicy)?"Manual":"Revisado",Review=new[]{r.Effect,r.Tradeoff,"Backup exato no Histórico; aplicar confirma valores, não mede FPS nem comprova que o aplicativo adotou a política."},
   Notes=new string[0],Conflicts=r.Code=="theme-dark"?new[]{Prefix+"theme-light"}:r.Code=="theme-light"?new[]{Prefix+"theme-dark"}:new string[0],
   SameTargets=new string[0],Operations=r.Operations.Select(o=>new RegOp{Hive=o.Hive,Key=o.Key,Name=o.Name,Kind=o.Kind,Data=o.Data,Delete=o.Delete}).ToArray(),
   Asset="",Hash="",Text="",Url=r.Source,Blocked=""}).ToList();
 }
 internal static List<PerformanceEntry> LibraryEntries(){
  return Rules.Select(r=>new PerformanceEntry{Id="v5-option-"+r.Code,Title=r.Title,Category=r.Category,Mode="Aplicável com backup",Action="native",Target=Prefix+r.Code,
   Effect=r.Effect,Tradeoff=r.Tradeoff,Source=r.Source,
   Steps="Revise o efeito e aplique somente se desejar esta opção. O Histórico guarda o estado exato para desfazer. Versão, edição e aplicativo compatível são conferidos antes da gravação."}).ToList();
 }
 internal static bool IsOption(Item item){return item!=null&&Rules.Any(x=>Prefix+x.Code==item.Id);}
 // A faixa de build ja esta declarada em cada Rule. Expor aqui evita que a camada de
 // contrato (Optimizations.cs) repita os numeros a mao e eles envelhecam em dobro.
 // maximum 0 significa "sem limite superior".
 internal static bool BuildRange(string id,out int minimum,out int maximum){
  minimum=0;maximum=0;
  var r=Rules.FirstOrDefault(x=>Prefix+x.Code==id);if(r==null)return false;
  minimum=r.Minimum<=10240?0:r.Minimum;maximum=r.Maximum==Int32.MaxValue?0:r.Maximum;return true;
 }
 internal static string Compatibility(Item item,Machine machine){
  if(!IsOption(item))return null;
  var r=Rules.SingleOrDefault(x=>Prefix+x.Code==item.Id);if(r==null)return "Preferência V5 não reconhecida.";
  if(machine==null||!machine.Windows||machine.Build<r.Minimum||machine.Build>r.Maximum)return "Não disponível nesta versão do Windows; confira a versão indicada na descrição.";
  if(r.Edition>0&&!SupportedEdition(machine.Edition,r.Edition==2))return "A edição do Windows não oferece suporte documentado a esta política. Use as Configurações do próprio Windows.";
  if(r.Product=="repair")return RepairIssue(r.Operations[0]);
  if(r.Product=="compact"&&!HasCompactMapping())return "Este Explorer não expõe o mapeamento revisado de Compact view. Use Exibir > Exibição compacta manualmente.";
  if(r.Product=="office365"&&!HasSupportedOffice())return "Requer Microsoft 365 Apps para empresas identificado no Click-to-Run (versão 1904+). Confira privacidade dentro do Office.";
  if(r.Product=="edge"||r.Product=="chrome"||r.Product=="firefox")if(BrowserMajor(r.Product)<r.ProductMinimum)return "Navegador compatível não encontrado nos locais conhecidos. Use as configurações do próprio navegador.";
 return null;
 }
 static string RepairIssue(RegOp op){
  var current=App.Capture(op).Before;
  if(!current.Delete&&(current.Kind!="DWord"||(current.Data!="0"&&current.Data!="1"&&current.Data!="2")))return "Restrição com formato inesperado. Nenhum valor será removido.";
  if(!current.Delete&&current.Data=="0")return "Esta restrição já está desativada; o valor explícito será preservado.";
  var machineOp=new RegOp{Hive="HKEY_LOCAL_MACHINE",Key=op.Key,Name=op.Name,Kind="DWord",Data="",Delete=true};
  var device=App.Capture(machineOp).Before;
  if(!device.Delete&&(device.Kind!="DWord"||device.Data!="0"))return "Há uma restrição do computador para esta ferramenta. Este reparo não modifica políticas de computador.";
  return null;
 }
 static bool SupportedEdition(string edition,bool enterpriseOnly){
  string e=(edition??"").ToLowerInvariant();bool enterprise=e=="enterprise"||e=="enterprisen"||e=="enterprises"||e=="enterprisesn"||e=="education"||e=="educationn"||e=="iotenterprise"||e=="iotenterprises";
  return enterprise||(!enterpriseOnly&&(e=="professional"||e=="professionaln"||e=="professionalworkstation"||e=="professionalworkstationn"||e=="professionaleducation"||e=="professionaleducationn"));
 }
#if TESTS
 internal static Func<string,int> TestBrowserMajor;
 internal static Func<string,bool> TestFeature;
#endif
 static int BrowserMajor(string product){
#if TESTS
  if(TestBrowserMajor!=null)return TestBrowserMajor(product);
#endif
  string relative=product=="edge"?@"Microsoft\Edge\Application\msedge.exe":product=="chrome"?@"Google\Chrome\Application\chrome.exe":@"Mozilla Firefox\firefox.exe";
  int version=0;foreach(var root in new[]{Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)}){
   try{string path=Path.Combine(root,relative);if(root.Length>0&&File.Exists(path))version=Math.Max(version,FileVersionInfo.GetVersionInfo(path).FileMajorPart);}catch{}
  }return version;
 }
 static bool HasCompactMapping(){
#if TESTS
  if(TestFeature!=null)return TestFeature("compact");
#endif
  try{using(var hive=RegistryKey.OpenBaseKey(RegistryHive.LocalMachine,RegistryView.Registry64))using(var key=hive.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced\Folder\UseCompactMode",false)){
   return key!=null&&unchecked((uint)Convert.ToInt64(key.GetValue("HKeyRoot")))==0x80000001u&&String.Equals(Convert.ToString(key.GetValue("RegPath")),ExplorerKey,StringComparison.OrdinalIgnoreCase)&&Convert.ToString(key.GetValue("ValueName"))=="UseCompactMode"&&Convert.ToString(key.GetValue("CheckedValue"))=="1"&&Convert.ToString(key.GetValue("UncheckedValue"))=="0";
  }}catch{return false;}
 }
 static bool HasSupportedOffice(){
#if TESTS
  if(TestFeature!=null)return TestFeature("office365");
#endif
  foreach(var view in new[]{RegistryView.Registry64,RegistryView.Registry32})try{using(var hive=RegistryKey.OpenBaseKey(RegistryHive.LocalMachine,view))using(var key=hive.OpenSubKey(@"SOFTWARE\Microsoft\Office\ClickToRun\Configuration",false)){
   if(key==null)continue;string products=Convert.ToString(key.GetValue("ProductReleaseIds"));Version version;
   if(products.Split(new[]{','}).Any(x=>x.Trim().StartsWith("O365ProPlus",StringComparison.OrdinalIgnoreCase)||x.Trim().StartsWith("O365Business",StringComparison.OrdinalIgnoreCase))&&Version.TryParse(Convert.ToString(key.GetValue("VersionToReport")),out version)&&version.Major==16&&version.Build>=11601)return true;
  }}catch{}return false;
 }
}

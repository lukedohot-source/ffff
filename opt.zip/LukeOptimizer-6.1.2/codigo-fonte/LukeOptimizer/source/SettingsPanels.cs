using System;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections.Generic;

// PAINÉIS COMPACTOS — uma linha por configuração.
//
// A regra do pedido: linha compacta com interruptor à direita, agrupada por assunto, sem
// um cartão gigante por opção. Centenas de configurações precisam caber sem rolar
// quilômetros, e a explicação técnica só aparece quando pedida.
//
// Três tipos de controle, e a escolha entre eles não é estética:
//
//   INTERRUPTOR  para configuração que só tem dois estados (ligada/desligada).
//   CAIXA        quando há mais de dois estados. Três interruptores que se excluem
//                mentem sobre a natureza da escolha — "Sempre", "Quando cheia" e
//                "Nunca" não são três chaves independentes, são uma decisão só.
//   BOTÃO        para AÇÃO. Rodar uma verificação de arquivos não é um estado que se
//                mantém ligado; virar isso interruptor seria mentira de interface.
//
// Nada aqui aplica sozinho. Marcar acumula ALTERAÇÃO PENDENTE, e a barra de baixo mostra
// quantas são, deixa revisar antes e aplicar em lote — uma elevação para o conjunto.
public partial class MainForm {
 class PanelState {
  internal string Panel="";
  internal FlowLayoutPanel Flow;
  internal Label Pending;
  internal TextBox Search;
  internal CheckBox ShowAdvanced,ShowIncompatible;
  internal readonly Dictionary<string,ToggleSwitch> Toggles=new Dictionary<string,ToggleSwitch>();
  internal readonly Dictionary<string,ComboBox> Picks=new Dictionary<string,ComboBox>();
  internal readonly List<Surface> Cards=new List<Surface>();
  internal readonly List<Button> Actions=new List<Button>();
 }
 readonly Dictionary<string,PanelState> settingPanels=new Dictionary<string,PanelState>();

 // Indicador pequeno ao lado do nome, nunca uma faixa colorida gigante.
 static string RiskMark(WindowsSetting setting){
  if(setting.Risk=="recomendado")return "✓";
  if(setting.Risk=="avançado")return "⚠";
  if(setting.Risk=="experimental")return "🧪";
  if(setting.Risk=="segurança")return "🔒";
  return "";
 }
 static bool IsAdvanced(WindowsSetting setting){return setting.Risk=="avançado"||setting.Risk=="experimental";}

 void BuildSettingsPanels(){
  foreach(string panel in WindowsSettings.Panels())BuildSettingsPanel(panel);
 }

 void BuildSettingsPanel(string panel){
  var page=Page(panel);
  var root=Rows(40,44,-1,54);page.Controls.Add(root);
  var state=new PanelState{Panel=panel};settingPanels[panel]=state;

  root.Controls.Add(Theme.Label(PanelIntro(panel),9,Theme.Muted),0,0);

  var filters=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false,AutoScroll=true,Margin=Padding.Empty};root.Controls.Add(filters,0,1);
  state.Search=new TextBox{Width=280,Font=Theme.Font(10),BackColor=Theme.Card,ForeColor=Theme.Text,
   Name="settings-search-"+panel,AccessibleName="Buscar em "+panel};
  filters.Controls.Add(state.Search);
  state.ShowAdvanced=new ToggleSwitch{Text="Mostrar avançadas e experimentais",AutoSize=false,Width=286,Height=34,
   ForeColor=Theme.Muted,BackColor=Theme.Bg,Name="settings-advanced-"+panel,AccessibleName="Mostrar avançadas e experimentais",Checked=false};
  filters.Controls.Add(state.ShowAdvanced);
  // Item 176: incompatível fica escondido por padrão, com filtro para revelar — em vez
  // de aparecer clicável e falhar depois.
  state.ShowIncompatible=new ToggleSwitch{Text="Mostrar não compatíveis",AutoSize=false,Width=222,Height=34,
   ForeColor=Theme.Muted,BackColor=Theme.Bg,Name="settings-incompatible-"+panel,AccessibleName="Mostrar não compatíveis",Checked=false};
  filters.Controls.Add(state.ShowIncompatible);

  state.Flow=new FlowLayoutPanel{Dock=DockStyle.Fill,AutoScroll=true,WrapContents=true,Padding=new Padding(0,0,8,8),Name="settings-flow-"+panel};
  root.Controls.Add(state.Flow,0,2);

  var bar=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false,AutoScroll=true,Margin=Padding.Empty};root.Controls.Add(bar,0,3);
  state.Pending=Theme.Label("Nenhuma alteração pendente.",10,Theme.Accent,true);
  state.Pending.Dock=DockStyle.None;state.Pending.Size=new Size(250,38);state.Pending.Name="settings-pending-"+panel;
  bar.Controls.Add(state.Pending);
  string key=panel;
  bar.Controls.Add(PanelButton(state,"settings-discard-"+panel,"Descartar",(s,e)=>{ClearPanel(key);},130,false));
  bar.Controls.Add(PanelButton(state,"settings-review-"+panel,"Revisar",async(s,e)=>await ReviewPanel(key,false),130,false));
  bar.Controls.Add(PanelButton(state,"settings-apply-"+panel,"Aplicar alterações",async(s,e)=>await ReviewPanel(key,true),190,true));
  bar.Controls.Add(PanelButton(state,"settings-defaults-"+panel,"Restaurar padrões",async(s,e)=>await RestorePanelDefaults(key),180,false));

  BuildPanelCards(state);
  state.Search.TextChanged+=(s,e)=>FilterPanel(key);
  state.ShowAdvanced.CheckedChanged+=(s,e)=>FilterPanel(key);
  state.ShowIncompatible.CheckedChanged+=(s,e)=>FilterPanel(key);
  UpdatePanelPending(key);
 }

 Button PanelButton(PanelState state,string name,string text,EventHandler handler,int width,bool primary){
  var button=Theme.Button(text,primary);button.Name=name;button.Width=width;button.Height=36;
  button.Margin=new Padding(0,0,8,0);button.Click+=handler;state.Actions.Add(button);return button;
 }

 static string PanelIntro(string panel){
  if(panel=="Privacidade")return "Cada linha é UMA configuração, com o que ela faz escrito em português. Não existe aqui um botão \"desativar tudo\": você escolhe o que muda.";
  if(panel=="Jogos")return "Marque o que quer mudar e aplique em lote. As opções marcadas 🧪 são experimentais: mexem no agendador do Windows e não têm ganho comprovado.";
  if(panel=="Windows Update")return "Como e quando este PC recebe atualizações. Desligar atualização de segurança não é otimização — é risco.";
  return "Marque as linhas que quer mudar. Nada é aplicado enquanto você não clicar em Aplicar, e tudo tem desfazer pelo Histórico.";
 }

 void BuildPanelCards(PanelState state){
  state.Flow.SuspendLayout();
  foreach(Control control in state.Flow.Controls.Cast<Control>().ToArray())control.Dispose();
  state.Cards.Clear();state.Toggles.Clear();state.Picks.Clear();
  foreach(string group in WindowsSettings.GroupsOf(state.Panel)){
   var card=new Surface{Width=452,Padding=new Padding(14,10,14,10),Margin=new Padding(0,0,12,12),
    Name="settings-card-"+state.Panel+"-"+group};
   state.Cards.Add(card);state.Flow.Controls.Add(card);
   var body=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=1,Margin=Padding.Empty};card.Controls.Add(body);
   var header=Theme.Label(group.ToUpperInvariant(),9,Theme.Muted,true);header.Dock=DockStyle.Top;header.Height=26;body.Controls.Add(header);
   foreach(var setting in WindowsSettings.All().Where(s=>s.Panel==state.Panel&&s.Group==group))
    body.Controls.Add(BuildSettingRow(state,setting));
   card.Height=body.PreferredSize.Height+24;
  }
  state.Flow.ResumeLayout();
 }

 Control BuildSettingRow(PanelState state,WindowsSetting setting){
  var row=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=2,Margin=new Padding(0,0,0,2),
   Name="settings-row-"+setting.Id};
  row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
  row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,34));
  string mark=RiskMark(setting);
  string label=setting.Name+(mark.Length>0?"  "+mark:"")+(setting.Restart?"  ↻":"");

  if(setting.IsChoice){
   var line=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=2,Margin=Padding.Empty};
   line.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
   line.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,186));
   var text=Theme.Label(label,10,Theme.Text);text.Dock=DockStyle.Fill;text.Height=28;
   line.Controls.Add(text,0,0);
   var combo=Combo();combo.Dock=DockStyle.None;combo.Width=180;combo.Name="settings-pick-"+setting.Id;
   combo.Items.Add("Não alterar");
   foreach(var choice in setting.Choices)combo.Items.Add(choice.Label);
   combo.SelectedIndex=0;
   string panel=state.Panel;
   combo.SelectedIndexChanged+=(s,e)=>UpdatePanelPending(panel);
   state.Picks[setting.Id]=combo;
   line.Controls.Add(combo,1,0);
   row.Controls.Add(line,0,0);
  }else{
   var toggle=new ToggleSwitch{Text=label,Dock=DockStyle.Fill,Margin=new Padding(0,0,4,0),
    ForeColor=Theme.Text,BackColor=Theme.Card,Font=Theme.Font(9.5f),
    Name="settings-toggle-"+setting.Id,AccessibleName=setting.Name,Height=28};
   string panel=state.Panel;
   toggle.CheckedChanged+=(s,e)=>{toggle.BackColor=toggle.Checked?Theme.Selection:Theme.Card;toggle.Invalidate();UpdatePanelPending(panel);};
   state.Toggles[setting.Id]=toggle;
   row.Controls.Add(toggle,0,0);
  }

  // ⓘ — detalhes sob demanda (item 7). A tela principal continua simples.
  var info=Theme.Button("ⓘ");info.Width=30;info.Height=26;info.Margin=new Padding(0,1,0,1);
  info.Name="settings-info-"+setting.Id;
  var current=setting;
  info.Click+=async(s,e)=>await InlineReview(current.Name,SettingSheet(current),false);
  row.Controls.Add(info,1,0);

  var summary=Theme.Label(setting.Summary,8.5f,Theme.Muted);
  summary.Dock=DockStyle.Top;summary.AutoEllipsis=false;summary.Height=setting.Summary.Length>96?32:18;
  summary.Margin=new Padding(0,0,0,4);
  var holder=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=1,Margin=Padding.Empty};
  holder.Controls.Add(row);holder.Controls.Add(summary);
  return holder;
 }

 // A ficha do item 7, inteira, em um texto só.
 internal string SettingSheet(WindowsSetting setting){
  var b=new StringBuilder();
  b.AppendLine(setting.Name).AppendLine();
  b.AppendLine("O QUE FAZ").AppendLine(setting.Summary).AppendLine();
  var items=CatalogIdsFor(setting);
  b.AppendLine("ESTADO ATUAL");
  foreach(var item in items){
   var observed=App.Observe(item,machine);
   b.AppendLine("  "+(setting.IsChoice?item.ReviewTitle:"neste PC")+": "+observed.State+(String.IsNullOrEmpty(observed.Detail)?"":" — "+observed.Detail));
  }
  b.AppendLine();
  b.AppendLine("CLASSIFICAÇÃO").AppendLine("  "+setting.Risk+(setting.Risk=="experimental"?" — sem ganho comprovado; existe porque você pediu para poder testar":""));
  b.AppendLine("  Reinício: "+(setting.Restart?"necessário":setting.SignOut?"basta sair e entrar de novo":"não"));
  b.AppendLine("  Administrador: "+(setting.Administrator?"sim":"não"));
  b.AppendLine("  Compatibilidade: "+(setting.MinBuild>0?"exige build "+setting.MinBuild+" ou mais recente"+(machine!=null&&machine.Build>0?"; este PC tem "+machine.Build:""):"Windows 10 e 11"));
  b.AppendLine();
  b.AppendLine("COMO VOLTAR ATRÁS");
  b.AppendLine("  O valor anterior é gravado no Histórico antes da mudança. Desfazer restaura exatamente o que havia, e recusa sobrescrever se outro programa tiver mudado o valor depois.");
  b.AppendLine();
  b.AppendLine("DETALHES TÉCNICOS");
  b.AppendLine("  "+setting.Technical);
  if(setting.Aliases.Length>0)b.AppendLine("  Também conhecido como: "+String.Join(", ",setting.Aliases));
  b.AppendLine("  Fonte: "+setting.Source);
  if(App.DeveloperMode&&setting.References.Length>0)
   b.AppendLine().AppendLine("ORIGEM DA PESQUISA (modo desenvolvedor)").AppendLine("  "+String.Join(", ",setting.References));
  return b.ToString();
 }
 List<Item> CatalogIdsFor(WindowsSetting setting){
  var result=new List<Item>();
  if(setting.IsChoice){for(int n=0;n<setting.Choices.Length;n++){var item=App.ById(setting.Id+"-"+(n+1));if(item!=null)result.Add(item);}}
  else{var item=App.ById(setting.Id);if(item!=null)result.Add(item);}
  return result;
 }

 // Ids escolhidos AGORA neste painel: interruptores marcados + escolhas que saíram de
 // "Não alterar".
 internal string[] PanelSelection(string panel){
  PanelState state;
  if(!settingPanels.TryGetValue(panel,out state))return new string[0];
  var ids=new List<string>();
  foreach(var pair in state.Toggles)if(pair.Value.Checked)ids.Add(pair.Key);
  foreach(var pair in state.Picks)if(pair.Value.SelectedIndex>0)ids.Add(pair.Key+"-"+pair.Value.SelectedIndex);
  return ids.ToArray();
 }
 void UpdatePanelPending(string panel){
  PanelState state;
  if(!settingPanels.TryGetValue(panel,out state)||state.Pending==null)return;
  int count=PanelSelection(panel).Length;
  state.Pending.Text=count==0?"Nenhuma alteração pendente."
   :count==1?"1 ALTERAÇÃO PENDENTE":count+" ALTERAÇÕES PENDENTES";
  var apply=state.Actions.FirstOrDefault(b=>b.Name=="settings-apply-"+panel);
  if(apply!=null)apply.Text=count==0?"Aplicar alterações":"Aplicar "+count+" alteraç"+(count==1?"ão":"ões");
 }
 void ClearPanel(string panel){
  PanelState state;
  if(!settingPanels.TryGetValue(panel,out state))return;
  foreach(var toggle in state.Toggles.Values)toggle.Checked=false;
  foreach(var pick in state.Picks.Values)pick.SelectedIndex=0;
  UpdatePanelPending(panel);
 }
 void FilterPanel(string panel){
  PanelState state;
  if(!settingPanels.TryGetValue(panel,out state))return;
  string term=state.Search==null?"":state.Search.Text;
  bool advanced=state.ShowAdvanced!=null&&state.ShowAdvanced.Checked;
  bool incompatible=state.ShowIncompatible!=null&&state.ShowIncompatible.Checked;
  state.Flow.SuspendLayout();
  foreach(var card in state.Cards){
   string group=card.Name.Substring(("settings-card-"+state.Panel+"-").Length);
   int visible=0;
   foreach(Control holder in card.Controls[0].Controls){
    var settings=WindowsSettings.All().Where(s=>s.Panel==state.Panel&&s.Group==group).ToArray();
    string id=RowId(holder);
    if(id==null)continue;
    var setting=settings.FirstOrDefault(s=>s.Id==id);
    if(setting==null)continue;
    bool show=WindowsSettings.Matches(setting,term)&&(advanced||!IsAdvanced(setting))&&(incompatible||PanelCompatible(setting));
    // NUNCA reler holder.Visible: o getter devolve visibilidade EFETIVA e a página
    // pode estar oculta. O estado do filtro vem do cálculo, não da UI.
    holder.Visible=show;
    if(show)visible++;
   }
   card.Visible=visible>0;
  }
  state.Flow.ResumeLayout();
 }
 static string RowId(Control holder){
  foreach(Control child in holder.Controls)
   if(child.Name!=null&&child.Name.StartsWith("settings-row-",StringComparison.Ordinal))
    return child.Name.Substring("settings-row-".Length);
  return null;
 }
 bool PanelCompatible(WindowsSetting setting){
  if(setting.MinBuild<=0)return true;
  if(machine==null||machine.Build<=0)return true;   // sem leitura confiável, não esconde
  return machine.Build>=setting.MinBuild;
 }

 // REVISAR e APLICAR compartilham o mesmo texto: o que a pessoa lê antes de confirmar é
 // exatamente o que ela veria em Revisar. Item 171.
 async Task ReviewPanel(string panel,bool apply){
  if(busy||scanning||resourceScanning||easyRunning||productRunning)return;
  var ids=PanelSelection(panel);
  if(ids.Length==0){
   await InlineReview("Nenhuma alteração pendente","Marque uma opção — ou escolha um valor numa das caixas — e o resumo aparece aqui antes de qualquer alteração.",false);
   return;
  }
  var text=new StringBuilder();
  text.AppendLine(ids.Length+" alteração(ões) pendente(s) em "+panel).AppendLine();
  foreach(string id in ids){
   var item=App.ById(id);
   var setting=WindowsSettings.All().FirstOrDefault(s=>id==s.Id||id.StartsWith(s.Id+"-",StringComparison.Ordinal));
   if(item==null||setting==null)continue;
   var observed=App.Observe(item,machine);
   text.AppendLine("· "+item.ReviewTitle);
   text.AppendLine("   Agora:    "+observed.State+(String.IsNullOrEmpty(observed.Detail)?"":" — "+observed.Detail));
   text.AppendLine("   Vai ficar: "+setting.Summary);
   text.AppendLine("   Risco: "+setting.Risk+"   ·   Reinício: "+(setting.Restart?"sim":setting.SignOut?"sair e entrar":"não")+
    "   ·   Administrador: "+(setting.Administrator?"sim":"não"));
   text.AppendLine("   Desfazer: pelo Histórico, restaurando o valor gravado antes desta mudança.");
   text.AppendLine();
  }
  text.AppendLine("O estado anterior de CADA item é gravado antes da primeira alteração. Se a gravação falhar, nada é alterado.");
  if(!apply){await InlineReview("Revisar alterações — "+panel,text.ToString(),false);return;}
  text.AppendLine().AppendLine("Aplicar agora?");
  if(!await InlineReview("Aplicar "+ids.Length+" alteração(ões)",text.ToString(),true))return;
  if(await Elevated("--apply-many",String.Join(",",ids)))ClearPanel(panel);
 }

 // Item 172: cada painel pode voltar ao padrão. Usa o Histórico — não um "valor padrão"
 // inventado pelo app, que seria chute sobre a máquina da pessoa.
 async Task RestorePanelDefaults(string panel){
  if(busy||scanning||resourceScanning||easyRunning||productRunning)return;
  var applied=records.FirstOrDefault(App.CanUndo);
  if(applied==null){
   await InlineReview("Nada para restaurar","Este painel restaura os valores que o LukeOptimizer gravou ANTES de alterar. Como ele ainda não alterou nada neste PC, não há valor anterior guardado.\r\n\r\nInventar um \"padrão de fábrica\" seria chute: o padrão do seu Windows depende da edição, da build e do que veio do fabricante.",false);
   return;
  }
  var ids=WindowsSettings.All().Where(s=>s.Panel==panel).SelectMany(s=>CatalogIdsFor(s)).Select(i=>i.Id).ToArray();
  if(ids.Length==0)return;
  string text="Backup: "+applied.Name+"\r\n\r\nAs configurações deste painel voltam ao valor gravado nesse backup.\r\n\r\n"+
   "Só entram as que estão nesse backup; as demais são ignoradas com o motivo escrito. Se outro programa alterou um valor depois, a restauração recusa sobrescrever em vez de apagar a mudança em silêncio.\r\n\r\nRequer administrador.";
  if(!await InlineReview("Restaurar padrões — "+panel,text,true))return;
  await Elevated("--restore-selection",applied.Id+"|"+String.Join(",",ids));
 }
}

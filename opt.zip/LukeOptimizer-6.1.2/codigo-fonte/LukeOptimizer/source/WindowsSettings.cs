using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

// CONFIGURAÇÕES DO WINDOWS — painéis compactos.
//
// Origem deste arquivo: a auditoria dos quatro projetos de referência (Winhance,
// Win11Debloat, Sophia Script, optimizerNXT). Ver REFERENCE_PARITY_REPORT.md.
//
// ---------------------------------------------------------------------------------
// LICENÇAS — por que aqui não há código de ninguém
//
// Win11Debloat e Sophia Script são MIT: permitem reuso com aviso preservado.
// Winhance é PolyForm Shield 1.0.0 — licença FONTE-DISPONÍVEL, não open source, que
// proíbe uso concorrente. optimizerNXT é GPL-3.0, cujo copyleft obrigaria este produto
// inteiro a virar GPLv3.
//
// Por isso nada aqui é código copiado. O que foi aproveitado é FATO TÉCNICO: qual valor
// do Registro o Windows lê para um determinado comportamento. Cada ajuste abaixo aponta
// para a documentação da Microsoft, e cada um foi conferido em MAIS DE UMA referência
// independente antes de entrar — quando quatro projetos que não se falam escrevem o
// mesmo valor, o fato está confirmado. Os que apareciam numa referência só e que eu não
// consegui confirmar ficaram DE FORA, listados como ausentes no relatório.
// ---------------------------------------------------------------------------------
//
// DEDUPLICAÇÃO: nada aqui repete par (chave, valor) que o LukeOptimizer já escreva. Há
// teste que percorre o catálogo inteiro e falha se dois ids diferentes gravarem o mesmo
// valor da mesma chave — é o que impede "Modo Jogo do Sophia" existir ao lado de "Modo
// Jogo do Winhance". Uma função, um id.
public class SettingChoice {
 public string Label="",Detail="";
 public RegOp[] Ops=new RegOp[0];
}
public class WindowsSetting {
 public string Id="",Name="",Summary="",Panel="",Group="",Risk="",Source="",Technical="";
 public bool Restart,Administrator,SignOut;
 public int MinBuild;                       // 0 = qualquer Windows 10/11
 public string[] Aliases=new string[0];     // termos técnicos que a busca também encontra
 public string[] References=new string[0];  // origens; só aparecem em Modo desenvolvedor
 public RegOp[] On=new RegOp[0];            // estado "ligado" de um interruptor
 public SettingChoice[] Choices=new SettingChoice[0];
 public bool IsChoice{get{return Choices.Length>0;}}
}

static class WindowsSettings {
 internal const string ExplorerAdvanced=@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced";
 const string DocTaskbar="https://learn.microsoft.com/en-us/windows/configuration/taskbar/";
 const string DocExplorer="https://learn.microsoft.com/en-us/windows/win32/shell/how-to-customize-the-explorer-namespace";
 const string DocPrivacy="https://learn.microsoft.com/en-us/windows/privacy/configure-windows-diagnostic-data-in-your-organization";
 const string DocGaming="https://learn.microsoft.com/en-us/windows-hardware/drivers/display/hardware-accelerated-gpu-scheduling";
 const string DocNotify="https://learn.microsoft.com/en-us/windows/apps/design/shell/tiles-and-notifications/notifications-visual-elements";
 const string DocUpdate="https://learn.microsoft.com/en-us/windows/deployment/update/waas-configure-wufb";
 const string DocMouse="https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-systemparametersinfow";

 static RegOp Cu(string key,string name,string data){return new RegOp{Hive="HKEY_CURRENT_USER",Key=key,Name=name,Data=data,Kind="DWord"};}
 static RegOp CuText(string key,string name,string data){return new RegOp{Hive="HKEY_CURRENT_USER",Key=key,Name=name,Data=data,Kind="String"};}
 static RegOp Lm(string key,string name,string data){return new RegOp{Hive="HKEY_LOCAL_MACHINE",Key=key,Name=name,Data=data,Kind="DWord"};}

 static WindowsSetting Toggle(string id,string panel,string group,string name,string summary,string risk,RegOp[] on,string source,string technical){
  return new WindowsSetting{Id=id,Panel=panel,Group=group,Name=name,Summary=summary,Risk=risk,On=on,Source=source,Technical=technical};
 }

 // ---------------------------------------------------------------------------------
 internal static List<WindowsSetting> All(){
  var list=new List<WindowsSetting>();

  // ============================================================ BARRA DE TAREFAS
  list.Add(Toggle("set-taskbar-taskview","Personalizar Windows","Barra de tarefas",
   "Botão Visão de Tarefas","Remove da barra o botão que mostra as áreas de trabalho e as janelas abertas. O atalho Windows+Tab continua funcionando.","opcional",
   new[]{Cu(ExplorerAdvanced,"ShowTaskViewButton","0")},DocTaskbar,
   "HKCU\\"+ExplorerAdvanced+" · ShowTaskViewButton = 0"));

  list.Add(Toggle("set-taskbar-widgets","Personalizar Windows","Barra de tarefas",
   "Widgets na barra","Remove o painel de notícias e tempo do canto da barra. Só afeta o botão; não desinstala nada.","opcional",
   new[]{Cu(ExplorerAdvanced,"TaskbarDa","0")},DocTaskbar,
   "HKCU\\"+ExplorerAdvanced+" · TaskbarDa = 0"));

  list.Add(Toggle("set-taskbar-endtask","Personalizar Windows","Barra de tarefas",
   "Finalizar tarefa no botão direito","Acrescenta \"Finalizar tarefa\" ao menu do botão direito na barra, para fechar um programa travado sem abrir o Gerenciador de tarefas.","recomendado",
   new[]{Cu(ExplorerAdvanced+@"\TaskbarDeveloperSettings","TaskbarEndTask","1")},DocTaskbar,
   "HKCU\\"+ExplorerAdvanced+"\\TaskbarDeveloperSettings · TaskbarEndTask = 1"));

  list.Add(Toggle("set-taskbar-seconds","Personalizar Windows","Barra de tarefas",
   "Segundos no relógio","Mostra os segundos ao lado da hora. Custa um pouco de energia porque o relógio passa a ser redesenhado a cada segundo.","opcional",
   new[]{Cu(ExplorerAdvanced,"ShowSecondsInSystemClock","1")},DocTaskbar,
   "HKCU\\"+ExplorerAdvanced+" · ShowSecondsInSystemClock = 1"));

  list.Add(Toggle("set-taskbar-lastactive","Personalizar Windows","Barra de tarefas",
   "Clicar no ícone alterna entre janelas","Com vários documentos do mesmo programa abertos, um clique no ícone volta para a última janela usada em vez de abrir a lista.","opcional",
   new[]{Cu(ExplorerAdvanced,"LastActiveClick","1")},DocTaskbar,
   "HKCU\\"+ExplorerAdvanced+" · LastActiveClick = 1"));

  list.Add(Toggle("set-taskbar-multimon","Personalizar Windows","Barra de tarefas",
   "Barra em todos os monitores","Mostra a barra de tarefas em cada monitor, não só no principal.","opcional",
   new[]{Cu(ExplorerAdvanced,"MMTaskbarEnabled","1")},DocTaskbar,
   "HKCU\\"+ExplorerAdvanced+" · MMTaskbarEnabled = 1"));

  // Mais de dois estados: é CAIXA DE ESCOLHA, não três interruptores que se contradizem.
  list.Add(new WindowsSetting{Id="set-taskbar-combine",Panel="Personalizar Windows",Group="Barra de tarefas",
   Name="Agrupar botões da barra",Summary="Decide quando janelas do mesmo programa viram um único botão.",Risk="opcional",
   Source=DocTaskbar,Technical="HKCU\\"+ExplorerAdvanced+" · TaskbarGlomLevel (0 sempre · 1 quando cheia · 2 nunca)",
   Choices=new[]{
    new SettingChoice{Label="Sempre agrupar",Detail="Um botão por programa, sem rótulo. É o padrão do Windows 11.",Ops=new[]{Cu(ExplorerAdvanced,"TaskbarGlomLevel","0")}},
    new SettingChoice{Label="Quando a barra estiver cheia",Detail="Mostra rótulo em cada janela e só agrupa quando falta espaço.",Ops=new[]{Cu(ExplorerAdvanced,"TaskbarGlomLevel","1")}},
    new SettingChoice{Label="Nunca agrupar",Detail="Um botão por janela, sempre com rótulo. Enche a barra rápido.",Ops=new[]{Cu(ExplorerAdvanced,"TaskbarGlomLevel","2")}}}});

  list.Add(new WindowsSetting{Id="set-taskbar-multimon-mode",Panel="Personalizar Windows",Group="Barra de tarefas",
   Name="Onde mostrar os aplicativos abertos",Summary="Com mais de um monitor, decide em qual barra cada janela aparece.",Risk="opcional",
   Source=DocTaskbar,Technical="HKCU\\"+ExplorerAdvanced+" · MMTaskbarMode (0 todas as barras · 1 principal + a da janela · 2 só a da janela)",
   Choices=new[]{
    new SettingChoice{Label="Em todas as barras",Ops=new[]{Cu(ExplorerAdvanced,"MMTaskbarMode","0")}},
    new SettingChoice{Label="Na principal e na do monitor da janela",Ops=new[]{Cu(ExplorerAdvanced,"MMTaskbarMode","1")}},
    new SettingChoice{Label="Só na barra do monitor da janela",Ops=new[]{Cu(ExplorerAdvanced,"MMTaskbarMode","2")}}}});

  // ================================================================ MENU INICIAR
  list.Add(Toggle("set-start-recommendations","Personalizar Windows","Menu Iniciar",
   "Recomendações e dicas no Iniciar","Desliga as sugestões que a Microsoft coloca na parte de baixo do menu Iniciar.","recomendado",
   new[]{Cu(ExplorerAdvanced,"Start_IrisRecommendations","0")},DocTaskbar,
   "HKCU\\"+ExplorerAdvanced+" · Start_IrisRecommendations = 0"));

  list.Add(Toggle("set-start-recent-docs","Personalizar Windows","Menu Iniciar",
   "Arquivos abertos recentemente","Deixa de listar no Iniciar e nas Listas de Atalhos os arquivos abertos há pouco. Útil em PC compartilhado.","opcional",
   new[]{Cu(ExplorerAdvanced,"Start_TrackDocs","0")},DocTaskbar,
   "HKCU\\"+ExplorerAdvanced+" · Start_TrackDocs = 0"));

  list.Add(Toggle("set-start-most-used","Personalizar Windows","Menu Iniciar",
   "Aplicativos mais usados","Deixa de destacar no Iniciar os programas que você mais abre.","opcional",
   new[]{Cu(ExplorerAdvanced,"Start_TrackProgs","0")},DocTaskbar,
   "HKCU\\"+ExplorerAdvanced+" · Start_TrackProgs = 0"));

  list.Add(Toggle("set-start-recent-list","Personalizar Windows","Menu Iniciar",
   "Itens recomendados por uso recente","Some a lista \"Recentes\" do painel de recomendações.","opcional",
   new[]{Cu(@"Software\Microsoft\Windows\CurrentVersion\Start","ShowRecentList","0")},DocTaskbar,
   "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Start · ShowRecentList = 0"));

  list.Add(Toggle("set-start-frequent-list","Personalizar Windows","Menu Iniciar",
   "Pastas usadas com frequência","Some a lista de pastas frequentes do painel de recomendações.","opcional",
   new[]{Cu(@"Software\Microsoft\Windows\CurrentVersion\Start","ShowFrequentList","0")},DocTaskbar,
   "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Start · ShowFrequentList = 0"));

  list.Add(Toggle("set-start-account-notifications","Personalizar Windows","Menu Iniciar",
   "Avisos da conta Microsoft no Iniciar","Desliga os avisos de conta que aparecem sobre o seu nome no menu Iniciar.","opcional",
   new[]{Cu(@"Software\Microsoft\Windows\CurrentVersion\SystemSettings\AccountNotifications","EnableAccountNotifications","0")},DocTaskbar,
   "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\SystemSettings\\AccountNotifications · EnableAccountNotifications = 0"));

  list.Add(new WindowsSetting{Id="set-start-layout",Panel="Personalizar Windows",Group="Menu Iniciar",
   Name="Espaço do menu Iniciar",Summary="Quanto do menu vai para os aplicativos fixados e quanto vai para as recomendações.",Risk="opcional",
   MinBuild=22000,Source=DocTaskbar,Technical="HKCU\\"+ExplorerAdvanced+" · Start_Layout (0 padrão · 1 mais fixados · 2 mais recomendações)",
   Choices=new[]{
    new SettingChoice{Label="Padrão",Ops=new[]{Cu(ExplorerAdvanced,"Start_Layout","0")}},
    new SettingChoice{Label="Mais aplicativos fixados",Ops=new[]{Cu(ExplorerAdvanced,"Start_Layout","1")}},
    new SettingChoice{Label="Mais recomendações",Ops=new[]{Cu(ExplorerAdvanced,"Start_Layout","2")}}}});

  // ================================================================= EXPLORADOR
  list.Add(Toggle("set-explorer-checkboxes","Personalizar Windows","Explorador de Arquivos",
   "Caixas de seleção nos arquivos","Mostra uma caixinha em cada arquivo para selecionar vários sem segurar Ctrl.","opcional",
   new[]{Cu(ExplorerAdvanced,"AutoCheckSelect","1")},DocExplorer,
   "HKCU\\"+ExplorerAdvanced+" · AutoCheckSelect = 1"));

  list.Add(Toggle("set-explorer-system-files","Personalizar Windows","Explorador de Arquivos",
   "Arquivos protegidos do sistema","Mostra também os arquivos que o Windows esconde por segurança. ATENÇÃO: apagar um deles por engano pode impedir o Windows de iniciar.","avançado",
   new[]{Cu(ExplorerAdvanced,"ShowSuperHidden","1")},DocExplorer,
   "HKCU\\"+ExplorerAdvanced+" · ShowSuperHidden = 1"));

  list.Add(Toggle("set-explorer-separate-process","Personalizar Windows","Explorador de Arquivos",
   "Abrir cada janela em processo separado","Uma janela travada deixa de derrubar as outras e a barra de tarefas. Em troca, cada janela usa memória própria.","avançado",
   new[]{Cu(ExplorerAdvanced,"SeparateProcess","1")},DocExplorer,
   "HKCU\\"+ExplorerAdvanced+" · SeparateProcess = 1"));

  list.Add(Toggle("set-explorer-sync-ads","Personalizar Windows","Explorador de Arquivos",
   "Anúncios de sincronização no Explorador","Remove as faixas que oferecem OneDrive e Microsoft 365 dentro das janelas de pasta. Não desativa o OneDrive.","recomendado",
   new[]{Cu(ExplorerAdvanced,"ShowSyncProviderNotifications","0")},DocExplorer,
   "HKCU\\"+ExplorerAdvanced+" · ShowSyncProviderNotifications = 0"));

  list.Add(Toggle("set-explorer-navpane-expand","Personalizar Windows","Explorador de Arquivos",
   "Painel lateral acompanha a pasta aberta","A árvore da esquerda se abre sozinha até a pasta em que você está.","opcional",
   new[]{Cu(ExplorerAdvanced,"NavPaneExpandToCurrentFolder","1")},DocExplorer,
   "HKCU\\"+ExplorerAdvanced+" · NavPaneExpandToCurrentFolder = 1"));

  list.Add(Toggle("set-explorer-confirm-delete","Personalizar Windows","Explorador de Arquivos",
   "Confirmar antes de mandar para a Lixeira","Volta a pedir confirmação ao excluir. É proteção, não otimização.","recomendado",
   new[]{Cu(@"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer","ConfirmFileDelete","1")},DocExplorer,
   "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer · ConfirmFileDelete = 1"));

  list.Add(new WindowsSetting{Id="set-explorer-drive-letters",Panel="Personalizar Windows",Group="Explorador de Arquivos",
   Name="Letra das unidades",Summary="Onde aparece o (C:) ao lado do nome do disco.",Risk="opcional",
   Source=DocExplorer,Technical="HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer · ShowDriveLettersFirst (0 depois do nome · 1 antes, só em rede · 2 nunca · 4 sempre antes)",
   Choices=new[]{
    new SettingChoice{Label="Depois do nome (padrão)",Ops=new[]{Cu(@"Software\Microsoft\Windows\CurrentVersion\Explorer","ShowDriveLettersFirst","0")}},
    new SettingChoice{Label="Antes do nome",Ops=new[]{Cu(@"Software\Microsoft\Windows\CurrentVersion\Explorer","ShowDriveLettersFirst","4")}},
    new SettingChoice{Label="Não mostrar a letra",Ops=new[]{Cu(@"Software\Microsoft\Windows\CurrentVersion\Explorer","ShowDriveLettersFirst","2")}}}});

  // ================================================================= PRIVACIDADE
  // Cada linha é UMA configuração, com o que ela faz escrito em português. O pedido é
  // explícito: nada de um botão "desativar tudo" que a pessoa aperta sem saber o quê.
  list.Add(new WindowsSetting{Id="set-privacy-telemetry",Panel="Privacidade",Group="Windows",
   Name="Dados de diagnóstico enviados à Microsoft",Summary="Reduz ao mínimo permitido o envio de dados de uso e falhas. Em edições Home o Windows mantém um mínimo obrigatório: esta opção NÃO zera o envio, e dizer que zera seria mentira.",
   Risk="recomendado",Administrator=true,Source=DocPrivacy,
   Technical="HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\DataCollection · AllowTelemetry = 0",
   Aliases=new[]{"AllowTelemetry","telemetry","DiagTrack"},
   On=new[]{Lm(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection","AllowTelemetry","0")}});

  list.Add(Toggle("set-privacy-tailored","Privacidade","Windows",
   "Experiências personalizadas","Impede que o Windows use seus dados de diagnóstico para escolher dicas, anúncios e sugestões sob medida.","recomendado",
   new[]{Cu(@"Software\Microsoft\Windows\CurrentVersion\Privacy","TailoredExperiencesWithDiagnosticDataEnabled","0")},DocPrivacy,
   "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Privacy · TailoredExperiencesWithDiagnosticDataEnabled = 0"));

  list.Add(Toggle("set-privacy-feedback","Privacidade","Windows",
   "Pedidos de opinião do Windows","Para de perguntar o que você achou do Windows.","opcional",
   new[]{Cu(@"SOFTWARE\Microsoft\Siuf\Rules","NumberOfSIUFInPeriod","0")},DocPrivacy,
   "HKCU\\SOFTWARE\\Microsoft\\Siuf\\Rules · NumberOfSIUFInPeriod = 0"));

  list.Add(Toggle("set-privacy-speech","Privacidade","Windows",
   "Reconhecimento de fala online","Retira o consentimento para enviar sua voz à Microsoft para melhorar o reconhecimento. A digitação por voz online deixa de funcionar; o reconhecimento local continua.","opcional",
   new[]{Cu(@"Software\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy","HasAccepted","0")},DocPrivacy,
   "HKCU\\Software\\Microsoft\\Speech_OneCore\\Settings\\OnlineSpeechPrivacy · HasAccepted = 0"));

  list.Add(Toggle("set-privacy-inking","Privacidade","Windows",
   "Personalização de escrita e digitação","Retira o consentimento para o Windows montar um dicionário pessoal do que você digita e escreve à mão. A correção automática fica menos ajustada a você.","opcional",
   new[]{Cu(@"Software\Microsoft\Personalization\Settings","AcceptedPrivacyPolicy","0")},DocPrivacy,
   "HKCU\\Software\\Microsoft\\Personalization\\Settings · AcceptedPrivacyPolicy = 0"));

  // ====================================================================== JOGOS
  list.Add(new WindowsSetting{Id="set-gaming-hags",Panel="Jogos",Group="Principal",
   Name="Agendamento de GPU pelo hardware",Summary="Deixa a própria placa de vídeo gerenciar a fila de trabalho, em vez do Windows. Pode reduzir um pouco a latência — ou não mudar nada, e em alguns drivers piorar. Exige reiniciar e placa/driver compatíveis.",
   Risk="avançado",Administrator=true,Restart=true,MinBuild=19041,Source=DocGaming,
   Technical="HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers · HwSchMode = 2 (1 desliga)",
   Aliases=new[]{"HAGS","HwSchMode","Hardware Accelerated GPU Scheduling","agendamento de GPU acelerado por hardware"},
   On=new[]{Lm(@"SYSTEM\CurrentControlSet\Control\GraphicsDrivers","HwSchMode","2")}});

  list.Add(new WindowsSetting{Id="set-gaming-dvr-policy",Panel="Jogos",Group="Principal",
   Name="Gravação de jogos para todos os usuários",Summary="Desliga a gravação em segundo plano pela política do sistema, valendo para todas as contas deste PC. Complementa a opção por usuário que já existe; a Game Bar continua abrindo.",
   Risk="opcional",Administrator=true,Source="https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-admx-gamedvr",
   Technical="HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\GameDVR · AllowGameDVR = 0",
   Aliases=new[]{"AllowGameDVR","Game DVR","gravação em segundo plano"},
   On=new[]{Lm(@"SOFTWARE\Policies\Microsoft\Windows\GameDVR","AllowGameDVR","0")}});

  list.Add(Toggle("set-gaming-gamebar-startup","Jogos","Principal",
   "Aviso da Game Bar ao abrir um jogo","Some a faixa \"pressione Win+G\" que aparece quando um jogo começa.","opcional",
   new[]{Cu(@"Software\Microsoft\GameBar","ShowStartupPanel","0")},
   "https://learn.microsoft.com/en-us/gaming/game-bar/",
   "HKCU\\Software\\Microsoft\\GameBar · ShowStartupPanel = 0"));

  // Experimentais: prometem pouco, mexem no agendador e não têm medição confiável.
  // Entram no Laboratório, nunca em perfil automático — é o que o pedido manda.
  list.Add(new WindowsSetting{Id="set-gaming-responsiveness",Panel="Jogos",Group="Experimental",
   Name="Prioridade entre jogos e tarefas de fundo",Summary="Reduz a fatia de CPU que o Windows reserva para tarefas de multimídia em segundo plano. EXPERIMENTAL: não há medição pública consistente de ganho, e em máquinas com áudio profissional pode causar falhas no som.",
   Risk="experimental",Administrator=true,Restart=true,
   Source="https://learn.microsoft.com/en-us/windows/win32/procthread/multimedia-class-scheduler-service",
   Technical="HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile · SystemResponsiveness = 10 (padrão 20)",
   Aliases=new[]{"SystemResponsiveness","MMCSS"},
   On=new[]{Lm(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile","SystemResponsiveness","10")}});

  list.Add(new WindowsSetting{Id="set-gaming-foreground-priority",Panel="Jogos",Group="Experimental",
   Name="Prioridade de programas em primeiro plano",Summary="Muda como o Windows divide o tempo de CPU entre a janela ativa e o resto. EXPERIMENTAL: o valor \"ideal\" varia por máquina e o efeito em jogos raramente é perceptível.",
   Risk="experimental",Administrator=true,Restart=true,
   Source="https://learn.microsoft.com/en-us/windows/win32/procthread/scheduling-priorities",
   Technical="HKLM\\System\\CurrentControlSet\\Control\\PriorityControl · Win32PrioritySeparation = 38 (padrão 2)",
   Aliases=new[]{"Win32PrioritySeparation","quantum","prioridade de primeiro plano"},
   On=new[]{Lm(@"System\CurrentControlSet\Control\PriorityControl","Win32PrioritySeparation","38")}});

  // =============================================================== NOTIFICAÇÕES
  list.Add(Toggle("set-notify-toasts","Personalizar Windows","Notificações",
   "Mostrar notificações","Desliga os avisos que aparecem no canto da tela. ATENÇÃO: isso inclui avisos de segurança, mensagens e alarmes.","avançado",
   new[]{Cu(@"Software\Microsoft\Windows\CurrentVersion\PushNotifications","ToastEnabled","0")},DocNotify,
   "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\PushNotifications · ToastEnabled = 0"));

  list.Add(Toggle("set-notify-lockscreen","Personalizar Windows","Notificações",
   "Notificações na tela de bloqueio","Impede que o conteúdo dos avisos apareça com o PC bloqueado. Bom para privacidade em mesa compartilhada.","recomendado",
   new[]{Cu(@"Software\Microsoft\Windows\CurrentVersion\PushNotifications","LockScreenToastEnabled","0")},DocNotify,
   "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\PushNotifications · LockScreenToastEnabled = 0"));

  // ============================================================= WINDOWS UPDATE
  list.Add(new WindowsSetting{Id="set-update-early",Panel="Windows Update",Group="Como atualizar",
   Name="Receber atualizações assim que ficam prontas",Summary="Liga a entrega antecipada de correções não críticas. Você recebe melhorias antes — e também problemas antes.",
   Risk="opcional",Administrator=true,Source=DocUpdate,
   Technical="HKLM\\SOFTWARE\\Microsoft\\WindowsUpdate\\UX\\Settings · IsContinuousInnovationOptedIn = 1 (0 desliga)",
   Aliases=new[]{"IsContinuousInnovationOptedIn"},
   On=new[]{Lm(@"SOFTWARE\Microsoft\WindowsUpdate\UX\Settings","IsContinuousInnovationOptedIn","0")}});

  list.Add(new WindowsSetting{Id="set-update-microsoft-products",Panel="Windows Update",Group="Como atualizar",
   Name="Atualizar outros produtos Microsoft",
   Risk="recomendado",Administrator=true,Source=DocUpdate,
   Summary="Faz o Windows Update cuidar também de Office e outros programas da Microsoft. Desligar deixa esses programas sem correção de segurança.",
   Technical="HKLM\\SOFTWARE\\Microsoft\\WindowsUpdate\\UX\\Settings · AllowMUUpdateService = 1",
   Aliases=new[]{"AllowMUUpdateService","Microsoft Update"},
   On=new[]{Lm(@"SOFTWARE\Microsoft\WindowsUpdate\UX\Settings","AllowMUUpdateService","1")}});

  // ============================================================ MOUSE E TECLADO
  list.Add(new WindowsSetting{Id="set-input-hover-time",Panel="Personalizar Windows",Group="Mouse e teclado",
   Name="Tempo para ativar ao passar o mouse",Summary="Quanto o ponteiro precisa ficar parado sobre um item antes de a dica ou o destaque aparecer.",Risk="opcional",
   SignOut=true,Source=DocMouse,Technical="HKCU\\Control Panel\\Mouse · MouseHoverTime (milissegundos; padrão 400)",
   Aliases=new[]{"MouseHoverTime","hover"},
   Choices=new[]{
    new SettingChoice{Label="Instantâneo (0 ms)",Ops=new[]{CuText(@"Control Panel\Mouse","MouseHoverTime","0")}},
    new SettingChoice{Label="Muito rápido (50 ms)",Ops=new[]{CuText(@"Control Panel\Mouse","MouseHoverTime","50")}},
    new SettingChoice{Label="Rápido (100 ms)",Ops=new[]{CuText(@"Control Panel\Mouse","MouseHoverTime","100")}},
    new SettingChoice{Label="Normal (250 ms)",Ops=new[]{CuText(@"Control Panel\Mouse","MouseHoverTime","250")}},
    new SettingChoice{Label="Padrão do Windows (400 ms)",Ops=new[]{CuText(@"Control Panel\Mouse","MouseHoverTime","400")}}}});

  list.Add(new WindowsSetting{Id="set-input-filter-keys",Panel="Personalizar Windows",Group="Mouse e teclado",
   Name="Atalho das Teclas de Filtragem",Summary="Desliga o aviso que aparece ao segurar Shift direito por oito segundos. É o irmão do atalho de cinco Shift.",Risk="opcional",
   Source="https://learn.microsoft.com/en-us/windows/win32/api/winuser/ns-winuser-filterkeys",
   Technical="HKCU\\Control Panel\\Accessibility\\Keyboard Response · Flags = 122",
   Aliases=new[]{"FilterKeys","teclas de filtragem"},
   On=new[]{CuText(@"Control Panel\Accessibility\Keyboard Response","Flags","122")}});

  list.Add(new WindowsSetting{Id="set-input-toggle-keys",Panel="Personalizar Windows",Group="Mouse e teclado",
   Name="Aviso sonoro de Caps Lock e Num Lock",Summary="Desliga o bipe ao apertar Caps Lock, Num Lock ou Scroll Lock.",Risk="opcional",
   Source="https://learn.microsoft.com/en-us/windows/win32/api/winuser/ns-winuser-togglekeys",
   Technical="HKCU\\Control Panel\\Accessibility\\ToggleKeys · Flags = 58",
   Aliases=new[]{"ToggleKeys"},
   On=new[]{CuText(@"Control Panel\Accessibility\ToggleKeys","Flags","58")}});

  return list;
 }

 // ------------------------------------------------------------------ catálogo
 // Vira Item porque é assim que o motor transacional do LukeOptimizer já sabe aplicar,
 // conferir, registrar no Histórico e DESFAZER. Um backend, não dois.
 internal static List<Item> AsCatalogItems(){
  var items=new List<Item>();
  foreach(var setting in All()){
   if(setting.IsChoice){
    for(int n=0;n<setting.Choices.Length;n++){
     var choice=setting.Choices[n];
     var item=Make(setting,setting.Id+"-"+(n+1),setting.Name+": "+choice.Label,choice.Ops);
     item.Review=new[]{setting.Summary+(String.IsNullOrEmpty(choice.Detail)?"":" "+choice.Detail),RollbackText(setting)};
     items.Add(item);
    }
   }else{
    var item=Make(setting,setting.Id,setting.Name,setting.On);
    item.Review=new[]{setting.Summary,RollbackText(setting)};
    items.Add(item);
   }
  }
  return items;
 }
 static string RollbackText(WindowsSetting setting){
  var b=new StringBuilder("O valor anterior é gravado no Histórico antes da mudança; Desfazer restaura exatamente o que havia.");
  if(setting.Administrator)b.Append(" Requer administrador.");
  if(setting.Restart)b.Append(" Só vale depois de REINICIAR o computador.");
  if(setting.SignOut)b.Append(" Vale ao entrar de novo no Windows.");
  if(setting.MinBuild>0)b.Append(" Exige build "+setting.MinBuild+" ou mais recente.");
  b.Append(" Detalhes técnicos: "+setting.Technical+".");
  return b.ToString();
 }
 static Item Make(WindowsSetting setting,string id,string title,RegOp[] ops){
  return new Item{Id=id,Name=title,ReviewTitle=title,Category=setting.Panel,
   Path=setting.Panel+" / "+setting.Group,Mode="Nativo",Type="Nativo",Native=true,ActionCode="",
   Available=true,ManualAllowed=true,MaxEligible=false,DefaultSelected=false,
   Notes=new string[0],Operations=ops,ReviewLevel="Revisado",Conflicts=new string[0],SameTargets=new string[0],
   Asset="",Hash="",Text="",Url=setting.Source,Blocked="",Review=new string[0]};
 }

 internal static WindowsSetting Resolve(string id){
  var found=All().SingleOrDefault(s=>s.Id==id);
  if(found==null)throw new ArgumentException("Configuração desconhecida: "+id);
  return found;
 }
 // A busca encontra tanto "agendamento de GPU" quanto "HAGS" ou "HwSchMode".
 internal static bool Matches(WindowsSetting setting,string term){
  if(setting==null||String.IsNullOrWhiteSpace(term))return true;
  string text=term.Trim();
  if(setting.Name.IndexOf(text,StringComparison.CurrentCultureIgnoreCase)>=0)return true;
  if(setting.Summary.IndexOf(text,StringComparison.CurrentCultureIgnoreCase)>=0)return true;
  if(setting.Group.IndexOf(text,StringComparison.CurrentCultureIgnoreCase)>=0)return true;
  if(setting.Technical.IndexOf(text,StringComparison.OrdinalIgnoreCase)>=0)return true;
  foreach(string alias in setting.Aliases)
   if(alias.IndexOf(text,StringComparison.OrdinalIgnoreCase)>=0)return true;
  return false;
 }
 internal static string[] Panels(){return All().Select(s=>s.Panel).Distinct().ToArray();}
 internal static string[] GroupsOf(string panel){return All().Where(s=>s.Panel==panel).Select(s=>s.Group).Distinct().ToArray();}
}

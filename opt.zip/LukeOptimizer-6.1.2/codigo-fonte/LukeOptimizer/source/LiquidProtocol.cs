using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Threading;
using System.Security.Principal;

// Versioned, local-only protocol. Fields are percent-escaped UTF-8, one row per line.
// Requests can select existing native items; they cannot supply registry paths or commands.
static class LiquidProtocol {
 static string Escape(string text){var b=new StringBuilder();foreach(byte c in Encoding.UTF8.GetBytes(text??""))if(c>=65&&c<=90||c>=97&&c<=122||c>=48&&c<=57||c==45||c==46||c==95||c==126)b.Append((char)c);else b.Append('%').Append(c.ToString("X2"));return b.ToString();}
 internal static string Row(params string[] fields){return String.Join("\t",fields.Select(Escape))+"\n";}
 internal static List<Item> Resolve(string payload){
  var ids=payload.Split(new[]{','}).Select(CatalogIds.Canonical).ToArray();
  if(ids.Length==0||ids.Length>CatalogIds.NativeItems().Count||ids.Any(String.IsNullOrWhiteSpace)||ids.Distinct().Count()!=ids.Length)throw new Exception("Seleção inválida. Marque cada opção somente uma vez.");
  var allowed=new HashSet<string>(Builtins.Create().Concat(V5Options.Items()).Concat(V5InputItems.Create()).Concat(ImportedOptions.Items()).Concat(ExtraSettings.Items()).Concat(ReviewedFeatures.Items()).Select(x=>x.Id));
  var result=new List<Item>();
  foreach(var id in ids){var item=App.Items.FirstOrDefault(x=>x.Id==id&&x.Native&&allowed.Contains(id));if(item==null)throw new Exception("Opção não reconhecida: "+id);result.Add(item);}
  App.UniqueOperations(result); // reject contradictory selections before creating a backup
  return result;
 }
 internal static bool NeedsAdmin(IEnumerable<Item> items){return items.Any(x=>x.ActionCode=="power"||x.ActionCode==ExtraSettings.Compression||(x.RestoreNative??new NativeSaved[0]).Any(n=>n.Code==ExtraSettings.Compression)||(x.Operations??new RegOp[0]).Any(App.RequiresAdmin));}
 internal static string ResponsePath(string id){Guid g;if(!Guid.TryParseExact(id,"N",out g))throw new Exception("Solicitação inválida.");return Path.Combine(App.DataRoot,"liquid",id+".txt");}
 static bool Admin(){return new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator);}
 internal static string HistoryRows(){
  var b=new StringBuilder();var records=App.History();var latest=records.FirstOrDefault(App.CanUndo);
  foreach(var r in records.Take(80)){
   bool can=r.UserSid==App.Sid&&latest!=null&&r.Id==latest.Id;
   bool admin=(r.Values??new List<SavedValue>()).Any(x=>App.RequiresAdmin(x.After))||!String.IsNullOrEmpty(r.NewPlan)||(r.ServiceValues!=null&&r.ServiceValues.Count>0)||r.PriorityValue!=null||(r.NativeValues??new List<NativeSaved>()).Any(x=>x.Code==ExtraSettings.Compression);
   var detail=ChangeAudit.Report(r);
   DateTime time;string shownTime=DateTime.TryParse(r.Time,out time)?time.ToLocalTime().ToString("dd/MM/yyyy HH:mm"):r.Time;
   b.Append(Row("history",r.Id,r.Name,shownTime,r.Status,detail,can?"1":"0",admin?"1":"0"));
 }return b.ToString();
 }
 internal static string ScanRows(){
  var body=new StringBuilder();var m=App.ScanHardware();body.Append(Row("pc",m.OS,m.Cpu,m.Gpu,m.Ram,m.Power));
  foreach(var i in Builtins.Create().Concat(V5Options.Items()).Concat(V5InputItems.Create()).Concat(ImportedOptions.Items()).Concat(ExtraSettings.Items()).Concat(ReviewedFeatures.Items())){
   var state=App.Observe(i,m);string issue=state.State=="Não compatível"||state.State=="Falha na leitura"?state.Detail:null;
   if(i.Id==ExtraSettings.Compression&&state.State=="Falha na leitura"&&!Admin())issue="O Windows exige administrador para consultar MMAgent. Clique em Verificar como administrador; essa verificação não aplica ajustes.";
   body.Append(Row("state",i.Id,state.State,state.Detail,issue??"",NeedsAdmin(new[]{i})?"1":"0",state.Verified?"1":"0"));
  }
  return body.Append(OptionInfo.Rows()).Append(ExtremeProfile.Rows()).Append(ExtraSettings.ManualRows()).Append(Row("checked_at",DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"))).ToString();
 }
 static string RefreshRows(){try{return ScanRows();}catch(Exception e){return Row("refresh_error","Não foi possível atualizar a leitura: "+e.Message);}}
 internal static int Run(string[] args){
  string path=null;bool refresh=false;HashSet<string> prior=null;try{
   if(args.Length!=5||args[0]!="--liquid")throw new Exception("Solicitação inválida.");
   path=ResponsePath(args[4]);if(args[3]!=App.Sid)throw new Exception("Use a mesma conta do Windows que abriu o app.");
   Directory.CreateDirectory(Path.GetDirectoryName(path));string verb=args[1],payload=args[2];var body=new StringBuilder();
   if(verb=="scan"){
    body.Append(ScanRows());
   }else if(verb=="apps"){
    body.Append(AppRemoval.Rows(AppRemoval.Scan()));
   }else if(verb=="apply"||verb=="undo"||verb=="remove-apps"||verb=="apply-custom"||verb=="extreme"||verb=="restore-selection"){
    refresh=verb!="remove-apps";
    var chosen=verb=="apply"?Resolve(payload):verb=="apply-custom"?ExtraSettings.Manual(payload):verb=="extreme"?ExtremeProfile.Resolve(payload):null;
    if(chosen!=null&&NeedsAdmin(chosen)&&!Admin())throw new Exception("O Windows exige permissão de administrador para esta seleção.");
    bool acquired=false;using(var gate=new Mutex(false,"Global\\LukeOptimizer-Change-20260910"))try{
     try{acquired=gate.WaitOne(0);}catch(AbandonedMutexException){acquired=true;}
     if(!acquired)throw new Exception("Há outra alteração em andamento. Aguarde terminar.");
     if(verb=="restore-selection"){chosen=App.RestoreSelectionItems(payload);if(NeedsAdmin(chosen)&&!Admin())throw new Exception("O Windows exige permissão de administrador para restaurar a seleção.");}
     prior=new HashSet<string>(App.History().Select(x=>x.Id));
     if(verb=="remove-apps"){
      var record=AppRemoval.Remove(payload,path+".cancel");body.Append(Row("operation",record.Id));body.Append(Row("result",record.Status,record.Message));
      body.Append(AppRemoval.Rows(AppRemoval.Scan()));
     }else if(verb=="apply"||verb=="apply-custom"||verb=="extreme"||verb=="restore-selection"){
      if(verb=="extreme")ExtremeProfile.Apply(payload);else if(verb=="apply")App.ApplyMany(payload.Split(new[]{','}));else App.ApplyTransaction(chosen,chosen.Count==1?"Nativo":"Perfil",verb=="extreme"?"Otimização extrema — Fazer tudo":verb=="restore-selection"?"Restaurar seleção do backup "+payload.Split(new[]{'|'})[0]:"Ajustes escolhidos ("+chosen.Count+")",CatalogIds.Migrations(payload),verb=="extreme"?ExtremeProfile.Skipped(chosen):null);
      var record=App.History().FirstOrDefault(x=>!prior.Contains(x.Id));
      if(record==null)throw new Exception("Não foi possível localizar o resultado da operação.");
      body.Append(Row("operation",record.Id));body.Append(Row("result",record.Status,record.Message));
     }else{
      // Exact ID from the review dialog: never undo a different operation that arrived later.
      App.RecordPath(payload);App.Undo(payload);body.Append(Row("operation",payload));body.Append(Row("result","desfeito","Os valores anteriores foram restaurados e conferidos."));
     }
    }finally{if(acquired)gate.ReleaseMutex();}
   }else if(verb=="verify"||verb=="export"){
    var record=App.Json.Deserialize<Record>(AtomicStore.Read(App.RecordPath(payload)));if(record.UserSid!=App.Sid)throw new Exception("Registro de outra conta.");
    if(verb=="verify")body.Append(Row("verification",record.Id,ChangeAudit.VerifyCurrent(record)));
    else body.Append(Row("exported",ChangeAudit.Export(record)));
   }else if(verb!="history")throw new Exception("Operação não reconhecida.");
   if(refresh)body.Append(RefreshRows());
   body.Append(HistoryRows());AtomicStore.Write(path,Row("protocol","1")+Row("ok","1")+body);return 0;
  }catch(Exception e){if(path!=null)try{Directory.CreateDirectory(Path.GetDirectoryName(path));string current=refresh?RefreshRows():"";var failed=prior==null?null:App.History().FirstOrDefault(x=>!prior.Contains(x.Id));AtomicStore.Write(path,Row("protocol","1")+Row("ok","0",e.Message)+(failed==null?"":Row("operation",failed.Id))+current+HistoryRows());}catch{}return 1;}
 }
}

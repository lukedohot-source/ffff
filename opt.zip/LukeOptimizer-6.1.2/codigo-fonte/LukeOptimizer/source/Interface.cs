using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Threading.Tasks;
using System.Windows.Forms;

static class Theme {
 // Paleta única do aplicativo. Selection/Hover/Alt/HeroFill/HeroText/CheckFill existiam
 // como Color.FromArgb fixos espalhados por cinco arquivos, o que tornava impossível
 // trocar de cor sem caçar cada um. Agora todos saem daqui.
 // Line desenha bordas; Disabled preenche botao desligado. Eram a mesma cor, e clarear
 // a borda escurecia o texto do botao desligado — agora cada papel tem a sua.
 internal static Color Bg,Side,Card,Line,Disabled,Text,Muted,Accent,Amber,Red,Contrast,Selection,Hover,Alt,HeroFill,HeroText,CheckFill;
 internal static bool BlueSkin;
 static Theme(){Apply(true);}
 // Apply(false) devolve a pele âmbar original; nada mais no código precisa mudar.
 internal static void Apply(bool blue){
  BlueSkin=blue;
  Text=Color.FromArgb(238,243,250);Red=Color.FromArgb(248,139,143);Amber=Color.FromArgb(244,191,112);
  if(blue){
   Bg=Color.FromArgb(12,16,24);Side=Color.FromArgb(16,21,32);Card=Color.FromArgb(22,29,43);
   Line=Color.FromArgb(70,90,120);Disabled=Color.FromArgb(38,48,66);Muted=Color.FromArgb(165,178,197);
   Accent=Color.FromArgb(88,166,255);            // 6,6:1 sobre Card e 7,5:1 contra Bg em botão primário
   Contrast=Color.FromArgb(236,150,205);         // serie secundaria: 108 graus de matiz do acento e longe do ambar de aviso
   Selection=Color.FromArgb(28,52,84);Hover=Color.FromArgb(30,42,62);Alt=Color.FromArgb(18,26,40);
   HeroFill=Color.FromArgb(24,34,52);HeroText=Color.FromArgb(186,206,235);CheckFill=Color.FromArgb(8,12,20);
  }else{
   Bg=Color.FromArgb(15,16,18);Side=Color.FromArgb(20,21,24);Card=Color.FromArgb(27,29,33);
   Line=Color.FromArgb(65,68,74);Disabled=Color.FromArgb(65,68,74);Muted=Color.FromArgb(180,185,194);
   Accent=Color.FromArgb(255,208,48);Contrast=Color.FromArgb(139,190,241);
   Selection=Color.FromArgb(62,55,27);Hover=Color.FromArgb(39,49,62);Alt=Color.FromArgb(25,33,44);
   HeroFill=Color.FromArgb(34,35,39);HeroText=Color.FromArgb(191,214,203);CheckFill=Color.FromArgb(3,2,5);
  }
 }
 internal static Font Font(float size,bool bold=false){return new Font("Segoe UI",size,bold?FontStyle.Bold:FontStyle.Regular);}
 internal static Label Label(string text,float size,Color color,bool bold=false){var label=size>=20?(Label)new HeadingLabel():new Label();label.Text=text;label.Font=Font(size,bold);label.ForeColor=color;label.AutoSize=false;label.Dock=DockStyle.Fill;label.TextAlign=ContentAlignment.MiddleLeft;label.AutoEllipsis=size<20;label.Margin=Padding.Empty;return label;}
 internal static ActionButton Button(string text,bool primary=false){return new ActionButton {Text=text,Primary=primary,Height=40,Width=175,Font=Font(10,true),Margin=new Padding(0,0,10,0),Cursor=Cursors.Hand,AccessibleName=text};}
 internal static TextBox ReadBox(){return new TextBox {Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Vertical,Dock=DockStyle.Fill,BackColor=Card,ForeColor=Text,BorderStyle=BorderStyle.None,Font=Font(10),Margin=Padding.Empty};}
 internal static Color StatusColor(string s){if(s=="Conferido"||s=="Valores conferidos"||s=="Plano ativo"||s=="aplicado"||s=="desfeito"||s=="Revisado")return Accent;if(s.Contains("erro")||s.Contains("Erro")||s.Contains("falha")||s=="Alto risco")return Red;if(s=="Parcial"||s=="Condicional"||s=="Nome incorreto"||s=="Não comprovado"||s=="Substituído")return Amber;return Muted;}
 internal static void DrawCheck(Graphics g,Rectangle box,bool selected,bool enabled){
  using(var fill=new SolidBrush(CheckFill))g.FillRectangle(fill,box);
  using(var border=new Pen(enabled?(selected?Accent:Muted):Line,selected?2:1))g.DrawRectangle(border,box);
  if(selected)using(var tick=new Pen(enabled?Accent:Muted,Math.Max(2,box.Width/7f))){tick.StartCap=tick.EndCap=LineCap.Round;g.DrawLines(tick,new[]{new Point(box.X+box.Width/5,box.Y+box.Height/2),new Point(box.X+box.Width*2/5,box.Y+box.Height*3/4),new Point(box.X+box.Width*4/5,box.Y+box.Height/4)});}
 }
 // Interruptor em pílula. O "ligado" usa Accent no trilho e Bg no botão — mesma
 // relação de contraste que ActionButton já usa para o botão primário (texto Bg
 // sobre fundo Accent), então o estado ligado fica legível sem inventar cor nova.
 // O "desligado" usa Disabled com borda Line: distingue de "ligado" por FORMA e
 // POSIÇÃO do botão, não só por cor, para não depender de enxergar bem o azul.
 internal static void DrawToggle(Graphics g,Rectangle track,bool on,bool enabled){
  var previous=g.SmoothingMode;g.SmoothingMode=SmoothingMode.AntiAlias;
  int radius=Math.Max(1,track.Height/2);
  using(var path=Round(track,radius))
  using(var brush=new SolidBrush(!enabled?Disabled:on?Accent:Disabled))g.FillPath(brush,path);
  if(!on||!enabled)using(var path=Round(track,radius))using(var pen=new Pen(enabled?Line:Disabled))g.DrawPath(pen,path);
  int inset=3,size=Math.Max(4,track.Height-inset*2);
  int x=on?track.Right-size-inset:track.X+inset;
  using(var knob=new SolidBrush(!enabled?Muted:on?Bg:Muted))g.FillEllipse(knob,x,track.Y+inset,size,size);
  g.SmoothingMode=previous;
 }
 internal static GraphicsPath Round(Rectangle r,int radius){int d=radius*2;var p=new GraphicsPath();p.AddArc(r.X,r.Y,d,d,180,90);p.AddArc(r.Right-d,r.Y,d,d,270,90);p.AddArc(r.Right-d,r.Bottom-d,d,d,0,90);p.AddArc(r.X,r.Bottom-d,d,d,90,90);p.CloseFigure();return p;}
}
// Herda de CheckBox de propósito: homeChecks é Dictionary<string,CheckBox> e os testes
// procuram CheckBox. Trocar a classe base obrigaria a mexer em assinatura, teclado e
// acessibilidade. Aqui muda só a pintura — Space continua alternando, leitor de tela
// continua anunciando caixa de seleção.
class ToggleSwitch : CheckBox {
 internal ToggleSwitch(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);Cursor=Cursors.Hand;}
 protected override void OnPaint(PaintEventArgs e){
  var g=e.Graphics;g.Clear(BackColor);
  int height=Math.Min(18,Math.Max(14,Height-10)),width=height*2;
  Theme.DrawToggle(g,new Rectangle(0,(Height-height)/2,width,height),Checked,Enabled);
  int left=width+10;
  TextRenderer.DrawText(g,Text,Font,new Rectangle(left,0,Math.Max(1,Width-left),Height),Enabled?ForeColor:Theme.Muted,TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);
  if(Focused)ControlPaint.DrawFocusRectangle(g,ClientRectangle,Theme.Text,BackColor);
 }
}
class HeadingLabel : Label {
 protected override void OnPaint(PaintEventArgs e){TextRenderer.DrawText(e.Graphics,Text,Font,ClientRectangle,ForeColor,TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.SingleLine|TextFormatFlags.EndEllipsis);}
}
class ReadableComboBox : ComboBox {
 internal ReadableComboBox(){DrawMode=DrawMode.OwnerDrawFixed;ItemHeight=24;}
 protected override void OnDrawItem(DrawItemEventArgs e){
  if(e.Bounds.Width<=0)return;
  bool selected=(e.State&DrawItemState.Selected)!=0;using(var brush=new SolidBrush(selected?Theme.Line:Theme.Card))e.Graphics.FillRectangle(brush,e.Bounds);
  string text=e.Index>=0&&e.Index<Items.Count?GetItemText(Items[e.Index]):Text;
  TextRenderer.DrawText(e.Graphics,text,Font,new Rectangle(e.Bounds.X+6,e.Bounds.Y,e.Bounds.Width-8,e.Bounds.Height),Enabled?Theme.Text:Theme.Muted,TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);
  if((e.State&DrawItemState.Focus)!=0)e.DrawFocusRectangle();
 }
}
class Surface : Panel {
 internal Color Fill=Theme.Card;
 public Surface(){DoubleBuffered=true;Padding=new Padding(20);Margin=new Padding(0,0,14,14);BackColor=Theme.Card;}
 protected override void OnPaintBackground(PaintEventArgs e){e.Graphics.Clear(Parent==null?Theme.Bg:Parent.BackColor);}
 protected override void OnPaint(PaintEventArgs e){var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;using(var path=Theme.Round(new Rectangle(0,0,Math.Max(1,Width-1),Math.Max(1,Height-1)),14))using(var brush=new SolidBrush(Fill)){g.FillPath(brush,path);using(var pen=new Pen(Theme.Line))g.DrawPath(pen,path);}base.OnPaint(e);}
}
class ActionButton : Button {
 internal bool Primary,Active;bool hover;
 public ActionButton(){FlatStyle=FlatStyle.Flat;FlatAppearance.BorderSize=0;SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);BackColor=Theme.Card;ForeColor=Theme.Text;}
 protected override void OnMouseEnter(EventArgs e){hover=true;Invalidate();base.OnMouseEnter(e);}
 protected override void OnMouseLeave(EventArgs e){hover=false;Invalidate();base.OnMouseLeave(e);}
 protected override void OnPaint(PaintEventArgs e){var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;g.Clear(Parent==null?Theme.Bg:Parent.BackColor);Color c=!Enabled?Theme.Disabled:Primary?Theme.Accent:Active?Theme.Selection:hover?Theme.Hover:Theme.Card;using(var path=Theme.Round(new Rectangle(0,0,Math.Max(1,Width-1),Math.Max(1,Height-1)),8))using(var b=new SolidBrush(c))g.FillPath(b,path);TextRenderer.DrawText(g,Text,Font,ClientRectangle,!Enabled?Theme.Muted:Primary?Theme.Bg:Active?Theme.Accent:Theme.Text,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);if(Focused)ControlPaint.DrawFocusRectangle(g,new Rectangle(4,4,Width-8,Height-8),Theme.Text,c);}
}
class CatalogList : ListView {
 ImageList rowHeight;
 public CatalogList(){DoubleBuffered=true;View=View.Details;FullRowSelect=true;MultiSelect=false;HideSelection=false;BackColor=Theme.Card;ForeColor=Theme.Text;BorderStyle=BorderStyle.None;Font=Theme.Font(10);Dock=DockStyle.Fill;OwnerDraw=true;rowHeight=new ImageList {ImageSize=new Size(1,36)};SmallImageList=rowHeight;}
 protected override void OnDrawColumnHeader(DrawListViewColumnHeaderEventArgs e){using(var b=new SolidBrush(Theme.Side))e.Graphics.FillRectangle(b,e.Bounds);TextRenderer.DrawText(e.Graphics,e.Header.Text,Font,new Rectangle(e.Bounds.X+12,e.Bounds.Y,e.Bounds.Width-16,e.Bounds.Height),Theme.Muted,TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);}
 protected override void OnDrawItem(DrawListViewItemEventArgs e){}
 protected override void OnDrawSubItem(DrawListViewSubItemEventArgs e){bool selected=e.Item.Selected;using(var b=new SolidBrush(selected?Theme.Selection:e.ItemIndex%2==0?Theme.Card:Theme.Alt))e.Graphics.FillRectangle(b,e.Bounds);Color color=e.ColumnIndex>=2?Theme.StatusColor(e.SubItem.Text):Theme.Text;TextRenderer.DrawText(e.Graphics,e.SubItem.Text,Font,new Rectangle(e.Bounds.X+12,e.Bounds.Y,e.Bounds.Width-18,e.Bounds.Height),color,TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis|TextFormatFlags.SingleLine);}
 protected override void Dispose(bool disposing){if(disposing)rowHeight.Dispose();base.Dispose(disposing);}
}

class CheckableList : CatalogList {
 protected override void OnDrawSubItem(DrawListViewSubItemEventArgs e){
  using(var brush=new SolidBrush(e.Item.Selected?Theme.Selection:Theme.Card))e.Graphics.FillRectangle(brush,e.Bounds);
  int inset=12;
  if(e.ColumnIndex==0&&CheckBoxes){Theme.DrawCheck(e.Graphics,new Rectangle(e.Bounds.X+9,e.Bounds.Y+(e.Bounds.Height-20)/2,20,20),e.Item.Checked,Enabled);inset=38;}
  TextRenderer.DrawText(e.Graphics,e.SubItem.Text,Font,new Rectangle(e.Bounds.X+inset,e.Bounds.Y,Math.Max(1,e.Bounds.Width-inset-8),e.Bounds.Height),e.Item.ForeColor,TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);
 }
}
public partial class MainForm : Form {
 readonly Dictionary<string,Panel> pages=new Dictionary<string,Panel>();readonly Dictionary<string,ActionButton> nav=new Dictionary<string,ActionButton>();
 readonly Dictionary<string,CheckBox> picks=new Dictionary<string,CheckBox>();readonly Dictionary<string,Label> pickStates=new Dictionary<string,Label>();
 Dictionary<string,Observed> states=new Dictionary<string,Observed>();HashSet<string> favorites=new HashSet<string>();Machine machine=new Machine();
 // Leitura estruturada do PC, usada pelo motor de compatibilidade e pela ficha de cada
 // opção. Fica NULA até a primeira análise de propósito: com perfil nulo o motor responde
 // "Não detectado", que é a verdade antes de alguém clicar em Analisar este PC. Preenchê-la
 // com um objeto vazio faria o motor responder o mesmo, mas parecendo que houve leitura.
 MachineProfile profile;
 readonly Dictionary<string,string[]> categoryFilters=new Dictionary<string,string[]>(StringComparer.Ordinal);
 Panel host;Label title,subtitle,footer,profileSummary,profileNote,cpu,gpu,ram,disk,os,verifiedMetric,attentionMetric,externalMetric,heroHint,diagHeader;
 TextBox search,detail,historyDetail,diagnosticText;ComboBox categories,reviewFilter,stateFilter;CatalogList catalog,history;
 ActionButton scan,apply,undo,maxApply,favorite,point,export;ProgressBar progress;System.Windows.Forms.Timer workerTimer;
 string serviceText="Ainda não consultado.";bool busy,scanning,ready,updatingPicks;DateTime lastScan;
 List<Record> records=new List<Record>(); readonly string favoritesPath=Path.Combine(App.DataRoot,"favoritos-v2.json");
 public MainForm() {
  Text="Luke Optimizer 6.1.2";BackColor=Theme.Bg;ForeColor=Theme.Text;Font=Theme.Font(10);Size=new Size(1360,900);MinimumSize=new Size(1080,720);StartPosition=FormStartPosition.CenterScreen;AutoScaleMode=AutoScaleMode.Dpi;KeyPreview=true;
  try{if(File.Exists(favoritesPath))favorites=new HashSet<string>(App.Json.Deserialize<string[]>(File.ReadAllText(favoritesPath)));}catch{}
  var root=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=2,RowCount=1,Margin=Padding.Empty};root.RowStyles.Add(new RowStyle(SizeType.Percent,100));root.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,App.ToolMode?0:216));root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));Controls.Add(root);
  var sidebar=new Panel {Dock=DockStyle.Fill,BackColor=Theme.Side,Padding=new Padding(18,24,18,20)};root.Controls.Add(sidebar,0,0);
  var side=new TableLayoutPanel {Dock=DockStyle.Fill,RowCount=3,ColumnCount=1};side.RowStyles.Add(new RowStyle(SizeType.Absolute,108));side.RowStyles.Add(new RowStyle(SizeType.Percent,100));side.RowStyles.Add(new RowStyle(SizeType.Absolute,105));sidebar.Controls.Add(side);sidebar.Visible=!App.ToolMode;
  var brand=new TableLayoutPanel {Dock=DockStyle.Fill,RowCount=3};brand.RowStyles.Add(new RowStyle(SizeType.Absolute,46));brand.RowStyles.Add(new RowStyle(SizeType.Absolute,22));brand.RowStyles.Add(new RowStyle(SizeType.Percent,100));brand.Controls.Add(Theme.Label("LUKE",24,Theme.Accent,true),0,0);brand.Controls.Add(Theme.Label("O P T I M I Z E R",9,Theme.Text,true),0,1);brand.Controls.Add(Theme.Label("VERSÃO 6.1.2",8,Theme.Muted),0,2);side.Controls.Add(brand,0,0);
  var links=new FlowLayoutPanel {Dock=DockStyle.Fill,FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoScroll=true};side.Controls.Add(links,0,1);
  // "Memory Manager" estava em inglês no meio de um menu em português. "Memória" diz a
  // mesma coisa para quem não é técnico. A página mantém a chave antiga; muda o rótulo.
  // Os painéis compactos entram na barra logo depois de Otimizações: é lá que a
  // pessoa vai procurar "personalizar o Windows" e "privacidade", não dentro de uma
  // aba chamada pelo nome de um projeto de referência — que não existe aqui.
  string[] names={"Painel","Otimizações","Personalizar Windows","Privacidade","Jogos","Windows Update","Rede","Temporários","Memória","Ferramentas","Catálogo","Diagnóstico","Histórico","Resultados"};
  for(int n=0;n<names.Length;n++){string key=names[n];var b=Theme.Button(key=="Avançado / Alto Impacto"?"Avançado":key);b.Width=176;b.Height=39;b.Margin=new Padding(0,0,0,6);b.Click+=(s,e)=>ShowPage(key);nav[key]=b;links.Controls.Add(b);}
  var bottom=new TableLayoutPanel {Dock=DockStyle.Fill,RowCount=2};bottom.RowStyles.Add(new RowStyle(SizeType.Absolute,48));bottom.RowStyles.Add(new RowStyle(SizeType.Percent,100));var backup=Theme.Button("Abrir backups");backup.Dock=DockStyle.Fill;backup.Click+=(s,e)=>OpenLocal(App.RecordsRoot);bottom.Controls.Add(backup,0,0);bottom.Controls.Add(Theme.Label("Seu pacote, em um só app.",9,Theme.Muted),0,1);side.Controls.Add(bottom,0,2);
  var main=new TableLayoutPanel {Dock=DockStyle.Fill,Padding=new Padding(27,20,24,10),RowCount=3,ColumnCount=1,BackColor=Theme.Bg};main.RowStyles.Add(new RowStyle(SizeType.Absolute,90));main.RowStyles.Add(new RowStyle(SizeType.Percent,100));main.RowStyles.Add(new RowStyle(SizeType.Absolute,47));root.Controls.Add(main,1,0);
  var top=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=2,RowCount=2};top.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,176));top.RowStyles.Add(new RowStyle(SizeType.Absolute,45));top.RowStyles.Add(new RowStyle(SizeType.Percent,100));title=Theme.Label("Visão geral",25,Theme.Text,true);subtitle=Theme.Label("Configurações, revisão e resultados em um só lugar.",10,Theme.Muted);top.Controls.Add(title,0,0);top.Controls.Add(subtitle,0,1);scan=Theme.Button("Analisar este PC");scan.Dock=DockStyle.Fill;scan.Margin=new Padding(0,1,0,4);scan.Click+=async(s,e)=>await RefreshScan();top.Controls.Add(scan,1,0);main.Controls.Add(top,0,0);
  if(EmbeddedInterface.Parent!=IntPtr.Zero){main.Padding=new Padding(10,0,10,2);main.RowStyles[0].Height=0;top.Visible=false;title.Visible=subtitle.Visible=false;scan.Text="Atualizar leitura do PC";}
  host=new Panel {Dock=DockStyle.Fill,BackColor=Theme.Bg};main.Controls.Add(host,0,1);
  var status=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=2};status.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));status.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,155));footer=Theme.Label("Preparando interface…",9,Theme.Muted);progress=new ProgressBar {Dock=DockStyle.Fill,Margin=new Padding(12,19,0,16),Style=ProgressBarStyle.Continuous};status.Controls.Add(footer,0,0);status.Controls.Add(progress,1,0);main.Controls.Add(status,0,2);
  BuildDashboard();BuildProfile();BuildCatalog();BuildDiagnostics();BuildHistory();BuildResources();BuildMaintenance();BuildScriptReview();BuildEasy();BuildPerformance();BuildNetworkWorkbench();BuildNetworkCenter();BuildSettingsPanels();BuildSourceReview();BuildFunctionalPages();BuildUnified();BuildProduct();BuildToolDirectory();ShowPage("Painel");
  workerTimer=new System.Windows.Forms.Timer {Interval=350};workerTimer.Tick+=(s,e)=>ReadWorkerProgress();
  PrepareEmbedded();
  Load+=async(s,e)=>{ready=true;RefreshHistory();RefreshCatalog();UpdateMetrics();if(EmbeddedInterface.Parent!=IntPtr.Zero){scanning=true;try{machine=await Task.Run(()=>App.ScanHardware());}finally{scanning=false;SetActions();footer.Text="Escolha a ação desta ferramenta.";}if(!App.IsUiTest()&&(title.Text=="Apps e RAM"||title.Text=="Manutenção"))await RefreshResources();return;}InitializeBridge();if(App.IsUiTest()||App.ToolMode)return;if(App.PreviewOutput!=null)StartPreview();else {await RefreshScan();await RefreshResources();}};
  KeyDown+=async(s,e)=>{if(inlineOverlay!=null){if(e.KeyCode==Keys.Escape&&inlineCancel!=null)inlineCancel();e.SuppressKeyPress=true;return;}if(e.Control&&e.KeyCode==Keys.F){ShowPage("Catálogo");search.Focus();search.SelectAll();e.SuppressKeyPress=true;}if(e.KeyCode==Keys.F5&&!busy&&!scanning){e.SuppressKeyPress=true;await RefreshScan();}};
  FormClosing+=(s,e)=>{if(busy||scanning||resourceScanning||easyRunning){e.Cancel=true;MessageBox.Show("Aguarde a operação terminar. O resultado e o backup serão salvos no histórico.",Text);}};
 }
 Panel Page(string name){var p=new Panel {Dock=DockStyle.Fill,BackColor=Theme.Bg};host.Controls.Add(p);pages[name]=p;return p;}
 TableLayoutPanel Rows(params float[] heights){var p=new TableLayoutPanel {Dock=DockStyle.Fill,RowCount=heights.Length,ColumnCount=1,Margin=Padding.Empty};foreach(float h in heights)p.RowStyles.Add(h<0?new RowStyle(SizeType.Percent,100):new RowStyle(SizeType.Absolute,h));return p;}
 // "Avançado / Alto Impacto" foi consolidado em "Otimizações" e não existe mais como
 // página; traduzir esse nome aposentado é legítimo. "Energia avançada" e "Ajustes
 // manuais" EXISTEM em pages e estavam na mesma lista, então TODA tentativa de abri-las
 // caía em Otimizações em silêncio: os botões que Ferramentas cria para cada página, os
 // itens Action="page" de performance-library.json, a navegação do modo embutido e o
 // mapa do V5Bridge apontavam para telas que nunca apareciam. Duas páginas inteiras eram
 // código morto visível. A regra passa a ser estrutural em vez de uma lista de nomes:
 // só cai em Otimizações o que não é página de verdade.
 void ShowPage(string key){if(!pages.ContainsKey(key))key="Otimizações";if(ready&&!App.IsUiTest()&&(key=="Apps e RAM"||key=="Manutenção"))BeginInvoke((Action)(async()=>await RefreshResources()));foreach(var p in pages)p.Value.Visible=p.Key==key;pages[key].BringToFront();foreach(var n in nav){n.Value.Active=n.Key==key;n.Value.Invalidate();}title.Text=key;subtitle.Text=key=="Otimizações"?"Selecione. Aplique. Acompanhe no histórico.":key=="Ferramentas"?"Todas as funções do Luke Optimizer.":key=="Catálogo"?"Busque um nome e veja o que cada item faz. As opções nativas têm backup.":key=="Otimização máxima"?"Escolha os ajustes. O modo fácil usa esta seleção.":key=="Seus 14 BATs"?"Conteúdo preservado, efeitos explicados e integração revisada.":key=="Apps e RAM"?"Consumo real, seleção explícita e fechamento sem apagar cache útil.":key=="Manutenção"?"Inicialização, serviços, temporários e foco — sempre opcionais.":key=="Diagnóstico"?"Leituras do seu PC e limites do que foi verificado.":key=="Histórico"?"Resultados por etapa e restauração dos valores anteriores.":"Seu PC, com ações claras e resultados verificáveis.";}
 void BuildDashboard(){
  var page=Page("Visão geral");var grid=Rows(214,112,-1);page.Controls.Add(grid);
  var hero=new Surface {Dock=DockStyle.Fill,Fill=Theme.HeroFill,BackColor=Theme.HeroFill,Padding=new Padding(25,17,25,17),Margin=new Padding(0,0,0,16)};grid.Controls.Add(hero,0,0);
  var heroGrid=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=2};heroGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,67));heroGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,33));hero.Controls.Add(heroGrid);
  var heroText=Rows(25,48,42,-1);heroGrid.Controls.Add(heroText,0,0);heroText.Controls.Add(Theme.Label("PERFIL REVISADO  /  BACKUP AUTOMÁTICO",9,Theme.Accent,true),0,0);heroText.Controls.Add(Theme.Label("Seu PC, no controle.",27,Theme.Text,true),0,1);heroText.Controls.Add(Theme.Label("Aplique os ajustes compatíveis e acompanhe cada resultado.",11,Theme.HeroText),0,2);
  var launch=Theme.Button("Otimização máxima  →",true);launch.Width=237;launch.Height=43;launch.Click+=(s,e)=>ShowPage("Otimização máxima");heroText.Controls.Add(launch,0,3);
  var aside=Rows(55,45,-1);aside.Padding=new Padding(26,15,0,5);heroGrid.Controls.Add(aside,1,0);aside.Controls.Add(Theme.Label(Builtins.Create().Count.ToString(),28,Theme.Accent,true),0,0);aside.Controls.Add(Theme.Label("ajustes no perfil\r\n6 pré-selecionados",10,Theme.Text),0,1);heroHint=Theme.Label("A compatibilidade será\r\nconferida neste PC.",9,Theme.Muted);aside.Controls.Add(heroHint,0,2);
  var metrics=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=4,RowCount=1};for(int n=0;n<4;n++)metrics.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,25));grid.Controls.Add(metrics,0,1);
  Metric(metrics,0,App.Items.Count.ToString(),"Arquivos catalogados",Theme.Text);verifiedMetric=Metric(metrics,1,"—","Configurações conferidas",Theme.Accent);attentionMetric=Metric(metrics,2,"—","Itens com atenção",Theme.Amber);externalMetric=Metric(metrics,3,"—","Externos não testados",Theme.Muted);
  var lower=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=2};lower.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,55));lower.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,45));grid.Controls.Add(lower,0,2);
  var review=new Surface {Dock=DockStyle.Fill};lower.Controls.Add(review,0,0);var r=Rows(32,65,60,60,-1);review.Controls.Add(r);r.Controls.Add(Theme.Label("O que a revisão encontrou",14,Theme.Text,true),0,0);
  r.Controls.Add(Theme.Label("Nomes que não descrevem o ajuste\r\n“Prioridade de GPU” alterava o sistema de arquivos.",10,Theme.Muted),0,1);r.Controls.Add(Theme.Label("59 pares com valores conflitantes\r\nIncluem ajustes e seus reversores predefinidos.",10,Theme.Muted),0,2);r.Controls.Add(Theme.Label("Execuções que exigem atenção\r\nBoot, serviços, paginação e comandos inválidos.",10,Theme.Muted),0,3);
  var inspect=Theme.Button("Ver revisão do catálogo");inspect.Dock=DockStyle.Bottom;inspect.Click+=(s,e)=>{reviewFilter.SelectedItem="Com atenção";ShowPage("Catálogo");};r.Controls.Add(inspect,0,4);
  var pc=new Surface {Dock=DockStyle.Fill,Margin=new Padding(0,0,0,14)};lower.Controls.Add(pc,1,0);var info=Rows(36,55,55,38,38,-1);pc.Controls.Add(info);info.Controls.Add(Theme.Label("Neste computador",14,Theme.Text,true),0,0);cpu=Theme.Label("CPU  ·  aguardando consulta",10,Theme.Text);gpu=Theme.Label("GPU  ·  aguardando consulta",10,Theme.Text);ram=Theme.Label("MEMÓRIA  ·  —",10,Theme.Muted);disk=Theme.Label("DISCO  ·  —",10,Theme.Muted);os=Theme.Label("Abra no Windows para consultar o estado real.",9,Theme.Muted);info.Controls.Add(cpu,0,1);info.Controls.Add(gpu,0,2);info.Controls.Add(ram,0,3);info.Controls.Add(disk,0,4);info.Controls.Add(os,0,5);
 }
 Label Metric(TableLayoutPanel parent,int col,string value,string label,Color color){var surface=new Surface {Dock=DockStyle.Fill,Padding=new Padding(16,10,12,12),Margin=new Padding(0,0,col==3?0:12,15)};parent.Controls.Add(surface,col,0);var r=Rows(47,-1);surface.Controls.Add(r);var l=Theme.Label(value,25,color,true);r.Controls.Add(l,0,0);r.Controls.Add(Theme.Label(label,9,Theme.Muted),0,1);return l;}
 void BuildProfile(){
  var page=Page("Otimização máxima");var root=Rows(66,-1,73,58);page.Controls.Add(root);
  profileNote=Theme.Label("Marque apenas o que você entende. Cada cartão explica o que muda, o possível impacto e como desfazer.\r\nO botão extremo não aplica políticas protegidas de navegador, Widgets ou Notícias; elas ficam no Catálogo para aplicação individual.",10,Theme.Muted);root.Controls.Add(profileNote,0,0);
  var scroll=new Panel {Dock=DockStyle.Fill,AutoScroll=true,BackColor=Theme.Bg};root.Controls.Add(scroll,0,1);var flow=new TableLayoutPanel {Dock=DockStyle.Top,AutoSize=true,ColumnCount=1,RowCount=8,Padding=new Padding(0,0,8,0)};scroll.Controls.Add(flow);int n=0;
  foreach(var i in App.Items.Where(x=>x.Native&&x.MaxEligible)) {
   var card=new Surface {Dock=DockStyle.Top,Height=112,Padding=new Padding(15,10,13,10),Margin=new Padding(0,0,0,10)};flow.RowStyles.Add(new RowStyle(SizeType.Absolute,122));flow.Controls.Add(card,0,n++);
   var row=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=3,RowCount=2};row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,32));row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,156));row.RowStyles.Add(new RowStyle(SizeType.Absolute,26));row.RowStyles.Add(new RowStyle(SizeType.Percent,100));card.Controls.Add(row);
   var pick=new ReadableCheckBox {Checked=i.DefaultSelected,AutoSize=false,Dock=DockStyle.Fill,AccessibleName=i.Name,BackColor=Theme.Card,ForeColor=Theme.Accent,Margin=new Padding(0,1,0,0)};picks[i.Id]=pick;row.Controls.Add(pick,0,0);row.Controls.Add(Theme.Label(i.Name,11,Theme.Text,true),1,0);var state=Theme.Label("Aguardando análise",9,Theme.Muted);state.TextAlign=ContentAlignment.MiddleRight;row.Controls.Add(state,2,0);pickStates[i.Id]=state;var info=OptionInfo.For(i);var desc=Theme.Label("O que faz: "+(i.Review.Length>0?i.Review[0]:"Sem descrição")+"\r\nImpacto: "+(i.Review.Length>1?i.Review[1]:"Confira o resultado")+"\r\nClassificação: "+info.Classification+" · "+info.Restart+" · "+info.Undo,9,Theme.Muted);row.Controls.Add(desc,1,1);row.SetColumnSpan(desc,2);var tooltip=new ToolTip();tooltip.SetToolTip(desc,desc.Text);pick.CheckedChanged+=(s,e)=>{if(!updatingPicks)UpdateProfile();};
  }
  profileSummary=Theme.Label("Antes de aplicar: o app salva um backup. Depois: confere cada etapa. Se algo falhar, restaura o conjunto; também é possível usar Desfazer no Histórico.",10,Theme.Muted);root.Controls.Add(profileSummary,0,2);
  var actions=new FlowLayoutPanel {Dock=DockStyle.Fill,WrapContents=false,AutoScroll=true};maxApply=Theme.Button("Executar otimização máxima",true);maxApply.Width=263;maxApply.Height=44;maxApply.Click+=async(s,e)=>{var ids=picks.Where(x=>x.Value.Checked&&x.Value.Enabled).Select(x=>x.Key).ToArray();if(ids.Length>0)await Elevated("--max",String.Join(",",ids));};actions.Controls.Add(maxApply);var reset=Theme.Button("Seleção padrão");reset.Width=160;reset.Height=44;reset.Click+=(s,e)=>{foreach(var i in App.Items.Where(x=>x.Native&&x.MaxEligible))picks[i.Id].Checked=i.DefaultSelected&&picks[i.Id].Enabled;UpdateProfile();};actions.Controls.Add(reset);root.Controls.Add(actions,0,3);
 }
 void BuildCatalog(){
  var page=Page("Catálogo");var root=Rows(43,42,-1,146,48);page.Controls.Add(root);
  var finder=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=2};finder.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));finder.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,295));search=new TextBox {Dock=DockStyle.Fill,BackColor=Theme.Card,ForeColor=Theme.Text,BorderStyle=BorderStyle.FixedSingle,Font=Theme.Font(12),Margin=new Padding(0,0,12,0),AccessibleName="Buscar nome, categoria ou conteúdo da revisão"};search.HandleCreated+=(s,e)=>{if(App.IsWindows)SendMessage(search.Handle,0x1501,(IntPtr)1,"Buscar ajuste, jogo ou hardware…  Ctrl+F");};categories=Combo();categories.Items.Add("Todas as categorias");// As 35 categorias brutas vinham cruas para a tela: ".Bats", "Regedits", "99 - Seus 14 BATs revisados" e prefixos numéricos. FeatureNaming.Groups unifica as // repetidas (havia "-3 - Personalização" E "-4 - Personalização") e dá nome limpo. // O Tag guarda as categorias BRUTAS, então o filtro não depende do texto exibido.
  foreach(var group in FeatureNaming.Groups(FeatureNaming.ForUser(App.Items))){categoryFilters.Add(group.Key,group.Value);categories.Items.Add(group.Key);}categories.SelectedIndex=0;finder.Controls.Add(search,0,0);finder.Controls.Add(categories,1,0);root.Controls.Add(finder,0,0);
  var filters=new FlowLayoutPanel {Dock=DockStyle.Fill,WrapContents=false};reviewFilter=Combo();reviewFilter.Width=220;reviewFilter.Items.AddRange(new object[]{"Todos · ocultar suporte","Ajustes revisados","Com atenção","Execução bloqueada","Duplicados / repetidos","Com conflitos","Favoritos","Arquivos de suporte","Todos os arquivos"});reviewFilter.SelectedIndex=0;stateFilter=Combo();stateFilter.Width=214;stateFilter.Items.AddRange(new object[]{"Todos os estados","Configurações conferidas","Parcial","Não configurado","Falha na leitura","Não verificado","Não compatível"});stateFilter.SelectedIndex=0;filters.Controls.Add(reviewFilter);filters.Controls.Add(stateFilter);root.Controls.Add(filters,0,1);
  catalog=new CatalogList();catalog.Columns.Add("Ajuste / arquivo",385);catalog.Columns.Add("Tipo",91);catalog.Columns.Add("Revisão",153);catalog.Columns.Add("Estado neste PC",159);catalog.Resize+=(s,e)=>FitColumns(catalog);catalog.SelectedIndexChanged+=(s,e)=>ShowItem();root.Controls.Add(catalog,0,2);
  var panel=new Surface {Dock=DockStyle.Fill,Margin=new Padding(0,12,0,10),Padding=new Padding(15,12,15,8)};detail=Theme.ReadBox();panel.Controls.Add(detail);root.Controls.Add(panel,0,3);
  var actions=new FlowLayoutPanel {Dock=DockStyle.Fill,WrapContents=false,AutoScroll=true};apply=Theme.Button("Aplicar selecionado",true);apply.Width=181;apply.Click+=async(s,e)=>await RunSelected();favorite=Theme.Button("Favoritar");favorite.Width=106;favorite.Click+=(s,e)=>ToggleFavorite();var contents=Theme.Button("Conteúdo e leitura");contents.Width=172;contents.Click+=(s,e)=>ViewContent();var origin=Theme.Button("Abrir origem");origin.Width=122;origin.Click+=(s,e)=>{var i=Selected();if(i!=null)OpenUrl(i.Url);};actions.Controls.Add(apply);actions.Controls.Add(contents);actions.Controls.Add(favorite);actions.Controls.Add(origin);root.Controls.Add(actions,0,4);
  search.TextChanged+=(s,e)=>RefreshCatalog();categories.SelectedIndexChanged+=(s,e)=>RefreshCatalog();reviewFilter.SelectedIndexChanged+=(s,e)=>RefreshCatalog();stateFilter.SelectedIndexChanged+=(s,e)=>RefreshCatalog();
 }
 void FitColumns(CatalogList list){if(list.Columns.Count!=4)return;int width=Math.Max(640,list.ClientSize.Width-22);if(list==catalog){list.Columns[0].Width=Math.Max(240,width-445);list.Columns[1].Width=92;list.Columns[2].Width=173;list.Columns[3].Width=180;}else{list.Columns[0].Width=157;list.Columns[1].Width=Math.Max(200,width-471);list.Columns[2].Width=210;list.Columns[3].Width=104;}}
 ComboBox Combo(){return new ReadableComboBox {Dock=DockStyle.Top,DropDownStyle=ComboBoxStyle.DropDownList,BackColor=Theme.Card,ForeColor=Theme.Text,FlatStyle=FlatStyle.Flat,Font=Theme.Font(10),Margin=new Padding(0,1,12,0)};}
 void BuildDiagnostics(){
  var page=Page("Diagnóstico");var root=Rows(69,-1,109);page.Controls.Add(root);diagHeader=Theme.Label("A análise consulta configurações e serviços. Nenhum benchmark de FPS ou latência é executado.\r\n“Conferido” indica leitura do Windows. “Valores conferidos” indica correspondência no Registro.",10,Theme.Muted);root.Controls.Add(diagHeader,0,0);var card=new Surface {Dock=DockStyle.Fill,Margin=new Padding(0,0,0,16)};diagnosticText=Theme.ReadBox();diagnosticText.Font=Theme.Font(10);card.Controls.Add(diagnosticText);root.Controls.Add(card,0,1);
  var actions=new FlowLayoutPanel {Dock=DockStyle.Fill,WrapContents=true};point=Theme.Button("Ponto de restauração");point.Width=189;point.Click+=async(s,e)=>await Elevated("--restorepoint","system");actions.Controls.Add(point);
  AddSystemButton(actions,"Proteção do Sistema","SystemPropertiesProtection.exe","");AddSettingsButton(actions,"Modo Jogo","ms-settings:gaming-gamemode");AddSettingsButton(actions,"Capturas","ms-settings:gaming-gamedvr");AddSettingsButton(actions,"Gráficos / GPU","ms-settings:display-advancedgraphics");AddSettingsButton(actions,"Inicialização","ms-settings:startupapps");AddSettingsButton(actions,"Armazenamento","ms-settings:storagesense");export=Theme.Button("Exportar diagnóstico");export.Width=182;export.Click+=(s,e)=>ExportReport();actions.Controls.Add(export);
  // A pergunta que nenhum teste automático responde: aplicar MUDA mesmo o Windows?
  // Estes dois botões respondem NESTA máquina. Ver source\SelfCheck.cs.
  var checkRead=Theme.Button("Conferir estado atual");checkRead.Name="selfcheck-read";checkRead.Width=196;checkRead.Margin=new Padding(0,0,10,10);
  checkRead.Click+=async(s,e)=>await RunSelfCheck(false);actions.Controls.Add(checkRead);
  var checkFull=Theme.Button("Provar que aplicar funciona");checkFull.Name="selfcheck-full";checkFull.Width=232;checkFull.Margin=new Padding(0,0,10,10);
  checkFull.Click+=async(s,e)=>await RunSelfCheck(true);actions.Controls.Add(checkFull);
  root.Controls.Add(actions,0,2);
 }
 void AddSystemButton(FlowLayoutPanel p,string text,string exe,string args){var b=Theme.Button(text);b.Width=173;b.Margin=new Padding(0,0,10,10);b.Click+=(s,e)=>OpenSystem(exe,args);p.Controls.Add(b);}
 void AddSettingsButton(FlowLayoutPanel p,string text,string uri){var b=Theme.Button(text);b.Width=137;b.Margin=new Padding(0,0,10,10);b.Click+=(s,e)=>{if(App.IsWindows)OpenLocal(uri);};p.Controls.Add(b);}
 void BuildHistory(){
  var page=Page("Histórico");var root=Rows(57,-1,170,48);page.Controls.Add(root);root.Controls.Add(Theme.Label("Desfazer restaura a última alteração gerenciada, usando seu backup real.\r\nScripts e programas externos têm registro de execução; suas mudanças internas não são restauradas pelo app.",10,Theme.Muted),0,0);history=new CatalogList();history.Columns.Add("Data e hora",157);history.Columns.Add("Operação",310);history.Columns.Add("Resultado",204);history.Columns.Add("Tipo",100);history.Resize+=(s,e)=>FitColumns(history);history.SelectedIndexChanged+=(s,e)=>ShowRecord();root.Controls.Add(history,0,1);var box=new Surface {Dock=DockStyle.Fill,Margin=new Padding(0,12,0,10),Padding=new Padding(14)};historyDetail=Theme.ReadBox();box.Controls.Add(historyDetail);root.Controls.Add(box,0,2);var actions=new FlowLayoutPanel {Dock=DockStyle.Fill,WrapContents=false};undo=Theme.Button("Desfazer última alteração",true);undo.Width=237;undo.Click+=async(s,e)=>await UndoLatest();actions.Controls.Add(undo);var open=Theme.Button("Abrir backups");open.Click+=(s,e)=>OpenLocal(App.RecordsRoot);actions.Controls.Add(open);AddHistoryActions(actions);root.Controls.Add(actions,0,3);
 }
 Observed State(Item i){Observed s;return states.TryGetValue(i.Id,out s)?s:new Observed {State="Não verificado",Detail="Execute Analisar este PC."};}
 Item Selected(){return catalog.SelectedItems.Count==0?null:(Item)catalog.SelectedItems[0].Tag;}
 void RefreshCatalog(){if(!ready)return;string selected=Selected()==null?null:Selected().Id;string q=search.Text.Trim(),cat=categories.SelectedItem as string,review=reviewFilter.SelectedItem as string,state=stateFilter.SelectedItem as string;catalog.BeginUpdate();catalog.Items.Clear();
  // Antes: Int32.Parse do prefixo numérico da categoria — uma categoria nova sem número
  // derrubaria a lista inteira com FormatException. A ordem agora vem de FeatureNaming.
  foreach(var i in FeatureNaming.ForUser(App.Items).OrderBy(x=>FeatureNaming.Rank(FeatureNaming.Category(x.Category))).ThenBy(x=>FeatureNaming.Category(x.Category),StringComparer.CurrentCultureIgnoreCase).ThenBy(x=>x.ReviewTitle,StringComparer.CurrentCultureIgnoreCase)) {
   if(cat!=null&&cat!="Todas as categorias"){string[] raw;if(!categoryFilters.TryGetValue(cat,out raw)||!raw.Contains(i.Category))continue;}
   if(q.Length>0&&(i.Id+" "+i.Name+" "+i.ReviewTitle+" "+i.Path+" "+String.Join(" ",i.Review??new string[0])).IndexOf(q,StringComparison.CurrentCultureIgnoreCase)<0)continue;
   if(review=="Todos · ocultar suporte"&&i.Mode=="Suporte")continue;if(review=="Ajustes revisados"&&!i.Native)continue;
   if(review=="Com atenção"&&!Attention(i))continue;if(review=="Execução bloqueada"&&i.ManualAllowed)continue;
   if(review=="Duplicados / repetidos"&&String.IsNullOrEmpty(i.DuplicateOf)&&(i.SameTargets??new string[0]).Length==0)continue;
   if(review=="Com conflitos"&&(i.Conflicts??new string[0]).Length==0)continue;if(review=="Favoritos"&&!favorites.Contains(i.Id))continue;if(review=="Arquivos de suporte"&&i.Mode!="Suporte")continue;
   var observed=State(i);if(state=="Configurações conferidas"&&!observed.Verified)continue;if(state!="Todos os estados"&&state!="Configurações conferidas"&&observed.State!=state)continue;
   var row=new ListViewItem((favorites.Contains(i.Id)?"★  ":"")+i.ReviewTitle){Tag=i};row.SubItems.Add(i.Mode);row.SubItems.Add(i.ReviewLevel);row.SubItems.Add(observed.State);catalog.Items.Add(row);if(i.Id==selected)row.Selected=true;
  }
  catalog.EndUpdate();if(catalog.SelectedItems.Count==0&&catalog.Items.Count>0)catalog.Items[0].Selected=true;ShowItem();
 }
 bool Attention(Item i){return new[]{"Alto risco","Erro no original","Não comprovado","Nome incorreto","Indisponível","Condicional"}.Contains(i.ReviewLevel);}
 void ShowItem(){if(apply==null)return;var i=Selected();if(i==null){detail.Text="Nenhum item nesta seleção.";apply.Enabled=favorite.Enabled=false;return;}var s=State(i);detail.Text=i.ReviewTitle+"  ·  "+i.ReviewLevel+"  ·  "+s.State+"\r\n"+String.Join("\r\n",i.Review??new string[0])+((i.Conflicts??new string[0]).Length>0?"\r\nConflita com "+i.Conflicts.Length+" outro(s) item(ns). Veja Conteúdo e leitura.":"")+(String.IsNullOrEmpty(i.ReplacementId)?"":"\r\nSubstituição disponível no perfil revisado.");
  apply.Text=!String.IsNullOrEmpty(i.ReplacementId)?"Usar versão revisada":i.Native?"Aplicar este ajuste":i.Mode=="Script"||i.Type=="Programa"||i.Type=="Instalador"?"Executar individualmente":i.Mode=="Integrado"||i.Mode=="Energia"?"Aplicar selecionado":"Abrir arquivo";
  apply.Enabled=ready&&!busy&&!scanning&&(!String.IsNullOrEmpty(i.ReplacementId)||(i.Available&&App.AssetIsPresent(i)&&i.ManualAllowed&&machine.Windows&&s.State!="Não compatível"));if(!App.AssetIsPresent(i)){apply.Text="Arquivo ausente";detail.Text+="\r\nEste arquivo não está disponível no pacote atual. Seu conteúdo e revisão continuam acessíveis em Conteúdo e leitura.";}favorite.Enabled=!busy;favorite.Text=favorites.Contains(i.Id)?"★ Salvo":"Favoritar";
 }
 void ToggleFavorite(){var i=Selected();if(i==null)return;if(!favorites.Add(i.Id))favorites.Remove(i.Id);try{File.WriteAllText(favoritesPath,App.Json.Serialize(favorites.ToArray()));}catch(Exception e){MessageBox.Show(e.Message,"Favoritos");}RefreshCatalog();}
 void ViewContent(){var i=Selected();if(i==null)return;var s=new StringBuilder();s.AppendLine(i.ReviewTitle).AppendLine("Arquivo original: "+i.Name).AppendLine(i.Path).AppendLine().AppendLine("REVISÃO").AppendLine(String.Join("\r\n",i.Review??new string[0])).AppendLine().AppendLine("LEITURA NESTE PC").AppendLine(State(i).Detail).AppendLine().AppendLine("CONFLITOS DE VALORES");foreach(var id in i.Conflicts??new string[0]){var other=App.Items.FirstOrDefault(x=>x.Id==id);s.AppendLine(other==null?id:other.Path);}s.AppendLine().AppendLine("CONTEÚDO ORIGINAL").AppendLine(String.IsNullOrEmpty(i.Text)?"Sem texto inspecionável. Programas de terceiros não foram executados para validar seu funcionamento.":i.Text);TextDialog("Revisão — "+i.Name,s.ToString());}
 void TextDialog(string name,string text){if(EmbeddedInterface.Parent!=IntPtr.Zero){InlineReview(name,text,false);return;}using(var f=new Form {Text=name,Size=new Size(960,680),MinimumSize=new Size(650,420),StartPosition=FormStartPosition.CenterParent,BackColor=Theme.Card,Padding=new Padding(22)}){var box=Theme.ReadBox();box.Font=Theme.Font(10);box.Text=text.Replace("\r\n","\n").Replace("\n",Environment.NewLine);f.Controls.Add(box);f.ShowDialog(this);}}
 async Task RefreshScan(){if(busy||scanning||resourceScanning)return;scanning=true;scan.Enabled=false;progress.Visible=true;progress.Value=0;footer.Text="Consultando hardware, preferências e serviços…";SetActions();
  // O perfil estruturado é lido na MESMA thread de fundo da análise, junto do resto.
  // WMI aqui tem timeout de 8 s por consulta; chamar isso na thread da interface a cada
  // clique em Detalhes travaria a janela — por isso é lido uma vez e guardado.
  try {var m=await Task.Run(()=>App.ScanHardware());var p=await Task.Run(()=>App.ReadProfile(m));var pg=new Progress<int>(v=>{progress.Value=v;footer.Text="Conferindo catálogo: "+v+"%";});states=await Task.Run(()=>App.ScanAll(m,n=>((IProgress<int>)pg).Report(n)));machine=m;profile=p;serviceText=await Task.Run(()=>App.ServiceReport());lastScan=DateTime.Now;footer.Text=m.Windows?"Análise concluída às "+lastScan.ToString("HH:mm")+" · Configurações consultadas; FPS não medido.":"Leituras disponíveis ao abrir este app no Windows.";}
  catch(Exception e){footer.Text="Análise incompleta: "+e.Message;}
  finally{scanning=false;scan.Enabled=true;progress.Visible=false;RefreshHistory();RefreshCatalog();UpdateMetrics();UpdateProfile();SetActions();}
 }
 void UpdateMetrics(){verifiedMetric.Text=states.Count==0?"—":states.Values.Count(x=>x.Verified).ToString();attentionMetric.Text=App.Items.Count(Attention).ToString();externalMetric.Text=App.Items.Count(x=>x.ReviewLevel=="Externo não testado").ToString();cpu.Text="CPU  ·  "+machine.Cpu;gpu.Text="GPU  ·  "+machine.Gpu;ram.Text="MEMÓRIA  ·  "+machine.Ram;disk.Text="DISCO  ·  "+machine.Disk;os.Text=machine.OS;
  // O bloco estruturado entra ao lado do texto livre, não no lugar dele: ele diz
  // explicitamente o que NÃO foi detectado e por quê, que é o que falta num relatório de
  // suporte. Enquanto não houver análise, a seção declara isso em vez de ficar em branco.
  diagnosticText.Text="COMPUTADOR\r\n"+machine.OS+"\r\nCPU: "+machine.Cpu+"\r\nGPU: "+machine.Gpu+"\r\nMemória: "+machine.Ram+"\r\nDisco do sistema: "+machine.Disk+"\r\nPaginação: "+machine.Pagefile+"\r\nEnergia: "+machine.Power+
   "\r\n\r\nPERFIL DETECTADO (usado pelo motor de compatibilidade)\r\n"+(profile==null?"Ainda não analisado. Clique em Analisar este PC.":App.ProfileReport(profile))+
   "\r\n"+OptimizationRegistry.Score(profile,delegate(string id){Observed found;return states.TryGetValue(id,out found)&&found.State=="Valores conferidos";})+"\r\n\r\n"+serviceText+"\r\n\r\nO QUE FOI REVISADO\r\n546 arquivos (532 anteriores + 14 BATs); 112 entradas de Registro normalizadas; 33 planos externos.\r\nRevisão estática do conteúdo legível, duplicatas e conflitos. 64 binários/pacotes não tiveram seu funcionamento testado.\r\n\r\nCOMO LER OS ESTADOS\r\nConferido: configuração consultada por API/plano ativo.\r\nValores conferidos: todos os valores do Registro coincidem com o ajuste. Isso não prova que uma chave legada seja usada pelo Windows.\r\nParcial: somente parte das configurações coincide.\r\nNão configurado: não coincide com o ajuste; pode estar no padrão do Windows.\r\nNão verificado: sem leitura que comprove o funcionamento.\r\nFalha na leitura: consulta não concluída; veja o motivo no catálogo.\r\n\r\nNenhum medidor de “saúde 100%”, ganho de FPS ou redução de ping foi estimado.";
 }
 void UpdateProfile(){if(maxApply==null)return;updatingPicks=true;int available=0,selected=0;foreach(var i in App.Items.Where(x=>x.Native&&x.MaxEligible)) {string incompatible=App.Compatibility(i,machine);bool allowed=machine.Windows&&incompatible==null;var pick=picks[i.Id];pick.Enabled=allowed&&!busy&&!scanning&&!resourceScanning&&!easyRunning;if(!allowed&&lastScan!=default(DateTime))pick.Checked=false;var state=State(i);pickStates[i.Id].Text=allowed?state.State:machine.Windows?"Ignorado neste PC":"Aguardando Windows";pickStates[i.Id].ForeColor=allowed?Theme.StatusColor(state.State):Theme.Amber;if(allowed)available++;if(allowed&&pick.Checked)selected++;}updatingPicks=false;
  profileSummary.Text=selected+" ajuste(s) selecionado(s) · "+available+" compatível(is) neste PC.\r\nO backup registra os valores anteriores. Se um ajuste falhar, ele é restaurado individualmente e os demais continuam. Consulte o resultado por etapa.";heroHint.Text=machine.Windows?available+" ajuste(s) compatível(is) neste PC.\r\nLeia o cartão antes de aplicar.":"Abra no Windows para\r\nconferir a compatibilidade.";maxApply.Enabled=ready&&!busy&&!scanning&&!resourceScanning&&!easyRunning&&selected>0;RefreshEasySummary();}
 void SetActions(){ShowItem();if(point!=null)point.Enabled=ready&&machine.Windows&&!busy&&!scanning&&!resourceScanning&&!easyRunning;if(undo!=null)undo.Enabled=ready&&machine.Windows&&!busy&&!scanning&&!resourceScanning&&!easyRunning&&records.Any(App.CanUndo);if(export!=null)export.Enabled=!busy&&!scanning&&!resourceScanning;UpdateProfile();if(apply!=null&&(resourceScanning||easyRunning))apply.Enabled=false;if(maxApply!=null&&(resourceScanning||easyRunning))maxApply.Enabled=false;ExtraEnabled();UpdateHome();UpdateFunctionalActions();}
 void RefreshHistory(){records=App.History();history.BeginUpdate();history.Items.Clear();foreach(var r in records){DateTime t;var row=new ListViewItem(DateTime.TryParse(r.Time,out t)?t.ToLocalTime().ToString("dd/MM/yy HH:mm"):r.Time){Tag=r};row.SubItems.Add(r.Name);row.SubItems.Add(r.Status);row.SubItems.Add(r.Kind);history.Items.Add(row);}history.EndUpdate();if(history.Items.Count>0)history.Items[0].Selected=true;ShowRecord();SetActions();}
 void ShowRecord(){if(historyDetail==null)return;if(history.SelectedItems.Count==0){historyDetail.Text="As operações aparecerão aqui. Ainda não há resultado de execução para mostrar.";return;}var r=(Record)history.SelectedItems[0].Tag;var s=new StringBuilder();s.AppendLine(r.Name+" · "+r.Status).AppendLine(r.Message).AppendLine();foreach(var step in r.Steps??new List<StepResult>())s.AppendLine(step.Name+" — "+step.Status+"\r\n"+step.Message);historyDetail.Text=ChangeAudit.Report(r);UpdateFunctionalActions();}
 async Task RunSelected(){var i=Selected();if(i==null||busy||scanning)return;if(!String.IsNullOrEmpty(i.ReplacementId)){ShowPage("Otimização máxima");return;}
  if(i.Native||i.Mode=="Integrado"||i.Mode=="Energia"||i.Mode=="Script"||i.Type=="Programa"||i.Type=="Instalador") {
   string text=i.ReviewTitle+"\r\n\r\n"+String.Join("\r\n",i.Review??new string[0])+"\r\n\r\n"+(i.Native||i.Mode=="Integrado"||i.Mode=="Energia"?"A configuração anterior será registrada.":"Este processo externo não tem desfazer automático.")+"\r\nExecutar agora?";
   if(await Confirm(text,"Aplicar ajuste"))await Elevated("--apply",i.Id);
  } else {busy=true;SetActions();try{await Task.Run(()=>App.EnsureGroup(i,n=>{}));App.Verify(i);OpenLocal(App.LocalAsset(i.Asset));}catch(Exception e){MessageBox.Show(e.Message,"Abrir arquivo");}finally{busy=false;SetActions();}}
 }
 async Task UndoLatest(){if(busy||scanning)return;var r=records.FirstOrDefault(App.CanUndo);if(r==null)return;if(await Confirm("Restaurar os valores anteriores de “"+r.Name+"”?\r\n\r\nO app interrompe a restauração se detectar mudanças posteriores nesses valores.","Desfazer alteração"))await Elevated("--undo",r.Id);}
 async Task<bool> Elevated(string action,string id){
#if TESTS
  if(TestElevation!=null)return await TestElevation(action,id);
#endif
  if(busy||productRunning||scanning||resourceScanning||!machine.Windows)return false;
  if(action=="--apply-many"||action=="--max"||action=="--extreme"||(action=="--apply"&&App.Items.Any(i=>i.Id==CatalogIds.Canonical(id)&&i.Native))){
   List<Item> chosen;try{chosen=action=="--extreme"?ExtremeProfile.Resolve(id):LiquidProtocol.Resolve(id);App.UniqueOperations(chosen);}catch(Exception e){footer.Text="A seleção não pôde ser preparada: "+e.Message;MessageBox.Show(footer.Text,Text);SetActions();return false;}
   cancelControlledBatch=false;var groups=new[]{chosen.Where(i=>!LiquidProtocol.NeedsAdmin(new[]{i})).ToArray(),chosen.Where(i=>LiquidProtocol.NeedsAdmin(new[]{i})).ToArray()};bool all=true;
   foreach(var group in groups){if(cancelControlledBatch){all=false;break;}if(group.Length==0)continue;var request=ExecutionControl.Create(group.Select(i=>i.Id).ToArray(),false,true);activeControlledRequest=request.Id;bool ok=await ElevatedCore("--execute-profile",request.Id);all=ok&&all;activeControlledRequest=null;}
   return all;
  }
  return await ElevatedCore(action,id);
 }
 async Task<bool> ElevatedCore(string action,string id){
 if(busy||productRunning||scanning||resourceScanning||!machine.Windows)return false;bool succeeded=false;bool needsAdmin=false;busy=true;SetActions();scan.Enabled=false;progress.Visible=true;progress.Value=0;footer.Text="Aguardando confirmação do Windows…";try{if(File.Exists(App.ProgressFile))File.Delete(App.ProgressFile);}catch{}workerTimer.Start();
  try {needsAdmin=App.ActionNeedsAdmin(action,id);var info=new ProcessStartInfo(Application.ExecutablePath,action+" "+App.Quote(id)+" "+App.Quote(App.Sid)){UseShellExecute=true,Verb=needsAdmin?"runas":"",WorkingDirectory=App.DataRoot};using(var p=Process.Start(info)){footer.Text="Executando operação. Acompanhe o progresso e o histórico…";await Task.Run(()=>p.WaitForExit());succeeded=p.ExitCode==0;footer.Text=succeeded?"Operação concluída. Consulte o resultado por etapa.":"Operação não concluída. Consulte o histórico e a mensagem do Windows.";}}
  catch(System.ComponentModel.Win32Exception e){try{App.RecordLaunchFailure(action,id,e,needsAdmin);}catch{}footer.Text=e.NativeErrorCode==1223?"Operação cancelada no Windows. Nenhuma etapa foi iniciada.":e.Message;}
  catch(Exception e){footer.Text=e.Message;MessageBox.Show(e.Message,Text);}
  finally {workerTimer.Stop();progress.Style=ProgressBarStyle.Continuous;busy=false;scan.Enabled=true;progress.Visible=false;RefreshHistory();ShowPage("Histórico");}
  string result=footer.Text;await RefreshScan();footer.Text=result;SetActions();
  return succeeded;
 }
 void ReadWorkerProgress(){try{var p=App.Json.Deserialize<ProgressState>(AtomicStore.Read(App.ProgressFile));progress.Style=ProgressBarStyle.Marquee;footer.Text=p.Stage+" · "+p.Detail;}catch{}}
 void OpenSystem(string exe,string args){if(!App.IsWindows)return;try{Process.Start(new ProcessStartInfo(App.SystemExe(exe),args){UseShellExecute=true});}catch(Exception e){MessageBox.Show(e.Message,Text);}}
 void OpenLocal(string path){try{Process.Start(new ProcessStartInfo(path){UseShellExecute=true});}catch(Exception e){MessageBox.Show(e.Message,Text);}}
 void OpenUrl(string url){Uri u;if(!Uri.TryCreate(url,UriKind.Absolute,out u)||u.Scheme!="https"){MessageBox.Show("Não há origem web para este item.",Text);return;}OpenLocal(url);}
 void ExportReport(){using(var d=new SaveFileDialog {Title="Salvar diagnóstico",Filter="Relatório HTML|*.html",FileName="LukeOptimizer-Diagnostico-"+DateTime.Now.ToString("yyyyMMdd-HHmm")+".html"})if(d.ShowDialog(this)==DialogResult.OK)try{File.WriteAllText(d.FileName,ReportHtml(),new UTF8Encoding(false));footer.Text="Diagnóstico exportado para "+d.FileName;}catch(Exception e){MessageBox.Show(e.Message,"Exportar diagnóstico");}}
 string ReportHtml(){Func<string,string> h=s=>System.Web.HttpUtility.HtmlEncode(s??"");var b=new StringBuilder("<!doctype html><html lang='pt-BR'><meta charset='utf-8'><title>Luke Optimizer — diagnóstico</title><style>body{font:15px system-ui;background:#10151d;color:#e8f0f5;margin:40px;line-height:1.55}h1{color:#8de9b8}table{border-collapse:collapse;width:100%}th,td{padding:12px;text-align:left;border-bottom:1px solid #334154;vertical-align:top}th{background:#202c3c}pre{white-space:pre-wrap}small{color:#a6b6c5}</style><h1>Luke Optimizer 6.1.2</h1><p>Diagnóstico em ");b.Append(h(DateTime.Now.ToString("g"))).Append("</p><pre>").Append(h(diagnosticText.Text)).Append("</pre><h2>Catálogo completo</h2><p>Revisão estática e estado consultado. Valores coincidentes não comprovam desempenho.</p><table><tr><th>Arquivo / ajuste</th><th>Revisão</th><th>Estado</th><th>Observações</th></tr>");foreach(var i in App.Items)b.Append("<tr><td>").Append(h(i.ReviewTitle)).Append("<br><small>").Append(h(i.Path)).Append("</small></td><td>").Append(h(i.ReviewLevel)).Append("</td><td>").Append(h(State(i).State)).Append("</td><td>").Append(h(String.Join("; ",i.Review??new string[0]))).Append("</td></tr>");b.Append("</table><h2>Histórico</h2>");foreach(var r in records)b.Append("<h3>").Append(h(r.Name+" — "+r.Status)).Append("</h3><pre>").Append(h(r.Message+"\n"+String.Join("\n",(r.Steps??new List<StepResult>()).Select(x=>x.Name+" — "+x.Status+": "+x.Message)))).Append("</pre>");return b.Append("</html>").ToString();}
 void StartPreview(){footer.Text="PRÉVIA DA INTERFACE · dados de Windows não consultados";progress.Visible=false;UpdateMetrics();UpdateProfile();var timer=new System.Windows.Forms.Timer {Interval=500};int step=0;string[] targets={"Central de desempenho","Perfis de jogos","Energia avançada","FPS e stutter","Hardware e rede","Modo fácil","Apps e RAM","Manutenção","Otimização máxima","Catálogo","Diagnóstico","Histórico","Rede e latência","Arquivos e referências"};timer.Tick+=(s,e)=>{if(step>=targets.Length*2){timer.Stop();timer.Dispose();Close();return;}if(step%2==0){ShowPage(targets[step/2]);Invalidate(true);}else{using(var bitmap=new Bitmap(ClientSize.Width,ClientSize.Height)){using(var g=Graphics.FromImage(bitmap))g.CopyFromScreen(PointToScreen(Point.Empty),Point.Empty,ClientSize);Directory.CreateDirectory(App.PreviewOutput);bitmap.Save(Path.Combine(App.PreviewOutput,"tela-"+(step/2)+".png"));}}step++;};timer.Start();}
 [System.Runtime.InteropServices.DllImport("user32.dll",CharSet=System.Runtime.InteropServices.CharSet.Unicode)] static extern IntPtr SendMessage(IntPtr hwnd,int msg,IntPtr wparam,string lparam);
 protected override void Dispose(bool disposing){if(disposing){if(workerTimer!=null)workerTimer.Dispose();DisposeProduct();}base.Dispose(disposing);}
}

using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Management;
using System.Collections.Generic;
using System.Runtime.InteropServices;

// PERFIL DA MÁQUINA — fatos, não suposições.
//
// Machine (Profile.cs) continua existindo e não muda: ele guarda strings prontas para a
// tela. MachineProfile é a leitura ESTRUTURADA que o motor de compatibilidade precisa —
// fabricante da CPU, núcleos, SMT, fabricante da GPU, bytes de RAM, tipo de mídia do
// disco, chassi, energia, Secure Boot, TPM, tipo de link de rede.
//
// Regra única e inegociável: o que não for lido do sistema fica VAZIO e o par *Known
// fica false. Nunca há valor inventado, nem "provavelmente", nem padrão otimista. Toda
// leitura que falhou entra em Notes com o motivo, e é isso que a interface mostra como
// "Não detectado" — que é diferente de "não compatível".
public class MachineProfile {
 public string CpuName="",CpuVendor="",GpuName="",GpuVendor="",Chassis="",SystemDriveMedia="",
               NetworkLink="",Manufacturer="",Model="",BiosVersion="",RamTier="",Edition="";
 public int PhysicalCores,LogicalCores,Build;
 public long RamBytes,SystemDriveFreeBytes,SystemDriveTotalBytes;
 public bool Windows,Is64;
 public bool Smt,SmtKnown;
 public bool Portable,PortableKnown;
 public bool OnAC,BatteryPresent,PowerKnown;
 public bool SecureBoot,SecureBootKnown;
 public bool Tpm,TpmKnown;
 public bool CoresKnown,RamKnown,StorageKnown,NetworkKnown;
 public List<string> Notes=new List<string>();

 internal bool CpuIsIntel(){return String.Equals(CpuVendor,"Intel",StringComparison.OrdinalIgnoreCase);}
 internal bool CpuIsAmd(){return String.Equals(CpuVendor,"AMD",StringComparison.OrdinalIgnoreCase);}
 internal bool GpuIsNvidia(){return String.Equals(GpuVendor,"NVIDIA",StringComparison.OrdinalIgnoreCase);}
 internal bool GpuIsAmd(){return String.Equals(GpuVendor,"AMD",StringComparison.OrdinalIgnoreCase);}
 internal bool GpuIsIntel(){return String.Equals(GpuVendor,"Intel",StringComparison.OrdinalIgnoreCase);}
 // "" quando o tipo de mídia não foi reconhecido — não assume SSD nem HDD.
 internal bool SolidState(){return SystemDriveMedia=="SSD"||SystemDriveMedia=="NVMe";}
}

static partial class App {
#if TESTS
 internal static MachineProfile TestProfile;
#endif
 // Fabricante a partir do nome do produto. As marcas são as que os próprios fabricantes
 // usam nas strings de Win32_Processor/Win32_VideoController; qualquer outra coisa fica
 // sem fabricante em vez de virar "outro" ou "desconhecido — trate como Intel".
 internal static string CpuVendorOf(string name){
  string n=(name??"").ToLowerInvariant();
  if(n.Contains("intel")||n.Contains("core(tm)")||n.Contains("xeon")||n.Contains("pentium")||n.Contains("celeron"))return "Intel";
  if(n.Contains("amd")||n.Contains("ryzen")||n.Contains("athlon")||n.Contains("epyc")||n.Contains("threadripper"))return "AMD";
  if(n.Contains("qualcomm")||n.Contains("snapdragon"))return "Qualcomm";
  return "";
 }
 internal static string GpuVendorOf(string name){
  string n=(name??"").ToLowerInvariant();
  if(n.Contains("nvidia")||n.Contains("geforce")||n.Contains("quadro")||n.Contains("rtx")||n.Contains("gtx"))return "NVIDIA";
  if(n.Contains("radeon")||n.Contains("amd ")||n.StartsWith("amd")||n.Contains("firepro"))return "AMD";
  if(n.Contains("intel")||n.Contains("uhd graphics")||n.Contains("iris")||n.Contains("arc "))return "Intel";
  return "";
 }
 // Faixas: abaixo de 8 GB muitos ajustes de inicialização e processos passam a valer a
 // pena; acima de 16 GB, liberar RAM deixa de ser assunto. Os cortes são explicados na
 // interface e não viram promessa de FPS.
 internal static string RamTierOf(long bytes){
  if(bytes<=0)return "";
  double gb=bytes/1073741824.0;
  return gb<8?"baixa":gb<=16?"média":"alta";
 }
 // Win32_SystemEnclosure.ChassisTypes: 8,9,10,11,12,14,18,21,30,31,32 são portáteis.
 // Tabela da especificação SMBIOS, citada na documentação da classe.
 static readonly int[] PortableChassis={8,9,10,11,12,14,18,21,30,31,32};
 internal static bool PortableChassisType(int code){return PortableChassis.Contains(code);}

 internal static MachineProfile ReadProfile(Machine basic){
#if TESTS
  if(TestProfile!=null)return TestProfile;
#endif
  var p=new MachineProfile();
  if(basic==null)basic=new Machine();
  p.Windows=basic.Windows;p.Build=basic.Build;p.Edition=basic.Edition??"";
  p.Is64=Environment.Is64BitOperatingSystem;
  p.OnAC=basic.OnAC;p.BatteryPresent=!basic.NoBattery;p.PowerKnown=basic.PowerKnown;
  if(!p.Windows){p.Notes.Add("Sem Windows neste ambiente: nenhuma leitura de hardware foi feita.");return p;}

  Read(p,"CPU",delegate{
   var rows=Query("SELECT Name,NumberOfCores,NumberOfLogicalProcessors FROM Win32_Processor");
   if(rows.Count==0)throw new Exception("Win32_Processor não retornou nenhum processador.");
   p.CpuName=String.Join(" / ",rows.Select(x=>Convert.ToString(x["Name"]).Trim()).ToArray());
   p.CpuVendor=CpuVendorOf(p.CpuName);
   foreach(var row in rows){
    p.PhysicalCores+=ToInt(row["NumberOfCores"]);
    p.LogicalCores+=ToInt(row["NumberOfLogicalProcessors"]);
   }
   p.CoresKnown=p.PhysicalCores>0&&p.LogicalCores>0;
   // SMT/Hyper-Threading é inferido de lógicos > físicos. Isso é aritmética sobre dois
   // números lidos do sistema, não chute: se um deles faltar, SmtKnown fica false.
   if(p.CoresKnown){p.Smt=p.LogicalCores>p.PhysicalCores;p.SmtKnown=true;}
  });

  Read(p,"GPU",delegate{
   var rows=Query("SELECT Name FROM Win32_VideoController");
   if(rows.Count==0)throw new Exception("Win32_VideoController não retornou nenhum adaptador.");
   p.GpuName=String.Join(" / ",rows.Select(x=>Convert.ToString(x["Name"]).Trim()).ToArray());
   // Com GPU integrada + dedicada, vale a dedicada para fins de compatibilidade.
   var vendors=rows.Select(x=>GpuVendorOf(Convert.ToString(x["Name"]))).Where(v=>v.Length>0).ToArray();
   p.GpuVendor=vendors.FirstOrDefault(v=>v!="Intel")??vendors.FirstOrDefault()??"";
  });

  Read(p,"Memória",delegate{
   var row=Query("SELECT TotalPhysicalMemory FROM Win32_ComputerSystem").FirstOrDefault();
   if(row==null)throw new Exception("Win32_ComputerSystem indisponível.");
   p.RamBytes=Convert.ToInt64(row["TotalPhysicalMemory"]);
   p.RamTier=RamTierOf(p.RamBytes);p.RamKnown=p.RamBytes>0;
  });

  Read(p,"Fabricante e modelo",delegate{
   var row=Query("SELECT Manufacturer,Model FROM Win32_ComputerSystem").FirstOrDefault();
   if(row==null)throw new Exception("Win32_ComputerSystem indisponível.");
   p.Manufacturer=Convert.ToString(row["Manufacturer"]).Trim();p.Model=Convert.ToString(row["Model"]).Trim();
  });

  Read(p,"BIOS/UEFI",delegate{
   var row=Query("SELECT SMBIOSBIOSVersion,ReleaseDate FROM Win32_BIOS").FirstOrDefault();
   if(row==null)throw new Exception("Win32_BIOS indisponível.");
   p.BiosVersion=Convert.ToString(row["SMBIOSBIOSVersion"]).Trim();
  });

  Read(p,"Chassi",delegate{
   var row=Query("SELECT ChassisTypes FROM Win32_SystemEnclosure").FirstOrDefault();
   if(row==null)throw new Exception("Win32_SystemEnclosure indisponível.");
   var codes=row["ChassisTypes"] as System.Collections.IEnumerable;
   if(codes==null)throw new Exception("ChassisTypes vazio.");
   foreach(object code in codes){
    int value=ToInt(code);if(value<=0)continue;
    p.Portable=PortableChassisType(value);p.PortableKnown=true;
    p.Chassis=p.Portable?"Notebook / portátil":"Desktop";
    break;
   }
   if(!p.PortableKnown)throw new Exception("Nenhum código de chassi reconhecido.");
  });
  // Bateria presente é um segundo indício, usado só quando o chassi não foi lido.
  if(!p.PortableKnown&&p.PowerKnown&&p.BatteryPresent){p.Portable=true;p.PortableKnown=true;p.Chassis="Portátil (deduzido da bateria; chassi não lido)";}

  Read(p,"Armazenamento do sistema",delegate{
   string root=Path.GetPathRoot(Environment.SystemDirectory);
   var drive=new DriveInfo(root);
   p.SystemDriveFreeBytes=drive.AvailableFreeSpace;p.SystemDriveTotalBytes=drive.TotalSize;
   p.SystemDriveMedia=SystemDriveMediaType(root);
   p.StorageKnown=p.SystemDriveTotalBytes>0;
   if(p.SystemDriveMedia.Length==0)p.Notes.Add("Tipo de mídia do disco do sistema não reconhecido: MSFT_PhysicalDisk indisponível ou sem MediaType. Ajustes que dependem de SSD ficam como Não detectado.");
  });

  Read(p,"Rede",delegate{
   var nics=System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces()
    .Where(n=>n.OperationalStatus==System.Net.NetworkInformation.OperationalStatus.Up
           && n.NetworkInterfaceType!=System.Net.NetworkInformation.NetworkInterfaceType.Loopback
           && n.NetworkInterfaceType!=System.Net.NetworkInformation.NetworkInterfaceType.Tunnel).ToArray();
   if(nics.Length==0)throw new Exception("Nenhum adaptador de rede ativo.");
   var wifi=nics.FirstOrDefault(n=>n.NetworkInterfaceType==System.Net.NetworkInformation.NetworkInterfaceType.Wireless80211);
   var chosen=wifi??nics[0];
   p.NetworkLink=(chosen.NetworkInterfaceType==System.Net.NetworkInformation.NetworkInterfaceType.Wireless80211?"Wi-Fi":"Ethernet")
    +(chosen.Speed>0?" · "+(chosen.Speed/1000000L)+" Mb/s":" · velocidade não informada");
   p.NetworkKnown=true;
  });

  Read(p,"Secure Boot",delegate{
   using(var h=Microsoft.Win32.RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine,Microsoft.Win32.RegistryView.Registry64))
   using(var k=h.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\SecureBoot\State")){
    if(k==null)throw new Exception("Chave SecureBoot\\State ausente: firmware legado (BIOS) ou valor não exposto.");
    object value=k.GetValue("UEFISecureBootEnabled");
    if(value==null)throw new Exception("UEFISecureBootEnabled ausente.");
    p.SecureBoot=ToInt(value)==1;p.SecureBootKnown=true;
   }
  });

  Read(p,"TPM",delegate{
   var rows=QueryIn(@"\\.\root\cimv2\Security\MicrosoftTpm","SELECT IsEnabled_InitialValue FROM Win32_Tpm");
   if(rows.Count==0){p.Tpm=false;p.TpmKnown=true;return;}
   p.Tpm=Convert.ToBoolean(rows[0]["IsEnabled_InitialValue"]);p.TpmKnown=true;
  });

  return p;
 }

 // Toda leitura passa por aqui: falha vira nota com motivo, nunca exceção que derruba a
 // análise e nunca valor plausível inventado no lugar.
 static void Read(MachineProfile p,string what,Action read){
  try{read();}catch(Exception e){p.Notes.Add(what+": não foi possível ler ("+e.Message.Trim()+").");}
 }
 static int ToInt(object value){try{return Convert.ToInt32(value);}catch{return 0;}}

 // MSFT_PhysicalDisk.MediaType: 3 = HDD, 4 = SSD, 5 = SCM; 0 e 1 significam
 // "não especificado"/"desconhecido" e NÃO viram SSD. BusType 17 = NVMe.
 internal static string MediaTypeName(int mediaType,int busType){
  if(busType==17)return "NVMe";
  if(mediaType==4)return "SSD";
  if(mediaType==3)return "HD";
  if(mediaType==5)return "Memória persistente";
  return "";
 }
 static string SystemDriveMediaType(string root){
  try{
   int number=-1;
   // Liga a letra da unidade ao disco físico por partição, em vez de supor "disco 0".
   foreach(var part in QueryIn(@"\\.\root\Microsoft\Windows\Storage","SELECT DiskNumber,DriveLetter FROM MSFT_Partition")){
    string letter=Convert.ToString(part["DriveLetter"]);
    if(letter.Length>0&&root.StartsWith(letter,StringComparison.OrdinalIgnoreCase)){number=ToInt(part["DiskNumber"]);break;}
   }
   foreach(var disk in QueryIn(@"\\.\root\Microsoft\Windows\Storage","SELECT DeviceId,MediaType,BusType FROM MSFT_PhysicalDisk")){
    if(number>=0&&ToInt(disk["DeviceId"])!=number)continue;
    return MediaTypeName(ToInt(disk["MediaType"]),ToInt(disk["BusType"]));
   }
  }catch{}
  return "";
 }
 static List<Dictionary<string,object>> QueryIn(string scope,string query){
  var result=new List<Dictionary<string,object>>();
  using(var search=new ManagementObjectSearcher(new ManagementScope(scope),new ObjectQuery(query),new System.Management.EnumerationOptions{Timeout=TimeSpan.FromSeconds(8),ReturnImmediately=true}))
  using(var found=search.Get())
   foreach(ManagementObject row in found){
    var map=new Dictionary<string,object>();
    foreach(PropertyData property in row.Properties)map[property.Name]=property.Value;
    result.Add(map);row.Dispose();
   }
  return result;
 }

 // Texto para a tela e para o relatório de suporte. Só afirma o que foi lido.
 internal static string ProfileReport(MachineProfile p){
  var b=new StringBuilder();
  b.AppendLine("Windows: "+(p.Windows?("build "+p.Build+(p.Edition.Length>0?" · "+p.Edition:"")+(p.Is64?" · 64 bits":" · 32 bits")):"não detectado"));
  b.AppendLine("CPU: "+Or(p.CpuName)+(p.CpuVendor.Length>0?" · fabricante "+p.CpuVendor:"")+(p.CoresKnown?" · "+p.PhysicalCores+" núcleos / "+p.LogicalCores+" threads":" · núcleos não detectados"));
  b.AppendLine("SMT/Hyper-Threading: "+(p.SmtKnown?(p.Smt?"ativo":"inativo"):"não detectado"));
  b.AppendLine("GPU: "+Or(p.GpuName)+(p.GpuVendor.Length>0?" · fabricante "+p.GpuVendor:""));
  b.AppendLine("RAM: "+(p.RamKnown?(p.RamBytes/1073741824.0).ToString("0.0")+" GB · faixa "+p.RamTier:"não detectada"));
  b.AppendLine("Disco do sistema: "+(p.StorageKnown?(p.SystemDriveFreeBytes/1073741824.0).ToString("0.0")+" GB livres de "+(p.SystemDriveTotalBytes/1073741824.0).ToString("0")+" GB":"não detectado")+" · mídia "+(p.SystemDriveMedia.Length>0?p.SystemDriveMedia:"não reconhecida"));
  b.AppendLine("Chassi: "+(p.PortableKnown?p.Chassis:"não detectado"));
  b.AppendLine("Energia: "+(p.PowerKnown?((p.OnAC?"na tomada":"na bateria")+(p.BatteryPresent?" · bateria presente":" · sem bateria")):"não detectada"));
  b.AppendLine("Rede: "+(p.NetworkKnown?p.NetworkLink:"não detectada"));
  b.AppendLine("Secure Boot: "+(p.SecureBootKnown?(p.SecureBoot?"ativo":"inativo"):"não detectado"));
  b.AppendLine("TPM: "+(p.TpmKnown?(p.Tpm?"presente e habilitado":"ausente ou desabilitado"):"não detectado"));
  b.AppendLine("Placa/modelo: "+Or(p.Manufacturer)+" "+Or(p.Model)+" · BIOS "+Or(p.BiosVersion));
  if(p.Notes.Count>0){
   b.AppendLine();b.AppendLine("Não foi possível ler (e por quê):");
   foreach(string note in p.Notes)b.AppendLine("· "+note);
  }
  return b.ToString();
 }
 static string Or(string value){return String.IsNullOrWhiteSpace(value)?"não detectado":value.Trim();}
}

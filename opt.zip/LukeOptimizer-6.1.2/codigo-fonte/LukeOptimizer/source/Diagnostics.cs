using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Management;
using System.Diagnostics;
using System.Runtime.InteropServices;

static partial class App {
 [StructLayout(LayoutKind.Sequential)] struct PowerStatus {public byte AC,Battery,Percent,Reserved;public int Lifetime,FullLifetime;}
 [DllImport("kernel32.dll")] static extern bool GetSystemPowerStatus(out PowerStatus state);
 static List<Dictionary<string,object>> Query(string query) {
  var rows=new List<Dictionary<string,object>>();
  using(var search=new ManagementObjectSearcher(new ManagementScope(@"\\.\root\cimv2"),new ObjectQuery(query),new System.Management.EnumerationOptions {Timeout=TimeSpan.FromSeconds(8),ReturnImmediately=true}))
  using(var result=search.Get())foreach(ManagementObject obj in result) {
   var row=new Dictionary<string,object>(StringComparer.OrdinalIgnoreCase);
   foreach(PropertyData prop in obj.Properties)row[prop.Name]=prop.Value;rows.Add(row);obj.Dispose();
  }
  return rows;
 }
 internal static Machine ScanHardware() {
#if TESTS
  if(TestMachine!=null)return TestMachine;
#endif
  var m=new Machine {Windows=IsWindows&&Environment.Is64BitOperatingSystem};
  if(!m.Windows){m.OS="Prévia de interface · sem acesso a um PC Windows";m.Error="Leitura do Windows indisponível neste ambiente.";return m;}
  try {
   using(var h=Microsoft.Win32.RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine,Microsoft.Win32.RegistryView.Registry64))
   using(var k=h.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion")) {
    Int32.TryParse(Convert.ToString(k.GetValue("CurrentBuildNumber")),out m.Build);
    m.Edition=Convert.ToString(k.GetValue("EditionID"));m.OS=(m.Build>=22000?"Windows 11":"Windows 10")+" · "+m.Edition+" · build "+m.Build;
   }
  }catch(Exception e){m.Error=e.Message;}
  try{m.Cpu=String.Join(" / ",Query("SELECT Name FROM Win32_Processor").Select(x=>Convert.ToString(x["Name"]).Trim()));}catch{m.Cpu="CPU não consultada";}
  try{m.Gpu=String.Join(" / ",Query("SELECT Name FROM Win32_VideoController").Select(x=>Convert.ToString(x["Name"])));}catch{m.Gpu="GPU não consultada";}
  try{var c=Query("SELECT TotalPhysicalMemory,AutomaticManagedPagefile FROM Win32_ComputerSystem").First();m.Ram=(Convert.ToDouble(c["TotalPhysicalMemory"])/1073741824.0).ToString("0.0")+" GB";m.Pagefile=Convert.ToBoolean(c["AutomaticManagedPagefile"])?"Gerenciado automaticamente":"Gerenciamento manual — revisar se houver falhas por memória";}catch{}
  try{var d=new DriveInfo(Path.GetPathRoot(Environment.SystemDirectory));m.Disk=(d.AvailableFreeSpace/1073741824.0).ToString("0.0")+" GB livres de "+(d.TotalSize/1073741824.0).ToString("0")+" GB";}catch{}
  try {PowerStatus p;m.PowerKnown=GetSystemPowerStatus(out p);m.OnAC=p.AC==1;m.NoBattery=p.Battery==128;}catch{}
  try{m.ActiveGuid=ActivePlan();m.Plans=RunCapture(SystemExe("powercfg.exe"),"/list",true);m.Power=m.Plans.Split(new[]{'\n'}).FirstOrDefault(x=>x.IndexOf(m.ActiveGuid,StringComparison.OrdinalIgnoreCase)>=0)??m.ActiveGuid;m.Power=m.Power.Trim();}catch(Exception e){m.Power=e.Message;}
  return m;
 }
 internal static Dictionary<string,Observed> ScanAll(Machine machine,Action<int> progress) {
  var result=new Dictionary<string,Observed>();int n=0;
  foreach(var i in Items){result[i.Id]=Observe(i,machine);if(++n%10==0)progress(n*100/Items.Count);}progress(100);return result;
 }
 internal static Observed Observe(Item item,Machine machine) {
  var o=new Observed {State="Não verificado",Detail="Este item não possui verificação automática de funcionamento."};
  if(!item.Available){o.State="Indisponível";o.Detail=item.Blocked;return o;}
  if(!AssetIsPresent(item)){o.State="Arquivo externo ausente";o.Detail="O arquivo original não foi fornecido neste pacote. O texto e a revisão disponíveis permanecem no catálogo; a execução exige o arquivo original validado.";return o;}
  if(!machine.Windows){o.Detail="Abra no Windows para consultar o estado real. Nenhum resultado foi simulado.";return o;}
  try {
   string incompatible=Compatibility(item,machine);if(incompatible!=null){o.State="Não compatível";o.Detail=incompatible;return o;}
   if(item.Native&&item.ActionCode=="power") {o.Verified=EqualGuid(machine.ActiveGuid,HighPlan);o.State=o.Verified?"Conferido":"Não configurado";o.Detail="Plano ativo: "+machine.ActiveGuid;o.Match=o.Verified?1:0;o.Total=1;return o;}
   if((item.Operations??new RegOp[0]).Length>0) {
    var lines=new List<string>();int absent=0;
    foreach(var op in item.Operations) {
     var now=Capture(op).Before;bool same=Same(now,op);o.Total++;if(same)o.Match++;if(now.Delete)absent++;
     lines.Add((same?"OK":"DIFERENTE")+" | "+op.Hive+"\\"+op.Key+" | "+op.Name+"\r\n  Atual: "+ValueText(now)+"\r\n  Proposto: "+ValueText(op));
    }
    o.Verified=o.Match==o.Total;o.State=o.Verified?"Valores conferidos":o.Match>0?"Parcial":"Não configurado";
    o.Detail=o.Match+" de "+o.Total+" valores correspondem ao ajuste. "+absent+" ausente(s). Ausência pode significar padrão do Windows.\r\nA leitura comprova a configuração gravada, não o ganho de desempenho ou a validade de uma chave legada.\r\n\r\n"+String.Join("\r\n\r\n",lines);return o;
   }
   if(item.Native) {
    var lines=new List<string>();
    foreach(string code in NativeSettings.Codes(item.ActionCode)) {string now=NativeSettings.Read(code);bool same=now==NativeSettings.Desired(code,now);o.Total++;if(same)o.Match++;lines.Add(code+": "+now+(same?" · confere":" · pode ajustar"));}
    o.Verified=o.Total>0&&o.Match==o.Total;o.State=o.Verified?"Conferido":o.Match>0?"Parcial":"Não configurado";o.Detail="Consulta direta à API do Windows.\r\n"+String.Join("\r\n",lines);return o;
   }
   if(item.Mode=="Energia") {
    var record=History().FirstOrDefault(r=>r.ItemId==item.Id&&r.Kind=="Energia"&&r.Status=="aplicado");
    o.Verified=record!=null&&EqualGuid(record.NewPlan,machine.ActiveGuid);o.State=o.Verified?"Plano ativo":"Não verificado";o.Detail=o.Verified?"O GUID importado por este item é o plano ativo. Ganho de desempenho não medido.":"Nenhum plano ativo foi associado a este arquivo pelo histórico do app. O nome do plano não comprova identidade.";return o;
   }
   if(item.Mode=="Suporte"||item.Mode=="Texto"||item.Mode=="Guia"||item.Mode=="Link"||item.Mode=="Atalho"){o.State="Referência";o.Detail="Arquivo de apoio ou consulta.";}
   else if(!item.ManualAllowed){o.State="Execução bloqueada";o.Detail=String.Join("\r\n",item.Review??new string[0]);}
   return o;
  }catch(Exception e){o.State="Falha na leitura";o.Detail=e.Message;return o;}
 }
 internal static string ValueText(RegOp value){return value.Delete?"ausente":value.Kind+" = "+(value.Data.Length>400?value.Data.Substring(0,400)+"…":value.Data);}
 internal static string ServiceReport() {
  if(!IsWindows)return "Serviços serão consultados no PC Windows.";
  try {
   string[] names={"Audiosrv","AudioEndpointBuilder","WlanSvc","Dhcp","bthserv","Spooler","wuauserv","BITS","WinDefend","SysMain","WSearch"};
   var rows=Query("SELECT Name,State,StartMode FROM Win32_Service WHERE "+String.Join(" OR ",names.Select(n=>"Name='"+n+"'")));
   return "Serviço — estado atual — inicialização\r\n\r\n"+String.Join("\r\n",names.Select(n=>{var r=rows.FirstOrDefault(x=>Convert.ToString(x["Name"])==n);return n+" — "+(r==null?"não encontrado":Convert.ToString(r["State"])+" — "+r["StartMode"]);}))+
    "\r\n\r\nUm serviço parado pode ser normal (início sob demanda). Serviço em execução não comprova que toda a função, rede ou proteção esteja operando corretamente.";
  }catch(Exception e){return "Não foi possível consultar os serviços: "+e.Message;}
 }
 internal static bool AssetIsPresent(Item item){
  if(item.Native||item.Mode=="Integrado"||!String.IsNullOrEmpty(item.ReplacementId))return true;
  if(String.IsNullOrEmpty(item.Asset))return false;
  if(File.Exists(LocalAsset(item.Asset)))return true;
  if(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceNames().Contains("payload.zip"))return true;
  var folder=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"source");
  return File.Exists(Path.Combine(folder,"payload.zip"))||(File.Exists(Path.Combine(folder,"payload.001"))&&File.Exists(Path.Combine(folder,"payload.002")));
 }
 static Stream Payload(Action<int> progress) {
  var embedded=System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("payload.zip");if(embedded!=null)return embedded;
  string folder=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"source"),zip=Path.Combine(folder,"payload.zip");
  if(!File.Exists(zip)) {
   string a=Path.Combine(folder,"payload.001"),b=Path.Combine(folder,"payload.002");
   if(!File.Exists(a)||!File.Exists(b))throw new Exception("O arquivo original ainda não foi extraído. Coloque esta atualização na mesma pasta do pacote anterior, com source/payload.001 e payload.002. Os ajustes nativos funcionam sem o pacote.");
   string temp=zip+".assembling";long total=new FileInfo(a).Length+new FileInfo(b).Length,done=0;
   try {
    using(var output=File.Create(temp))foreach(string part in new[]{a,b})using(var input=File.OpenRead(part)){var buffer=new byte[1024*1024];int count;while((count=input.Read(buffer,0,buffer.Length))>0){output.Write(buffer,0,count);done+=count;progress((int)(done*60/total));}}
    if(Digest(temp)!="9944bdbb24aa0ae77b5ae47625a28e894f16b5941da9bac811c26dab59f9e1f3")throw new Exception("As partes do pacote não correspondem ao conteúdo esperado. Baixe novamente as partes originais.");
    File.Move(temp,zip);
   }catch{if(File.Exists(temp))File.Delete(temp);throw;}
  }
  return File.OpenRead(zip);
 }
 internal static void EnsureGroup(Item item,Action<int> progress) {
  if(String.IsNullOrEmpty(item.Asset))throw new Exception("Este item não possui arquivo no pacote.");
  string prefix=item.Asset.Split(new[]{'/'})[0]+"/";
  var group=Items.Where(x=>!x.Native&&x.Available&&!String.IsNullOrEmpty(x.Hash)&&x.Asset.StartsWith(prefix)&&!x.Category.StartsWith("0 - ")&&!x.Blocked.StartsWith("Ativação")).ToList();
  if(group.All(x=>File.Exists(LocalAsset(x.Asset)))){VerifyGroup(item);return;}
  using(var input=Payload(progress))using(var zip=new ZipArchive(input,ZipArchiveMode.Read)) {
   var entries=zip.Entries.Where(e=>group.Any(i=>i.Asset==e.FullName)).ToList();int n=0;
   foreach(var entry in entries) {
    string target=LocalAsset(entry.FullName);Directory.CreateDirectory(Path.GetDirectoryName(target));string temp=target+".preparing";
    using(var source=entry.Open())using(var output=File.Create(temp))source.CopyTo(output);
    var expected=group.Single(i=>i.Asset==entry.FullName);if(Digest(temp)!=expected.Hash){File.Delete(temp);throw new Exception("Arquivo do pacote não confere: "+expected.Name);}
    if(File.Exists(target))File.Delete(target);File.Move(temp,target);progress(60+(++n)*40/Math.Max(1,entries.Count));
   }
  }
  VerifyGroup(item);
 }
}

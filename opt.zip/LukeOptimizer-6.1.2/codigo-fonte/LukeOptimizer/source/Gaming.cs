using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.InteropServices;
using System.ComponentModel;

public class PowerOption {
 public string Id,Name,Subgroup,Setting,Description; public uint Target;
}
static class PowerTuning {
 internal const string Cpu="54533251-82be-4824-96c1-47b60b740d00";
 internal static readonly PowerOption[] Options={
  new PowerOption{Id="epp",Name="CPU: preferir desempenho (EPP 25%)",Subgroup=Cpu,Setting="36687f9e-e3a5-4dbf-b1dc-15eb381c6863",Target=25,Description="Favorece desempenho em CPUs com controle autônomo compatível. Pode aumentar calor e consumo; o firmware pode ignorar o pedido."},
  new PowerOption{Id="max",Name="CPU: permitir estado máximo de 100%",Subgroup=Cpu,Setting="bc5038f7-23e0-4960-96da-33abaf5935ec",Target=100,Description="Remove um limite de estado máximo imposto pelo plano. Não é overclock nem garante frequência turbo."},
  new PowerOption{Id="min",Name="CPU: permitir repouso (mínimo de 5%)",Subgroup=Cpu,Setting="893dee8e-2bef-41e0-89c6-b55d0929964c",Target=5,Description="Permite economizar energia quando ocioso e deixa margem térmica para carga. Não limita o máximo durante o jogo."},
  new PowerOption{Id="boost",Name="CPU: permitir boost",Subgroup=Cpu,Setting="be337238-0d82-4146-a960-4f3749d470c7",Target=1,Description="Modo Enabled. O efeito depende do processador e firmware; compare com o valor original. Turbo pode aumentar consumo e temperatura."},
  new PowerOption{Id="pcie",Name="PCIe: testar sem economia do link",Subgroup="501a4d13-42af-4429-9fd1-a8218c268e20",Setting="ee12f906-d277-404b-b6da-e5fa1a576df5",Target=0,Description="Teste A/B para problemas de transição do link. Pode aumentar consumo; não é correção universal de stutter."},
  new PowerOption{Id="disk",Name="Disco: evitar desligamento por inatividade",Subgroup="0012ee47-9041-4b5d-9b77-535fba8b1442",Setting="6738e2c4-e8a5-4a42-b16a-e040e769756e",Target=0,Description="Pode evitar espera ao reativar HDDs secundários. Não acelera SSDs/NVMe; aumenta consumo e tempo de funcionamento de HDDs."}
 };
 [DllImport("powrprof.dll")] static extern uint PowerReadACValueIndex(IntPtr root,ref Guid scheme,ref Guid subgroup,ref Guid setting,out uint value);
 [DllImport("powrprof.dll")] static extern uint PowerWriteACValueIndex(IntPtr root,ref Guid scheme,ref Guid subgroup,ref Guid setting,uint value);
 [DllImport("powrprof.dll")] static extern uint PowerSetActiveScheme(IntPtr root,ref Guid scheme);
#if TESTS
 internal static Func<string,string> TestRead;
 internal static Action<string,string> TestWrite;
#endif
 internal static bool IsCode(string code){return code!=null&&code.StartsWith("powerac|",StringComparison.Ordinal);}
 internal static PowerOption Decode(string code,out Guid scheme){
  string[] parts=(code??"").Split(new[]{'|'});scheme=Guid.Empty;
  if(parts.Length!=3||parts[0]!="powerac"||!Guid.TryParseExact(parts[1],"D",out scheme))throw new Exception("Configuração de energia inválida.");
  var option=Options.SingleOrDefault(x=>x.Id==parts[2]);if(option==null)throw new Exception("Opção de energia fora da lista revisada.");return option;
 }
 internal static string Code(string scheme,string id){string c="powerac|"+scheme+"|"+id;Guid parsed;Decode(c,out parsed);return c;}
 internal static string Desired(string code){Guid plan;return Decode(code,out plan).Target.ToString(CultureInfo.InvariantCulture);}
 internal static string Read(string code){
  Guid scheme;var option=Decode(code,out scheme);
#if TESTS
  if(TestRead!=null)return TestRead(code);
#endif
  var subgroup=new Guid(option.Subgroup);var setting=new Guid(option.Setting);uint value;
  uint error=PowerReadACValueIndex(IntPtr.Zero,ref scheme,ref subgroup,ref setting,out value);
  if(error!=0)throw new Win32Exception((int)error,"Opção não disponível no plano: "+option.Name);
  return value.ToString(CultureInfo.InvariantCulture);
 }
 internal static void Write(string code,string value){
  Guid scheme;var option=Decode(code,out scheme);uint number;
  if(!UInt32.TryParse(value,NumberStyles.None,CultureInfo.InvariantCulture,out number))throw new Exception("Backup de energia inválido.");
#if TESTS
  if(TestWrite!=null){TestWrite(code,value);return;}
#endif
  var subgroup=new Guid(option.Subgroup);var setting=new Guid(option.Setting);
  uint error=PowerWriteACValueIndex(IntPtr.Zero,ref scheme,ref subgroup,ref setting,number);
  if(error!=0)throw new Win32Exception((int)error,"O Windows recusou o ajuste de energia.");
  // Refresh only if this is still active. Never switch a plan changed by the user.
  if(App.EqualGuid(App.ActivePlan(),scheme.ToString())){error=PowerSetActiveScheme(IntPtr.Zero,ref scheme);if(error!=0)throw new Win32Exception((int)error);}
 }
 internal static Item Build(string scheme,string id){var option=Options.Single(x=>x.Id==id);return new Item{Id="power-v4-"+id,Name=option.Name,ReviewTitle=option.Name,Native=true,ActionCode=Code(scheme,id),Operations=new RegOp[0]};}
}

public class GameProfile {
 public string Id {get;set;} public string Name {get;set;} public string Executable {get;set;}
 public bool HighGpu {get;set;} public bool DisableFullscreen {get;set;}
 public int TargetFps {get;set;} public string Notes {get;set;}
 public string[] CloseApps {get;set;}
 public override string ToString(){return Name;}
}
static class GameProfiles {
 internal static string Root {get{return Path.Combine(App.DataRoot,"jogos-v4");}}
 internal static string FileFor(string id){Guid parsed;if(!Guid.TryParseExact(id,"N",out parsed))throw new Exception("Perfil inválido.");return Path.Combine(Root,id+".json");}
 internal static string ValidateExecutable(string path,bool mustExist){
  if(String.IsNullOrWhiteSpace(path)||path.IndexOfAny(new[]{'"','\r','\n','|','\0'})>=0||!Path.IsPathRooted(path)||path.StartsWith(@"\\"))throw new Exception("Escolha um executável local do jogo.");
  string full=Path.GetFullPath(path);
  if(full.Length<4||full[1]!=':'||!full.EndsWith(".exe",StringComparison.OrdinalIgnoreCase)||ResourceMonitor.Within(full,Environment.GetFolderPath(Environment.SpecialFolder.Windows)))throw new Exception("O caminho deve apontar para um jogo .exe fora da pasta Windows.");
  if(mustExist&&!File.Exists(full))throw new Exception("Executável não encontrado. Atualize o caminho do perfil.");return full;
 }
 internal static void Validate(GameProfile p,bool exists){
  if(p==null||String.IsNullOrWhiteSpace(p.Name)||p.Name.Length>100||p.TargetFps<0||p.TargetFps>1000||(p.Notes??"").Length>6000)throw new Exception("Perfil inválido: confira nome, FPS alvo (0–1000) e notas.");
  FileFor(p.Id);p.Executable=ValidateExecutable(p.Executable,exists);
  if(p.CloseApps!=null&&(p.CloseApps.Length>100||p.CloseApps.Any(x=>!ResourceMonitor.Closable.Contains(x))))throw new Exception("Lista de fechamento contém um app não autorizado.");
 }
 internal static List<GameProfile> Load(){
  var list=new List<GameProfile>();if(!Directory.Exists(Root))return list;
  foreach(string file in Directory.GetFiles(Root,"*.json"))try{if(new FileInfo(file).Length>64000)continue;var p=App.Json.Deserialize<GameProfile>(AtomicStore.Read(file));Validate(p,false);list.Add(p);}catch{}
  return list.OrderBy(x=>x.Name).ToList();
 }
 internal static void Save(GameProfile p){Validate(p,true);Directory.CreateDirectory(Root);AtomicStore.Write(FileFor(p.Id),App.Json.Serialize(p));}
 internal static string SetGpuToken(string before){
  var tokens=(before??"").Split(new[]{';'}).Select(t=>t.Trim()).Where(t=>t.Length>0&&!t.StartsWith("GpuPreference=",StringComparison.OrdinalIgnoreCase)).ToList();
  tokens.Add("GpuPreference=2");return String.Join(";",tokens)+";";
 }
 internal static string AddFullscreenToken(string before){
  string value=(before??"").Trim();if(value.Split(new[]{' '}).Where(t=>t.Length>0).Contains("DISABLEDXMAXIMIZEDWINDOWEDMODE",StringComparer.OrdinalIgnoreCase))return value;
  return value.Length==0?"~ DISABLEDXMAXIMIZEDWINDOWEDMODE":value+" DISABLEDXMAXIMIZEDWINDOWEDMODE";
 }
 internal static RegOp StringOp(string key,string exe,string data){return new RegOp{Hive="HKEY_CURRENT_USER",Key=key,Name=exe,Kind="String",Data=data};}
 internal static List<RegOp> Operations(GameProfile p){return Operations(p,new List<RegOp>());}
 internal static List<RegOp> Operations(GameProfile p,List<RegOp> expected){
  var ops=new List<RegOp>();
  if(p.HighGpu){var op=StringOp(@"Software\Microsoft\DirectX\UserGpuPreferences",p.Executable,"");var previous=App.Capture(op).Before;if(!previous.Delete&&previous.Kind!="String")throw new Exception("Preferência de GPU tem tipo inesperado.");expected.Add(previous);op.Data=SetGpuToken(previous.Delete?"":previous.Data);ops.Add(op);}
  if(p.DisableFullscreen){var op=StringOp(@"Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers",p.Executable,"");var previous=App.Capture(op).Before;if(!previous.Delete&&previous.Kind!="String")throw new Exception("Compatibilidade tem tipo inesperado.");expected.Add(previous);op.Data=AddFullscreenToken(previous.Delete?"":previous.Data);ops.Add(op);}
  return ops;
 }
}
static partial class App {
 internal static string PowerTargetIssue(string code){
  Guid scheme;PowerTuning.Decode(code,out scheme);bool onAC;
#if TESTS
  if(TestMachine!=null)onAC=TestMachine.PowerKnown&&TestMachine.OnAC;else
#endif
  {PowerStatus status;onAC=GetSystemPowerStatus(out status)&&status.AC==1;}
  if(!onAC)return "Ajustes AC exigem conexão à tomada.";
  if(!EqualGuid(ActivePlan(),scheme.ToString()))return "O plano de energia mudou. Analise novamente.";return null;
 }
 internal static void ApplyPowerOptions(string requestId){
  var req=ReadRequest(requestId);var ids=req.PowerOptions;
  if(ids==null||ids.Length==0||ids.Length>PowerTuning.Options.Length||ids.Distinct().Count()!=ids.Length||ids.Any(id=>!PowerTuning.Options.Any(o=>o.Id==id)))throw new Exception("Seleção de energia inválida.");
  var machine=ScanHardware();if(!machine.PowerKnown||!machine.OnAC)throw new Exception("Conecte o PC à tomada e analise novamente.");
  string scheme=ActivePlan();if(!EqualGuid(scheme,req.PowerScheme))throw new Exception("O plano mudou desde a seleção. Analise novamente.");
  ApplyTransaction(ids.Select(id=>PowerTuning.Build(scheme,id)),"Nativo","Energia avançada · somente na tomada");
 }
 internal static void ApplyGameProfile(string requestId){
  var p=ReadRequest(requestId).Game;GameProfiles.Validate(p,true);var expected=new List<RegOp>();var ops=GameProfiles.Operations(p,expected);
  if(ops.Count==0)throw new Exception("Marque GPU de alto desempenho ou o teste de tela cheia. FPS alvo e notas são orientações, não limitadores.");
  ApplyTransaction(new[]{new Item{Id="game-v4-"+p.Id,Name="Perfil: "+p.Name,ReviewTitle="GPU / compatibilidade por jogo",Native=false,Operations=ops.ToArray(),Expected=expected.ToArray(),Path=p.Executable,Text="",ActionCode="gameprofile"}},"Integrado","Perfil de jogo: "+p.Name);
 }
}

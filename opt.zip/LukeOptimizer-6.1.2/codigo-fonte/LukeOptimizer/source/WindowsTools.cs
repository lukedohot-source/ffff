using System;
using System.Collections.Generic;
using System.Linq;

// FERRAMENTAS DO WINDOWS — atalhos para o que já existe no sistema.
//
// Esta tela costumava listar um botão por arquivo .bat recebido, rotulado com o nome do
// arquivo, e o clique só mostrava o parecer da revisão. Material de desenvolvimento
// apresentado como recurso do produto. Agora ela abre ferramentas REAIS.
//
// Regra desta lista: nada aqui altera configuração. São atalhos. O LukeOptimizer abre o
// console nativo e sai do caminho — quem muda alguma coisa é a ferramenta do Windows,
// com a própria confirmação e o próprio desfazer.
//
// Por que não é "botão vazio": cada entrada aponta para um executável, console MMC ou
// página de Configurações que existe no Windows 10/11. Se um deles não existir na edição
// instalada, o erro aparece com mensagem legível em vez de falhar em silêncio.
public class WindowsTool {
 public string Id="",Name="",Description="",Target="",Arguments="",Kind="exe";
}

static class WindowsTools {
 // "exe" roda por App.SystemExe (resolvido em System32, nunca por PATH).
 // "settings" e "url" abrem por shell. "folder" abre uma pasta.
 internal static List<WindowsTool> All(){
  return new List<WindowsTool>{
   // O "God Mode" clássico é uma pasta com CLSID. Em vez de criar pasta no disco da
   // pessoa, abrimos o mesmo destino pelo shell — mesmo resultado, sem deixar lixo.
   new WindowsTool{Id="godmode",Name="Painel avançado do Windows",Kind="url",
    Target="shell:::{ED7BA470-8E54-465E-825C-99712043E01C}",
    Description="Acesso centralizado a todas as tarefas administrativas do Painel de Controle, numa lista só."},

   new WindowsTool{Id="devmgmt",Name="Gerenciador de dispositivos",Kind="exe",Target="mmc.exe",Arguments="devmgmt.msc",
    Description="Lista o hardware instalado e os drivers de cada dispositivo. É onde se atualiza ou reverte um driver."},

   new WindowsTool{Id="diskmgmt",Name="Gerenciamento de disco",Kind="exe",Target="mmc.exe",Arguments="diskmgmt.msc",
    Description="Mostra as unidades e partições, com espaço, sistema de arquivos e letra atribuída."},

   new WindowsTool{Id="services",Name="Serviços do Windows",Kind="exe",Target="mmc.exe",Arguments="services.msc",
    Description="Console oficial de serviços, com descrição e dependências de cada um."},

   new WindowsTool{Id="taskschd",Name="Agendador de tarefas",Kind="exe",Target="mmc.exe",Arguments="taskschd.msc",
    Description="Tarefas que o Windows e os programas instalados executam em horários ou eventos."},

   new WindowsTool{Id="eventvwr",Name="Visualizador de eventos",Kind="exe",Target="mmc.exe",Arguments="eventvwr.msc",
    Description="Registro de erros, avisos e travamentos do Windows. É o primeiro lugar a olhar quando algo falha sem explicação."},

   new WindowsTool{Id="taskmgr",Name="Gerenciador de tarefas",Kind="exe",Target="taskmgr.exe",
    Description="Processos, desempenho, inicialização e serviços em tempo real."},

   new WindowsTool{Id="control",Name="Painel de controle",Kind="exe",Target="control.exe",
    Description="Painel de Controle clássico, com as páginas que ainda não migraram para Configurações."},

   new WindowsTool{Id="features",Name="Recursos do Windows",Kind="exe",Target="OptionalFeatures.exe",
    Description="Ativa ou desativa recursos opcionais como Hyper-V, WSL, Sandbox e .NET."},

   new WindowsTool{Id="ncpa",Name="Conexões de rede",Kind="exe",Target="control.exe",Arguments="ncpa.cpl",
    Description="Adaptadores de rede instalados, com propriedades de IP, DNS e status de cada um."},

   new WindowsTool{Id="firewall",Name="Firewall avançado",Kind="exe",Target="mmc.exe",Arguments="WF.msc",
    Description="Regras de entrada e saída do Firewall do Windows, por programa e por porta."},

   new WindowsTool{Id="sysdm",Name="Propriedades do sistema",Kind="exe",Target="SystemPropertiesAdvanced.exe",
    Description="Desempenho, perfis de usuário, variáveis de ambiente, memória virtual e proteção do sistema."},

   new WindowsTool{Id="perfmon",Name="Monitor de recursos",Kind="exe",Target="resmon.exe",
    Description="CPU, memória, disco e rede detalhados por processo, com mais profundidade que o Gerenciador de Tarefas."},

   new WindowsTool{Id="msinfo",Name="Informações do sistema",Kind="exe",Target="msinfo32.exe",
    Description="Inventário completo de hardware, componentes e ambiente de software."},

   new WindowsTool{Id="cleanmgr",Name="Limpeza de disco do Windows",Kind="exe",Target="cleanmgr.exe",
    Description="Ferramenta oficial de limpeza da Microsoft. Complementa a limpeza do LukeOptimizer; não substitui."},

   new WindowsTool{Id="dfrgui",Name="Otimizar unidades",Kind="exe",Target="dfrgui.exe",
    Description="Desfragmentação em disco mecânico e TRIM em SSD, pela ferramenta do próprio Windows."},

   new WindowsTool{Id="mdsched",Name="Diagnóstico de memória",Kind="exe",Target="mdsched.exe",
    Description="Teste de RAM da Microsoft. Agenda a verificação para a próxima inicialização."},

   new WindowsTool{Id="secure",Name="Segurança do Windows",Kind="settings",Target="windowsdefender:",
    Description="Estado do antivírus, firewall, proteção de conta e inicialização segura."},

   new WindowsTool{Id="update",Name="Windows Update",Kind="settings",Target="ms-settings:windowsupdate",
    Description="Atualizações pendentes, histórico e opções de reinício."},

   new WindowsTool{Id="startupapps",Name="Aplicativos de inicialização",Kind="settings",Target="ms-settings:startupapps",
    Description="Página do Windows que lista o que abre junto com o sistema."}
  };
 }

 internal static WindowsTool Resolve(string id){
  var found=All().SingleOrDefault(t=>t.Id==id);
  if(found==null)throw new ArgumentException("Ferramenta do Windows desconhecida: "+id);
  return found;
 }
}

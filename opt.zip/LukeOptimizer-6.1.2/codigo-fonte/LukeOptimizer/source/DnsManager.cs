using System;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.NetworkInformation;
using System.Globalization;
using System.Threading;
using System.Collections.Generic;

// GERENCIADOR DE DNS
//
// Trocar DNS muda QUEM resolve os nomes que este PC acessa e para onde vão essas
// consultas. É escolha de privacidade e de confiança, não de velocidade — e é por isso
// que esta função nunca entra em perfil automático nem em "otimização recomendada".
//
// A lista de provedores foi conferida contra config/dns.json do projeto WinUtil
// (ChrisTitusTech/winutil, licença MIT) na versão atual do repositório. Os endereços são
// públicos e documentados pelos próprios provedores; nenhum código foi copiado.
// Ver licenses/winutil-MIT.txt e docs WINUTIL_PARITY_REPORT.md.
//
// ---------------------------------------------------------------------------------
// SEGURANÇA — por que o adaptador é identificado por ÍNDICE e não por nome
//
// netsh aceita tanto `name="Ethernet"` quanto o índice numérico da interface. Nome de
// adaptador é texto livre: a pessoa pode renomear para qualquer coisa, inclusive com
// aspas e caracteres que o interpretador de linha de comando trata de forma especial.
// Montar um comando com esse texto seria criar superfície de injeção no único lugar do
// programa que precisa de administrador para mexer em rede.
//
// O índice é sempre um número inteiro atribuído pelo Windows. Validado como dígitos, ele
// não tem como virar outra coisa. Todo endereço também é validado por IPAddress.TryParse
// e conferido contra a família esperada antes de entrar na linha de comando.
// ---------------------------------------------------------------------------------
public class DnsProvider {
 public string Id="",Name="",Description="";
 public string V4Primary="",V4Secondary="",V6Primary="",V6Secondary="",Doh="";
 public bool Automatic;   // devolve o adaptador ao DNS entregue pelo roteador (DHCP)
}

// Estado de um adaptador, como lido agora. Somente leitura, sem elevação.
public class DnsAdapter {
 public int IndexV4,IndexV6;
 public string Name="",Description="",Kind="";
 public bool Up,V4Known,V6Known;
 public List<string> V4Servers=new List<string>();
 public List<string> V6Servers=new List<string>();
 public bool Dhcp;
}

// O que foi gravado antes de mudar, para poder voltar exatamente ao que era.
// Propriedades, não campos: este objeto atravessa o JSON do Histórico — é gravado pelo
// processo elevado que aplica e lido por OUTRO processo elevado, o que desfaz.
public class DnsBackup {
 public int IndexV4 {get;set;} public int IndexV6 {get;set;}
 public string AdapterName {get;set;}
 public bool WasDhcp {get;set;}
 public List<string> V4Servers {get;set;}
 public List<string> V6Servers {get;set;}
 public DnsBackup(){AdapterName="";V4Servers=new List<string>();V6Servers=new List<string>();}
}

// O que o Histórico guarda de uma troca de DNS: o estado anterior (para voltar) e o que
// foi efetivamente gravado (para conferir depois e para recusar sobrescrever mudança
// posterior feita fora do aplicativo).
public class DnsSaved {
 public DnsBackup Before {get;set;}
 public string[] Applied {get;set;}      // endereços gravados, na ordem; vazio em "automático"
 public string ProviderId {get;set;}
 public string AdapterName {get;set;}
 public bool ToAutomatic {get;set;}
 public DnsSaved(){Applied=new string[0];ProviderId="";AdapterName="";}
}

// Pedido já validado. Nada aqui é texto livre: provedor vem do catálogo fechado, índices
// são números e endereços passaram por ValidAddress.
public class DnsRequest {
 public DnsProvider Provider;
 public int IndexV4,IndexV6;
 public string CustomV4="",CustomV6="";
}

static class DnsManager {
 internal const string Automatic="dns-auto",Custom="dns-custom";

 internal static List<DnsProvider> Providers(){
  return new List<DnsProvider>{
   new DnsProvider{Id=Automatic,Name="Automático (do roteador)",Automatic=true,
    Description="Devolve o adaptador ao DNS que o seu roteador ou provedor entrega. É o padrão do Windows e o estado para onde 'Restaurar' volta."},

   new DnsProvider{Id="dns-cloudflare",Name="Cloudflare",
    V4Primary="1.1.1.1",V4Secondary="1.0.0.1",V6Primary="2606:4700:4700::1111",V6Secondary="2606:4700:4700::1001",
    Doh="https://cloudflare-dns.com/dns-query",
    Description="Resolvedor público da Cloudflare. Não filtra conteúdo."},

   new DnsProvider{Id="dns-cloudflare-malware",Name="Cloudflare · bloqueia malware",
    V4Primary="1.1.1.2",V4Secondary="1.0.0.2",V6Primary="2606:4700:4700::1112",V6Secondary="2606:4700:4700::1002",
    Doh="https://security.cloudflare-dns.com/dns-query",
    Description="Igual ao anterior, recusando domínios conhecidos por malware. Um site legítimo classificado errado deixa de abrir."},

   new DnsProvider{Id="dns-cloudflare-family",Name="Cloudflare · família",
    V4Primary="1.1.1.3",V4Secondary="1.0.0.3",V6Primary="2606:4700:4700::1113",V6Secondary="2606:4700:4700::1003",
    Doh="https://family.cloudflare-dns.com/dns-query",
    Description="Malware e conteúdo adulto. Filtro por domínio, no PC inteiro — não substitui controle parental nem impede acesso por outros meios."},

   new DnsProvider{Id="dns-google",Name="Google Public DNS",
    V4Primary="8.8.8.8",V4Secondary="8.8.4.4",V6Primary="2001:4860:4860::8888",V6Secondary="2001:4860:4860::8844",
    Doh="https://dns.google/dns-query",
    Description="Resolvedor público do Google. Não filtra conteúdo."},

   new DnsProvider{Id="dns-quad9",Name="Quad9",
    V4Primary="9.9.9.9",V4Secondary="149.112.112.112",V6Primary="2620:fe::fe",V6Secondary="2620:fe::9",
    Doh="https://dns.quad9.net/dns-query",
    Description="Fundação suíça sem fins lucrativos. Bloqueia domínios maliciosos por padrão."},

   new DnsProvider{Id="dns-opendns",Name="OpenDNS",
    V4Primary="208.67.222.222",V4Secondary="208.67.220.220",V6Primary="2620:119:35::35",V6Secondary="2620:119:53::53",
    Doh="https://doh.opendns.com/dns-query",
    Description="Resolvedor da Cisco, com filtro de phishing."},

   new DnsProvider{Id="dns-adguard",Name="AdGuard · anúncios e rastreadores",
    V4Primary="94.140.14.14",V4Secondary="94.140.15.15",V6Primary="2a10:50c0::ad1:ff",V6Secondary="2a10:50c0::ad2:ff",
    Doh="https://dns.adguard-dns.com/dns-query",
    Description="Recusa domínios de anúncio e rastreamento. Pode quebrar site que depende deles para carregar ou para login."},

   new DnsProvider{Id="dns-adguard-family",Name="AdGuard · família",
    V4Primary="94.140.14.15",V4Secondary="94.140.15.16",V6Primary="2a10:50c0::bad1:ff",V6Secondary="2a10:50c0::bad2:ff",
    Doh="https://family.adguard-dns.com/dns-query",
    Description="Anúncios, rastreadores, malware e conteúdo adulto."},

   new DnsProvider{Id="dns-mullvad",Name="Mullvad",
    V4Primary="194.242.2.2",V4Secondary="194.242.2.3",V6Primary="2a07:e340::2",V6Secondary="2a07:e340::3",
    Doh="https://dns.mullvad.net/dns-query",
    Description="Resolvedor sem registro de consultas, mantido pela Mullvad. Não filtra conteúdo."},

   new DnsProvider{Id="dns-mullvad-adblock",Name="Mullvad · anúncios e rastreadores",
    V4Primary="194.242.2.3",V4Secondary="194.242.2.2",V6Primary="2a07:e340::3",V6Secondary="2a07:e340::2",
    Doh="https://adblock.dns.mullvad.net/dns-query",
    Description="Igual ao anterior, recusando anúncio e rastreamento."},

   new DnsProvider{Id=Custom,Name="Personalizado",
    Description="Você informa os endereços. São validados antes de qualquer alteração; endereço inválido é recusado e nada é gravado."}
  };
 }

 internal static DnsProvider Resolve(string id){
  var found=Providers().SingleOrDefault(p=>p.Id==id);
  if(found==null)throw new ArgumentException("Provedor de DNS fora do catálogo: "+id);
  return found;
 }

 // ---------------------------------------------------------------- leitura
 // Somente leitura, sem elevação: é o que a tela mostra ANTES de qualquer escolha.
 internal static List<DnsAdapter> Read(){
#if TESTS
  // Fora do Windows não existe adaptador com índice de interface. O gancho permite
  // exercitar DETECTAR → BACKUP → APLICAR → CONFERIR → DESFAZER inteiro contra um
  // adaptador de mentira; o que ele NÃO cobre é o netsh de verdade, e o relatório de
  // testes diz isso com todas as letras.
  if(App.TestDnsRead!=null)return App.TestDnsRead();
#endif
  var result=new List<DnsAdapter>();
  foreach(var nic in NetworkInterface.GetAllNetworkInterfaces()){
   if(nic.NetworkInterfaceType==NetworkInterfaceType.Loopback||nic.NetworkInterfaceType==NetworkInterfaceType.Tunnel)continue;
   var adapter=new DnsAdapter{
    Name=nic.Name,Description=nic.Description,Up=nic.OperationalStatus==OperationalStatus.Up,
    Kind=nic.NetworkInterfaceType==NetworkInterfaceType.Wireless80211?"Wi-Fi":"Ethernet"};
   try{
    var properties=nic.GetIPProperties();
    foreach(var server in properties.DnsAddresses){
     if(server.AddressFamily==System.Net.Sockets.AddressFamily.InterNetwork)adapter.V4Servers.Add(server.ToString());
     else if(server.AddressFamily==System.Net.Sockets.AddressFamily.InterNetworkV6)adapter.V6Servers.Add(server.ToString());
    }
    try{adapter.IndexV4=properties.GetIPv4Properties().Index;adapter.V4Known=true;}catch{}
    try{adapter.IndexV6=properties.GetIPv6Properties().Index;adapter.V6Known=true;}catch{}
    // "Automático" aqui significa: o endereço IP vem por DHCP. O Windows não expõe
    // diretamente "o DNS veio do DHCP", então usamos o mesmo indício que o painel de
    // rede usa, e o texto da tela diz que é indício e não certeza.
    adapter.Dhcp=properties.GetIPv4Properties().IsDhcpEnabled;
   }catch{}
   result.Add(adapter);
  }
  return result;
 }

 // ---------------------------------------------------------------- validação
 // Índice é sempre número. Esta é a barreira que impede o nome do adaptador — texto
 // livre, que a pessoa controla — de entrar numa linha de comando.
 internal static bool ValidIndex(int index){return index>0&&index<100000;}

 internal static bool ValidAddress(string address,bool ipv6){
  if(String.IsNullOrWhiteSpace(address))return false;
  string text=address.Trim();
  // IPAddress.TryParse aceita as formas ABREVIADAS herdadas de inet_addr: "1.1.1" vira
  // 1.1.0.1 e "1" vira 0.0.0.1. Gravar isso como servidor DNS deixaria a pessoa sem
  // resolver nome nenhum, e ela teria digitado algo que "parecia" ter sido aceito.
  // Para IPv4 exigimos os quatro octetos, só dígitos, antes de qualquer outra coisa.
  if(!ipv6){
   var parts=text.Split(new[]{'.'});
   if(parts.Length!=4)return false;
   foreach(string part in parts){
    if(part.Length==0||part.Length>3)return false;
    foreach(char digit in part)if(digit<'0'||digit>'9')return false;
   }
  }
  IPAddress parsed;
  if(!IPAddress.TryParse(text,out parsed))return false;
  bool six=parsed.AddressFamily==System.Net.Sockets.AddressFamily.InterNetworkV6;
  if(six!=ipv6)return false;
  // Recusa endereços que não fazem sentido como servidor: qualquer-endereço, loopback
  // e multicast. Gravar um deles deixaria o PC sem resolver nome nenhum.
  if(parsed.Equals(IPAddress.Any)||parsed.Equals(IPAddress.IPv6Any))return false;
  if(IPAddress.IsLoopback(parsed))return false;
  byte[] bytes=parsed.GetAddressBytes();
  if(!six&&bytes[0]>=224)return false;            // multicast e reservado
  if(six&&bytes[0]==0xff)return false;            // multicast IPv6
  return true;
 }

 // Argumentos do netsh, montados só a partir de número e endereço já validados.
 // family é "ipv4" ou "ipv6"; nada disso vem de texto da pessoa.
 internal static string SetArguments(string family,int index,string address,bool primary){
  if(family!="ipv4"&&family!="ipv6")throw new ArgumentException("Família de endereços inválida.");
  if(!ValidIndex(index))throw new ArgumentException("Índice de adaptador inválido.");
  if(!ValidAddress(address,family=="ipv6"))throw new ArgumentException("Endereço de DNS inválido: "+address);
  return "interface "+family+" "+(primary?"set":"add")+" dnsservers name="+index+
         " static "+address.Trim()+(primary?" primary":" index=2")+" validate=no";
 }
 internal static string ResetArguments(string family,int index){
  if(family!="ipv4"&&family!="ipv6")throw new ArgumentException("Família de endereços inválida.");
  if(!ValidIndex(index))throw new ArgumentException("Índice de adaptador inválido.");
  return "interface "+family+" set dnsservers name="+index+" source=dhcp";
 }

 // Plano completo: o que será executado, em ordem, para um adaptador e um provedor.
 // A tela mostra isto ANTES de pedir administrador — é a prévia que o produto exige.
 internal static List<string> Plan(DnsAdapter adapter,DnsProvider provider,string customV4,string customV6){
  if(adapter==null)throw new ArgumentException("Adaptador não informado.");
  if(provider==null)throw new ArgumentException("Provedor não informado.");
  var plan=new List<string>();
  if(provider.Automatic){
   if(adapter.V4Known)plan.Add(ResetArguments("ipv4",adapter.IndexV4));
   if(adapter.V6Known)plan.Add(ResetArguments("ipv6",adapter.IndexV6));
   if(plan.Count==0)throw new ArgumentException("Este adaptador não expõe índice de interface; não é possível alterar o DNS dele.");
   return plan;
  }
  string v4Primary=provider.Id==Custom?customV4:provider.V4Primary;
  string v4Secondary=provider.Id==Custom?"":provider.V4Secondary;
  string v6Primary=provider.Id==Custom?customV6:provider.V6Primary;
  string v6Secondary=provider.Id==Custom?"":provider.V6Secondary;

  if(!String.IsNullOrWhiteSpace(v4Primary)){
   if(!adapter.V4Known)throw new ArgumentException("Este adaptador não expõe índice IPv4.");
   plan.Add(SetArguments("ipv4",adapter.IndexV4,v4Primary,true));
   if(!String.IsNullOrWhiteSpace(v4Secondary))plan.Add(SetArguments("ipv4",adapter.IndexV4,v4Secondary,false));
  }
  // IPv6 só é tocado quando o adaptador expõe índice IPv6 E o provedor tem endereço v6.
  // Gravar IPv4 e deixar o IPv6 no resolvedor antigo faria metade das consultas
  // continuarem indo para onde a pessoa acabou de escolher não mandar.
  if(!String.IsNullOrWhiteSpace(v6Primary)&&adapter.V6Known){
   plan.Add(SetArguments("ipv6",adapter.IndexV6,v6Primary,true));
   if(!String.IsNullOrWhiteSpace(v6Secondary))plan.Add(SetArguments("ipv6",adapter.IndexV6,v6Secondary,false));
  }
  if(plan.Count==0)throw new ArgumentException("Nada a aplicar: informe ao menos um endereço válido.");
  return plan;
 }

 // Backup do estado anterior, gravado ANTES de qualquer escrita.
 internal static DnsBackup Capture(DnsAdapter adapter){
  if(adapter==null)throw new ArgumentException("Adaptador não informado.");
  return new DnsBackup{IndexV4=adapter.IndexV4,IndexV6=adapter.IndexV6,AdapterName=adapter.Name,
   WasDhcp=adapter.V4Servers.Count==0&&adapter.V6Servers.Count==0,
   V4Servers=new List<string>(adapter.V4Servers),V6Servers=new List<string>(adapter.V6Servers)};
 }
 // Plano de restauração a partir do backup: volta ao que era, inclusive "automático".
 internal static List<string> RestorePlan(DnsBackup backup){
  if(backup==null)throw new ArgumentException("Backup não informado.");
  var plan=new List<string>();
  if(backup.WasDhcp||backup.V4Servers.Count==0){if(ValidIndex(backup.IndexV4))plan.Add(ResetArguments("ipv4",backup.IndexV4));}
  else for(int n=0;n<backup.V4Servers.Count;n++)plan.Add(SetArguments("ipv4",backup.IndexV4,backup.V4Servers[n],n==0));
  if(backup.WasDhcp||backup.V6Servers.Count==0){if(ValidIndex(backup.IndexV6))plan.Add(ResetArguments("ipv6",backup.IndexV6));}
  else for(int n=0;n<backup.V6Servers.Count;n++)plan.Add(SetArguments("ipv6",backup.IndexV6,backup.V6Servers[n],n==0));
  // Plano vazio seria um "Desfazer" que roda, diz que deu certo e não muda nada. É pior
  // que um erro: a pessoa acreditaria ter voltado ao estado anterior. Quem não tem
  // caminho de volta não pode ser alterado — ApplyDns confere isto ANTES de escrever.
  if(plan.Count==0)throw new ArgumentException("Este backup não descreve nenhum adaptador conhecido; não há caminho de volta a executar.");
  return plan;
 }

 // Os endereços que um plano realmente grava, na ordem. Lidos do próprio plano — e não
 // recalculados do provedor — para que a conferência seja feita sobre o que foi enviado.
 internal static string[] AddressesIn(List<string> plan){
  var list=new List<string>();
  foreach(string step in plan??new List<string>()){
   int at=step.IndexOf(" static ",StringComparison.Ordinal);
   if(at<0)continue;
   string rest=step.Substring(at+8);
   int space=rest.IndexOf(' ');
   list.Add(space<0?rest:rest.Substring(0,space));
  }
  return list.ToArray();
 }

 // Nome humano de cada etapa. O comando continua no corpo da etapa; aqui vai o que a
 // pessoa lê na lista do Histórico.
 internal static string StepName(string step){
  string family=(step??"").IndexOf(" ipv6 ",StringComparison.Ordinal)>=0?"IPv6":"IPv4";
  if((step??"").IndexOf("source=dhcp",StringComparison.Ordinal)>=0)return "Voltar ao DNS do roteador ("+family+")";
  return ((step??"").IndexOf(" primary",StringComparison.Ordinal)>=0?"Servidor principal (":"Servidor alternativo (")+family+")";
 }

 // ---------------------------------------------------------------- pedido
 // Formato: provedor|índiceIPv4|índiceIPv6|endereçoIPv4|endereçoIPv6
 //
 // O NOME do adaptador não entra no pedido de propósito. Ele é texto que a pessoa
 // controla, e o pedido atravessa a linha de comando de um processo elevado. O que
 // atravessa é número; o processo elevado relê os adaptadores e encontra o certo por
 // índice, conferindo TODAS as famílias que o pedido declara.
 internal static DnsRequest Parse(string payload){
  var parts=(payload??"").Split(new[]{'|'});
  if(parts.Length!=5)throw new ArgumentException("Pedido de DNS inválido.");
  var request=new DnsRequest{Provider=Resolve(parts[0])};
  if(!Int32.TryParse(parts[1],NumberStyles.None,CultureInfo.InvariantCulture,out request.IndexV4)||
     !Int32.TryParse(parts[2],NumberStyles.None,CultureInfo.InvariantCulture,out request.IndexV6))
   throw new ArgumentException("Índice de adaptador inválido no pedido de DNS.");
  // Zero significa "esta família não existe neste adaptador" — é o único valor fora da
  // faixa que o pedido aceita, e ele não vira comando nenhum.
  if(request.IndexV4!=0&&!ValidIndex(request.IndexV4))throw new ArgumentException("Índice IPv4 inválido.");
  if(request.IndexV6!=0&&!ValidIndex(request.IndexV6))throw new ArgumentException("Índice IPv6 inválido.");
  if(request.IndexV4==0&&request.IndexV6==0)throw new ArgumentException("O adaptador escolhido não expõe índice de interface; não é possível alterar o DNS dele.");
  request.CustomV4=(parts[3]??"").Trim();request.CustomV6=(parts[4]??"").Trim();
  if(request.Provider.Id==Custom){
   if(request.CustomV4.Length==0&&request.CustomV6.Length==0)throw new ArgumentException("Informe ao menos um endereço para o DNS personalizado.");
   if(request.CustomV4.Length>0&&!ValidAddress(request.CustomV4,false))throw new ArgumentException("Endereço IPv4 inválido: "+request.CustomV4);
   if(request.CustomV6.Length>0&&!ValidAddress(request.CustomV6,true))throw new ArgumentException("Endereço IPv6 inválido: "+request.CustomV6);
  }else if(request.CustomV4.Length>0||request.CustomV6.Length>0)
   throw new ArgumentException("Endereço digitado só é aceito com o provedor Personalizado.");
  return request;
 }

 // Monta o pedido a partir da escolha da tela e o valida pelo MESMO caminho que o
 // processo elevado usará. Nada sai daqui que seria recusado lá.
 internal static string PayloadFor(DnsAdapter adapter,string providerId,string customV4,string customV6){
  if(adapter==null)throw new ArgumentException("Adaptador não informado.");
  var provider=Resolve(providerId);
  bool custom=provider.Id==Custom;
  string payload=provider.Id+"|"+(adapter.V4Known?adapter.IndexV4:0).ToString(CultureInfo.InvariantCulture)+"|"+
   (adapter.V6Known?adapter.IndexV6:0).ToString(CultureInfo.InvariantCulture)+"|"+
   (custom?(customV4??"").Trim():"")+"|"+(custom?(customV6??"").Trim():"");
  Parse(payload);
  return payload;
 }

 // Encontra o adaptador do pedido entre os que existem AGORA. Exige coincidir em todas
 // as famílias que o pedido declara: IPv4 e IPv6 têm numeração separada no Windows, e
 // dois adaptadores diferentes podem repetir um mesmo número em famílias diferentes.
 // Na dúvida, recusa — escrever no adaptador errado deixaria a pessoa sem internet.
 internal static DnsAdapter Locate(List<DnsAdapter> adapters,int indexV4,int indexV6){
  if(adapters==null)throw new ArgumentException("Nenhum adaptador foi lido.");
  if(indexV4==0&&indexV6==0)throw new ArgumentException("Pedido sem índice de adaptador.");
  var found=adapters.Where(a=>(indexV4==0||(a.V4Known&&a.IndexV4==indexV4))&&(indexV6==0||(a.V6Known&&a.IndexV6==indexV6))).ToList();
  if(found.Count==0)throw new Exception("O adaptador escolhido não foi encontrado agora. Ele pode ter sido desconectado, desativado ou renumerado pelo Windows. Nada foi alterado; abra a tela de rede de novo e escolha outra vez.");
  if(found.Count>1)throw new Exception("Mais de um adaptador responde pelo mesmo índice. Para não alterar o adaptador errado, nada foi feito.");
  return found[0];
 }

 // Confere a leitura seguinte contra o que foi gravado. Devolve null quando confere.
 internal static string Verify(DnsAdapter after,DnsSaved saved){
  if(saved==null)return "Não há registro do que foi gravado; não é possível conferir.";
  if(after==null)return "O adaptador não pôde ser lido de novo; não foi possível conferir.";
  // "Automático" não tem como ser confirmado por leitura: assim que o adaptador volta ao
  // DHCP o roteador já entrega os servidores dele, e o Windows mostra esses endereços
  // sem dizer que vieram do DHCP. Dizer "conferido" aqui seria inventar certeza.
  if(saved.ToAutomatic)return null;
  var missing=new List<string>();
  foreach(string address in saved.Applied??new string[0]){
   var list=address.IndexOf(':')>=0?after.V6Servers:after.V4Servers;
   if(!list.Any(s=>String.Equals(s,address,StringComparison.OrdinalIgnoreCase)))missing.Add(address);
  }
  if(missing.Count==0)return null;
  return "Estes endereços não apareceram na leitura seguinte: "+String.Join(", ",missing.ToArray())+
   ". O comando não acusou erro, então o Windows pode apenas não ter atualizado a leitura ainda — ou a alteração não valeu. Confira em Ver servidores DNS; Desfazer continua disponível.";
 }

 // Alguém mexeu no DNS deste adaptador DEPOIS da aplicação? Então Desfazer sobrescreveria
 // uma escolha mais nova. Mesma regra do restauro de registro: interrompe e explica.
 internal static string Drift(DnsAdapter now,DnsSaved saved){
  if(saved==null||now==null)return null;
  if(saved.ToAutomatic)return null;   // não há como afirmar a origem dos servidores atuais
  foreach(string address in saved.Applied??new string[0]){
   var list=address.IndexOf(':')>=0?now.V6Servers:now.V4Servers;
   if(!list.Any(s=>String.Equals(s,address,StringComparison.OrdinalIgnoreCase)))
    return "O DNS deste adaptador foi alterado depois desta aplicação: "+address+" não está mais configurado. "+
     "A restauração foi interrompida para não desfazer uma escolha mais recente que o aplicativo não fez.";
  }
  return null;
 }

 // Texto da confirmação: o que muda, o que custa, e o que será executado.
 internal static string Confirmation(DnsAdapter adapter,DnsProvider provider,List<string> plan){
  var b=new StringBuilder();
  b.AppendLine("Adaptador: "+adapter.Name+" ("+adapter.Kind+")").AppendLine();
  b.AppendLine("DNS atual: "+Describe(adapter)).AppendLine();
  b.AppendLine("Novo: "+provider.Name);
  b.AppendLine(provider.Description).AppendLine();
  b.AppendLine("Trocar DNS muda QUEM resolve os nomes que este PC acessa e para onde vão essas consultas. É escolha de privacidade e confiança, não de velocidade: não aumenta a banda contratada e raramente muda a sensação de navegação.").AppendLine();
  b.AppendLine("O estado atual será gravado no Histórico antes da mudança, e Desfazer devolve exatamente o que está agora — inclusive 'automático'.").AppendLine();
  b.AppendLine(plan.Count+" comando(s) serão executados neste adaptador. Requer administrador.").AppendLine();
  b.AppendLine("Aplicar agora?");
  return b.ToString();
 }
 internal static string Describe(DnsAdapter adapter){
  if(adapter==null)return "desconhecido";
  var parts=new List<string>();
  if(adapter.V4Servers.Count>0)parts.Add("IPv4 "+String.Join(", ",adapter.V4Servers.ToArray()));
  if(adapter.V6Servers.Count>0)parts.Add("IPv6 "+String.Join(", ",adapter.V6Servers.ToArray()));
  if(parts.Count==0)return "automático (entregue pelo roteador)";
  return String.Join("  ·  ",parts.ToArray());
 }

 // Detalhes técnicos: é aqui — e só aqui — que netsh aparece na tela.
 internal static string Technical(DnsAdapter adapter,DnsProvider provider,List<string> plan){
  var b=new StringBuilder();
  b.AppendLine("Adaptador: "+(adapter==null?"—":adapter.Name+" ("+adapter.Kind+")"));
  if(adapter!=null)b.AppendLine("Índice de interface: IPv4 "+(adapter.V4Known?adapter.IndexV4.ToString(CultureInfo.InvariantCulture):"não exposto")+
   " · IPv6 "+(adapter.V6Known?adapter.IndexV6.ToString(CultureInfo.InvariantCulture):"não exposto"));
  b.AppendLine("DNS atual: "+Describe(adapter)).AppendLine();
  b.AppendLine("Escolha: "+provider.Name);
  if(!provider.Automatic&&provider.Id!=Custom){
   b.AppendLine("IPv4: "+provider.V4Primary+", "+provider.V4Secondary);
   b.AppendLine("IPv6: "+provider.V6Primary+", "+provider.V6Secondary);
   b.AppendLine("DNS-over-HTTPS do provedor: "+provider.Doh+"  (informativo; o Windows só usa este endereço se você ativar DNS criptografado nas configurações de rede — este aplicativo não ativa)");
  }
  b.AppendLine();
  b.AppendLine("Comandos, nesta ordem:");
  foreach(string step in plan??new List<string>())b.AppendLine("  netsh.exe "+step);
  b.AppendLine();
  b.AppendLine("O adaptador é identificado pelo ÍNDICE numérico, nunca pelo nome: nome de adaptador é texto livre e não pode entrar numa linha de comando executada como administrador.");
  b.AppendLine("validate=no evita que o netsh espere a validação do servidor, que demora e falha em rede sem saída no momento da troca.");
  b.AppendLine();
  b.AppendLine("Antes de gravar, o estado atual vai para o Histórico e o app confere que existe um plano de volta. Depois de gravar, o adaptador é lido de novo e o resultado dessa leitura fica registrado.");
  b.AppendLine("Fonte: https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/netsh-interface-ipv4");
  return b.ToString();
 }
}

static partial class App {
#if TESTS
 internal static Func<List<DnsAdapter>> TestDnsRead;
 internal static Func<string,int> TestDnsCommand;   // devolve o código de saída do netsh
#endif
 const int DnsTimeoutSeconds=60;

 // Executa um plano de netsh, uma etapa por vez, registrando cada uma no Histórico antes
 // de seguir. Para no primeiro erro: continuar depois de uma falha escreveria metade da
 // configuração e deixaria o adaptador num estado que ninguém escolheu.
 static bool RunDnsPlan(List<string> plan,string prefix,Record record,CancellationToken token){
  string executable=null;
#if TESTS
  if(TestDnsCommand==null)
#endif
  executable=SystemExe("netsh.exe");
  int order=0;
  foreach(string step in plan){
   order++;
   int exit;string output;bool timedOut=false,cancelled=false;
#if TESTS
   if(TestDnsCommand!=null){exit=TestDnsCommand(step);output="(execução simulada pelos testes)";}
   else{
#endif
   var result=ManagedCommand.Run(executable,step,DnsTimeoutSeconds,token);
   exit=result.ExitCode;timedOut=result.TimedOut;cancelled=result.Cancelled;
   output=result.Output+"\r\nLog completo: "+result.LogPath;
#if TESTS
   }
#endif
   bool ok=!timedOut&&!cancelled&&exit==0;
   record.Steps.Add(new StepResult{Id=prefix+"-"+order,Name=DnsManager.StepName(step),
    Status=timedOut?"tempo esgotado":cancelled?"cancelado":ok?"concluído":"falhou",
    Message="netsh.exe "+step+"\r\nCódigo de saída: "+exit+"\r\n"+output});
   Save(record);
   if(!ok)return false;
  }
  return true;
 }

 // GERENCIADOR DE DNS — aplicação.
 //
 // DETECTAR → PRÉVIA → BACKUP → APLICAR → CONFERIR → REGISTRAR → DESFAZER.
 //
 // Duas decisões que valem registro:
 //
 // 1. Falha no meio da gravação volta sozinha. Meia troca é pior que qualquer um dos
 //    dois estados: metade das consultas iria para o resolvedor antigo, e a pessoa não
 //    teria como saber disso olhando a tela.
 //
 // 2. Conferência que não bate NÃO volta sozinha. Os comandos não acusaram erro; o
 //    Windows pode só não ter atualizado a leitura. Desfazer por conta própria aqui
 //    seria trocar o DNS duas vezes sem a pessoa pedir. O registro diz que não conferiu,
 //    e Desfazer continua a um clique.
 internal static Record ApplyDns(string payload,CancellationToken token){
  var request=DnsManager.Parse(payload);
  var record=NewRecord("Servidores DNS · "+request.Provider.Name,request.Provider.Id,"DNS");
  record.RequestedAdmin=true;
  Save(record);
  try{
   // DETECTAR: o adaptador é reencontrado AGORA, no processo elevado, pelo índice.
   var adapter=DnsManager.Locate(DnsManager.Read(),request.IndexV4,request.IndexV6);
   var plan=DnsManager.Plan(adapter,request.Provider,request.CustomV4,request.CustomV6);
   // BACKUP: gravado e CONFERIDO antes de qualquer escrita. RestorePlan lança quando não
   // há caminho de volta — e aí a alteração não acontece.
   var backup=DnsManager.Capture(adapter);
   var undo=DnsManager.RestorePlan(backup);
   record.DnsValue=new DnsSaved{Before=backup,ProviderId=request.Provider.Id,AdapterName=adapter.Name,
    ToAutomatic=request.Provider.Automatic,Applied=DnsManager.AddressesIn(plan)};
   record.Steps.Add(new StepResult{Id="dns-backup",Name="DNS anterior gravado",Status="gravado",
    Message="Adaptador: "+adapter.Name+" ("+adapter.Kind+")\r\nAntes: "+DnsManager.Describe(adapter)+
     "\r\nDesfazer executará "+undo.Count+" comando(s) para voltar exatamente a este estado."});
   record.Status="pronto para aplicar";
   Save(record);   // se o Histórico não aceitar a gravação, nada abaixo executa

   record.Status="aplicando";record.ChangesStarted=true;Save(record);
   if(!RunDnsPlan(plan,"dns-set",record,token)){
    record.Status="restaurando";Save(record);
    bool back=RunDnsPlan(undo,"dns-rollback",record,token);
    record.OutcomeCode=back?"COMMAND_FAILED":"ROLLBACK_FAILED";
    record.Status=back?"falhou e foi desfeito":"falha na restauração";
    record.Message=back
     ?"A troca falhou no meio e o DNS anterior foi recolocado. Nada ficou pela metade. O erro de cada comando está nas etapas acima."
     :"A troca falhou E a volta ao estado anterior também falhou. O DNS deste adaptador pode estar incompleto. Abra o Histórico, use Desfazer de novo; se insistir, configure o adaptador em Conexões de rede do Windows — o estado anterior está registrado na etapa 'DNS anterior gravado'.";
    Save(record);return record;
   }

   // CONFERIR: relê o adaptador e compara com o que foi gravado.
   string problem;
   try{problem=DnsManager.Verify(DnsManager.Locate(DnsManager.Read(),request.IndexV4,request.IndexV6),record.DnsValue);}
   catch(Exception e){problem="Não foi possível reler o adaptador para conferir: "+e.Message;}
   record.Steps.Add(new StepResult{Id="dns-verify",Name="Conferência após a troca",
    Status=problem==null?(request.Provider.Automatic?"sem como conferir":"conferido"):"não confere",
    Message=problem??(request.Provider.Automatic
     ?"O adaptador voltou ao DNS automático. O Windows informa quais servidores estão em uso, mas não informa que vieram do roteador — por isso esta etapa não afirma que conferiu."
     :"Os endereços gravados apareceram na leitura seguinte: "+String.Join(", ",record.DnsValue.Applied))});
   record.OutcomeCode=problem==null?"OK":"VERIFY_FAILED";
   record.Status="aplicado";
   record.Message="Adaptador: "+adapter.Name+"\r\nAntes: "+DnsManager.Describe(backup.WasDhcp?new DnsAdapter():adapter)+
    "\r\nAgora: "+request.Provider.Name+"\r\n"+request.Provider.Description+
    "\r\n\r\nTrocar DNS muda QUEM resolve os nomes deste PC. Não aumenta a banda contratada."+
    (problem==null?"":"\r\n\r\nATENÇÃO: "+problem)+
    "\r\n\r\nDesfazer, no Histórico, devolve exatamente o DNS que havia antes.";
  }catch(Exception e){
   // Só chega aqui antes da primeira gravação: depois dela todo caminho sai pelo bloco
   // de rollback acima. ChangesStarted diz qual dos dois foi, e fica no registro.
   record.Status=record.ChangesStarted?"falhou":"falhou antes de alterar";
   record.OutcomeCode=ErrorHelp.For(e).ErrorCode;
   record.Message=ErrorHelp.For(e).FriendlyError+"\r\n"+e.Message;
   record.FailureDetail=e.ToString();
  }
  Save(record);return record;
 }

 // DESFAZER. Chamado por Undo() quando o registro é de DNS.
 internal static void RestoreDns(Record record){
  if(record==null||record.DnsValue==null||record.DnsValue.Before==null)
   throw new Exception("Este registro não guarda o DNS anterior; não há o que restaurar.");
  var saved=record.DnsValue;
  var plan=DnsManager.RestorePlan(saved.Before);
  var adapter=DnsManager.Locate(DnsManager.Read(),saved.Before.IndexV4,saved.Before.IndexV6);
  // Mesma regra do restauro de registro: se mudaram esses valores depois, para.
  string drift=DnsManager.Drift(adapter,saved);
  if(drift!=null)throw new Exception(drift);
  record.Status="restaurando";Save(record);
  try{
   bool ok=RunDnsPlan(plan,"dns-undo",record,CancellationToken.None);
   if(ok){
    var after=DnsManager.Locate(DnsManager.Read(),saved.Before.IndexV4,saved.Before.IndexV6);
    record.Status="desfeito";
    record.Message="DNS anterior recolocado no adaptador "+adapter.Name+".\r\nAgora: "+DnsManager.Describe(after)+
     (saved.Before.WasDhcp?"\r\nO adaptador voltou a receber o DNS do roteador.":"");
    Save(record);return;
   }
   record.Status="falha na restauração";
   record.Message="A restauração não terminou. O DNS deste adaptador pode estar incompleto; tente Desfazer de novo pelo Histórico.";
   Save(record);
   throw new Exception(record.Message);
  }catch(Exception e){
   if(record.Status!="falha na restauração"){record.Status="falha na restauração";record.Message=e.Message;Save(record);}
   throw;
  }
 }
}

using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;

public class PerformanceEntry {
 public string Id {get;set;} public string Title {get;set;} public string Category {get;set;}
 public string Mode {get;set;} public string Effect {get;set;} public string Tradeoff {get;set;}
 public string Steps {get;set;} public string Action {get;set;} public string Target {get;set;} public string Source {get;set;}
}
static class PerformanceLibrary {
 internal static List<PerformanceEntry> Load(){
  List<PerformanceEntry> list;
  using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("performance-library.json"))using(var reader=new StreamReader(stream))list=App.Json.Deserialize<List<PerformanceEntry>>(reader.ReadToEnd());
  using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("v5-advanced-library.json"))using(var reader=new StreamReader(stream))list.AddRange(App.Json.Deserialize<List<PerformanceEntry>>(reader.ReadToEnd()));
  list.AddRange(ImportedOptions.LibraryEntries());list.Add(ExtraSettings.Library());list.AddRange(ReviewedFeatures.Library());
  foreach(var item in OriginalItems())list.Add(new PerformanceEntry{Id="catalog-"+item.Id,Title=item.ReviewTitle??item.Name,Category="Arquivos originais / "+item.Category,Mode=item.ReviewLevel??"Manual",Action="catalog",Target=item.Id,Effect=String.Join(" ",item.Review??new string[0]),Tradeoff=String.IsNullOrWhiteSpace(item.Blocked)?"Arquivo original preservado; consulte a revisão antes de usar. Não incluído na aplicação automática.":item.Blocked,Steps="Abra Ver arquivo e revisão nesta janela. ID original: "+item.Id,Source=item.Url??""});
  var manual=new HashSet<string>(CatalogIds.NativeItems().Where(i=>(i.Operations??new RegOp[0]).Any(App.IsPolicy)).Select(i=>i.Id));
  foreach(var entry in list.Where(e=>e.Action=="native"&&manual.Contains(e.Target)))entry.Mode="Manual";
  return list;
 }
 internal static List<Item> OriginalItems(){
  List<Item> items;using(var s=Assembly.GetExecutingAssembly().GetManifestResourceStream("catalog.json"))using(var r=new StreamReader(s))items=App.Json.Deserialize<List<Item>>(r.ReadToEnd());
  if(ImportedScripts.All.Count==0)ImportedScripts.Load();items.AddRange(ImportedScripts.AsCatalogItems());return items;
 }
 internal static string Describe(PerformanceEntry e){return e.Title+"\r\n"+e.Category+" · "+e.Mode+"\r\n\r\nQUANDO AJUDA\r\n"+e.Effect+"\r\n\r\nCOMO USAR\r\n"+e.Steps+"\r\n\r\nEFEITOS / LIMITES\r\n"+e.Tradeoff+"\r\n\r\nFonte oficial / referência técnica: "+e.Source+"\r\nBiblioteca revisada em 12/09/2026. Ganhos dependem do hardware e do jogo.";}
}

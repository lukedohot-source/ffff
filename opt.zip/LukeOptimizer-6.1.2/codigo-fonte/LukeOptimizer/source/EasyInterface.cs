﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.NetworkInformation;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

public partial class MainForm {
 readonly List<Control> extraActions=new List<Control>();
 readonly Dictionary<string,CheckBox> servicePicks=new Dictionary<string,CheckBox>();
 readonly Dictionary<string,Label> serviceLabels=new Dictionary<string,Label>();
 ListView appsList,startupList,batList;ComboBox focusList,processSort,processTier,serviceTier;TextBox processSearch;CheckBox showProtected;
 TextBox ramExplanation,easyResult,batDetail,tempDetail;Label easyCpu,easyRam,easyProcess,easySummary;
 List<ProcessToken> processSnapshot=new List<ProcessToken>();TempScan tempSnapshot;ResourceSample currentSample;
 bool resourceScanning,easyRunning;
 ActionButton ExtraButton(string text,EventHandler click,bool primary=false,int width=185) {
  var b=Theme.Button(text,primary);b.Width=width;b.Margin=new Padding(0,0,10,8);b.Click+=click;extraActions.Add(b);return b;
 }
 ListView CheckList(params string[] columns) {
  var list=new CheckableList {Dock=DockStyle.Fill,View=View.Details,CheckBoxes=true,FullRowSelect=true,HideSelection=false,
   MultiSelect=false,BackColor=Theme.Card,ForeColor=Theme.Text,BorderStyle=BorderStyle.None,Font=Theme.Font(10)};
  for(int i=0;i<columns.Length;i++)list.Columns.Add(columns[i],i==0?220:150);
  return list;
 }
 Surface Box(){return new Surface {Dock=DockStyle.Fill,Margin=new Padding(0,0,0,12)};}
 void BuildEasy() {
  var page=Page("Modo fácil");var grid=Rows(188,106,105,60,-1);page.Controls.Add(grid);
  var hero=Box();hero.Fill=Theme.HeroFill;hero.BackColor=hero.Fill;grid.Controls.Add(hero,0,0);
  var split=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=2};split.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));split.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,258));hero.Controls.Add(split);
  var intro=Rows(25,50,-1);split.Controls.Add(intro,0,0);intro.Controls.Add(Theme.Label("MODO FÁCIL  /  SEM PROMESSAS DE FPS",9,Theme.Accent,true),0,0);
  intro.Controls.Add(Theme.Label("Mais espaço para o que importa.",22,Theme.Text,true),0,1);
  intro.Controls.Add(Theme.Label("Ajustes revisados, apps sob seu controle e resultado medido.\r\nNada é alterado até você confirmar.",10,Theme.Muted),0,2);
  var buttons=Rows(57,50,-1);buttons.Padding=new Padding(14,12,0,0);split.Controls.Add(buttons,1,0);
  var go=ExtraButton("OTIMIZAR AGORA",async(s,e)=>await RunEasy(),true,236);go.Dock=DockStyle.Fill;buttons.Controls.Add(go,0,0);
  var edit=ExtraButton("Escolher ajustes",(s,e)=>ShowPage("Otimização máxima"),false,236);edit.Dock=DockStyle.Fill;buttons.Controls.Add(edit,0,1);
  buttons.Controls.Add(Theme.Label("Backup das configurações · resultado por etapa",8,Theme.Muted),0,2);
  var metrics=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=3};for(int i=0;i<3;i++)metrics.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,33.333f));grid.Controls.Add(metrics,0,1);
  easyCpu=Metric(metrics,0,"—","CPU · amostra curta",Theme.Accent);easyRam=Metric(metrics,1,"—","RAM disponível · inclui reutilizável",Theme.Contrast);easyProcess=Metric(metrics,2,"—","Processos · quantidade não é nota",Theme.Text);
  var summary=Box();summary.Padding=new Padding(16,8,16,8);grid.Controls.Add(summary,0,2);easySummary=Theme.Label("Abra no Windows para consultar seu PC.\r\nNenhum processo é selecionado automaticamente para fechar.",10,Theme.Muted);summary.Controls.Add(easySummary);
  var presets=new FlowLayoutPanel {Dock=DockStyle.Fill,WrapContents=false,AutoScroll=true};grid.Controls.Add(presets,0,3);
  presets.Controls.Add(ExtraButton("Preset Jogos",(s,e)=>SetPreset(true),false,145));presets.Controls.Add(ExtraButton("Preset Trabalho / CAD",(s,e)=>SetPreset(false),false,187));
  presets.Controls.Add(ExtraButton("Escolher apps para fechar",(s,e)=>ShowPage("Apps e RAM"),false,230));
  presets.Controls.Add(ExtraButton("Desfazer",async(s,e)=>await UndoLatest(),false,118));
  var result=Box();result.Margin=Padding.Empty;grid.Controls.Add(result,0,4);easyResult=Theme.ReadBox();easyResult.Text="Aguardando primeira medição.\r\n\r\nA RAM será liberada fechando apps que você selecionar. Sem esvaziar cache útil, sem desligar paginação e sem encerrar serviços por estarem ociosos.\r\nGanho de FPS só pode ser confirmado comparando o mesmo cenário no seu jogo.";result.Controls.Add(easyResult);
 }
 void SetPreset(bool games) {
  if(busy||scanning||easyRunning)return;updatingPicks=true;
  foreach(var item in App.Items.Where(i=>i.Native&&i.MaxEligible))picks[item.Id].Checked=item.DefaultSelected&&(games||(item.ActionCode!="capture"&&item.ActionCode!="gamemode"));
  updatingPicks=false;UpdateProfile();RefreshEasySummary();footer.Text="Preset selecionado; ainda não aplicado. Alto desempenho e mouse são opcionais.";
 }
 List<ProcessToken> CheckedProcesses() {
  if(appsList==null)return new List<ProcessToken>();
  return appsList.CheckedItems.Cast<ListViewItem>().SelectMany(row=>((ProcessGroup)row.Tag).Processes).ToList();
 }
 string[] PickedNative() {return picks.Where(p=>p.Value.Checked&&App.Compatibility(App.Items.Single(i=>i.Id==p.Key),machine)==null).Select(p=>p.Key).ToArray();}
 void RefreshEasySummary() {
  if(easySummary==null)return;int count=machine.Windows?PickedNative().Length:0,apps=appsList==null?0:appsList.CheckedItems.Count;
  easySummary.Text=count+" ajuste(s) compatível(is) selecionado(s) + "+apps+" app(s) para solicitar fechamento.\r\n"+
   "Fora deste botão: exclusão de arquivos, serviços, desinstalação, rede e prioridade.\r\n"+(apps==0?"Selecione em Apps e RAM o que você não usará durante o jogo/trabalho.":"Salve seu trabalho. O modo fácil não força o fechamento nem ignora pedidos de salvar.");
 }
 void ExtraEnabled() {
  bool enabled=ready&&machine.Windows&&!busy&&!scanning&&!resourceScanning&&!easyRunning;
  foreach(var c in extraActions)c.Enabled=enabled;
  if(appsList!=null)appsList.Enabled=enabled;if(startupList!=null)startupList.Enabled=enabled;if(focusList!=null)focusList.Enabled=enabled;
  foreach(var check in servicePicks.Values)check.Enabled=enabled;
  RefreshEasySummary();
 }
 void ShowSample(ResourceSample sample) {
  currentSample=sample;if(easyCpu==null)return;
  easyCpu.Text=sample!=null&&sample.CpuKnown?sample.CpuPercent.ToString("0.0")+"%":"—";
  easyRam.Text=sample!=null&&sample.MemoryKnown?(sample.AvailableMB/1024).ToString("0.00")+" GB":"—";
  easyProcess.Text=sample!=null&&machine.Windows?sample.Processes.ToString():"—";
  ramExplanation.Text=ResourceMonitor.Describe(sample)+"\r\n\r\n0% de CPU não significa inútil: apps ociosos podem fornecer áudio, rede, sincronização ou segurança. RAM ocupada por cache pode ser reutilizada pelo Windows.\r\nO fechamento normal respeita diálogos de salvar. A opção forçada pode perder abas, chamadas ou dados não salvos. Não há fechamento periódico/automático.";
 }
 void BuildResources() {
  var page=Page("Apps e RAM");var root=Rows(66,49,43,-1,112,51);page.Controls.Add(root);
  root.Controls.Add(Theme.Label("1. Atualize o consumo.  2. Marque o que não vai usar, ou use Marcar nível.  3. Clique em Fechar apps marcados.\r\nSistema, drivers, serviços, jogos e anticheat continuam preservados. Launchers, sincronização e software de periférico agora aparecem, no nível extremo.",10,Theme.Muted),0,0);
  var controls=new FlowLayoutPanel {Dock=DockStyle.Fill,WrapContents=false,AutoScroll=true};root.Controls.Add(controls,0,1);
  controls.Controls.Add(ExtraButton("Atualizar consumo",async(s,e)=>await RefreshResources(),false,185));
  processTier=Combo();processTier.Dock=DockStyle.None;processTier.Width=290;processTier.Margin=new Padding(8,4,8,0);
  processTier.Items.AddRange(new object[]{"Nível 1 · apps de usuário","Nível 2 · + sincronização e atualizadores","Nível 3 · + launchers e periféricos"});
  processTier.SelectedIndex=0;processTier.AccessibleName="Nível de redução de processos";controls.Controls.Add(processTier);
  controls.Controls.Add(ExtraButton("Marcar nível",(s,e)=>MarkProcessTier(),false,150));
  showProtected=new CheckBox {Text="Mostrar também os preservados",AutoSize=true,ForeColor=Theme.Muted,Margin=new Padding(12,10,0,0)};controls.Controls.Add(showProtected);showProtected.CheckedChanged+=(s,e)=>FillProcesses();
  var filters=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=4};filters.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));filters.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,155));filters.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,165));filters.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,140));root.Controls.Add(filters,0,2);
  processSearch=Field();processSearch.AccessibleName="Filtrar apps por nome";filters.Controls.Add(processSearch,0,0);processSort=Combo();processSort.Items.AddRange(new object[]{"Maior RAM","Maior CPU","Mais processos","Nome"});processSort.SelectedIndex=0;filters.Controls.Add(processSort,1,0);
  filters.Controls.Add(ExtraButton("Marcar visíveis",(s,e)=>{foreach(ListViewItem row in appsList.Items)if(((ProcessGroup)row.Tag).CanClose)row.Checked=true;},false,155),2,0);
  filters.Controls.Add(ExtraButton("Limpar seleção",(s,e)=>{foreach(ListViewItem row in appsList.Items)row.Checked=false;},false,132),3,0);
  processSearch.TextChanged+=(s,e)=>FillProcesses();processSort.SelectedIndexChanged+=(s,e)=>FillProcesses();
  appsList=CheckList("App / selecionar","RAM residente*","CPU amostrada","Estado / proteção");appsList.Columns[0].Width=215;appsList.Columns[1].Width=133;appsList.Columns[2].Width=135;appsList.Columns[3].Width=375;
  appsList.ItemCheck+=(s,e)=>{if(e.NewValue==CheckState.Checked&&!((ProcessGroup)appsList.Items[e.Index].Tag).CanClose)e.NewValue=CheckState.Unchecked;BeginInvoke((Action)RefreshEasySummary);};root.Controls.Add(appsList,0,3);
  var note=Box();note.Margin=new Padding(0,10,0,10);root.Controls.Add(note,0,4);ramExplanation=Theme.ReadBox();ramExplanation.Text="Clique em Atualizar consumo para ver os apps deste PC. Marcar uma caixa ainda não fecha nada. A memória exibida não é uma promessa de quanto será liberado.";note.Controls.Add(ramExplanation);
  var actions=new FlowLayoutPanel {Dock=DockStyle.Fill,WrapContents=false,AutoScroll=true};root.Controls.Add(actions,0,5);
  actions.Controls.Add(ExtraButton("Fechar apps marcados",async(s,e)=>await RunClose(false),true,220));
  actions.Controls.Add(ExtraButton("Forçar fechamento…",async(s,e)=>await RunClose(true),false,200));
  actions.Controls.Add(ExtraButton("Reabrir apps fechados",async(s,e)=>await ReopenLastClosedApps(),false,205));
  actions.Controls.Add(ExtraButton("Gerenciador de Tarefas",(s,e)=>OpenSystem("Taskmgr.exe",""),false,208));
 }
 internal string ProcessTierKey(){
  int index=processTier==null?0:processTier.SelectedIndex;
  return index==2?"extremo":index==1?"agressivo":"leve";
 }
 // Marca de uma vez tudo que pertence ao nível escolhido e está fechável AGORA.
 // Não fecha nada: o fechamento continua exigindo o botão e a confirmação.
 void MarkProcessTier(){
  if(appsList==null)return;
  string tier=ProcessTierKey();int marked=0;
  foreach(ListViewItem row in appsList.Items){
   var group=(ProcessGroup)row.Tag;
   bool wanted=group.CanClose&&ResourceMonitor.WithinTier(group.Name,tier);
   row.Checked=wanted;if(wanted)marked++;
  }
  RefreshEasySummary();
  footer.Text=marked+" app(s) marcado(s) no nível "+tier+". "+ResourceMonitor.TierWarning(tier);
 }
 internal string ServiceTierKey(){
  int index=serviceTier==null?0:serviceTier.SelectedIndex;
  return index==2?"extremo":index==1?"agressivo":"leve";
 }
 void MarkServiceTier(){
  string tier=ServiceTierKey();int marked=0;
  foreach(var pair in servicePicks){
   bool wanted=App.ServiceWithinTier(pair.Key,tier);
   pair.Value.Checked=wanted;if(wanted)marked++;
  }
  footer.Text=marked+" serviço(s) marcado(s) no nível "+tier+". "+App.ServiceTierWarning(tier);
 }
 // Desativa o nível inteiro numa transação só. Cada serviço guarda o modo de
 // inicialização e o estado anteriores; Desfazer restaura os dois.
 async Task RunServiceTier(){
  if(busy||scanning||resourceScanning||easyRunning)return;
  string tier=ServiceTierKey();
  string[] names;
  try{names=App.ServicesInTier(tier);}catch(Exception e){footer.Text=e.Message;return;}
  if(names.Length==0)return;
  string detail=String.Join("\r\n",names.Select(n=>"• "+n+" — "+App.OptionalServices[n]));
  if(!await Confirm("DESATIVAR "+names.Length+" SERVIÇO(S) DO NÍVEL "+tier.ToUpperInvariant()+
   "\r\n\r\n"+App.ServiceTierWarning(tier)+
   "\r\n\r\n"+detail+
   "\r\n\r\nCada serviço é parado e marcado como Desativado, com o estado anterior salvo no Histórico. "+
   "Serviços com dependentes ativos são recusados e nada é forçado. "+
   "Isto NÃO aumenta FPS por si só: o ganho é menos coisa rodando em segundo plano.\r\n\r\nContinuar?",
   "Desativar nível "+tier))return;
  await Elevated("--services-tier",tier);await RefreshResources();
 }
 async Task ReopenLastClosedApps(){
  if(busy||scanning||resourceScanning||easyRunning)return;
  var record=records.FirstOrDefault(r=>r.Kind=="Apps e RAM"&&r.ClosedApps!=null&&r.ClosedApps.Count>0);
  if(record==null){footer.Text="Nenhum registro recente com apps fechados por este aplicativo.";return;}
  string list=String.Join("\r\n",record.ClosedApps.Select(a=>"• "+a.Name+"  ("+a.Path+")"));
  if(!await Confirm("Reabrir "+record.ClosedApps.Count+" aplicativo(s) fechado(s) em "+record.Time+"?\r\n\r\n"+list+
   "\r\n\r\nCada um é iniciado do zero, sem argumentos e sem restaurar sessão: abas, janelas e trabalho não salvo NÃO voltam. "+
   "Executáveis que saíram do lugar ou deixaram de estar na lista autorizada são ignorados.","Reabrir apps fechados"))return;
  await Elevated("--reopen-apps",record.Id);
 }
 async Task RefreshResources() {
  if(busy||scanning||resourceScanning||easyRunning)return;resourceScanning=true;scan.Enabled=false;SetActions();footer.Text="Medindo CPU/RAM e identificando processos…";
  try {
   processSnapshot=await Task.Run(()=>ResourceMonitor.ScanProcesses());FillProcesses();ShowSample(await Task.Run(()=>ResourceMonitor.Measure()));
   var entries=await Task.Run(()=>App.ScanStartup());startupList.Items.Clear();
   foreach(var entry in entries){var row=new ListViewItem(entry.Name){Tag=entry};row.SubItems.Add(entry.Allowed?"Opcional":"Preservado");row.SubItems.Add(entry.Command);startupList.Items.Add(row);}
   // Uma única ida ao pool para os 41 serviços, em vez de um await por serviço:
   // cada consulta abre um ServiceController e enumera dependentes.
   var serviceStatus=await Task.Run(()=>{
    var map=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
    foreach(string name in App.OptionalServices.Keys)map[name]=App.OptionalServiceStatus(name);
    return map;
   });
   foreach(var pair in serviceStatus)if(serviceLabels.ContainsKey(pair.Key))serviceLabels[pair.Key].Text=pair.Value;
   footer.Text="Medição concluída. CPU é uma amostra; FPS e input lag não foram medidos.";
  }catch(Exception e){footer.Text="Medição incompleta: "+e.Message;}
  finally{resourceScanning=false;scan.Enabled=true;SetActions();}
 }
 void FillProcesses() {
  if(appsList==null)return;var selected=new HashSet<string>(appsList.CheckedItems.Cast<ListViewItem>().Select(r=>((ProcessGroup)r.Tag).Name),StringComparer.OrdinalIgnoreCase);
  appsList.BeginUpdate();appsList.Items.Clear();focusList.Items.Clear();
  var groups=ResourceMonitor.Groups(processSnapshot);string order=processSort==null?"Maior RAM":processSort.SelectedItem as string;
  if(order=="Maior CPU")groups=groups.OrderByDescending(g=>g.CpuPercent).ToList();else if(order=="Mais processos")groups=groups.OrderByDescending(g=>g.Processes.Count).ToList();else if(order=="Nome")groups=groups.OrderBy(g=>g.Name).ToList();
  foreach(var group in groups) {
   foreach(var token in group.Processes.Where(p=>ResourceMonitor.Focusable.Contains(p.Name)&&p.Started>0))focusList.Items.Add(new FocusOption {Token=token});
   if(!showProtected.Checked&&!group.CanClose)continue;
   if(processSearch!=null&&processSearch.Text.Length>0&&group.Name.IndexOf(processSearch.Text,StringComparison.OrdinalIgnoreCase)<0)continue;
   var row=new ListViewItem(group.Name+"  ("+group.Processes.Count+")"){Tag=group};
   row.SubItems.Add(group.Processes.All(p=>p.MemoryKnown)?group.MemoryMB.ToString("0")+" MB*":"Não consultada");row.SubItems.Add(group.Processes.All(p=>p.CpuKnown)?group.CpuPercent.ToString("0.0")+"%":"Não consultada");
   string tier=ResourceMonitor.Tier(group.Name);
   row.SubItems.Add(group.CanClose
    ?"Nível "+(tier=="leve"?"1 · app de usuário":tier=="agressivo"?"2 · sincronização/atualizador":"3 · launcher ou periférico")+" — confirme se não precisa"
    :group.Processes.First(p=>!String.IsNullOrEmpty(p.Protection)).Protection);
   if(!group.CanClose)row.ForeColor=Theme.Muted;appsList.Items.Add(row);row.Checked=group.CanClose&&selected.Contains(group.Name);
  }
  if(focusList.Items.Count>0)focusList.SelectedIndex=0;appsList.EndUpdate();RefreshEasySummary();
 }
 Task<bool> Confirm(string text,string title="Confirmar seleção") {if(EmbeddedInterface.Parent!=IntPtr.Zero)return InlineReview(title,text,true);return Task.FromResult(MessageBox.Show(this,text,title,MessageBoxButtons.YesNo,MessageBoxIcon.Warning,MessageBoxDefaultButton.Button2)==DialogResult.Yes);}
 async Task RunClose(bool force) {
  if(busy||scanning||resourceScanning||easyRunning)return;var selected=CheckedProcesses();if(selected.Count==0){MessageBox.Show("Marque os apps que deseja fechar. Nenhum app foi selecionado automaticamente.",Text);return;}
  string names=String.Join(", ",selected.Select(p=>p.Name).Distinct());
  if(!await Confirm((force?"FORÇAR ENCERRAMENTO: pode perder dados não salvos, abas e chamadas. Não há desfazer.\r\n":"Salve seu trabalho. Solicitar fechamento normal, sem forçar.\r\n")+"\r\n"+names+"\r\n\r\nContinuar?",force?"Confirmar perda potencial de dados":"Liberar RAM fechando apps"))return;
  busy=true;scan.Enabled=false;SetActions();
  try {var pg=new Progress<string>(x=>footer.Text=x);var r=await Task.Run(()=>App.CloseApps(selected,force,x=>((IProgress<string>)pg).Report(x)));
   ShowSample(r.AfterSample);easyResult.Text=r.Message;footer.Text=r.Status+". Consulte os resultados por processo no Histórico.";
  }catch(Exception e){MessageBox.Show(e.Message,Text);}
  finally {busy=false;scan.Enabled=true;RefreshHistory();SetActions();ShowPage("Histórico");}
 }
 async Task RunEasy() {
  if(busy||scanning||resourceScanning||easyRunning||!machine.Windows)return;
  var ids=PickedNative();var selected=CheckedProcesses();
  if(selected.Count>300){MessageBox.Show("Selecione menos apps: o limite é 300 processos por operação.",Text);return;}
  if(ids.Length==0&&selected.Count==0){MessageBox.Show("Escolha um preset/ajuste ou selecione apps para fechar.",Text);return;}
  string settings=String.Join("\r\n",ids.Select(id=>"• "+App.Items.Single(i=>i.Id==id).Name));
  if(!await Confirm("Aplicar estes ajustes com backup:\r\n"+(ids.Length>0?settings:"Nenhum")+"\r\n\r\nSolicitar fechamento normal destes apps:\r\n"+
   (selected.Count>0?String.Join(", ",selected.Select(p=>p.Name).Distinct()):"Nenhum")+
   "\r\n\r\nSalve seu trabalho. Clipes da Game Bar serão afetados se Captura estiver selecionada. Não haverá exclusão de arquivos, desativação de serviços, mudança de rede ou reinício. Continuar?","Otimização máxima revisada"))return;
  easyRunning=true;ExtraEnabled();ResourceSample before=null;
  try {
   busy=true;scan.Enabled=false;SetActions();footer.Text="Medindo antes da otimização…";before=await Task.Run(()=>ResourceMonitor.Measure());busy=false;
   if(ids.Length>0&&!await Elevated("--max",String.Join(",",ids))){easyResult.Text="Ajustes cancelados/falharam. Fechamento de apps não iniciado; consulte o Histórico.";return;}
   busy=true;scan.Enabled=false;SetActions();string actions=ids.Length+" ajuste(s) selecionado(s). Consulte o histórico para os aplicados/já configurados/ignorados.";
   if(selected.Count>0){var pg=new Progress<string>(x=>footer.Text=x);var rec=await Task.Run(()=>App.CloseApps(selected,false,x=>((IProgress<string>)pg).Report(x)));actions+="\r\nApps: "+rec.Status+". "+rec.Steps.Count(x=>x.Status=="encerrado")+" processo(s) encerrado(s).";}
   var after=await Task.Run(()=>ResourceMonitor.Measure());var report=App.SaveComparison(before,after,actions);ShowSample(after);easyResult.Text=report.Message;footer.Text="Concluído. Veja a variação medida e os resultados no Histórico.";
  }catch(Exception e){easyResult.Text="Operação incompleta: "+e.Message+"\r\nConsulte o Histórico antes de repetir. Apps fechados não são reabertos pelo desfazer.";MessageBox.Show(e.Message,Text);}
  finally {busy=false;easyRunning=false;scan.Enabled=true;RefreshHistory();SetActions();ShowPage("Modo fácil");}
 }
 class FocusOption {public ProcessToken Token;public override string ToString(){return Token.Name+" · PID "+Token.Pid;}}
 void BuildMaintenance() {
  var page=Page("Manutenção");var root=Rows(42,48,-1);page.Controls.Add(root);
  root.Controls.Add(Theme.Label("Ferramentas opcionais. Não executadas pelo botão máximo. Leia o efeito antes de confirmar.",10,Theme.Muted),0,0);
  var selector=Combo();selector.Items.AddRange(new object[]{"Inicialização de apps","Serviços opcionais","Limpeza de temporários","Foco: jogo / CAD / render","Windows, rede e discos"});root.Controls.Add(selector,0,1);
  var container=new Panel {Dock=DockStyle.Fill};root.Controls.Add(container,0,2);var sections=new List<Panel>();
  for(int n=0;n<5;n++){var panel=new Panel {Dock=DockStyle.Fill,BackColor=Theme.Bg};container.Controls.Add(panel);sections.Add(panel);}
  selector.SelectedIndexChanged+=(s,e)=>{for(int n=0;n<5;n++)sections[n].Visible=n==selector.SelectedIndex;sections[selector.SelectedIndex].BringToFront();};selector.SelectedIndex=0;
  var start=Rows(78,-1,96);sections[0].Controls.Add(start);start.Controls.Add(Theme.Label("Desative apenas o que não precisa abrir ao entrar no Windows. O app fica instalado.\r\nEscopo: entradas reconhecidas em HKCU Run; não inclui todos os mecanismos de inicialização.\r\nOneDrive/launchers podem deixar de sincronizar/atualizar até você abri-los.",10,Theme.Muted),0,0);
  startupList=CheckList("Entrada","Classificação","Comando (somente leitura)");startupList.Columns[2].Width=550;
  startupList.ItemCheck+=(s,e)=>{if(e.NewValue==CheckState.Checked&&!((StartupEntry)startupList.Items[e.Index].Tag).Allowed)e.NewValue=CheckState.Unchecked;};start.Controls.Add(startupList,0,1);
  var startActions=new FlowLayoutPanel {Dock=DockStyle.Fill};start.Controls.Add(startActions,0,2);
  startActions.Controls.Add(ExtraButton("Atualizar lista",async(s,e)=>await RefreshResources(),false,145));
  startActions.Controls.Add(ExtraButton("Desativar selecionados",async(s,e)=>{
   var chosen=startupList.CheckedItems.Cast<ListViewItem>().Select(r=>(StartupEntry)r.Tag).ToList();if(chosen.Count==0)return;
   if(!await Confirm("Não iniciar no próximo login:\r\n"+String.Join("\r\n",chosen.Select(x=>x.Name))+"\r\n\r\nBackup dos valores será salvo. Apps em execução não serão fechados. Continuar?"))return;
   await Elevated("--startup",App.SaveRequest(new OperationRequest {Startup=chosen}));await RefreshResources();
  },true,218));
  startActions.Controls.Add(ExtraButton("Inicialização do Windows",(s,e)=>OpenLocal("ms-settings:startupapps"),false,220));
  var serviceHeights=new List<float>{104,46};serviceHeights.AddRange(App.OptionalServices.Select(x=>112f));serviceHeights.Add(60);var services=Rows(serviceHeights.ToArray());sections[1].Controls.Add(services);services.Controls.Add(Theme.Label("Estar parado pode ser normal. Desativar permanentemente corta a função, não cria desempenho grátis.\r\nNenhum serviço vem selecionado. Defender, Update, rede, áudio, drivers, SysMain e anticheat ficam fora por construção.\r\nDependentes ativos impedem a alteração. Desfazer restaura o estado salvo de cada um.",10,Theme.Muted),0,0);
  var tierBar=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false,AutoScroll=true};services.Controls.Add(tierBar,0,1);
  serviceTier=Combo();serviceTier.Dock=DockStyle.None;serviceTier.Width=300;serviceTier.Margin=new Padding(0,4,8,0);
  serviceTier.Items.AddRange(new object[]{"Nível 1 · recursos que quase ninguém usa","Nível 2 · + busca, impressão, scanner, local","Nível 3 · + Bluetooth, Xbox, DLNA, sensores"});
  serviceTier.SelectedIndex=0;serviceTier.AccessibleName="Nível de redução de serviços";tierBar.Controls.Add(serviceTier);
  tierBar.Controls.Add(ExtraButton("Marcar nível",(s,e)=>MarkServiceTier(),false,150));
  tierBar.Controls.Add(ExtraButton("Desativar nível inteiro…",async(s,e)=>await RunServiceTier(),false,215));
  int index=2;
  sections[1].AutoScroll=true;services.MinimumSize=new Size(0,210+112*App.OptionalServices.Count);
  foreach(var entry in App.OptionalServices){string name=entry.Key;var card=Box();card.Padding=new Padding(16,8,16,8);services.Controls.Add(card,0,index++);var inside=Rows(25,28,-1);card.Controls.Add(inside);
   string tier=App.ServiceTier(name);
   var check=new ReadableCheckBox {Text=name+"  ·  nível "+(tier=="leve"?"1":tier=="agressivo"?"2":"3")+" — desativar",Dock=DockStyle.Fill,ForeColor=tier=="extremo"?Theme.Amber:Theme.Text,Font=Theme.Font(11,true),AccessibleName="Desativar "+name+", nível "+tier};servicePicks[name]=check;inside.Controls.Add(check,0,0);inside.Controls.Add(Theme.Label(entry.Value,9,Theme.Muted),0,1);var label=Theme.Label("Ainda não consultado",9,Theme.Amber);serviceLabels[name]=label;inside.Controls.Add(label,0,2);
  }
  var serviceActions=new FlowLayoutPanel {Dock=DockStyle.Fill};services.Controls.Add(serviceActions,0,index);serviceActions.Controls.Add(ExtraButton("Desativar serviços marcados",async(s,e)=>{
   var selected=servicePicks.Where(x=>x.Value.Checked).Select(x=>x.Key).ToArray();if(selected.Length==0)return;
   if(!await Confirm("Desativação persistente até Desfazer:\r\n\r\n"+String.Join("\r\n",selected.Select(n=>n+": "+App.OptionalServices[n]))+"\r\n\r\nConfirmar perda temporária dessas funções?"))return;
   await Elevated("--services",String.Join(",",selected));await RefreshResources();
  },true,260));serviceActions.Controls.Add(ExtraButton("Ver histórico / desfazer",(s,e)=>ShowPage("Histórico"),false,215));
  serviceActions.Controls.Add(ExtraButton("Marcar tudo do nível",(s,e)=>MarkServiceTier(),false,185));
  var clean=Rows(103,-1,54);sections[2].Controls.Add(clean);clean.Controls.Add(Theme.Label("Somente .tmp/.temp em LocalAppData\\Temp, sem uso/alteração/criação há mais de 7 dias.\r\nAnálise limitada a 2.000 candidatos e 10 segundos. Links/junções, arquivos recentes e em uso são ignorados.\r\nExclusão PERMANENTE, sem desfazer. Não limpa Prefetch, shaders, Downloads, cookies ou backups de projetos.",10,Theme.Muted),0,0);
  var tmp=Box();clean.Controls.Add(tmp,0,1);tempDetail=Theme.ReadBox();tempDetail.Text="Primeiro analise. Nenhum arquivo foi selecionado.";tmp.Controls.Add(tempDetail);var cleanActions=new FlowLayoutPanel {Dock=DockStyle.Fill};clean.Controls.Add(cleanActions,0,2);
  cleanActions.Controls.Add(ExtraButton("Analisar temporários",async(s,e)=>await AnalyzeTemps(),false,205));cleanActions.Controls.Add(ExtraButton("Excluir arquivos listados…",async(s,e)=>await RemoveTemps(),true,248));
  var focus=Rows(96,60,95,-1);sections[3].Controls.Add(focus);focus.Controls.Add(Theme.Label("Foco opcional: AboveNormal, nunca Realtime/High. Somente o jogo/app explicitamente selecionado.\r\nAbra o jogo ou CAD e atualize a lista. Alguns anticheats recusam a mudança; ela não será forçada.\r\nVale até encerrar a instância do programa ou desfazer. Afinidade, núcleos e clocks não são alterados.",10,Theme.Muted),0,0);
  focusList=Combo();focus.Controls.Add(focusList,0,1);var focusActions=new FlowLayoutPanel {Dock=DockStyle.Fill};focus.Controls.Add(focusActions,0,2);
  focusActions.Controls.Add(ExtraButton("Atualizar jogos / apps",async(s,e)=>await RefreshResources(),false,203));focusActions.Controls.Add(ExtraButton("Aplicar foco opcional",async(s,e)=>{
   var option=focusList.SelectedItem as FocusOption;if(option==null){MessageBox.Show("Abra um jogo/app reconhecido e atualize a lista.",Text);return;}
   if(await Confirm("Alterar somente "+option+" de Normal para AboveNormal?\r\n\r\nNão há garantia de ganho. Se piorar, use Desfazer no Histórico."))await Elevated("--priority",App.SaveRequest(new OperationRequest {Target=option.Token}));
  },true,209));focusActions.Controls.Add(ExtraButton("Desfazer foco no histórico",(s,e)=>ShowPage("Histórico"),false,222));
  focus.Controls.Add(Theme.Label("Lista reconhecida inclui CS2, Fortnite, Roblox, Valorant, AutoCAD, Revit, SketchUp, Lumion e Blender.\r\nNão há loop que muda repetidamente a prioridade nem detecção por CPU acumulada.\r\nMinério/malware não é detectado por prioridade ou nome; use a Segurança do Windows.",10,Theme.Muted),0,3);
  var windows=Rows(72,210,-1);sections[4].Controls.Add(windows);windows.Controls.Add(Theme.Label("Atalhos abrem ferramentas do Windows; o app não registra essas tarefas como executadas.\r\nNão é preciso usar tudo. Reparos e otimização de disco não devem concorrer com seu jogo.",10,Theme.Muted),0,0);
  var nativeActions=new FlowLayoutPanel {Dock=DockStyle.Fill,AutoScroll=true};windows.Controls.Add(nativeActions,0,1);
  nativeActions.Controls.Add(ExtraButton("Otimizar unidades",(s,e)=>OpenSystem("dfrgui.exe",""),false,215));
  nativeActions.Controls.Add(ExtraButton("Armazenamento",(s,e)=>OpenLocal("ms-settings:storagesense"),false,215));
  nativeActions.Controls.Add(ExtraButton("Apps instalados",(s,e)=>OpenLocal("ms-settings:appsfeatures"),false,215));
  nativeActions.Controls.Add(ExtraButton("Segurança do Windows",(s,e)=>OpenLocal("windowsdefender:"),false,215));
  nativeActions.Controls.Add(ExtraButton("Privacidade / diagnóstico",(s,e)=>OpenLocal("ms-settings:privacy-feedback"),false,215));
  nativeActions.Controls.Add(ExtraButton("Rede do Windows",(s,e)=>OpenLocal("ms-settings:network-status"),false,215));
  nativeActions.Controls.Add(ExtraButton("Guia oficial SFC / DISM",(s,e)=>OpenUrl("https://support.microsoft.com/en-us/windows/using-system-file-checker-in-windows-365e0031-36b1-6031-f804-8fd86e0ef4ca"),false,215));
  nativeActions.Controls.Add(ExtraButton("Ler adaptadores de rede",(s,e)=>ReadNetwork(),false,215));
  // O texto que ficava aqui explicava onde estavam os 14 .bat recebidos. Isso é
  // informação de desenvolvimento, não recurso: saiu da tela do usuário. O que
  // importa para quem usa é o que o programa NÃO faz, e isso continua dito.
  windows.Controls.Add(Theme.Label("Nenhuma ação apaga backups, força troca de DNS, desativa atualizações, trava a CPU em 100% ou reinicia o PC sem aviso.\r\nNenhum driver, antivírus ou componente de segurança é instalado, removido ou desativado automaticamente.",9.5f,Theme.Muted));
 }
 async Task AnalyzeTemps() {
  if(busy||scanning||resourceScanning)return;busy=true;scan.Enabled=false;SetActions();
  try{tempSnapshot=await Task.Run(()=>TempCleaner.Scan());tempDetail.Text=tempSnapshot.Files.Count+" candidato(s), "+(tempSnapshot.Files.Sum(f=>f.Bytes)/1048576.0).ToString("0.0")+" MB lógicos. "+tempSnapshot.Skipped+" ignorado(s)."+(tempSnapshot.Truncated?"\r\nAnálise limitada: nem todos os arquivos foram lidos.":"")+"\r\n\r\n"+String.Join("\r\n",tempSnapshot.Files.Select(f=>f.Path+" — "+f.Bytes+" bytes"));}
  catch(Exception e){tempSnapshot=null;tempDetail.Text=e.Message;}
  finally{busy=false;scan.Enabled=true;SetActions();}
 }
 async Task RemoveTemps() {
  if(busy||scanning||resourceScanning||tempSnapshot==null||tempSnapshot.Files.Count==0)return;var scanResult=tempSnapshot;
  if(!await Confirm("Excluir PERMANENTEMENTE os "+scanResult.Files.Count+" arquivos listados em "+scanResult.Root+"?\r\n\r\nSomente .tmp/.temp antigos. Arquivos que mudaram/em uso serão ignorados. Sem lixeira e SEM DESFAZER. Continuar?","Exclusão permanente de temporários"))return;
  busy=true;scan.Enabled=false;SetActions();
  try{var r=await Task.Run(()=>App.CleanTemps(scanResult));tempDetail.Text=r.Message+"\r\n\r\n"+String.Join("\r\n",r.Steps.Select(s=>s.Name+" — "+s.Status+": "+s.Message));tempSnapshot=null;}
  catch(Exception e){MessageBox.Show(e.Message,Text);tempSnapshot=null;}
  finally{busy=false;scan.Enabled=true;RefreshHistory();SetActions();}
 }
 void ReadNetwork() {
  var text=new StringBuilder("ADAPTADORES — somente leitura\r\nVelocidade do link não equivale à velocidade da internet. Nenhum DNS ou parâmetro TCP alterado.\r\n\r\n");
  try{foreach(var nic in NetworkInterface.GetAllNetworkInterfaces()) {text.AppendLine(nic.Name+" — "+nic.OperationalStatus+" — "+(nic.Speed/1000000.0).ToString("0")+" Mbps de link");foreach(var dns in nic.GetIPProperties().DnsAddresses)text.AppendLine("DNS: "+dns);text.AppendLine();}}catch(Exception e){text.AppendLine(e.Message);}TextDialog("Diagnóstico de rede",text.ToString());
 }
 void BuildScriptReview() {
  var page=Page(ScriptAuditPage);var root=Rows(66,-1,214,51);page.Controls.Add(root);root.Controls.Add(Theme.Label("Todos os 14 arquivos estão reunidos e revisados. Originais preservados como texto, sem execução.\r\nIntegração não significa executar cada comando: veja o que foi reaproveitado, corrigido ou excluído.",10,Theme.Muted),0,0);
  batList=CheckList("Arquivo recebido","Parecer","Integração no app");batList.CheckBoxes=false;batList.Columns[0].Width=268;batList.Columns[1].Width=157;batList.Columns[2].Width=430;root.Controls.Add(batList,0,1);
  foreach(var r in ImportedScripts.All){var row=new ListViewItem(r.Name){Tag=r};row.SubItems.Add(r.Status);row.SubItems.Add(r.Integration);batList.Items.Add(row);}
  var details=Box();details.Margin=new Padding(0,12,0,10);root.Controls.Add(details,0,2);batDetail=Theme.ReadBox();details.Controls.Add(batDetail);
  batList.SelectedIndexChanged+=(s,e)=>{if(batList.SelectedItems.Count==0)return;var r=(ScriptReview)batList.SelectedItems[0].Tag;batDetail.Text=r.Name+" — "+r.Status+"\r\nNO APP: "+r.Integration+"\r\n\r\n"+String.Join("\r\n\r\n",r.Findings);};
  var actions=new FlowLayoutPanel {Dock=DockStyle.Fill};root.Controls.Add(actions,0,3);var original=Theme.Button("Ver conteúdo original");original.Width=220;original.Click+=(s,e)=>{if(batList.SelectedItems.Count==0)return;var r=(ScriptReview)batList.SelectedItems[0].Tag;TextDialog("Somente leitura — "+r.Name,r.Text+"\r\n\r\nSHA-256: "+r.Hash);};actions.Controls.Add(original);
  var report=Theme.Button("Abrir revisão completa");report.Width=220;report.Click+=(s,e)=>OpenLocal(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"REVISAO_14_BATS.html"));actions.Controls.Add(report);
  if(batList.Items.Count>0)batList.Items[0].Selected=true;
 }
}

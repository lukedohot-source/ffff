﻿using System;
using System.Linq;
using System.Collections.Generic;

static partial class App {
 internal static bool ActionNeedsAdmin(string action,string payload){
  if(action=="--diagnostic-command")return CommandTools.Resolve(payload).Administrator;
  if(action=="--execute-profile"||action=="--silent-execute")return ExecutionControl.NeedsAdmin(payload);
  if(action=="--extreme")return LiquidProtocol.NeedsAdmin(ExtremeProfile.Resolve(payload));
  if(action=="--restore-selection")return LiquidProtocol.NeedsAdmin(RestoreSelectionItems(payload));
  if(action=="--apply-custom")return LiquidProtocol.NeedsAdmin(ExtraSettings.Manual(payload));
  if(action=="--remove-apps"){ValidateRemovalPayload(payload);return false;}
  if(action=="--apply-many"||action=="--max")return LiquidProtocol.NeedsAdmin(LiquidProtocol.Resolve(payload));
  if(action=="--apply"){
   var item=Items.FirstOrDefault(i=>i.Id==CatalogIds.Canonical(payload));
   return item==null||!item.Native||LiquidProtocol.NeedsAdmin(new[]{item});
  }
  if(action=="--undo"||action=="--undo-last"){
   var record=action=="--undo-last"?History().FirstOrDefault(CanUndo):Json.Deserialize<Record>(AtomicStore.Read(RecordPath(payload)));
   return record==null||(record.Values??new List<SavedValue>()).Any(v=>RequiresAdmin(v.Before))||!String.IsNullOrEmpty(record.NewPlan)||(record.ServiceValues!=null&&record.ServiceValues.Count>0)||record.PriorityValue!=null||(record.NativeValues??new List<NativeSaved>()).Any(v=>v.Code==ExtraSettings.Compression);
  }
  return true;
 }
 internal static string PreflightItem(Item item,Machine machine){
  try{
   string reason=Compatibility(item,machine);if(reason!=null)return reason;
   // Capture failures skip this item; write permission is checked per value by
   // ApplyTransaction, retaining the original request and applying other values.
   foreach(var op in item.Operations??new RegOp[0])Capture(op);
   foreach(var code in CodesFor(item))NativeSettings.Read(code);
   if(item.ActionCode=="power"){
#if TESTS
    if(TestPlanGet==null)
#endif
    if(!new System.Security.Principal.WindowsPrincipal(System.Security.Principal.WindowsIdentity.GetCurrent()).IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator))return "Plano de energia exige permissão administrativa; ignorado neste perfil.";
    ActivePlan();
   }
   return null;
  }catch(Exception e){return e.Message;}
 }
 // Each child uses the existing transaction and rollback. Child snapshots are
 // embedded in the durable parent BEFORE each write; no untracked child files.
 internal static void ApplyIsolated(List<Item> chosen,string name,string[] aliases,List<StepResult> skipped){
  if(chosen.Count==0)throw new Exception("Nenhuma opção foi selecionada.");
  UniqueOperations(chosen);
  var parent=NewRecord(name,chosen[0].Id,"Perfil");parent.Schema=5;parent.IdMigrations=aliases;
  parent.ItemIds=chosen.Select(i=>i.Id).ToArray();parent.IsolatedSteps=new List<Record>();parent.Evidence=new List<SettingEvidence>();
  var exclusions=skipped??new List<StepResult>();var ready=new List<Item>();var machine=ScanHardware();
  foreach(var item in chosen){var why=PreflightItem(item,machine);if(why==null)ready.Add(item);else exclusions.Add(new StepResult{Id=item.Id,Name=item.ReviewTitle,Status="ignorado",Message=why});}
  parent.Steps=exclusions.ToList();Save(parent);
  Action<Record> persist=child=>{
   if(child!=null&&child.Platform==null)child.Platform=ExecutionPlatform;
   var recoverable=parent.IsolatedSteps.Where(r=>r.ChangesStarted&&r.Status!="desfeito"&&r.Status!="falhou e foi desfeito").ToList();
   parent.Attachments=parent.IsolatedSteps.SelectMany(r=>r.Attachments??new List<BackupAttachment>()).ToList();
   parent.Values=recoverable.SelectMany(r=>r.Values??new List<SavedValue>()).ToList();
   parent.NativeValues=recoverable.SelectMany(r=>r.NativeValues??new List<NativeSaved>()).ToList();
   var power=recoverable.FirstOrDefault(r=>!String.IsNullOrEmpty(r.NewPlan));
   parent.PreviousPlan=power==null?null:power.PreviousPlan;parent.NewPlan=power==null?null:power.NewPlan;parent.PlanReused=true;
   parent.ChangesStarted=recoverable.Count>0;
   parent.Evidence=parent.IsolatedSteps.SelectMany(r=>r.Evidence??new List<SettingEvidence>()).ToList();
   parent.Steps=exclusions.Concat(parent.IsolatedSteps.SelectMany(r=>r.Steps)).ToList();
   Save(parent);
  };
  parent.Status="aplicando";Save(parent);
  foreach(var item in ready){
   if(ExecutionControl.Cancelled){parent.ExecutionCancelled=true;foreach(var pendingItem in ready.SkipWhile(i=>i.Id!=item.Id))exclusions.Add(new StepResult{Id=pendingItem.Id,Name=pendingItem.ReviewTitle,Status="ignorado",Message="Cancelado ou limite de tempo atingido antes desta ação; nenhuma gravação iniciada."});persist(null);break;}
   WriteProgress(ready.Count==0?0:parent.IsolatedSteps.Count*100/ready.Count,"Executando item",parent.IsolatedSteps.Count+" / "+ready.Count+" concluídos · "+item.ReviewTitle);
   var child=NewRecord(item.ReviewTitle,item.Id,"Nativo");parent.IsolatedSteps.Add(child);
   try{ApplyTransaction(new[]{item},"Nativo",item.ReviewTitle,null,null,child,persist);}
   catch(Exception e){
    // A failed rollback is recoverable through the parent, too. Other successful
    // children are never rolled back because this child failed.
    var step=child.Steps.FirstOrDefault(x=>x.Id==item.Id);
    if(step==null){step=new StepResult{Id=item.Id,Name=item.ReviewTitle};child.Steps.Add(step);}
    step.Status=child.Status=="falha na restauração"?"restauração pendente":"ignorado";
    step.Message=child.Status=="falhou e foi desfeito"?"Etapa revertida individualmente. "+e.Message:e.Message;
   }
   persist(child); // If durable storage fails, stop; never start another write.
  }
  bool pending=parent.IsolatedSteps.Any(r=>r.Status=="falha na restauração");
  parent.Status=pending?"falha na restauração":parent.ChangesStarted?"aplicado":"sem alterações";
  parent.Message=parent.IsolatedSteps.Count(r=>r.Status=="aplicado")+" etapa(s) aplicada(s); "+parent.Steps.Count(s=>s.Status=="ignorado")+" ignorada(s). Desfazer restaura os valores anteriores deste conjunto.";
  if(pending)parent.Message+=" Uma etapa precisa de nova tentativa de restauração pelo Histórico.";
  Save(parent);WriteProgress(100,parent.Status,parent.Message);
 }
}

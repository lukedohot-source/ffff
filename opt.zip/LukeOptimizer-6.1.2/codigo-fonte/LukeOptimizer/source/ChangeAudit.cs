using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;

public class SettingEvidence {
 public string ItemId,Name,Kind,Target,Code,Before,Requested,Observed,BeforeTime,ObservedTime,Outcome,Error;
 public RegOp Registry;
 public bool BeforeKnown,ObservedKnown,WriteAttempted,ChangedConfirmed,PermissionSkipped;
 public string Restored,RestoreTime,RestoreOutcome;
 public bool RestoredKnown;
}
static class ChangeAudit {
 internal static string Now(){return DateTime.UtcNow.ToString("o");}
 internal static string Value(RegOp r){return r.Delete?"Ausente":r.Kind+" = "+r.Data;}
 internal static string Error(Exception e){return e.GetType().Name+" (0x"+e.HResult.ToString("X8")+"): "+e.Message;}
 internal static string Summary(Record r){
  if(r.Removals!=null)return r.Removals.Count(x=>x.Status=="Removido e conferido")+" app(s) removido(s) com ausência confirmada; "+r.Removals.Count(x=>!x.AfterKnown)+" leitura(s) não confirmada(s).";
  if(r.Evidence==null)return "Registro antigo: não contém leituras detalhadas de antes/depois.";
  return r.Evidence.Count(x=>x.ChangedConfirmed)+" mudança(s) confirmada(s) ao aplicar; "+r.Evidence.Count(x=>x.Outcome=="Já estava assim")+" já estava(m) assim; "+r.Evidence.Count(x=>x.RestoreOutcome=="Restaurado e conferido")+" restaurada(s).";
 }
 internal static SettingEvidence Add(Record r,Item i,string kind,string target,string requested,RegOp registry=null,string code=null){
  var e=new SettingEvidence{ItemId=i.Id,Name=i.ReviewTitle,Kind=kind,Target=target,Requested=requested,Registry=registry,Code=code,Outcome="Ainda não executado"};r.Evidence.Add(e);return e;
 }
 internal static string Read(SettingEvidence e){return e.Registry!=null?Value(App.Capture(e.Registry).Before):e.Kind=="Plano de energia"?App.ActivePlan():NativeSettings.Read(e.Code);}
 internal static void Before(SettingEvidence e,string value){e.Before=value;e.BeforeKnown=true;e.BeforeTime=Now();}
 internal static void Readback(Record r,bool restore=false){
  if(r.Evidence==null)return;
  foreach(var e in r.Evidence){
   try{
    var actual=Read(e);var time=Now();
    if(restore){e.Restored=actual;e.RestoredKnown=true;e.RestoreTime=time;e.RestoreOutcome=!e.BeforeKnown?"Antes desconhecido":actual==e.Before?"Restaurado e conferido":"Diferente do valor anterior";continue;}
    e.Observed=actual;e.ObservedKnown=true;e.ObservedTime=time;e.ChangedConfirmed=e.WriteAttempted&&e.BeforeKnown&&actual!=e.Before&&actual==e.Requested;
    e.Outcome=e.PermissionSkipped?"Ignorado por falta de permissão":!e.BeforeKnown?"Antes desconhecido":e.ChangedConfirmed?"Mudou e foi conferido":actual==e.Before&&actual==e.Requested?"Já estava assim":actual==e.Before?"Não mudou":actual==e.Requested?"Valor presente; gravação pelo app não comprovada":"Leitura diferente do solicitado";
   }catch(Exception ex){
    if(restore){e.RestoredKnown=false;e.RestoreTime=Now();e.RestoreOutcome="Não foi possível conferir: "+Error(ex);}
    else{e.ObservedKnown=false;e.ChangedConfirmed=false;e.ObservedTime=Now();e.Outcome="Leitura indisponível";e.Error=Error(ex);}
   }
  }
 }
 internal static string Report(Record r){
  var b=new StringBuilder("LUKE OPTIMIZER — LOG DE CONFIGURAÇÕES\r\n");
  b.AppendLine(r.Name).AppendLine("ID: "+r.Id).AppendLine("Data (UTC): "+r.Time).AppendLine("Resultado: "+r.Status).AppendLine(r.Message).AppendLine(Summary(r));
  b.AppendLine("As leituras comprovam valores armazenados/API; não medem ganho de FPS. Ausente significa que o valor não existia; não significa zero.");
  foreach(var migration in r.IdMigrations??new string[0])b.AppendLine("Compatibilidade de ID: "+migration);
  if(!String.IsNullOrEmpty(r.FailureStage))b.AppendLine("Etapa da falha: "+r.FailureStage).AppendLine("Diagnóstico: "+r.FailureDetail);
  if(r.Removals!=null){
   b.AppendLine("Appx: conta atual. WinGet pode abranger o PC. Remover pode apagar dados do app; não há desfazer automático.");
   foreach(var e in r.Removals)b.AppendLine().AppendLine(e.Name+" — "+e.Status).AppendLine("Método: "+e.Method+" | "+e.Scope).AppendLine("Antes: "+(e.Before??"Não lido")+" | UTC: "+e.Started).AppendLine("Solicitado: desinstalar somente o app escolhido").AppendLine("Lido depois: "+(e.AfterKnown?e.After:"Não confirmado")+" | UTC: "+e.Checked).AppendLine("Tentativa de remoção: "+(e.Attempted?"Sim":"Não")).AppendLine("Diagnóstico: "+e.Error);
  }else if(r.Evidence==null){
   b.AppendLine("Os valores 'solicitados' abaixo são do backup antigo. Não são uma leitura posterior. Use Conferir agora para consultar o estado atual.");
   foreach(var v in r.Values??new List<SavedValue>())b.AppendLine(v.After.Hive+"\\"+v.After.Key+" | "+v.After.Name).AppendLine("Antes: "+Value(v.Before)).AppendLine("Solicitado: "+Value(v.After));
   foreach(var v in r.NativeValues??new List<NativeSaved>())b.AppendLine("API "+v.Code+" | Antes: "+v.Before+" | Solicitado: "+v.After);
  }else foreach(var e in r.Evidence){
   b.AppendLine().AppendLine(e.Name+" — "+e.Outcome).AppendLine(e.Kind+": "+e.Target);
   b.AppendLine("Antes: "+(e.BeforeKnown?e.Before:"Não lido")+" | UTC: "+e.BeforeTime).AppendLine("Solicitado: "+e.Requested);
   b.AppendLine("Lido depois: "+(e.ObservedKnown?e.Observed:"Não confirmado")+" | UTC: "+e.ObservedTime).AppendLine("Tentativa de gravação: "+(e.WriteAttempted?"Sim":"Não"));
   if(!String.IsNullOrEmpty(e.Error))b.AppendLine("Erro: "+e.Error);
   if(e.RestoreTime!=null)b.AppendLine("Após restaurar: "+(e.RestoredKnown?e.Restored:"Não confirmado")+" | "+e.RestoreOutcome+" | UTC: "+e.RestoreTime);
  }
  foreach(var step in r.Steps??new List<StepResult>())b.AppendLine().AppendLine(step.Name+": "+step.Status).AppendLine(step.Message);
  return b.ToString();
 }
 internal static string VerifyCurrent(Record r){
  if(r.UserSid!=App.Sid)throw new Exception("Este registro pertence a outra conta do Windows.");
  if(r.Removals!=null)return AppRemoval.Verify(r);
  var entries=r.Evidence??new List<SettingEvidence>();
  if(r.Evidence==null){
   foreach(var v in r.Values??new List<SavedValue>())entries.Add(new SettingEvidence{Kind="Registro",Target=v.After.Hive+"\\"+v.After.Key+" | "+v.After.Name,Registry=v.After,BeforeKnown=true,Before=Value(v.Before),Requested=Value(v.After)});
   foreach(var v in r.NativeValues??new List<NativeSaved>())entries.Add(new SettingEvidence{Kind="API do Windows",Target=v.Code,Code=v.Code,BeforeKnown=true,Before=v.Before,Requested=v.After});
   if(!String.IsNullOrEmpty(r.NewPlan))entries.Add(new SettingEvidence{Kind="Plano de energia",Target="Plano ativo",BeforeKnown=true,Before=r.PreviousPlan,Requested=r.NewPlan});
  }
  var b=new StringBuilder("CONFERÊNCIA ATUAL — "+Now()+" UTC\r\n"+r.Name+"\r\n");int matches=0,previous=0,other=0,unknown=0;
  b.AppendLine("Esta leitura é separada do log da aplicação. Não altera configurações nem reescreve o resultado antigo.");
  foreach(var e in entries){
   b.AppendLine().AppendLine(e.Target);
   try{string actual=Read(e);string status;if(actual==e.Requested){matches++;status="Coincide com o solicitado";}else if(e.BeforeKnown&&actual==e.Before){previous++;status="Está no valor anterior";}else{other++;status="Diferente do solicitado e do anterior";}
    b.AppendLine("Atual: "+actual).AppendLine("Solicitado: "+e.Requested).AppendLine(status);
   }catch(Exception ex){unknown++;b.AppendLine("Não foi possível ler: "+Error(ex));}
  }
  if(entries.Count==0)b.AppendLine("Esta operação não tem valores de Registro/API/plano disponíveis para conferência automática.");
  return matches+" coincide(m); "+previous+" no valor anterior; "+other+" diferente(s); "+unknown+" leitura(s) indisponível(is).\r\n\r\n"+b;
 }
 internal static string Export(Record r){
  App.RecordPath(r.Id);var folder=Path.Combine(App.DataRoot,"logs");Directory.CreateDirectory(folder);var path=Path.Combine(folder,r.Id+".txt");AtomicStore.Write(path,Report(r));return path;
 }
}

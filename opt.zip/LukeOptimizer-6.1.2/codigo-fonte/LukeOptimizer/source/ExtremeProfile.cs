using System;
using System.Linq;
using System.Collections.Generic;

// The automatic profile is a fixed list of existing transactional adapters.
// The client cannot turn an arbitrary command or catalog entry into a profile action.
class ExtremeGroup {
 internal string Id,Title,Effect,Tradeoff;internal bool Selected;internal string[] Items;
 // Selected NÃO é o que o grupo pede: é o que ele pode cumprir. Um grupo sem nenhuma
 // opção elegível vinha marcado e exportado como "1" pelo protocolo, prometendo um efeito
 // que ExtremeIds() jamais produzia — a lista de itens era vazia. Marcar aqui, e não em
 // cada chamador, torna impossível reintroduzir a promessa vazia.
 internal ExtremeGroup(string id,string title,string effect,string tradeoff,bool selected,params string[] items){
  Id=id;Title=title;Effect=effect;Tradeoff=tradeoff;Items=items??new string[0];Selected=selected&&Items.Length>0;
 }
 internal bool Empty(){return Items.Length==0;}
}
static class ExtremeProfile {
 // Os grupos são constantes. Groups() era chamado uma vez por opção dentro de
 // OptionInfo.For, alocando 7 grupos e 7 arrays a cada chamada.
 static ExtremeGroup[] groups;
 static readonly object GroupGate=new object();
 internal static ExtremeGroup[] Groups(){
  lock(GroupGate){if(groups==null)groups=Build();return groups;}
 }
 static ExtremeGroup[] Build(){return new[]{
  new ExtremeGroup("games","Priorizar o jogo","Ativa o Modo Jogo e desliga a gravação de clipes em segundo plano.","A Game Bar deixa de gravar clipes em segundo plano. Confira o resultado no seu jogo.",true,"native-gamemode","native-capture"),
  // SEM ITENS, e o texto passa a dizer isso. Tudo que caberia aqui é política do Windows
  // (fora do botão automático por construção: IsReviewed recusa Software\Policies) ou é
  // experimental (pack-e8ea680d9741, execução global em segundo plano, que depende de
  // teste A/B). O grupo continua existindo para explicar a ausência — some da lista de
  // aplicáveis porque Selected agora exige itens, e não porque foi escondido.
  new ExtremeGroup("background","Menos apps em segundo plano","NENHUMA opção entra aqui no botão automático. Reduzir apps em segundo plano no Windows depende de política protegida do Registro ou da chave global de execução em segundo plano, que é experimental.","Para fazer isso, use Apps e RAM (fechar apps escolhidos por você) ou marque a opção global manualmente em Otimizações, ciente de que ela exige teste antes/depois.",false),
  new ExtremeGroup("windows","Menos atividade do Windows","NENHUMA opção entra aqui no botão automático. Reduzir sugestões e conteúdo promocional do Windows é ajuste de privacidade e personalização, não de desempenho, e não deve viajar escondido dentro de um perfil de performance.","Escolha item a item em Otimizações. Nada aqui promete FPS.",false),
  new ExtremeGroup("visual","Interface mais leve","Reduz animações, transparência, espiada na área de trabalho e espera dos menus.","O Windows fica visualmente mais simples. Isso melhora a sensação de resposta da interface; não mede FPS do jogo.",true,"native-window","native-effects","native-menu","native-transparency","pack-d1b3e7ae9f70","pack-3d76b7e8529c"),
  // Serviços NÃO são itens de catálogo: quem os altera é App.DisableOptionalServices, com
  // lista protegida, níveis e dependências próprias. Este grupo nunca pôde ter itens — a
  // promessa "impede Fax, mapas offline e DLNA de iniciarem" não era cumprida por ninguém.
  new ExtremeGroup("services","Serviços que você pode dispensar","NENHUMA opção entra aqui no botão automático. Serviços não passam por este perfil: eles têm tela própria, com 41 serviços opcionais em três níveis, 54 protegidos que nunca são tocados e conferência de dependências antes de mudar qualquer coisa.","Use Manutenção › Serviços e escolha o nível. Serviço em execução só muda de fato depois de reiniciar.",false),
  new ExtremeGroup("power","Energia para desempenho","Seleciona Alto desempenho em desktops compatíveis ligados à tomada.","Opcional: aumenta consumo e calor. A vantagem depende do hardware e do jogo. O plano anterior fica salvo para desfazer.",false,"native-power"),
  new ExtremeGroup("visual54","Reduzir redesenho de janelas","Arrasta apenas o contorno das janelas.","Preferência visual opcional; sem promessa de FPS.",false,"native-dragoutline")
 };}
 internal static string Rows(){return String.Concat(Groups().Select(g=>LiquidProtocol.Row("extreme",g.Id,g.Title,g.Effect,g.Tradeoff,g.Selected?"1":"0",String.Join(",",g.Items))));}
 internal static bool IsReviewed(Item item){
  return item.Native&&item.ManualAllowed&&String.IsNullOrEmpty(item.Blocked)
   &&!(item.Operations??new RegOp[0]).Any(o=>App.IsPolicy(o)||o.Hive!="HKEY_CURRENT_USER")
   &&item.ActionCode!=ExtraSettings.Compression;
 }
 internal static List<Item> Resolve(string payload){
  var items=LiquidProtocol.Resolve(payload);
  if(items.Any(i=>!IsReviewed(i)))throw new Exception("A seleção contém uma opção manual, protegida ou não revisada.");
  return items;
 }
 internal static void Apply(string payload){
  var chosen=Resolve(payload);App.ApplyIsolated(chosen,"Otimização extrema",CatalogIds.Migrations(payload),Skipped(chosen));
 }
 internal static List<StepResult> Skipped(List<Item> chosen){
  var ids=new HashSet<string>(chosen.Select(i=>i.Id));var result=new List<StepResult>();var machine=App.ScanHardware();
  foreach(var item in CatalogIds.NativeItems().Where(i=>!ids.Contains(i.Id))){var info=OptionInfo.For(item);string reason=info.AutomaticReason;if(info.Automatic){var current=App.Observe(item,machine);reason=current.State=="Não compatível"||current.State=="Falha na leitura"?current.Detail:"Grupo desmarcado na revisão.";}result.Add(new StepResult{Id=item.Id,Name=item.ReviewTitle,Status="ignorado",Message=reason});}
  foreach(var entry in PerformanceLibrary.Load().Where(e=>e.Action!="native"))result.Add(new StepResult{Id=entry.Id,Name=entry.Title,Status="ignorado",Message="Manual, diagnóstico ou arquivo de referência. Não executado pelo Fazer tudo."});
  return result;
 }
}

using System;
using System.Linq;
using System.Collections.Generic;

// The automatic profile is a fixed list of existing transactional adapters.
// The client cannot turn an arbitrary command or catalog entry into a profile action.
class ExtremeGroup {
 internal string Id,Title,Effect,Tradeoff;internal bool Selected;internal string[] Items;
 internal ExtremeGroup(string id,string title,string effect,string tradeoff,bool selected,params string[] items){Id=id;Title=title;Effect=effect;Tradeoff=tradeoff;Selected=selected;Items=items;}
}
static class ExtremeProfile {
 internal static ExtremeGroup[] Groups(){return new[]{
  new ExtremeGroup("games","Priorizar o jogo","Ativa o Modo Jogo e desliga a gravação de clipes em segundo plano.","A Game Bar deixa de gravar clipes em segundo plano. Confira o resultado no seu jogo.",true,"native-gamemode","native-capture"),
  new ExtremeGroup("background","Menos apps em segundo plano","Reduz somente ajustes locais já testados do perfil; políticas de navegador, Widgets e Notícias ficam fora do botão automático.","Algumas opções podem exigir reabrir o aplicativo. Políticas do Windows são manuais porque podem ser bloqueadas por permissões, edição ou organização.",false),
  new ExtremeGroup("windows","Menos atividade do Windows","Reduz sugestões locais sem criar políticas protegidas no Registro.","Dicas e conteúdo promocional podem diminuir. Não promete ganho de FPS e pode exigir nova sessão.",true),
  new ExtremeGroup("visual","Interface mais leve","Reduz animações, transparência, espiada na área de trabalho e espera dos menus.","O Windows fica visualmente mais simples. Isso melhora a sensação de resposta da interface; não mede FPS do jogo.",true,"native-window","native-effects","native-menu","native-transparency","pack-d1b3e7ae9f70","pack-3d76b7e8529c"),
  new ExtremeGroup("services","Serviços que você pode dispensar","Impede Fax, mapas offline e compartilhamento de mídia de iniciarem após reiniciar o PC.","Fax, atualização de mapas offline e compartilhamento de mídia DLNA ficam indisponíveis. Desmarque este grupo se usa esses recursos. Serviços em execução só mudam após reiniciar.",false),
  new ExtremeGroup("power","Energia para desempenho","Seleciona Alto desempenho em desktops compatíveis ligados à tomada.","Opcional: aumenta consumo e calor. A vantagem depende do hardware e do jogo. O plano anterior fica salvo para desfazer.",false,"native-power"),
  new ExtremeGroup("visual54","Reduzir redesenho de janelas","Arrasta apenas o contorno das janelas.","Preferência visual opcional; sem promessa de FPS.",false,"native-dragoutline")
 };}
 internal static string Rows(){return String.Concat(Groups().Select(g=>LiquidProtocol.Row("extreme",g.Id,g.Title,g.Effect,g.Tradeoff,g.Selected?"1":"0",String.Join(",",g.Items))));}
 internal static bool IsReviewed(Item item){
  return item.Native&&item.ManualAllowed&&String.IsNullOrEmpty(item.Blocked)
   &&!(item.Operations??new RegOp[0]).Any(o=>App.IsPolicy(o)||o.Hive!="HKEY_CURRENT_USER")
   &&item.ActionCode!=ExtraSettings.Compression;
 }
 internal static List<Item> Resolve(string payload){
  var items=LiquidProtocol.Resolve(payload);
  if(items.Any(i=>!IsReviewed(i)))throw new Exception("A seleção contém uma opção manual, protegida ou não revisada.");
  return items;
 }
 internal static void Apply(string payload){
  var chosen=Resolve(payload);App.ApplyIsolated(chosen,"Otimização extrema",CatalogIds.Migrations(payload),Skipped(chosen));
 }
 internal static List<StepResult> Skipped(List<Item> chosen){
  var ids=new HashSet<string>(chosen.Select(i=>i.Id));var result=new List<StepResult>();var machine=App.ScanHardware();
  foreach(var item in CatalogIds.NativeItems().Where(i=>!ids.Contains(i.Id))){var info=OptionInfo.For(item);string reason=info.AutomaticReason;if(info.Automatic){var current=App.Observe(item,machine);reason=current.State=="Não compatível"||current.State=="Falha na leitura"?current.Detail:"Grupo desmarcado na revisão.";}result.Add(new StepResult{Id=item.Id,Name=item.ReviewTitle,Status="ignorado",Message=reason});}
  foreach(var entry in PerformanceLibrary.Load().Where(e=>e.Action!="native"))result.Add(new StepResult{Id=entry.Id,Name=entry.Title,Status="ignorado",Message="Manual, diagnóstico ou arquivo de referência. Não executado pelo Fazer tudo."});
  return result;
 }
}

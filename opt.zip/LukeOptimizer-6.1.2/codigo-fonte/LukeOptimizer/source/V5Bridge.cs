﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Windows.Forms;

static partial class App {
 internal static string UiPage,UiOption;internal static bool ToolMode;
 internal static readonly Dictionary<string,string> UiPages=new Dictionary<string,string>(StringComparer.Ordinal) {
  {"central","Otimizações"},{"fps","FPS e stutter"},{"input","Central de desempenho"},
  {"rede","Rede e latência"},{"processos","Apps e RAM"},{"personalizar","Central de desempenho"},
  {"biblioteca","Central de desempenho"},{"historico","Histórico"},{"energia","Energia avançada"},
  {"perfis","Perfis de jogos"},{"manutencao","Manutenção"},{"fontes","Arquivos e referências"},
  {"remover","Remover apps"},{"manual","Ajustes manuais"},{"hardware","Hardware e rede"},{"facil","Modo fácil"},{"bats","Seus 14 BATs"}
 };
 internal static bool ReadUiArguments(string[] args){
  if(args.Length==0||args[0]!="--ui-page"&&args[0]!="--ui-option")return false;
  if(args.Length!=2)throw new ArgumentException("Argumentos da interface inválidos.");
  if(args[0]=="--ui-page"){if(!UiPages.ContainsKey(args[1]))throw new ArgumentException("Ferramenta não reconhecida.");UiPage=args[1];}
  else{var entry=PerformanceLibrary.Load().FirstOrDefault(x=>x.Id==args[1]||x.Action=="native"&&x.Target==CatalogIds.Canonical(args[1]));if(entry==null)throw new ArgumentException("Opção não reconhecida.");UiPage="central";UiOption=entry.Id;}
  ToolMode=true;return true;
 }
}
public partial class MainForm {
 void InitializeBridge(){
  if(!App.ToolMode)return;ShowPage(App.UiOption!=null?"Central de desempenho":App.UiPages[App.UiPage]);
  if(App.UiPage=="personalizar")performanceSearch.Text="Personalização";
  else if(App.UiPage=="input")performanceSearch.Text="latência";
  if(App.UiOption!=null){performanceSearch.Clear();performanceCategory.SelectedIndex=0;performanceMode.SelectedIndex=0;FilterPerformance();
   foreach(ListViewItem row in performanceList.Items){row.Selected=((PerformanceEntry)row.Tag).Id==App.UiOption;if(row.Selected){row.EnsureVisible();row.Focused=true;performanceDetail.Text=PerformanceLibrary.Describe((PerformanceEntry)row.Tag);}}
  }
  footer.Text="Luke Optimizer 5 · ferramenta local · alterações somente pelos botões de aplicação";
 }
 void BuildSourceReview(){
  var page=Page("Arquivos e referências");var root=Rows(80,-1,100);page.Controls.Add(root);
  root.Controls.Add(Theme.Label("Seus arquivos, com revisão por função\r\nA biblioteca identifica ajustes aplicáveis, ferramentas, alternativas e itens sem benefício comprovado.",11,Theme.Muted),0,0);
  var body=Theme.ReadBox();root.Controls.Add(body,0,1);
  body.Text="PACOTES DE OTIMIZAÇÃO\r\nOs 23 scripts de Registro/CMD do RAR se repetem no ZIP 1Trilhão. Foram examinados por comando e substituídos por funções revisadas quando úteis.\r\n\r\nWCREE\r\nO executável contém botões que baixam comandos do Discord e os executam. Os destinos foram mapeados estaticamente; os scripts remotos não estão embutidos e seu conteúdo não foi presumido.\r\n\r\nCUSTOMIZAÇÃO\r\nO ZIP contém recursos e mudanças de GTA/FiveM. A personalização do Windows é uma área própria, com preferências leves.\r\n\r\nGPU E TECLADO\r\nGPU Priority e SFIO Priority não são usados pelo MMCSS conforme a documentação Microsoft. O REG de teclado ativa FilterKeys; os controles de entrada usam APIs com backup do estado anterior.\r\n\r\nLIQUID\r\nA interface principal desta versão é Windows Forms. Os fontes antigos de ImGui/DX11 são preservados para consulta; não são o executável aberto pelo atalho.\r\n\r\nO relatório abaixo contém o mapa completo, hashes, limitações e substituições. Nenhum executável enviado é iniciado pela auditoria.";
  body.Text="VERSÃO 5.2 — INTEGRAÇÃO E LOGS\r\n\r\nWIN11DEBLOAT\r\nAs 141 entradas do catálogo estão em Remover apps, com seleção individual. Somente apps escolhidos são processados; o log consulta a instalação antes e depois. Remover pode apagar dados e não tem desfazer automático.\r\n\r\nOPTIMIZER + NOVOS PACOTES\r\nOpções adaptadas estão em Otimizações e Central de desempenho; os dois campos decimais estão em Ajustes manuais. Configurações de serviços só são aplicáveis se o serviço existir. O mapa completo mostra o destino de cada valor reconhecido e os comandos sem execução.\r\n\r\nCURSED TWEAKER\r\nO BAT interno foi extraído estaticamente do executável PyInstaller. Não foi aberto. Prioridades de processos críticos, limpeza forçada e desativação indiscriminada de serviços não foram incorporadas.\r\n\r\nLOGS\r\nO Histórico distingue: mudou e foi conferido / já estava assim / não mudou / não confirmado / restaurado. Conferir agora faz uma nova leitura, preservando o log original. Salvar log TXT exporta o diagnóstico.\r\n\r\n"+body.Text;
  var row=ActionRow();root.Controls.Add(row,0,2);row.Controls.Add(V4Button("Abrir mapa completo",(s,e)=>OpenLocal(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"MAPA-DOS-ARQUIVOS.html")),true,225));
  row.Controls.Add(V4Button("Manual e fontes",(s,e)=>OpenLocal(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"LEIA-ME.html")),false,190));
  row.Controls.Add(V4Button("Contato / Discord",(s,e)=>OpenUrl("https://discord.com/users/1344439142850760816"),false,190));
 }
}

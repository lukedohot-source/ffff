using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;

class HomeOption {
 internal string Id,Title,Category;
 internal bool Diagnostic;
 internal HomeOption(string id,string title,string category,bool diagnostic=false){Id=id;Title=title;Category=category;Diagnostic=diagnostic;}
}
public partial class MainForm {
 readonly Dictionary<string,CheckBox> homeChecks=new Dictionary<string,CheckBox>();
 readonly Dictionary<string,HomeOption> homeOptions=new Dictionary<string,HomeOption>();
 readonly List<Button> homeActions=new List<Button>();
 readonly List<Surface> homeCards=new List<Surface>();
 Label homeCount;FlowLayoutPanel homeFlow;CheckBox homeAdvanced;
 readonly List<FlowLayoutPanel> homeColumns=new List<FlowLayoutPanel>();int homeLayoutWidth;bool arrangingHome;
 bool homeSync;TextBox homeSearch;ComboBox homeRisk;readonly HashSet<string> collapsedHome=new HashSet<string>();
#if TESTS
 internal Func<bool,string[],string[],Task> TestHomeApply;
 internal Action TestHomeUndo;
#endif
 static readonly string[] HomeCategories={"FPS","Input Lag","Windows","Processos","Inicialização","Rede","Energia","SSD","Diagnóstico"};
 internal static List<HomeOption> PrimaryOptions(){var options=new List<HomeOption>{
  new HomeOption("native-gamemode","Ativar Game Mode","FPS"),new HomeOption("native-capture","Desativar gravação de jogos","FPS"),
  new HomeOption("native-mouse","Desativar aceleração do mouse","Input Lag"),new HomeOption("v5-native-keyrepeat","Ajustar repetição do teclado","Input Lag"),new HomeOption("v5-native-sticky","Desativar atalho de cinco Shift","Input Lag"),
  new HomeOption("native-window","Reduzir animação das janelas","Windows"),new HomeOption("native-effects","Reduzir animações","Windows"),new HomeOption("native-menu","Acelerar abertura de submenus","Windows"),new HomeOption("native-transparency","Reduzir transparência","Windows"),new HomeOption("native-dragoutline","Arrastar janelas pelo contorno","Windows"),new HomeOption("native-cursorshadow","Desativar sombra do ponteiro","Windows"),
  new HomeOption("pack-d1b3e7ae9f70","Desativar Aero Peek","Windows"),new HomeOption("pack-3d76b7e8529c","Reduzir animações da barra","Windows"),
  new HomeOption("native-power","Ativar plano Alto desempenho","Energia")};
  options.AddRange(ReviewedDiagnostics.Ids.Select(id=>new HomeOption(id,ReviewedDiagnostics.Title(id),ReviewedDiagnostics.Category(id),true)));return options;
 }
 Button HomeButton(string name,string text,EventHandler handler,int width,bool primary=false){var button=Theme.Button(text,primary);button.Name=name;button.Width=width;button.Height=38;button.Margin=new Padding(0,0,8,8);button.Click+=handler;homeActions.Add(button);return button;}
 void BuildUnified(){
  var page=Page("Otimizações");var root=Rows(170,-1);page.Controls.Add(root);
  var top=Rows(86,46,46,40);root.Controls.Add(top,0,0);
  var actions=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=true,AutoScroll=true,Margin=Padding.Empty};top.Controls.Add(actions,0,0);
  actions.Controls.Add(HomeButton("home-clean","Limpar temporários",async(s,e)=>await QuickCleanupOneClick(),176,true));
  actions.Controls.Add(HomeButton("home-memory","Liberar RAM",async(s,e)=>await FreeMemoryOneClick(),158,true));
  actions.Controls.Add(HomeButton("home-processes","Reduzir processos",async(s,e)=>await RunProcessReduction(),174,true));
  actions.Controls.Add(HomeButton("home-apps","Remover apps",(s,e)=>ShowPage("Remover apps"),150));
  actions.Controls.Add(HomeButton("home-extreme","Otimização Ultra",async(s,e)=>await RunUltraProfile(),187,true));
  var second=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false,AutoScroll=true,Margin=Padding.Empty};top.Controls.Add(second,0,1);
  
  var third=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false,AutoScroll=true,Margin=Padding.Empty,Visible=false};top.Controls.Add(third,0,2);
  homeAdvanced=new ReadableCheckBox{Text="Opções avançadas incluídas abaixo",AutoSize=false,Width=260,Height=36,Margin=new Padding(6,0,8,0),ForeColor=Theme.Muted,BackColor=Theme.Bg,AccessibleName="Opções avançadas incluídas",Checked=true,Visible=false};third.Controls.Add(homeAdvanced);
  homeCount=Theme.Label("",10,Theme.Accent,true);homeCount.Dock=DockStyle.None;homeCount.Width=170;homeCount.Height=36;third.Controls.Add(homeCount);
  var simulate=Theme.Button("Simular seleção");simulate.Name="home-simulate";simulate.Width=154;simulate.Height=34;simulate.Click+=async(s,e)=>{var ids=homeChecks.Where(c=>c.Value.Checked&&!homeOptions[c.Key].Diagnostic).Select(c=>c.Key).ToArray();if(ids.Length>0)await ProductWork(token=>ExecutionHub.SimulateAsync(ids,token,ProductProgress),true);};third.Controls.Add(simulate);
  var filters=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false,AutoScroll=true,Visible=false};top.Controls.Add(filters,0,3);homeSearch=new TextBox{Width=300,Font=Theme.Font(10),BackColor=Theme.Card,ForeColor=Theme.Text,AccessibleName="Buscar opções"};filters.Controls.Add(homeSearch);homeRisk=Combo();homeRisk.Width=170;homeRisk.Items.AddRange(new object[]{"Todos os riscos","Baixo","Moderado","Alto","Favoritos"});homeRisk.SelectedIndex=0;filters.Controls.Add(homeRisk);var filterHint=Theme.Label("",1,Theme.Bg);filterHint.Dock=DockStyle.None;filterHint.Width=1;filterHint.Height=1;
  homeFlow=new FlowLayoutPanel{Dock=DockStyle.Fill,AutoScroll=true,WrapContents=true,Padding=new Padding(0,0,8,12),Visible=false};root.Controls.Add(homeFlow,0,1);
  foreach(var option in PrimaryOptions())homeOptions.Add(option.Id,option);
  foreach(var item in CatalogIds.NativeItems().Where(i=>!homeOptions.ContainsKey(i.Id)))homeOptions.Add(item.Id,new HomeOption(item.Id,item.ReviewTitle,AdvancedCategory(item)));
  foreach(var category in HomeCategories)collapsedHome.Add(category);
  BuildHomeCards();var inlineTools=new FlowLayoutPanel{Dock=DockStyle.Fill,AutoScroll=true,WrapContents=true,Padding=new Padding(0,8,8,8),Visible=false};homeSearch.TextChanged+=(s,e)=>BuildHomeCards();homeRisk.SelectedIndexChanged+=(s,e)=>BuildHomeCards();homeAdvanced.CheckedChanged+=(s,e)=>BuildHomeCards();homeFlow.SizeChanged+=(s,e)=>SizeHomeCards();

 }
 static string AdvancedCategory(Item item){string text=(item.Category+" "+item.ReviewTitle).ToLowerInvariant();return text.Contains("energia")||text.Contains("power")?"Energia":text.Contains("rede")||text.Contains("dns")||text.Contains("tcp")?"Rede":text.Contains("mouse")||text.Contains("tecl")||text.Contains("input")?"Input Lag":text.Contains("game")||text.Contains("jog")||text.Contains("fps")?"FPS":text.Contains("disco")||text.Contains("ssd")||text.Contains("ntfs")?"SSD":text.Contains("serviço")||text.Contains("segundo plano")?"Processos":"Windows";}
 void BuildHomeCards(){
  var saved=homeChecks.Where(x=>x.Value.Checked).Select(x=>x.Key).ToArray();bool first=homeChecks.Count==0;
  homeFlow.SuspendLayout();foreach(Control control in homeFlow.Controls.Cast<Control>().ToArray())control.Dispose();homeCards.Clear();homeChecks.Clear();homeColumns.Clear();homeLayoutWidth=0;
  var primary=new HashSet<string>(PrimaryOptions().Select(o=>o.Id));
  foreach(string category in HomeCategories){
   var options=homeOptions.Values.Where(o=>o.Category==category).ToArray();
   var card=new Surface{Padding=new Padding(16,10,16,10),Margin=new Padding(0,0,12,12),Name="home-category-"+category};homeCards.Add(card);homeFlow.Controls.Add(card);
   var body=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=1,Margin=Padding.Empty};card.Controls.Add(body);
   var header=Theme.Button((collapsedHome.Contains(category)?"+ ":"− ")+category);header.Name="home-collapse-"+category;header.Height=32;header.Dock=DockStyle.Top;header.Click+=(s,e)=>{if(!collapsedHome.Add(category))collapsedHome.Remove(category);BuildHomeCards();};body.Controls.Add(header);
   foreach(var option in options){
    var row=new TableLayoutPanel{Height=productPrefs==null||productPrefs.Compact?32:40,Dock=DockStyle.Top,ColumnCount=1,Margin=Padding.Empty,Name="home-row-"+option.Id,Visible=HomeVisible(option,primary)&&!collapsedHome.Contains(category)};
    var check=new ReadableCheckBox{Text=option.Title+(!option.Diagnostic&&OptionInfo.For(App.Items.Single(i=>i.Id==option.Id)).Classification=="Manual"?" · Manual":""),Dock=DockStyle.Fill,Margin=new Padding(0,0,5,0),ForeColor=Theme.Text,BackColor=Theme.Card,Font=Theme.Font(9.5f),Name="home-check-"+option.Id,AccessibleName=option.Title};homeChecks.Add(option.Id,check);row.Controls.Add(check,0,0);
    
    string id=option.Id;check.Checked=first?!option.Diagnostic&&App.Items.Any(i=>i.Id==id&&i.DefaultSelected):saved.Contains(id);
    check.CheckedChanged+=(s,e)=>{check.BackColor=check.Checked?Color.FromArgb(62,55,27):Theme.Card;check.Invalidate();if(!homeSync)UpdateHome();};check.BackColor=check.Checked?Color.FromArgb(62,55,27):Theme.Card;
    body.Controls.Add(row);
   }
   foreach(var link in CategoryTools(category)){string target=link.Value;var button=Theme.Button(link.Key);button.Visible=false;button.Height=34;button.Dock=DockStyle.Top;button.Margin=new Padding(0,5,0,0);button.Click+=(s,e)=>{if(target.StartsWith("ms-settings:"))OpenLocal(target);else if(target=="dfrgui.exe")OpenSystem(target,"");else ShowPage(target);};body.Controls.Add(button);}
   int visibleRows=collapsedHome.Contains(category)?0:options.Count(o=>HomeVisible(o,primary));card.Height=52+(productPrefs==null||productPrefs.Compact?32:40)*visibleRows+39*(collapsedHome.Contains(category)||!String.IsNullOrWhiteSpace(homeSearch.Text)?0:CategoryTools(category).Count);
  }
  homeFlow.ResumeLayout();SizeHomeCards();UpdateHome();
 }
 bool HomeVisible(HomeOption option,HashSet<string> primary){
  string query=homeSearch==null?"":homeSearch.Text.Trim();
  if(query.Length>0&&(option.Title+" "+option.Category+" "+option.Id).IndexOf(query,StringComparison.CurrentCultureIgnoreCase)<0)return false;
  string risk=homeRisk==null?"Todos os riscos":Convert.ToString(homeRisk.SelectedItem);if(risk=="Favoritos")return favorites.Contains(option.Id);return risk=="Todos os riscos"||(option.Diagnostic?risk=="Baixo":OptionInfo.For(App.Items.Single(i=>i.Id==option.Id)).Risk==risk);
 }
 Dictionary<string,string> CategoryTools(string category){var result=new Dictionary<string,string>();
  if(category=="FPS"){result.Add("Comparar FPS e frametime","FPS e stutter");result.Add("Ajustar GPU por jogo","Perfis de jogos");}
  if(category=="Input Lag")result.Add("Ver opções de input lag","Central de desempenho");
  if(category=="Processos")result.Add("Limitar apps em segundo plano","Apps e RAM");
  if(category=="Inicialização")result.Add("Otimizar inicialização","Manutenção");
  if(category=="Rede")result.Add("Diagnosticar rede e latência","Rede e latência");
  if(category=="Energia")result.Add("Ajustar energia","Otimizações");
  if(category=="SSD"){result.Add("Otimizar SSD · ferramenta do Windows","dfrgui.exe");result.Add("Limpeza segura · ver opções","Manutenção");}
  if(category=="Diagnóstico")result.Add("Ver hardware e diagnóstico","Hardware e rede");
  if(category=="Windows"){result.Add("Desativar apps em segundo plano · opções","ms-settings:appsfeatures");result.Add("Reduzir atividade da busca · opções","ms-settings:search-permissions");}
  return result;
 }
 void SizeHomeCards(){
  if(homeFlow==null||arrangingHome)return;int width=homeFlow.ClientSize.Width-32;if(width==homeLayoutWidth)return;homeLayoutWidth=width;arrangingHome=true;homeFlow.SuspendLayout();
  try{
   foreach(var card in homeCards)if(card.Parent!=null)card.Parent.Controls.Remove(card);
   foreach(var column in homeColumns)column.Dispose();homeColumns.Clear();
   int count=width>=1420?3:width>=720?2:1;int cardWidth=Math.Max(280,width/count-12);var heights=new int[count];
   for(int n=0;n<count;n++){var column=new FlowLayoutPanel{FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Width=cardWidth,MinimumSize=new Size(cardWidth,0),MaximumSize=new Size(cardWidth,0),Margin=new Padding(0,0,12,0)};homeColumns.Add(column);homeFlow.Controls.Add(column);}
   foreach(var card in homeCards){int column=Array.IndexOf(heights,heights.Min());card.Width=cardWidth;card.Margin=new Padding(0,0,0,12);homeColumns[column].Controls.Add(card);heights[column]+=card.Height+12;}
  }finally{homeFlow.ResumeLayout();arrangingHome=false;}
 }
 async Task ShowHomeDetails(HomeOption option){
  string text;
  if(option.Diagnostic)text=ReviewedDiagnostics.Detail(option.Id)+"\r\n\r\nCompatibilidade: Windows 10/11. Somente leitura; resultados no Histórico. Não altera configurações e não exige desfazer.\r\nFonte: "+ReviewedDiagnostics.Source(option.Id);
  else{var item=App.Items.Single(i=>i.Id==option.Id);var info=OptionInfo.For(item);text=String.Join("\r\n",item.Review??new string[0])+"\r\n\r\nClassificação: "+info.Classification+"\r\nRisco: "+info.Risk+"\r\nCompatibilidade: "+info.Compatibility+"\r\n"+info.AutomaticReason+"\r\n"+info.Restart+"\r\n\r\nBackup: "+App.RecordsRoot+"\r\nDesfazer: valores, tipos e ausência anteriores restaurados pelo Histórico. Mudanças posteriores são preservadas.\r\n\r\nFonte: "+item.Url+"\r\nID preservado: "+item.Id;}
  await InlineReview(option.Title,text,false);
 }
 bool HomeBulkSafe(HomeOption option){if(option.Diagnostic)return true;var item=App.Items.First(i=>i.Id==option.Id);return ExtremeProfile.Groups().Where(g=>g.Selected).SelectMany(g=>g.Items).Contains(option.Id)&&ExtremeProfile.IsReviewed(item);}
 void SetHomeSelection(bool selected){homeSync=true;foreach(var pair in homeChecks){var item=App.Items.FirstOrDefault(i=>i.Id==pair.Key);pair.Value.Checked=selected&&pair.Value.Enabled&&item!=null&&!pair.Value.Text.Contains("Diagnóstico")&&ExtremeProfile.IsReviewed(item);}homeSync=false;UpdateHome();}
 void UpdateHome(){if(homeCount==null)return;bool enabled=ready&&machine.Windows&&!busy&&!scanning&&!resourceScanning&&!easyRunning;
  foreach(var check in homeChecks.Values)check.Enabled=enabled;
  foreach(var button in homeActions)button.Enabled=enabled;
  homeAdvanced.Enabled=!busy&&!scanning&&!resourceScanning&&!easyRunning;
  homeCount.Text=homeChecks.Count(x=>x.Value.Checked)+" selecionadas";
  var applyButton=homeActions.FirstOrDefault(b=>b.Name=="home-apply");if(applyButton!=null)applyButton.Enabled=enabled&&homeChecks.Any(x=>x.Value.Checked);
  var undoButton=homeActions.FirstOrDefault(b=>b.Name=="home-undo");if(undoButton!=null)undoButton.Enabled=enabled&&records.Any(App.CanUndo);
  var restoreButton=homeActions.FirstOrDefault(b=>b.Name=="home-restore-selection");if(restoreButton!=null)restoreButton.Enabled=enabled&&records.Any(App.CanUndo)&&HomePayload(false).Length>0;
 }
 string[] ResolveHomeConflicts(IEnumerable<string> ids){var accepted=new List<Item>();foreach(string id in ids.Distinct()){var item=App.Items.FirstOrDefault(i=>i.Id==id);if(item==null)continue;try{App.UniqueOperations(accepted.Concat(new[]{item}));accepted.Add(item);}catch{}}return accepted.Select(i=>i.Id).ToArray();}
 internal string[] HomePayload(bool extreme){var selected=homeChecks.Where(x=>x.Value.Checked&&!homeOptions[x.Key].Diagnostic).Select(x=>x.Key);
  if(!extreme)return ResolveHomeConflicts(selected);var allowed=new HashSet<string>(CatalogIds.NativeItems().Where(ExtremeProfile.IsReviewed).Select(i=>i.Id));return ResolveHomeConflicts(selected.Concat(allowed).Where(allowed.Contains));
 }
 async Task RunHome(bool extreme){
  if(busy||scanning||resourceScanning||easyRunning||!machine.Windows)return;
  string[] ids=HomePayload(extreme),diagnostics=extreme?new string[0]:homeChecks.Where(x=>x.Value.Checked&&homeOptions[x.Key].Diagnostic).Select(x=>x.Key).ToArray();
  if(ids.Length==0&&diagnostics.Length==0)return;
#if TESTS
  if(TestHomeApply!=null){await TestHomeApply(extreme,ids,diagnostics);return;}
#endif
  string review=String.Join("\r\n",ids.Select(id=>"• "+App.Items.Single(i=>i.Id==id).ReviewTitle).Concat(diagnostics.Select(id=>"• "+ReviewedDiagnostics.Title(id))));
  string policy="Cada ajuste tem backup, verificação e restauração individual em caso de falha. Valores sem permissão são ignorados; os demais continuam. Desfazer restaura os ajustes aplicados deste conjunto. Diagnósticos fazem somente leitura.";
  var manual=ids.Select(id=>App.Items.Single(i=>i.Id==id)).Where(i=>OptionInfo.For(i).Classification=="Manual"||OptionInfo.For(i).Risk!="Baixo").ToList();
  if(manual.Count>0)review+="\r\n\r\nOPÇÕES MANUAIS / COM RISCO\r\n"+String.Join("\r\n\r\n",manual.Select(i=>i.ReviewTitle+": "+String.Join(" ",i.Review??new string[0])));
  if(!await InlineReview(extreme?"Otimização extrema":"Aplicar selecionadas",review+"\r\n\r\n"+policy,true))return;
  if(ids.Length>0&&!await Elevated(extreme?"--extreme":"--apply-many",String.Join(",",ids)))return;
  if(diagnostics.Length>0){busy=true;SetActions();try{foreach(string id in diagnostics){footer.Text=ReviewedDiagnostics.Title(id)+"…";await Task.Run(()=>App.RunReviewedDiagnostic(id));}}finally{busy=false;RefreshHistory();SetActions();ShowPage("Histórico");}}
 }
 async Task RunQuickProfile(){
  if(busy||scanning||resourceScanning||easyRunning||!machine.Windows)return;
  homeSync=true;
  foreach(var pair in homeChecks){var option=homeOptions[pair.Key];if(option.Diagnostic){pair.Value.Checked=false;continue;}var item=App.Items.FirstOrDefault(i=>i.Id==pair.Key);var info=item==null?null:OptionInfo.For(item);pair.Value.Checked=item!=null&&item.DefaultSelected&&info.Risk=="Baixo"&&info.Automatic;}
  homeSync=false;UpdateHome();await RunHome(false);
 }
 async Task RunUltraProfile(){
  if(busy||scanning||resourceScanning||easyRunning||!machine.Windows)return;
  SetHomeSelection(true);await RunHome(true);
 }
 void PopulateToolDirectory(FlowLayoutPanel flow){
  var title=Theme.Label("Ferramentas integradas · opções e BATs revisados",11,Theme.Accent,true);title.Width=700;title.Height=30;flow.Controls.Add(title);
  var note=Theme.Label("",1,Theme.Bg);note.Width=1;note.Height=1;
  foreach(var script in ImportedScripts.All){var review=script;var button=Theme.Button(review.Name+" · "+review.Status);button.Name="tool-review-"+review.Id;button.Width=220;button.Height=40;button.Margin=new Padding(0,0,10,10);button.Click+=(s,e)=>TextDialog("Revisão — "+review.Name,"Status: "+review.Status+"\r\nIntegração: "+review.Integration+"\r\nHash: "+review.Hash+"\r\n\r\nAchados:\r\n"+String.Join("\r\n",review.Findings??new string[0])+"\r\n\r\nConteúdo preservado:\r\n"+review.Text);flow.Controls.Add(button);}
  foreach(var target in pages.Keys.Where(k=>k!="Otimizações"&&k!="Ferramentas"&&k!="Histórico").ToArray()){string name=target;var button=Theme.Button(name);button.Width=190;button.Height=48;button.Margin=new Padding(0,0,10,10);button.Click+=(s,e)=>ShowPage(name);flow.Controls.Add(button);}
 }
 void BuildToolDirectory(){var page=Page("Ferramentas");var flow=new FlowLayoutPanel{Dock=DockStyle.Fill,AutoScroll=true,Padding=new Padding(0,8,0,0)};page.Controls.Add(flow);PopulateToolDirectory(flow);}
}

using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;

class HomeOption {
 internal string Id,Title,Category;
 internal bool Diagnostic;
 internal HomeOption(string id,string title,string category,bool diagnostic=false){Id=id;Title=title;Category=category;Diagnostic=diagnostic;}
}
public partial class MainForm {
 readonly Dictionary<string,CheckBox> homeChecks=new Dictionary<string,CheckBox>();
 readonly Dictionary<string,HomeOption> homeOptions=new Dictionary<string,HomeOption>();
 readonly List<Button> homeActions=new List<Button>();
 readonly List<Surface> homeCards=new List<Surface>();
 Label homeCount;FlowLayoutPanel homeFlow;CheckBox homeAdvanced;
 readonly List<FlowLayoutPanel> homeColumns=new List<FlowLayoutPanel>();int homeLayoutWidth;bool arrangingHome;
 bool homeSync;TextBox homeSearch;ComboBox homeRisk;readonly HashSet<string> collapsedHome=new HashSet<string>();
 // Filtro corrente. Control.Visible devolve a visibilidade EFETIVA (some quando a página
 // está oculta), por isso o estado do filtro é guardado aqui em vez de ser lido da UI.
 readonly HashSet<string> hiddenHome=new HashSet<string>();
 readonly HashSet<string> hiddenCards=new HashSet<string>();
#if TESTS
 internal Func<bool,string[],string[],Task> TestHomeApply;
 internal Action TestHomeUndo;
#endif
 static readonly string[] HomeCategories={"FPS","Input Lag","Windows","Processos","Inicialização","Rede","Energia","SSD","Diagnóstico"};
 internal static List<HomeOption> PrimaryOptions(){var options=new List<HomeOption>{
  new HomeOption("native-gamemode","Ativar Game Mode","FPS"),new HomeOption("native-capture","Desativar gravação de jogos","FPS"),
  new HomeOption("native-mouse","Desativar aceleração do mouse","Input Lag"),new HomeOption("v5-native-keyrepeat","Ajustar repetição do teclado","Input Lag"),new HomeOption("v5-native-sticky","Desativar atalho de cinco Shift","Input Lag"),
  new HomeOption("native-window","Reduzir animação das janelas","Windows"),new HomeOption("native-effects","Reduzir animações","Windows"),new HomeOption("native-menu","Acelerar abertura de submenus","Windows"),new HomeOption("native-transparency","Reduzir transparência","Windows"),new HomeOption("native-dragoutline","Arrastar janelas pelo contorno","Windows"),new HomeOption("native-cursorshadow","Desativar sombra do ponteiro","Windows"),
  new HomeOption("pack-d1b3e7ae9f70","Desativar Aero Peek","Windows"),new HomeOption("pack-3d76b7e8529c","Reduzir animações da barra","Windows"),
  new HomeOption("native-power","Ativar plano Alto desempenho","Energia")};
  options.AddRange(ReviewedDiagnostics.Ids.Select(id=>new HomeOption(id,ReviewedDiagnostics.Title(id),ReviewedDiagnostics.Category(id),true)));return options;
 }
 Button HomeButton(string name,string text,EventHandler handler,int width,bool primary=false){var button=Theme.Button(text,primary);button.Name=name;button.Width=width;button.Height=38;button.Margin=new Padding(0,0,8,8);button.Click+=handler;homeActions.Add(button);return button;}
 void BuildUnified(){
  // 86+46+46+44 = 222. A linha valia 170 enquanto as três faixas de baixo estavam ocultas.
  var page=Page("Otimizações");var root=Rows(222,-1);page.Controls.Add(root);
  var top=Rows(86,46,46,44);root.Controls.Add(top,0,0);
  var actions=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=true,AutoScroll=true,Margin=Padding.Empty};top.Controls.Add(actions,0,0);
  actions.Controls.Add(HomeButton("home-clean","Limpar temporários",async(s,e)=>await QuickCleanupOneClick(),176,true));
  actions.Controls.Add(HomeButton("home-memory","Liberar RAM",async(s,e)=>await FreeMemoryOneClick(),158,true));
  actions.Controls.Add(HomeButton("home-processes","Reduzir processos",async(s,e)=>await RunProcessReduction(),174,true));
  actions.Controls.Add(HomeButton("home-processes-deep","Reduzir processos: extremo",async(s,e)=>await RunProcessReduction("extremo"),228));
  actions.Controls.Add(HomeButton("home-gaming-session","Sessão de jogo",async(s,e)=>await RunGamingSessionProfile(),168,true));
  actions.Controls.Add(HomeButton("home-apps","Remover apps",(s,e)=>ShowPage("Remover apps"),150));
  actions.Controls.Add(HomeButton("home-extreme","Otimização Ultra",async(s,e)=>await RunUltraProfile(),187,true));
  var second=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false,AutoScroll=true,Margin=Padding.Empty};top.Controls.Add(second,0,1);
  var selectAll=HomeButton("home-select-all","Selecionar tudo",(s,e)=>SetHomeSelection(true),140);second.Controls.Add(selectAll);
  var clear=HomeButton("home-clear","Limpar seleção",(s,e)=>SetHomeSelection(false),140);second.Controls.Add(clear);
  var apply=HomeButton("home-apply","Aplicar selecionadas",async(s,e)=>await RunHome(false),170,true);second.Controls.Add(apply);
  var undo=HomeButton("home-undo","Desfazer",async(s,e)=>await HomeUndoClick(),140);second.Controls.Add(undo);
  // Restaurar reescreve o Windows com valores gravados antes: é alteração real, com
  // elevação, e segue a mesma regra de todo o resto da página — revisar antes de aplicar.
  // Este botão era o único que ia direto para a elevação, sem dizer QUAL backup usaria
  // nem O QUE mudaria. Aplicar, Ultra, remoção de apps e ajustes manuais todos revisam.
  var restore=HomeButton("home-restore-selection","Restaurar seleção",async(s,e)=>{
   var rec=records.FirstOrDefault(App.CanUndo);if(rec==null)return;
   var ids=HomePayload(false);if(ids.Length==0)return;
   var chosen=ids.Select(App.ById).Where(i=>i!=null).ToArray();
   DateTime when;string stamp=DateTime.TryParse(rec.Time,out when)?when.ToLocalTime().ToString("dd/MM/yyyy HH:mm"):rec.Time;
   string text="Backup: "+rec.Name+" · "+stamp+"\r\n\r\n"+
    "Estas configurações voltam ao valor gravado nesse backup:\r\n"+
    String.Join("\r\n",chosen.Select(i=>"· "+i.ReviewTitle).ToArray())+
    "\r\n\r\nSe outro programa alterou algum desses valores depois do backup, a restauração recusa sobrescrever e informa, em vez de apagar a mudança em silêncio.\r\nRequer administrador.";
   if(!await InlineReview("Confirmar restauração da seleção",text,true))return;
   await Elevated("--restore-selection",rec.Id+"|"+String.Join(",",ids));
  },170);second.Controls.Add(restore);
  var windowDetails=HomeButton("home-details-native-window","Detalhes da otimização selecionada",async(s,e)=>{var item=App.ById("native-window");if(item!=null)await ShowHomeDetails(new HomeOption(item.Id,item.ReviewTitle,"Windows"));},220);second.Controls.Add(windowDetails);
  
  var third=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false,AutoScroll=true,Margin=Padding.Empty};top.Controls.Add(third,0,2);
  homeAdvanced=new ReadableCheckBox{Text="Mostrar também as opções avançadas",AutoSize=false,Width=280,Height=36,Margin=new Padding(6,0,8,0),ForeColor=Theme.Muted,BackColor=Theme.Bg,AccessibleName="Mostrar também as opções avançadas",Checked=false};third.Controls.Add(homeAdvanced);
  homeCount=Theme.Label("",10,Theme.Accent,true);homeCount.Dock=DockStyle.None;homeCount.Width=170;homeCount.Height=36;third.Controls.Add(homeCount);
  var simulate=Theme.Button("Simular seleção");simulate.Name="home-simulate";simulate.Width=154;simulate.Height=34;simulate.Click+=async(s,e)=>{var ids=homeChecks.Where(c=>c.Value.Checked&&!homeOptions[c.Key].Diagnostic).Select(c=>c.Key).ToArray();if(ids.Length>0)await ProductWork(token=>ExecutionHub.SimulateAsync(ids,token,ProductProgress),true);};third.Controls.Add(simulate);
  var filters=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false,AutoScroll=true};top.Controls.Add(filters,0,3);homeSearch=new TextBox{Width=300,Font=Theme.Font(10),BackColor=Theme.Card,ForeColor=Theme.Text,AccessibleName="Buscar opções"};filters.Controls.Add(homeSearch);homeRisk=Combo();homeRisk.Width=170;homeRisk.Items.AddRange(new object[]{"Todos os riscos","Baixo","Moderado","Alto","Favoritos"});homeRisk.SelectedIndex=0;filters.Controls.Add(homeRisk);
  homeFlow=new FlowLayoutPanel{Dock=DockStyle.Fill,AutoScroll=true,WrapContents=true,Padding=new Padding(0,0,8,12)};root.Controls.Add(homeFlow,0,1);
  foreach(var option in PrimaryOptions())homeOptions.Add(option.Id,option);
  foreach(var item in CatalogIds.NativeItems().Where(i=>!homeOptions.ContainsKey(i.Id)))homeOptions.Add(item.Id,new HomeOption(item.Id,item.ReviewTitle,AdvancedCategory(item)));
  // Categorias abertas por padrão: com as avançadas desmarcadas a lista já é curta.
  BuildHomeCards();homeSearch.TextChanged+=(s,e)=>ApplyHomeFilter();homeRisk.SelectedIndexChanged+=(s,e)=>ApplyHomeFilter();homeAdvanced.CheckedChanged+=(s,e)=>ApplyHomeFilter();homeFlow.SizeChanged+=(s,e)=>SizeHomeCards();

 }
 static string AdvancedCategory(Item item){string text=(item.Category+" "+item.ReviewTitle).ToLowerInvariant();return text.Contains("energia")||text.Contains("power")?"Energia":text.Contains("rede")||text.Contains("dns")||text.Contains("tcp")?"Rede":text.Contains("mouse")||text.Contains("tecl")||text.Contains("input")?"Input Lag":text.Contains("game")||text.Contains("jog")||text.Contains("fps")?"FPS":text.Contains("disco")||text.Contains("ssd")||text.Contains("ntfs")?"SSD":text.Contains("serviço")||text.Contains("segundo plano")?"Processos":"Windows";}
 void BuildHomeCards(){
  var saved=homeChecks.Where(x=>x.Value.Checked).Select(x=>x.Key).ToArray();bool first=homeChecks.Count==0;
  homeFlow.SuspendLayout();foreach(Control control in homeFlow.Controls.Cast<Control>().ToArray())control.Dispose();
  // Cartão filtrado fica fora de qualquer coluna; sem isto ele escaparia do Dispose acima.
  foreach(var previous in homeCards)previous.Dispose();
  homeCards.Clear();homeChecks.Clear();homeColumns.Clear();homeLayoutWidth=0;
  var primary=new HashSet<string>(PrimaryOptions().Select(o=>o.Id));
  foreach(string category in HomeCategories){
   var options=homeOptions.Values.Where(o=>o.Category==category).ToArray();
   var card=new Surface{Padding=new Padding(16,10,16,10),Margin=new Padding(0,0,12,12),Name="home-category-"+category};homeCards.Add(card);homeFlow.Controls.Add(card);
   var body=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=1,Margin=Padding.Empty};card.Controls.Add(body);
   var header=Theme.Button((collapsedHome.Contains(category)?"+ ":"− ")+category);header.Name="home-collapse-"+category;header.Height=32;header.Dock=DockStyle.Top;header.Click+=(s,e)=>{if(!collapsedHome.Add(category))collapsedHome.Remove(category);ApplyHomeFilter();};body.Controls.Add(header);
   foreach(var option in options){
    var row=new TableLayoutPanel{Height=productPrefs==null||productPrefs.Compact?32:40,Dock=DockStyle.Top,ColumnCount=1,Margin=Padding.Empty,Name="home-row-"+option.Id,Visible=HomeVisible(option,primary)&&!collapsedHome.Contains(category)};
    var check=new ReadableCheckBox{Text=option.Title+(!option.Diagnostic&&OptionInfo.For(App.ById(option.Id)).Classification=="Manual"?" · Manual":""),Dock=DockStyle.Fill,Margin=new Padding(0,0,5,0),ForeColor=Theme.Text,BackColor=Theme.Card,Font=Theme.Font(9.5f),Name="home-check-"+option.Id,AccessibleName=option.Title};homeChecks.Add(option.Id,check);row.Controls.Add(check,0,0);
    string id=option.Id;var defaults=App.ById(id);check.Checked=first?!option.Diagnostic&&defaults!=null&&defaults.DefaultSelected:saved.Contains(id);
    check.CheckedChanged+=(s,e)=>{check.BackColor=check.Checked?Theme.Selection:Theme.Card;check.Invalidate();if(!homeSync)UpdateHome();};check.BackColor=check.Checked?Theme.Selection:Theme.Card;
    body.Controls.Add(row);
   }
   foreach(var link in CategoryTools(category)){string target=link.Value;var button=Theme.Button(link.Key);button.Name="home-tool-"+category+"-"+link.Key;button.Height=34;button.Dock=DockStyle.Top;button.Margin=new Padding(0,5,0,0);button.Click+=(s,e)=>{if(target.StartsWith("ms-settings:"))OpenLocal(target);else if(target=="dfrgui.exe")OpenSystem(target,"");else ShowPage(target);};body.Controls.Add(button);}
  }
  homeFlow.ResumeLayout();ApplyHomeFilter();
 }
 // Filtra sem destruir e recriar 131 controles: só alterna Visible e recalcula alturas.
 // Chamado a cada tecla da busca, por isso não pode alocar por opção.
 void ApplyHomeFilter(){
  if(homeFlow==null)return;
  var primary=new HashSet<string>(PrimaryOptions().Select(o=>o.Id));
  int rowHeight=productPrefs==null||productPrefs.Compact?32:40;
  bool searching=homeSearch!=null&&!String.IsNullOrWhiteSpace(homeSearch.Text);
  hiddenHome.Clear();hiddenCards.Clear();homeFlow.SuspendLayout();
  try{
   foreach(var card in homeCards){
    string category=card.Name.Substring("home-category-".Length);
    bool collapsed=collapsedHome.Contains(category);
    int visibleRows=0;
    foreach(Control child in card.Controls[0].Controls){
     if(child.Name!=null&&child.Name.StartsWith("home-row-",StringComparison.Ordinal)){
      string id=child.Name.Substring("home-row-".Length);
      bool matches=HomeVisible(homeOptions[id],primary);
      if(!matches)hiddenHome.Add(id);
      // NUNCA reler child.Visible aqui. O getter devolve a visibilidade EFETIVA: ele sobe
      // até o formulário e devolve false se qualquer ancestral estiver escondido. Como o
      // cartão é ancestral da linha, reler travava a página: uma passada com o cartão
      // escondido fazia toda linha ler false, visibleRows ficava 0, o cartão se escondia
      // de novo e nunca mais voltava. A primeira passada roda dentro de BuildHomeCards,
      // antes de Show(), quando NADA está efetivamente visível — então as 9 categorias
      // nasciam escondidas e a tela Otimizações abria vazia. Vale o valor recém-decidido.
      bool rowVisible=matches&&!collapsed;
      child.Visible=rowVisible;
      if(rowVisible)visibleRows++;
      continue;
     }
     if(child.Name!=null&&child.Name.StartsWith("home-tool-",StringComparison.Ordinal))child.Visible=!collapsed&&!searching;
     else if(child.Name!=null&&child.Name.StartsWith("home-collapse-",StringComparison.Ordinal))child.Text=(collapsed?"+ ":"− ")+category;
    }
    int tools=collapsed||searching?0:CategoryTools(category).Count;
    card.Height=52+rowHeight*visibleRows+39*tools;
    bool showCard=collapsed||visibleRows>0;
    card.Visible=showCard;if(!showCard)hiddenCards.Add(card.Name);
   }
  }finally{homeFlow.ResumeLayout();}
  // Sentinela impossível: SizeHomeCards ignora a chamada quando a largura não mudou,
  // e 0 é uma largura alcançável quando o painel ainda não foi dimensionado.
  homeLayoutWidth=Int32.MinValue;SizeHomeCards();UpdateHome();
 }
 bool HomeVisible(HomeOption option,HashSet<string> primary){
  // A caixa "opções avançadas" deixa de ser decorativa: sem ela a página abre com as
  // opções curadas de PrimaryOptions em vez das 131 do catálogo inteiro.
  if(homeAdvanced!=null&&!homeAdvanced.Checked&&!primary.Contains(option.Id))return false;
  string query=homeSearch==null?"":homeSearch.Text.Trim();
  if(query.Length>0&&(option.Title+" "+option.Category+" "+option.Id).IndexOf(query,StringComparison.CurrentCultureIgnoreCase)<0)return false;
  string risk=homeRisk==null?"Todos os riscos":Convert.ToString(homeRisk.SelectedItem);if(risk=="Favoritos")return favorites.Contains(option.Id);return risk=="Todos os riscos"||(option.Diagnostic?risk=="Baixo":OptionInfo.For(App.ById(option.Id)).Risk==risk);
 }
 Dictionary<string,string> CategoryTools(string category){var result=new Dictionary<string,string>();
  if(category=="FPS"){result.Add("Comparar FPS e frametime","FPS e stutter");result.Add("Ajustar GPU por jogo","Perfis de jogos");}
  if(category=="Input Lag")result.Add("Ver opções de input lag","Central de desempenho");
  if(category=="Processos")result.Add("Limitar apps em segundo plano","Apps e RAM");
  if(category=="Inicialização")result.Add("Otimizar inicialização","Manutenção");
  if(category=="Rede")result.Add("Diagnosticar rede e latência","Rede e latência");
  if(category=="Energia")result.Add("Ajustar energia","Otimizações");
  if(category=="SSD"){result.Add("Otimizar SSD · ferramenta do Windows","dfrgui.exe");result.Add("Limpeza segura · ver opções","Manutenção");}
  if(category=="Diagnóstico")result.Add("Ver hardware e diagnóstico","Hardware e rede");
  if(category=="Windows"){result.Add("Desativar apps em segundo plano · opções","ms-settings:appsfeatures");result.Add("Reduzir atividade da busca · opções","ms-settings:search-permissions");}
  return result;
 }
 void SizeHomeCards(){
  if(homeFlow==null||arrangingHome)return;int width=homeFlow.ClientSize.Width-32;if(width==homeLayoutWidth)return;homeLayoutWidth=width;arrangingHome=true;homeFlow.SuspendLayout();
  try{
   foreach(var card in homeCards)if(card.Parent!=null)card.Parent.Controls.Remove(card);
   foreach(var column in homeColumns)column.Dispose();homeColumns.Clear();
   int count=width>=1420?3:width>=720?2:1;int cardWidth=Math.Max(280,width/count-12);var heights=new int[count];
   for(int n=0;n<count;n++){var column=new FlowLayoutPanel{FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Width=cardWidth,MinimumSize=new Size(cardWidth,0),MaximumSize=new Size(cardWidth,0),Margin=new Padding(0,0,12,0)};homeColumns.Add(column);homeFlow.Controls.Add(column);}
   // A largura é atribuída ANTES do desvio: um cartão filtrado para fora continua com a
   // largura da coluna atual, então ele reaparece já no tamanho certo quando a busca é
   // limpa, em vez de voltar com os 200 px padrão de Panel e só se ajustar no próximo
   // redimensionamento da janela.
   foreach(var card in homeCards){card.Width=cardWidth;card.Margin=new Padding(0,0,0,12);if(hiddenCards.Contains(card.Name))continue;int column=Array.IndexOf(heights,heights.Min());homeColumns[column].Controls.Add(card);heights[column]+=card.Height+12;}
  }finally{homeFlow.ResumeLayout();arrangingHome=false;}
 }
 async Task ShowHomeDetails(HomeOption option){
  string text;
  if(option.Diagnostic)text=ReviewedDiagnostics.Detail(option.Id)+"\r\n\r\nCompatibilidade: Windows 10/11. Somente leitura; resultados no Histórico. Não altera configurações e não exige desfazer.\r\nFonte: "+ReviewedDiagnostics.Source(option.Id);
  else{
   // A ficha passou a vir do contrato único (OptimizationRegistry), que acrescenta o que
   // faltava aqui: nível de evidência, confiança separada do risco, estágio e o veredito
   // do motor de compatibilidade PARA ESTE PC — não mais a frase genérica "Windows 10/11".
   var item=App.ById(option.Id);var info=OptionInfo.For(item);
   text=String.Join("\r\n",item.Review??new string[0])+"\r\n\r\n"+OptimizationRegistry.Details(option.Id,profile)
    +"\r\n"+info.AutomaticReason+"\r\nPasta dos backups: "+App.RecordsRoot;
   if(profile==null)text+="\r\n\r\nEste PC ainda não foi analisado: clique em Analisar este PC para a compatibilidade deixar de ser \"Não detectado\".";
  }
  await InlineReview(option.Title,text,false);
 }
 bool HomeBulkSafe(HomeOption option){if(option.Diagnostic)return true;var item=App.ById(option.Id);return item!=null&&ExtremeProfile.Groups().Where(g=>g.Selected).SelectMany(g=>g.Items).Contains(option.Id)&&ExtremeProfile.IsReviewed(item);}
 // "Selecionar tudo" marca o que está VISÍVEL no filtro atual: marcar em silêncio uma
 // opção que a pessoa não pode ver foi o que tornou a página escondida perigosa.
 // O teste de diagnóstico passa a usar HomeOption.Diagnostic; o antigo Text.Contains
 // ("Diagnóstico") nunca casava, porque nenhum título de diagnóstico contém a palavra.
 void SetHomeSelection(bool selected){
  homeSync=true;
  foreach(var pair in homeChecks){
   var option=homeOptions[pair.Key];
   var item=option.Diagnostic?null:App.ById(pair.Key);
   var info=item==null?null:OptionInfo.For(item);
   pair.Value.Checked=selected&&item!=null&&!hiddenHome.Contains(pair.Key)
    &&info!=null&&ExtremeProfile.IsReviewed(item)&&info.Classification!="Manual";
  }
  homeSync=false;UpdateHome();
 }
 void UpdateHome(){if(homeCount==null)return;bool enabled=ready&&machine.Windows&&!busy&&!scanning&&!resourceScanning&&!easyRunning;
  foreach(var check in homeChecks.Values)check.Enabled=enabled;
  foreach(var button in homeActions)button.Enabled=enabled;
  homeAdvanced.Enabled=!busy&&!scanning&&!resourceScanning&&!easyRunning;
  homeCount.Text=homeChecks.Count(x=>x.Value.Checked)+" selecionadas";
  var applyButton=homeActions.FirstOrDefault(b=>b.Name=="home-apply");if(applyButton!=null)applyButton.Enabled=enabled&&homeChecks.Any(x=>x.Value.Checked);
  var undoButton=homeActions.FirstOrDefault(b=>b.Name=="home-undo");if(undoButton!=null)undoButton.Enabled=enabled&&records.Any(App.CanUndo);
  var restoreButton=homeActions.FirstOrDefault(b=>b.Name=="home-restore-selection");if(restoreButton!=null)restoreButton.Enabled=enabled&&records.Any(App.CanUndo)&&HomePayload(false).Length>0;
 }
 string[] ResolveHomeConflicts(IEnumerable<string> ids){var accepted=new List<Item>();foreach(string id in ids.Distinct()){var item=App.ById(id);if(item==null)continue;try{App.UniqueOperations(accepted.Concat(new[]{item}));accepted.Add(item);}catch{}}return accepted.Select(i=>i.Id).ToArray();}
 // Conjunto do botão Ultra: os itens dos grupos MARCADOS de ExtremeProfile.
 // Antes era "todo item que passa em IsReviewed", o que incluía native-power — cujo
 // grupo "Energia para desempenho" vem desmarcado — e dezenas de opções que a tela de
 // perfil não anuncia. OptionInfo.Automatic sempre leu os grupos; agora as duas
 // respostas coincidem, que é o que UnifiedUiTests já exigia.
 internal static string[] ExtremeIds(){
  var ids=new List<string>();
  foreach(var group in ExtremeProfile.Groups()){
   if(!group.Selected)continue;
   foreach(string id in group.Items){
    string canonical=CatalogIds.Canonical(id);
    var item=App.ById(canonical);
    if(item!=null&&ExtremeProfile.IsReviewed(item))ids.Add(canonical);
   }
  }
  return ids.ToArray();
 }
 internal string[] HomePayload(bool extreme){var selected=homeChecks.Where(x=>x.Value.Checked&&!homeOptions[x.Key].Diagnostic).Select(x=>x.Key);
  if(!extreme)return ResolveHomeConflicts(selected);return ResolveHomeConflicts(ExtremeIds());
 }
 async Task RunHome(bool extreme){
  if(busy||scanning||resourceScanning||easyRunning||!machine.Windows)return;
  string[] ids=HomePayload(extreme),diagnostics=extreme?new string[0]:homeChecks.Where(x=>x.Value.Checked&&homeOptions[x.Key].Diagnostic).Select(x=>x.Key).ToArray();
  if(ids.Length==0&&diagnostics.Length==0)return;
#if TESTS
  if(TestHomeApply!=null){await TestHomeApply(extreme,ids,diagnostics);return;}
#endif
  string review=String.Join("\r\n",ids.Select(id=>"• "+App.ById(id).ReviewTitle).Concat(diagnostics.Select(id=>"• "+ReviewedDiagnostics.Title(id))));
  string policy="Cada ajuste tem backup, verificação e restauração individual em caso de falha. Valores sem permissão são ignorados; os demais continuam. Desfazer restaura os ajustes aplicados deste conjunto. Diagnósticos fazem somente leitura.";
  var manual=ids.Select(App.ById).Where(i=>OptionInfo.For(i).Classification=="Manual"||OptionInfo.For(i).Risk!="Baixo").ToList();
  if(manual.Count>0)review+="\r\n\r\nOPÇÕES MANUAIS / COM RISCO\r\n"+String.Join("\r\n\r\n",manual.Select(i=>i.ReviewTitle+": "+String.Join(" ",i.Review??new string[0])));
  if(!await InlineReview(extreme?"Otimização extrema":"Aplicar selecionadas",review+"\r\n\r\n"+policy,true))return;
  if(ids.Length>0&&!await Elevated(extreme?"--extreme":"--apply-many",String.Join(",",ids)))return;
  if(diagnostics.Length>0){busy=true;SetActions();try{foreach(string id in diagnostics){footer.Text=ReviewedDiagnostics.Title(id)+"…";await Task.Run(()=>App.RunReviewedDiagnostic(id));}}finally{busy=false;RefreshHistory();SetActions();ShowPage("Histórico");}}
 }
 async Task HomeUndoClick(){
#if TESTS
  if(TestHomeUndo!=null){TestHomeUndo();return;}
#endif
  try{await Elevated("--undo-last","");}catch(Exception error){footer.Text=ErrorHelp.For(error).FriendlyError;}
 }
 async Task RunGamingSessionProfile(){
  if(busy||scanning||resourceScanning||easyRunning||!machine.Windows)return;
  string[] ids={"native-gamemode","native-capture","native-power"};
  homeSync=true;
  foreach(var pair in homeChecks){pair.Value.Checked=ids.Contains(pair.Key);}
  homeSync=false;UpdateHome();await RunHome(false);
 }
 async Task RunQuickProfile(){
  if(busy||scanning||resourceScanning||easyRunning||!machine.Windows)return;
  homeSync=true;
  foreach(var pair in homeChecks){var option=homeOptions[pair.Key];if(option.Diagnostic){pair.Value.Checked=false;continue;}var item=App.ById(pair.Key);var info=item==null?null:OptionInfo.For(item);pair.Value.Checked=item!=null&&item.DefaultSelected&&info.Risk=="Baixo"&&info.Automatic;}
  homeSync=false;UpdateHome();await RunHome(false);
 }
 async Task RunUltraProfile(){
  if(busy||scanning||resourceScanning||easyRunning||!machine.Windows)return;
  // Deixa a tela mostrar exatamente o que o perfil vai aplicar, em vez de marcar tudo
  // e aplicar outra coisa. A prévia de RunHome lista o mesmo conjunto.
  var ids=new HashSet<string>(ExtremeIds(),StringComparer.Ordinal);
  homeSync=true;
  foreach(var pair in homeChecks)pair.Value.Checked=ids.Contains(pair.Key);
  homeSync=false;UpdateHome();
  await RunHome(true);
 }
 void PopulateToolDirectory(FlowLayoutPanel flow){
  var title=Theme.Label("Ferramentas integradas · opções e BATs revisados",11,Theme.Accent,true);title.Width=700;title.Height=30;flow.Controls.Add(title);
  var note=Theme.Label("",1,Theme.Bg);note.Width=1;note.Height=1;
  foreach(var script in ImportedScripts.All){var review=script;var button=Theme.Button(review.Name+" · "+review.Status);button.Name="tool-review-"+review.Id;button.Width=220;button.Height=40;button.Margin=new Padding(0,0,10,10);button.Click+=(s,e)=>TextDialog("Revisão — "+review.Name,"Status: "+review.Status+"\r\nIntegração: "+review.Integration+"\r\nHash: "+review.Hash+"\r\n\r\nAchados:\r\n"+String.Join("\r\n",review.Findings??new string[0])+"\r\n\r\nConteúdo preservado:\r\n"+review.Text);flow.Controls.Add(button);}
  foreach(var target in pages.Keys.Where(k=>k!="Otimizações"&&k!="Ferramentas"&&k!="Histórico").ToArray()){string name=target;var button=Theme.Button(name);button.Width=190;button.Height=48;button.Margin=new Padding(0,0,10,10);button.Click+=(s,e)=>ShowPage(name);flow.Controls.Add(button);}
 }
 void BuildToolDirectory(){var page=Page("Ferramentas");var flow=new FlowLayoutPanel{Dock=DockStyle.Fill,AutoScroll=true,Padding=new Padding(0,8,0,0)};page.Controls.Add(flow);PopulateToolDirectory(flow);}
}

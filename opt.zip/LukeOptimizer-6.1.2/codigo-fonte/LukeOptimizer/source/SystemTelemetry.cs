﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.Management;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Threading;

public class MemorySnapshot {
 public long TotalBytes {get;set;} public long AvailableBytes {get;set;} public long UsedBytes {get;set;}
 public long CacheBytes {get;set;} public long CommitBytes {get;set;} public long CommitLimitBytes {get;set;}
 public long? FreeBytes {get;set;} public long? StandbyBytes {get;set;} public long? CompressedBytes {get;set;}
 public int Handles {get;set;} public int Processes {get;set;} public int Threads {get;set;}
 public string Note {get;set;}
}
public class TelemetrySnapshot {
 public string Time {get;set;} public MemorySnapshot Memory {get;set;} public double? CpuPercent {get;set;}
 public double? NetworkReceiveBytesPerSecond {get;set;} public double? NetworkSendBytesPerSecond {get;set;}
 public string Storage {get;set;} public string PowerPlan {get;set;} public string Gpu {get;set;} public string Sensors {get;set;}
 public int? StartupCount {get;set;} public string StartupCoverage {get;set;} public bool? RestartPending {get;set;}
 public List<ProcessToken> TopProcesses {get;set;} public string Note {get;set;} public int? HealthScore {get;set;} public string HealthExplanation {get;set;}
}
static class SystemTelemetry {
 [StructLayout(LayoutKind.Sequential)] struct PerformanceInfo {
  public uint Size;public UIntPtr CommitTotal,CommitLimit,CommitPeak,PhysicalTotal,PhysicalAvailable,SystemCache,KernelTotal,KernelPaged,KernelNonpaged,PageSize;public uint HandleCount,ProcessCount,ThreadCount;
 }
 [DllImport("psapi.dll",SetLastError=true)] static extern bool GetPerformanceInfo(out PerformanceInfo info,uint size);
 internal static MemorySnapshot Memory(){
  PerformanceInfo p;if(!GetPerformanceInfo(out p,(uint)Marshal.SizeOf(typeof(PerformanceInfo))))throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
  long page=checked((long)p.PageSize.ToUInt64());Func<UIntPtr,long> bytes=v=>checked((long)v.ToUInt64()*page);
  return new MemorySnapshot{TotalBytes=bytes(p.PhysicalTotal),AvailableBytes=bytes(p.PhysicalAvailable),UsedBytes=bytes(p.PhysicalTotal)-bytes(p.PhysicalAvailable),CacheBytes=bytes(p.SystemCache),CommitBytes=bytes(p.CommitTotal),CommitLimitBytes=bytes(p.CommitLimit),Handles=(int)p.HandleCount,Processes=(int)p.ProcessCount,Threads=(int)p.ThreadCount,Note="Disponível inclui memória livre e standby reutilizável. Cache inclui standby e working set do sistema; não some essas categorias. Livre, standby e comprimida só aparecem quando o provedor os informar."};
 }
 internal static void OptionalMemory(MemorySnapshot m){try{
  using(var search=new ManagementObjectSearcher("root\\cimv2","SELECT * FROM Win32_PerfFormattedData_PerfOS_Memory")){search.Options.Timeout=TimeSpan.FromSeconds(2);using(var rows=search.Get())foreach(ManagementObject row in rows)using(row){
   long? core=Value(row,"StandbyCacheCoreBytes"),normal=Value(row,"StandbyCacheNormalPriorityBytes"),reserve=Value(row,"StandbyCacheReserveBytes");
   if(core.HasValue&&normal.HasValue&&reserve.HasValue)m.StandbyBytes=core+normal+reserve;
   m.FreeBytes=Value(row,"FreeAndZeroPageListBytes");break;
  }}
 }catch(Exception e){m.Note+=" Contadores opcionais indisponíveis: "+e.Message;}}
 static long? Value(ManagementObject row,string name){try{var property=row.Properties.Cast<PropertyData>().FirstOrDefault(p=>p.Name==name);return property==null||property.Value==null?(long?)null:Convert.ToInt64(property.Value);}catch{return null;}}
 static DateTime gpuTime=DateTime.MinValue;static string gpuCache="Não consultada";static readonly object HardwareGate=new object();
 internal static string Gpu(){lock(HardwareGate){if(DateTime.UtcNow-gpuTime<TimeSpan.FromMinutes(2))return gpuCache;try{var names=new List<string>();using(var search=new ManagementObjectSearcher("SELECT Name,DriverVersion,ConfigManagerErrorCode FROM Win32_VideoController")){search.Options.Timeout=TimeSpan.FromSeconds(3);using(var rows=search.Get())foreach(ManagementObject row in rows)using(row)names.Add(row["Name"]+" · driver "+row["DriverVersion"]+" · código do dispositivo "+row["ConfigManagerErrorCode"]);}gpuCache=names.Count==0?"GPU não detectada":String.Join(Environment.NewLine,names);}catch(Exception e){gpuCache="GPU não disponível: "+e.Message;}gpuTime=DateTime.UtcNow;return gpuCache;}}
 static Dictionary<string,long[]> Network(){var result=new Dictionary<string,long[]>();foreach(var adapter in NetworkInterface.GetAllNetworkInterfaces().Where(n=>n.OperationalStatus==OperationalStatus.Up&&n.NetworkInterfaceType!=NetworkInterfaceType.Loopback))try{var s=adapter.GetIPStatistics();result[adapter.Id]=new[]{s.BytesReceived,s.BytesSent};}catch{}return result;}
 internal static TelemetrySnapshot Read(CancellationToken token){
  var t=new TelemetrySnapshot{Time=DateTime.Now.ToString("G"),Sensors="Temperatura e uso de GPU: provedor confiável não integrado; leitura indisponível.",StartupCoverage="Entradas Run do usuário e da máquina + pastas Inicializar. Tarefas agendadas não estão incluídas.",TopProcesses=new List<ProcessToken>()};
  var notes=new List<string>();var network=Network();var clock=Stopwatch.StartNew();
  try{var sample=ResourceMonitor.Measure(400);if(sample.CpuKnown)t.CpuPercent=sample.CpuPercent;}catch(Exception e){notes.Add(e.Message);}
  if(token.IsCancellationRequested)return t;
  try{t.Memory=Memory();OptionalMemory(t.Memory);}catch(Exception e){notes.Add(e.Message);}
  try{t.TopProcesses=ResourceMonitor.ScanProcesses().OrderByDescending(p=>p.MemoryMB).Take(12).ToList();}catch(Exception e){notes.Add(e.Message);}
  var after=Network();double elapsed=clock.Elapsed.TotalSeconds;var stable=network.Keys.Intersect(after.Keys).Where(k=>after[k][0]>=network[k][0]&&after[k][1]>=network[k][1]).ToArray();
  if(stable.Length>0&&elapsed>0){t.NetworkReceiveBytesPerSecond=stable.Sum(k=>after[k][0]-network[k][0])/elapsed;t.NetworkSendBytesPerSecond=stable.Sum(k=>after[k][1]-network[k][1])/elapsed;}
  try{t.Storage=String.Join(Environment.NewLine,DriveInfo.GetDrives().Where(d=>d.DriveType==DriveType.Fixed&&d.IsReady).Select(d=>d.Name+" · "+Format(d.AvailableFreeSpace)+" livres / "+Format(d.TotalSize)+" totais"));}catch(Exception e){notes.Add(e.Message);}
  try{t.PowerPlan=App.ActivePlan();}catch(Exception e){t.PowerPlan="Não disponível: "+e.Message;}
  try{t.StartupCount=StartupCount();}catch(Exception e){notes.Add("Inicialização: "+e.Message);}
  t.Gpu=Gpu();t.RestartPending=PlatformSnapshot.PendingRestart();t.Note=String.Join(Environment.NewLine,notes);
  Score(t);return t;
 }
 internal static void Score(TelemetrySnapshot t){
  if(t.Memory==null||t.Memory.TotalBytes<=0||!t.CpuPercent.HasValue||!t.RestartPending.HasValue){t.HealthScore=null;t.HealthExplanation="Leituras insuficientes. Não há pontuação estimada.";return;}
  double available=100.0*t.Memory.AvailableBytes/t.Memory.TotalBytes;int ram=available<10?30:available<20?15:0,cpu=t.CpuPercent.Value>90?20:0,reboot=t.RestartPending==true?10:0;
  t.HealthScore=100-ram-cpu-reboot;t.HealthExplanation="Indicador momentâneo, não benchmark: 100 − "+ram+" (RAM disponível <10%:30; <20%:15) − "+cpu+" (CPU >90%:20) − "+reboot+" (reinício pendente:10). Não avalia segurança, vida útil do SSD, drivers ou FPS.";
 }
 internal static int StartupCount(){int count=0;foreach(var hive in new[]{Microsoft.Win32.RegistryHive.CurrentUser,Microsoft.Win32.RegistryHive.LocalMachine})using(var root=Microsoft.Win32.RegistryKey.OpenBaseKey(hive,Microsoft.Win32.RegistryView.Registry64))using(var key=root.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run"))if(key!=null)count+=key.ValueCount;foreach(var folder in new[]{Environment.SpecialFolder.Startup,Environment.SpecialFolder.CommonStartup}){string path=Environment.GetFolderPath(folder);if(Directory.Exists(path))count+=Directory.GetFiles(path).Count(p=>!Path.GetFileName(p).Equals("desktop.ini",StringComparison.OrdinalIgnoreCase));}return count;}
 internal static string Format(long bytes){return (bytes/(1024.0*1024*1024)).ToString("0.00")+" GB";}
 internal static string Format(long? bytes){return bytes.HasValue?Format(bytes.Value):"Não disponível";}
}
public class MemoryAction {
 public int Pid {get;set;} public string Name {get;set;} public string State {get;set;} public string Message {get;set;}
 public long? BeforeBytes {get;set;} public long? AfterBytes {get;set;} public string ErrorCode {get;set;}
}
static class MemoryManager {
 [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint access,bool inherit,int pid);
 [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
 [DllImport("psapi.dll",SetLastError=true)] static extern bool EmptyWorkingSet(IntPtr process);
 internal static List<MemoryAction> Trim(IEnumerable<ProcessToken> selection,bool simulate,CancellationToken cancel){
  var results=new List<MemoryAction>();var seen=new HashSet<int>();
  foreach(var chosen in selection){if(cancel.IsCancellationRequested)break;if(!seen.Add(chosen.Pid))continue;
   var r=new MemoryAction{Pid=chosen.Pid,Name=chosen.Name,State="ignorada",ErrorCode="PROCESS_PROTECTED"};results.Add(r);
   try{using(var process=Process.GetProcessById(chosen.Pid)){
    var current=ResourceMonitor.Identify(process);
    if(!ResourceMonitor.SameIdentity(chosen,current))throw new InvalidOperationException("O processo mudou desde a análise. Atualize a lista.");
    int own,session;using(var self=Process.GetCurrentProcess()){own=self.Id;session=self.SessionId;}
    string protect=ResourceMonitor.Protection(current,own,session,Environment.GetFolderPath(Environment.SpecialFolder.Windows));
    if(!String.IsNullOrEmpty(protect)){r.Message=protect;continue;}
    r.BeforeBytes=process.WorkingSet64;if(simulate){r.State="não executada";r.ErrorCode="SIMULATION";r.Message="Identidade e permissões de seleção verificadas; nenhuma página removida.";continue;}
    IntPtr handle=OpenProcess(0x1000|0x0100,false,chosen.Pid);if(handle==IntPtr.Zero)throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
    try{if(process.HasExited||process.StartTime.ToUniversalTime().Ticks!=chosen.Started)throw new InvalidOperationException("O processo terminou ou mudou.");if(!EmptyWorkingSet(handle))throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());}finally{CloseHandle(handle);}
    process.Refresh();r.AfterBytes=process.WorkingSet64;r.State="aplicada";r.ErrorCode="OK";r.Message="Working set solicitado ao Windows. O processo pode recarregar as páginas imediatamente. Isto não comprova ganho de desempenho e não possui rollback de páginas.";
   }}catch(Exception e){var failure=ErrorHelp.For(e);r.State=failure.State;r.ErrorCode=failure.ErrorCode;r.Message=failure.FriendlyError+" "+e.Message;}
  }return results;
 }
}

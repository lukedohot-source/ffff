using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

// CENTRAL DE REDE — o que a pessoa quer fazer, não o comando que faz.
//
// O backend já existia e já era testado: NetworkTools tem 6 ações numa allowlist fechada
// e 3 diagnósticos somente leitura. O que faltava era a tradução. Quem quer arrumar a
// internet procura "internet", não "netsh int ip reset".
//
// Cada entrada aqui é uma TAREFA com nome humano, composta de uma ou mais ações já
// auditadas. Os comandos reais continuam existindo e continuam visíveis — em Detalhes
// técnicos, que é onde quem quer auditar vai olhar.
//
// Nada aqui é botão vazio: toda tarefa aponta para ids que NetworkTools.Resolve aceita,
// e há teste conferindo isso. Uma tarefa que eu não soubesse implementar de verdade
// simplesmente não está nesta lista — trocar DNS, por exemplo, exige backup e
// restauração por adaptador e fica para quando isso existir, em vez de virar um botão
// que promete e não cumpre.
public class NetworkTask {
 public string Id="",Name="",Summary="",Detail="";
 public string[] Actions=new string[0];   // ids de NetworkTools.Actions()
 public string Diagnostic="";             // id de NetworkTools.Diagnostics
 public bool Disconnects,NeedsRestart,Administrator;
}

static class NetworkCenter {
 internal static List<NetworkTask> Tasks(){
  var tasks=new List<NetworkTask>{
   new NetworkTask{Id="net-task-refresh",Name="Limpar IP / Internet",
    Summary="Descarta o cache de nomes e pede um endereço novo ao roteador. É o primeiro a tentar quando um site não abre ou a conexão ficou estranha depois de trocar de rede.",
    Detail="Não acelera a internet e não muda a velocidade contratada. Serve para desfazer cache velho e endereço travado. A conexão cai por alguns segundos enquanto o endereço é renovado.",
    Actions=new[]{"net-flushdns","net-arp","net-renew"}},

   new NetworkTask{Id="net-task-repair",Name="Reparar conexão",
    Summary="Recoloca no padrão as camadas de rede do Windows. Use quando a internet parou de funcionar depois de um programa de VPN, proxy ou antivírus, e o resto já falhou.",
    Detail="Este é o passo pesado. Desfaz configurações que outros programas gravaram nas camadas de rede, o que pode desconfigurar VPN e proxy que você usa. EXIGE REINICIAR e NÃO tem desfazer automático — por isso a configuração atual é gravada no Histórico antes, e se essa gravação falhar a ação não executa.",
    Actions=new[]{"net-winsock","net-ipreset"}},

   new NetworkTask{Id="net-task-register",Name="Registrar nomes na rede",
    Summary="Pede ao Windows para anunciar de novo o nome deste PC na rede local. Ajuda quando o PC sumiu do compartilhamento de arquivos ou da impressora de rede.",
    Detail="Mexe apenas no registro de nomes desta máquina. Não altera IP, DNS nem nada da conexão com a internet.",
    Actions=new[]{"net-registerdns"}},

   new NetworkTask{Id="net-task-test",Name="Testar conexão",
    Summary="Mede perda de pacotes, tempo de resposta e variação entre respostas. É o número que importa para jogo e chamada de vídeo — mais do que a velocidade de download.",
    Detail="Somente leitura: não altera nada. Mede o caminho até o host escolhido AGORA. Não mede o servidor do seu jogo, não mede bufferbloat sob carga e não mede input lag.",
    Diagnostic="netdiag-quality"},

   new NetworkTask{Id="net-task-dns-info",Name="Ver servidores DNS",
    Summary="Mostra quais servidores DNS cada adaptador está usando e quanto tempo leva para alcançá-los.",
    Detail="Somente leitura: não troca DNS nenhum. E atenção ao que o número significa — ele mede o caminho de rede até o servidor, NÃO o tempo de resposta a uma consulta de nome. Um servidor pode ir mal no ping e resolver nomes rápido, ou simplesmente não responder a ping.",
    Diagnostic="netdiag-dns"},

   new NetworkTask{Id="net-task-mtu",Name="Descobrir tamanho máximo de pacote",
    Summary="Procura o maior pacote que atravessa a rede inteiro até o roteador, sem ser partido no caminho.",
    Detail="Somente leitura: NÃO altera o MTU. Muitos roteadores e firewalls descartam em silêncio o tipo de pacote usado nesta medição; nesse caso o resultado é inconclusivo e o app diz isso, em vez de chutar um número.",
    Diagnostic="netdiag-mtu"}
  };
  // As bandeiras vêm das ações reais, não de campo escrito à mão: se uma ação passar a
  // derrubar a conexão, o aviso da tarefa acompanha sozinho.
  foreach(var task in tasks){
   foreach(string id in task.Actions){
    var action=NetworkTools.Resolve(id);
    task.Disconnects=task.Disconnects||action.Disconnects;
    task.NeedsRestart=task.NeedsRestart||action.NeedsRestart;
    task.Administrator=task.Administrator||action.Administrator;
   }
  }
  return tasks;
 }

 internal static NetworkTask Resolve(string id){
  var found=Tasks().SingleOrDefault(t=>t.Id==id);
  if(found==null)throw new ArgumentException("Tarefa de rede desconhecida: "+id);
  return found;
 }
 internal static bool IsRead(NetworkTask task){return task!=null&&task.Actions.Length==0&&task.Diagnostic.Length>0;}

 // Texto de confirmação, em português comum primeiro e comando depois.
 internal static string Confirmation(NetworkTask task){
  var b=new StringBuilder();
  b.AppendLine(task.Summary).AppendLine();
  b.AppendLine(task.Detail).AppendLine();
  if(task.Disconnects)b.AppendLine("A CONEXÃO PODE CAIR durante a execução. Feche downloads, chamadas e partidas antes.");
  if(task.NeedsRestart)b.AppendLine("EXIGE REINICIAR o computador depois.");
  if(task.Actions.Length>0){
   b.AppendLine("Esta tarefa NÃO tem desfazer automático.").AppendLine();
   b.AppendLine("O que será executado, nesta ordem:");
   foreach(string id in task.Actions){var a=NetworkTools.Resolve(id);b.AppendLine("· "+a.Name+" — "+a.Effect);}
   b.AppendLine();
  }
  b.AppendLine("Executar agora?");
  return b.ToString();
 }

 // Detalhes técnicos: comando exato, tempo limite, se precisa de administrador e fonte.
 // É aqui — e só aqui — que ipconfig e netsh aparecem.
 internal static string Technical(NetworkTask task){
  var b=new StringBuilder();
  b.AppendLine(task.Name).AppendLine();
  b.AppendLine(task.Summary).AppendLine();
  b.AppendLine("O que acontece por baixo:").AppendLine();
  foreach(string id in task.Actions){
   var a=NetworkTools.Resolve(id);
   b.AppendLine("Comando:  "+a.Executable+" "+a.Arguments);
   b.AppendLine("  Efeito: "+a.Effect);
   b.AppendLine("  Custo:  "+a.Tradeoff);
   b.AppendLine("  Limite: "+a.TimeoutSeconds+" s    Administrador: "+(a.Administrator?"sim":"não"));
   if(!String.IsNullOrEmpty(a.BackupArguments))b.AppendLine("  Backup antes: "+a.Executable+" "+a.BackupArguments+" (gravado no Histórico; se falhar, a alteração não executa)");
   b.AppendLine("  Fonte:  "+a.Source);
   b.AppendLine();
  }
  if(task.Diagnostic.Length>0){
   b.AppendLine("Leitura: "+NetworkTools.DiagnosticTitle(task.Diagnostic));
   b.AppendLine(NetworkTools.DiagnosticDetail(task.Diagnostic));
   b.AppendLine();
   b.AppendLine("Nenhuma configuração é alterada por esta leitura.");
  }
  return b.ToString();
 }
}

using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

class ReadableCheckBox : CheckBox {
 internal ReadableCheckBox(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);}
 protected override void OnPaint(PaintEventArgs e){
  e.Graphics.Clear(BackColor);int size=Math.Max(20,(int)(20*e.Graphics.DpiX/96));var box=new Rectangle(0,(Height-size)/2,size,size);
  Theme.DrawCheck(e.Graphics,box,Checked,Enabled);
  TextRenderer.DrawText(e.Graphics,Text,Font,new Rectangle(size+8,0,Math.Max(1,Width-size-8),Height),Enabled?ForeColor:Theme.Muted,TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);
  if(Focused)ControlPaint.DrawFocusRectangle(e.Graphics,ClientRectangle,Theme.Text,BackColor);
 }
}
class FramePlot : Control {
 internal FrameSummary Before,After;
 internal FramePlot(){DoubleBuffered=true;BackColor=Theme.Card;Dock=DockStyle.Fill;MinimumSize=new Size(200,130);}
 protected override void OnPaint(PaintEventArgs e){
  base.OnPaint(e);var g=e.Graphics;g.Clear(Theme.Card);var area=new Rectangle(58,27,Math.Max(1,Width-77),Math.Max(1,Height-60));
  var all=new[]{Before,After}.Where(s=>s!=null).ToArray();
  if(all.Length==0){TextRenderer.DrawText(g,"Importe suas capturas para ver os picos de frametime.",Theme.Font(10),ClientRectangle,Theme.Muted,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);return;}
  double top=Math.Max(10,all.Max(s=>s.Max));
  using(var pen=new Pen(Theme.Line))for(int i=0;i<=4;i++){int y=area.Bottom-i*area.Height/4;g.DrawLine(pen,area.Left,y,area.Right,y);TextRenderer.DrawText(g,(top*i/4).ToString("0.#"),Font,new Point(3,y-8),Theme.Muted);}
  foreach(var s in all){var values=s.Timeline;int bins=Math.Min(area.Width,values.Length);var points=new PointF[bins];
   for(int i=0;i<bins;i++){int start=i*values.Length/bins,end=Math.Max(start+1,(i+1)*values.Length/bins);double max=0;for(int n=start;n<end;n++)max=Math.Max(max,values[n]);points[i]=new PointF(area.Left+(float)i*area.Width/Math.Max(1,bins-1),area.Bottom-(float)(max/top*area.Height));}
   if(points.Length>1)using(var pen=new Pen(s==Before?Theme.Blue:Theme.Accent,1.5f))g.DrawLines(pen,points);
  }
  TextRenderer.DrawText(g,"ms · azul: antes · roxo: depois · cada coluna preserva o pior intervalo",Font,new Point(area.Left,6),Theme.Muted);
  TextRenderer.DrawText(g,"0%                  Progresso de cada captura (quadros)                  100%",Font,new Rectangle(area.Left,area.Bottom+7,area.Width,23),Theme.Muted,TextFormatFlags.HorizontalCenter);
 }
}
public partial class MainForm {
 List<PerformanceEntry> performanceEntries;ListView performanceList;TextBox performanceSearch,performanceDetail;ComboBox performanceCategory,performanceMode;
 ActionButton performanceAction;Label performanceCount;
 ComboBox gameList;TextBox gameName,gamePath,gameNotes,gameExplanation;NumericUpDown gameFps;CheckBox gameGpu,gameFullscreen;
 string editingGameId;string[] gameApps=new string[0];
 readonly Dictionary<string,CheckBox> powerChecks=new Dictionary<string,CheckBox>();readonly Dictionary<string,Label> powerStates=new Dictionary<string,Label>();string powerScheme;
 Label powerHeading;TextBox labReport,networkHost,networkReport;CancellationTokenSource labCancel;ActionButton cancelLab;
 FrameSummary beforeFrames,afterFrames;FramePlot framePlot;TextBox frameText;NumericUpDown frameTarget,frameWarmup;
 TextBox Field(){return new TextBox{Dock=DockStyle.Fill,BackColor=Theme.Card,ForeColor=Theme.Text,BorderStyle=BorderStyle.FixedSingle,Font=Theme.Font(11)};}
 FlowLayoutPanel ActionRow(){return new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false,AutoScroll=true,Margin=Padding.Empty};}
 ActionButton V4Button(string text,EventHandler click,bool primary=false,int width=185){var button=ExtraButton(text,click,primary,width);button.Height=34;button.Margin=new Padding(0,0,8,0);return button;}
 void ScrollPage(Panel page,TableLayoutPanel content,int minimum){page.AutoScroll=true;content.Dock=DockStyle.Top;content.Height=Math.Max(minimum,page.ClientSize.Height);page.Resize+=(s,e)=>content.Height=Math.Max(minimum,page.ClientSize.Height);}
 void BuildPerformance(){BuildLibrary();BuildGames();BuildPowerLab();BuildFrames();BuildHardwareLab();}
 void BuildLibrary(){
  performanceEntries=PerformanceLibrary.Load();var page=Page("Central de desempenho");var root=Rows(102,46,-1,190,56);page.Controls.Add(root);ScrollPage(page,root,630);
  var hero=Box();hero.Padding=new Padding(16,10,16,10);hero.Fill=Color.FromArgb(35,32,57);root.Controls.Add(hero,0,0);
  var intro=Rows(35,-1);hero.Controls.Add(intro);performanceCount=Theme.Label("Seu próximo ganho começa pelo gargalo.",20,Theme.Accent,true);intro.Controls.Add(performanceCount,0,0);
  intro.Controls.Add(Theme.Label(performanceEntries.Count+" opções e ferramentas · FPS, latência, RAM, CPU, GPU, disco e rede\r\nCada item indica se aplica um ajuste, abre uma ferramenta ou oferece orientação.",10,Theme.Text),0,1);
  var filters=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=3};filters.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));filters.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,200));filters.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,220));root.Controls.Add(filters,0,1);
  performanceSearch=Field();performanceSearch.AccessibleName="Pesquisar otimizações";performanceSearch.Margin=new Padding(0,0,10,8);filters.Controls.Add(performanceSearch,0,0);
  performanceCategory=Combo();performanceCategory.Dock=DockStyle.Fill;performanceCategory.Items.Add("Todas as áreas");performanceCategory.Items.AddRange(performanceEntries.Select(x=>x.Category).Distinct().OrderBy(x=>x).ToArray());performanceCategory.SelectedIndex=0;filters.Controls.Add(performanceCategory,1,0);
  performanceMode=Combo();performanceMode.Dock=DockStyle.Fill;performanceMode.Items.AddRange(new object[]{"Todos os tipos","Aplicável com backup","Ferramenta no app","Guias / ferramentas externas"});performanceMode.SelectedIndex=0;filters.Controls.Add(performanceMode,2,0);
  performanceList=CheckList("Opção / ferramenta","Área","Como funciona");performanceList.CheckBoxes=false;performanceList.Columns[0].Width=410;performanceList.Columns[1].Width=180;performanceList.Columns[2].Width=220;root.Controls.Add(performanceList,0,2);
  performanceDetail=Theme.ReadBox();performanceDetail.Margin=new Padding(12);root.Controls.Add(performanceDetail,0,3);
  var actions=ActionRow();root.Controls.Add(actions,0,4);performanceAction=V4Button("Abrir opção",async(s,e)=>await RunPerformanceEntry(),true,210);actions.Controls.Add(performanceAction);
  actions.Controls.Add(V4Button("Ler fonte oficial",(s,e)=>{var item=ChosenPerformance();if(item!=null)OpenUrl(item.Source);},false,170));
  actions.Controls.Add(V4Button("Comparar meu desempenho",(s,e)=>ShowPage("FPS e stutter"),false,250));
  performanceSearch.TextChanged+=(s,e)=>FilterPerformance();performanceCategory.SelectedIndexChanged+=(s,e)=>FilterPerformance();performanceMode.SelectedIndexChanged+=(s,e)=>FilterPerformance();
  performanceList.SelectedIndexChanged+=(s,e)=>{var item=ChosenPerformance();if(item==null)return;performanceDetail.Text=PerformanceLibrary.Describe(item);performanceAction.Text=item.Action=="native"?"Aplicar ajuste…":item.Action=="link"?"Abrir guia oficial":"Abrir opção";};FilterPerformance();
 }
 PerformanceEntry ChosenPerformance(){return performanceList.SelectedItems.Count==0?null:(PerformanceEntry)performanceList.SelectedItems[0].Tag;}
 void FilterPerformance(){
  string q=performanceSearch.Text.Trim(),cat=performanceCategory.SelectedItem as string,mode=performanceMode.SelectedItem as string;performanceList.BeginUpdate();performanceList.Items.Clear();
  foreach(var x in performanceEntries.Where(x=>(cat=="Todas as áreas"||x.Category==cat)&&(mode=="Todos os tipos"||x.Mode==mode||(mode=="Guias / ferramentas externas"&&x.Mode!="Aplicável com backup"&&x.Mode!="Ferramenta no app"))&&
   (q.Length==0||(x.Title+" "+x.Category+" "+x.Effect+" "+x.Steps).IndexOf(q,StringComparison.OrdinalIgnoreCase)>=0))){var row=new ListViewItem(x.Title){Tag=x};row.SubItems.Add(x.Category);row.SubItems.Add(x.Mode);performanceList.Items.Add(row);}
  performanceList.EndUpdate();if(performanceList.Items.Count>0)performanceList.Items[0].Selected=true;else performanceDetail.Text="Nenhuma opção encontrada. Tente outra palavra ou área.";
 }
 async Task RunPerformanceEntry(){
  var entry=ChosenPerformance();if(entry==null)return;
  if(entry.Action=="native"){
   var item=App.Items.Single(x=>x.Id==entry.Target);if(!await Confirm(item.Name+"\r\n\r\n"+entry.Effect+"\r\n"+entry.Tradeoff+"\r\n\r\n"+((item.Operations??new RegOp[0]).Any(o=>o.Hive=="HKEY_LOCAL_MACHINE")?"Escopo: computador, incluindo outros usuários.":"Escopo: preferências desta conta.")+"\r\nSalvar backup e aplicar agora?"))return;await Elevated("--apply",item.Id);
  }else if(entry.Action=="page"){ShowPage(entry.Target);if(entry.Target=="Energia avançada")await ReadPowerOptions();}
  else if(entry.Action=="settings")OpenLocal(entry.Target);
  else if(entry.Action=="system"){if(entry.Target=="reliability")OpenSystem("perfmon.exe","/rel");else if(entry.Target.EndsWith(".msc"))OpenSystem("mmc.exe",App.Quote(App.SystemExe(entry.Target)));else OpenSystem(entry.Target,"");}
  else if(entry.Action=="link")OpenUrl(entry.Source);
  else if(entry.Action=="catalog"){ShowPage("Catálogo");search.Text=entry.Target;RefreshCatalog();}
 }
 void BuildGames(){
  var page=Page("Perfis de jogos");var root=Rows(64,47,38,47,43,47,83,-1,56);page.Controls.Add(root);ScrollPage(page,root,610);
  root.Controls.Add(Theme.Label("Preferências por executável, lista de apps dispensáveis e notas do seu teste.\r\nSalvar organiza o perfil. Aplicar altera apenas as duas opções marcadas de GPU/compatibilidade.",10,Theme.Muted),0,0);
  var select=ActionRow();root.Controls.Add(select,0,1);gameList=Combo();gameList.Width=320;select.Controls.Add(gameList);select.Controls.Add(V4Button("Novo perfil",(s,e)=>NewGame(),false,135));select.Controls.Add(V4Button("Salvar perfil",(s,e)=>SaveGameUi(),false,145));
  gameName=Field();gameName.AccessibleName="Nome do jogo";root.Controls.Add(gameName,0,2);
  var path= new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2};path.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));path.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,160));root.Controls.Add(path,0,3);gamePath=Field();gamePath.ReadOnly=true;gamePath.AccessibleName="Executável do jogo";path.Controls.Add(gamePath,0,0);path.Controls.Add(V4Button("Escolher .exe",(s,e)=>{using(var d=new OpenFileDialog{Filter="Executável do jogo|*.exe",Title="Selecione o executável do jogo (não o launcher)"})if(d.ShowDialog(this)==DialogResult.OK){gamePath.Text=d.FileName;if(gameName.Text=="Novo jogo")gameName.Text=Path.GetFileNameWithoutExtension(d.FileName);}},false,150),1,0);
  var settings=ActionRow();root.Controls.Add(settings,0,4);gameGpu=new CheckBox{Text="Preferir GPU de alto desempenho",AutoSize=true,ForeColor=Theme.Text,Margin=new Padding(0,8,24,0)};gameFullscreen=new CheckBox{Text="Teste A/B: desativar otimizações de tela cheia",AutoSize=true,ForeColor=Theme.Amber,Margin=new Padding(0,8,0,0)};settings.Controls.Add(gameGpu);settings.Controls.Add(gameFullscreen);
  var fps=ActionRow();root.Controls.Add(fps,0,5);var label=Theme.Label("FPS alvo (anotação)",10,Theme.Text);label.Dock=DockStyle.None;label.Width=170;label.Height=35;fps.Controls.Add(label);gameFps=new NumericUpDown{Minimum=0,Maximum=1000,Value=144,Width=90,BackColor=Theme.Card,ForeColor=Theme.Text};fps.Controls.Add(gameFps);
  fps.Controls.Add(V4Button("Guardar apps marcados",(s,e)=>{gameApps=CheckedProcesses().Select(p=>p.Name).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();UpdateGameExplanation();},false,215));fps.Controls.Add(V4Button("Escolher apps",(s,e)=>ShowPage("Apps e RAM"),false,150));
  gameExplanation=Theme.ReadBox();root.Controls.Add(gameExplanation,0,6);gameNotes=Field();gameNotes.Multiline=true;gameNotes.ScrollBars=ScrollBars.Vertical;gameNotes.AccessibleName="Notas: resolução, preset, VRR, Reflex e resultados";root.Controls.Add(gameNotes,0,7);
  var actions=ActionRow();root.Controls.Add(actions,0,8);actions.Controls.Add(V4Button("Aplicar preferências…",async(s,e)=>await ApplyGameUi(),true,217));
  actions.Controls.Add(V4Button("Preparar apps…",async(s,e)=>await PrepareGameApps(),false,175));actions.Controls.Add(V4Button("Gráficos do Windows",(s,e)=>OpenLocal("ms-settings:display-advancedgraphics"),false,202));actions.Controls.Add(V4Button("Medir resultado",(s,e)=>ShowPage("FPS e stutter"),false,160));
  gameList.SelectedIndexChanged+=(s,e)=>{var p=gameList.SelectedItem as GameProfile;if(p!=null)FillGame(p);};ReloadGames(null);NewGame();
 }
 void UpdateGameExplanation(){gameExplanation.Text="Apps guardados: "+(gameApps.Length==0?"nenhum":String.Join(", ",gameApps))+"\r\nFPS alvo é uma anotação, não um limitador. Ajuste o limite dentro do jogo/driver.\r\nGPU e tela cheia exigem reiniciar o jogo; compare o teste de tela cheia e use Histórico para desfazer.\r\nNotas abaixo: resolução, qualidade, Reflex/Anti-Lag, VRR, driver e resultado do teste.";}
 void NewGame(){gameList.SelectedIndex=-1;FillGame(new GameProfile{Id=Guid.NewGuid().ToString("N"),Name="Novo jogo",Executable="",TargetFps=144,Notes="",CloseApps=new string[0]});}
 void FillGame(GameProfile p){editingGameId=p.Id;gameName.Text=p.Name;gamePath.Text=p.Executable;gameFps.Value=p.TargetFps;gameGpu.Checked=p.HighGpu;gameFullscreen.Checked=p.DisableFullscreen;gameNotes.Text=p.Notes??"";gameApps=p.CloseApps??new string[0];UpdateGameExplanation();}
 GameProfile CurrentGame(){return new GameProfile{Id=editingGameId,Name=gameName.Text.Trim(),Executable=gamePath.Text,TargetFps=(int)gameFps.Value,HighGpu=gameGpu.Checked,DisableFullscreen=gameFullscreen.Checked,Notes=gameNotes.Text,CloseApps=gameApps};}
 void ReloadGames(string id){gameList.Items.Clear();foreach(var p in GameProfiles.Load()){gameList.Items.Add(p);if(p.Id==id)gameList.SelectedItem=p;}}
 bool SaveGameUi(){try{var p=CurrentGame();GameProfiles.Save(p);ReloadGames(p.Id);footer.Text="Perfil salvo. Configurações do Windows ainda não foram alteradas.";return true;}catch(Exception e){MessageBox.Show(e.Message,Text);return false;}}
 async Task ApplyGameUi(){if(!SaveGameUi())return;var p=CurrentGame();if(!p.HighGpu&&!p.DisableFullscreen){MessageBox.Show("Marque uma das preferências de GPU/tela cheia. FPS alvo e notas não alteram o Windows.",Text);return;}
  if(await Confirm("Aplicar a “"+p.Name+"”?\r\n"+p.Executable+"\r\n\r\n"+(p.HighGpu?"• Preferir GPU de alto desempenho.\r\n":"")+(p.DisableFullscreen?"• Testar sem otimizações de tela cheia (pode piorar).\r\n":"")+"\r\nBackup exato no Histórico. Reinicie o jogo e compare."))await Elevated("--gameprofile",App.SaveRequest(new OperationRequest{Game=p}));
 }
 async Task PrepareGameApps(){
  if(gameApps.Length==0){MessageBox.Show("Escolha apps em Apps e RAM e depois use Guardar apps marcados neste perfil.",Text);return;}
  if(!await Confirm("Solicitar fechamento normal de: "+String.Join(", ",gameApps)+"?\r\nSalve seu trabalho. Gravações, chamadas e downloads podem parar. Nenhum app será forçado."))return;
  await V4Read(async()=>{var snapshot=await Task.Run(()=>ResourceMonitor.ScanProcesses());var selected=snapshot.Where(p=>gameApps.Contains(p.Name,StringComparer.OrdinalIgnoreCase)&&String.IsNullOrEmpty(p.Protection)).ToList();
   if(selected.Count==0){gameExplanation.Text="Nenhum dos apps guardados está disponível para fechamento nesta sessão.";return;}
   var record=await Task.Run(()=>App.CloseApps(selected,false,_=>{}));gameExplanation.Text=record.Message;RefreshHistory();});
 }
 void BuildPowerLab(){
  var page=Page("Energia avançada");var root=Rows(92,47,-1,54);page.Controls.Add(root);powerHeading=Theme.Label("Controle o plano atual, somente quando ligado à tomada.\r\nNenhuma opção vem marcada. Confira os valores e teste uma mudança por vez.\r\nBackups restauram o valor original da opção no plano original; bateria permanece com suas preferências.",10,Theme.Muted);root.Controls.Add(powerHeading,0,0);
  var tools=ActionRow();root.Controls.Add(tools,0,1);tools.Controls.Add(V4Button("Ler plano e opções",async(s,e)=>await ReadPowerOptions(),false,195));tools.Controls.Add(V4Button("Energia do Windows",(s,e)=>OpenLocal("ms-settings:powersleep"),false,190));
  var scroll=new Panel{Dock=DockStyle.Fill,AutoScroll=true};root.Controls.Add(scroll,0,2);var cards=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=1};scroll.Controls.Add(cards);int row=0;
  foreach(var option in PowerTuning.Options){var card=Box();card.Height=123;card.Dock=DockStyle.Top;cards.RowStyles.Add(new RowStyle(SizeType.Absolute,135));cards.Controls.Add(card,0,row++);var content=Rows(27,45,-1);card.Controls.Add(content);
   var check=new ReadableCheckBox{Text=option.Name,Dock=DockStyle.Fill,Font=Theme.Font(11,true),ForeColor=Theme.Text,Enabled=false};powerChecks[option.Id]=check;content.Controls.Add(check,0,0);content.Controls.Add(Theme.Label(option.Description,10,Theme.Muted),0,1);var state=Theme.Label("Leia o plano para consultar disponibilidade.",9,Theme.Amber);powerStates[option.Id]=state;content.Controls.Add(state,0,2);
  }
  var actions=ActionRow();root.Controls.Add(actions,0,3);actions.Controls.Add(V4Button("Aplicar opções marcadas…",async(s,e)=>await ApplyPowerUi(),true,260));actions.Controls.Add(V4Button("Desfazer última alteração",async(s,e)=>await UndoLatest(),false,235));
 }
 async Task ReadPowerOptions(){await V4Read(async()=>{
  var data=await Task.Run(()=>{var m=App.ScanHardware();var statuses=new Dictionary<string,string>();string scheme=App.ActivePlan();foreach(var option in PowerTuning.Options)try{statuses[option.Id]=PowerTuning.Read(PowerTuning.Code(scheme,option.Id));}catch(Exception e){statuses[option.Id]="Indisponível: "+e.Message;}return Tuple.Create(m,scheme,statuses);});
  powerScheme=data.Item2;powerHeading.Text=data.Item1.Power+"\r\nGUID: "+powerScheme+"\r\nSomente AC. "+(data.Item1.PowerKnown&&data.Item1.OnAC?"Na tomada. Mais desempenho pode significar mais calor; compare.":"Conecte à tomada para aplicar.");
  foreach(var option in PowerTuning.Options){uint value;string state=data.Item3[option.Id];bool available=UInt32.TryParse(state,out value)&&data.Item1.PowerKnown&&data.Item1.OnAC;powerChecks[option.Id].Enabled=available;powerChecks[option.Id].Checked=false;powerStates[option.Id].Text=available?"Atual: "+state+" → proposto: "+option.Target+" · API consultada; efeito depende do hardware":state;}
 });}
 async Task ApplyPowerUi(){var ids=powerChecks.Where(p=>p.Value.Checked&&p.Value.Enabled).Select(p=>p.Key).ToArray();if(ids.Length==0){MessageBox.Show("Leia o plano e marque ao menos uma opção disponível.",Text);return;}
  if(!await Confirm("Aplicar no plano consultado, somente na tomada?\r\n\r\n"+String.Join("\r\n",PowerTuning.Options.Where(o=>ids.Contains(o.Id)).Select(o=>o.Name))+"\r\n\r\nPode aumentar calor e consumo. Os valores anteriores serão salvos antes da primeira alteração."))return;
  await Elevated("--poweroptions",App.SaveRequest(new OperationRequest{PowerScheme=powerScheme,PowerOptions=ids}));
 }
 void BuildFrames(){
  var page=Page("FPS e stutter");var root=Rows(62,48,48,115,-1,52,46);page.Controls.Add(root);ScrollPage(page,root,530);
  root.Controls.Add(Theme.Label("1. Grave o jogo com PresentMon (veja Como capturar).  2. Importe o arquivo ANTES.\r\n3. Repita a mesma cena após o ajuste e importe DEPOIS. O gráfico mostra FPS e travamentos.",10,Theme.Muted),0,0);
  var actions=ActionRow();actions.WrapContents=true;actions.AutoScroll=false;root.Controls.Add(actions,0,1);actions.Controls.Add(V4Button("Importar ANTES…",async(s,e)=>await ImportFrames(true),false,185));actions.Controls.Add(V4Button("Importar DEPOIS…",async(s,e)=>await ImportFrames(false),true,190));actions.Controls.Add(V4Button("PresentMon oficial",(s,e)=>OpenUrl("https://github.com/GameTechDev/PresentMon/releases"),false,190));actions.Controls.Add(V4Button("Como capturar",(s,e)=>TextDialog("Capturar frametimes","No PresentMon, escolha o processo do jogo e grave um CSV de 60–120 segundos, sem menus/loading, com a mesma cena, resolução e qualidade.\r\n\r\nPara o console atual: --process_name Jogo.exe --timed 60 --terminate_after_timed --v1_metrics --output_file captura.csv\r\n\r\nUse somente o binário oficial. O app não baixa nem executa PresentMon. Importe aqui MsBetweenPresents, FrameTime ou CPUFrameTime. Escolha o mesmo tipo de quadro; não misture quadros gerados com renderizados."),false,160));
  var inputs=ActionRow();inputs.WrapContents=true;inputs.AutoScroll=false;root.Controls.Add(inputs,0,2);var target=Theme.Label("FPS que você busca",10,Theme.Text);target.Dock=DockStyle.None;target.Width=174;target.Height=30;inputs.Controls.Add(target);frameTarget=new NumericUpDown{Minimum=1,Maximum=1000,Value=144,Width=75,BackColor=Theme.Card,ForeColor=Theme.Text};inputs.Controls.Add(frameTarget);
  var warm=Theme.Label("Excluir aquecimento (s)",10,Theme.Text);warm.Dock=DockStyle.None;warm.Width=205;warm.Height=30;warm.Margin=new Padding(20,0,0,0);inputs.Controls.Add(warm);frameWarmup=new NumericUpDown{Minimum=0,Maximum=3600,Value=0,Width=75,BackColor=Theme.Card,ForeColor=Theme.Text};inputs.Controls.Add(frameWarmup);
  var note=Theme.Label("Ajuste antes de importar.",9,Theme.Muted);note.Dock=DockStyle.None;note.Width=190;note.Height=30;note.Margin=new Padding(12,0,0,0);inputs.Controls.Add(note);
  framePlot=new FramePlot();root.Controls.Add(framePlot,0,3);frameText=Theme.ReadBox();frameText.Margin=new Padding(0,10,0,10);root.Controls.Add(frameText,0,4);
  root.Controls.Add(Theme.Label("Compare a mesma cena, resolução, preset, limite de FPS e driver. Faça pelo menos três repetições.\r\nO relatório explica o cálculo dos picos. Alterar alvo ou aquecimento exige reimportar as capturas.",9,Theme.Muted),0,5);
  var export=ActionRow();root.Controls.Add(export,0,6);export.Controls.Add(V4Button("Exportar comparação HTML",(s,e)=>ExportFrames(),false,252));export.Controls.Add(V4Button("Limpar comparação",(s,e)=>{beforeFrames=afterFrames=null;UpdateFrames();},false,185));UpdateFrames();
 }
 async Task<FrameStream> ChooseStream(FrameCapture capture){
  if(capture.Streams.Count==1)return capture.Streams[0];
  if(EmbeddedInterface.Parent!=IntPtr.Zero){var choices=new ListBox{Height=190,Dock=DockStyle.Top,BackColor=Theme.Card,ForeColor=Theme.Text,Font=Theme.Font(10),HorizontalScrollbar=true};foreach(var stream in capture.Streams)choices.Items.Add(stream);choices.SelectedIndex=0;FrameStream selected=capture.Streams[0];choices.SelectedIndexChanged+=(s,e)=>selected=choices.SelectedItem as FrameStream;return await InlineReview("Escolha o jogo da captura","A captura tem mais de uma sequência. Escolha o mesmo jogo e tipo de quadro em ANTES e DEPOIS.",true,choices)?selected:null;}
  using(var dialog=new Form{Text="Escolha o processo / swapchain / tipo de quadro",Width=860,Height=430,StartPosition=FormStartPosition.CenterParent,BackColor=Theme.Bg,ForeColor=Theme.Text,MinimizeBox=false,MaximizeBox=false}){
   var list=new ListBox{Dock=DockStyle.Fill,BackColor=Theme.Card,ForeColor=Theme.Text,Font=Theme.Font(10),HorizontalScrollbar=true};foreach(var s in capture.Streams)list.Items.Add(s);dialog.Controls.Add(list);
   var button=Theme.Button("Analisar selecionado");button.Dock=DockStyle.Bottom;button.DialogResult=DialogResult.OK;dialog.Controls.Add(button);dialog.AcceptButton=button;list.SelectedIndex=0;
   return dialog.ShowDialog(this)==DialogResult.OK?list.SelectedItem as FrameStream:null;
  }
 }
 async Task ImportFrames(bool before){using(var dialog=new OpenFileDialog{Title=before?"Captura ANTES":"Captura DEPOIS",Filter="CSV de frametimes|*.csv"}){
  if(dialog.ShowDialog(this)!=DialogResult.OK)return;await V4Read(async()=>{var capture=await Task.Run(()=>FrameAnalysis.Load(dialog.FileName));var stream=await ChooseStream(capture);if(stream==null)return;
   int target=(int)frameTarget.Value;double warm=(double)frameWarmup.Value;var summary=await Task.Run(()=>FrameAnalysis.Summarize(capture,stream,target,warm));if(before)beforeFrames=summary;else afterFrames=summary;UpdateFrames();});
 }}
 void UpdateFrames(){framePlot.Before=beforeFrames;framePlot.After=afterFrames;framePlot.Invalidate();frameText.Text="ANTES\r\n"+(beforeFrames==null?"Ainda não importado.":beforeFrames.Describe())+"\r\n\r\nDEPOIS\r\n"+(afterFrames==null?"Ainda não importado.":afterFrames.Describe())+"\r\n\r\n"+FrameAnalysis.Compare(beforeFrames,afterFrames);}
 void ExportFrames(){if(beforeFrames==null&&afterFrames==null)return;using(var dialog=new SaveFileDialog{Filter="Relatório HTML|*.html",FileName="LukeOptimizer-Comparacao-"+DateTime.Now.ToString("yyyyMMdd-HHmm")+".html"})if(dialog.ShowDialog(this)==DialogResult.OK)try{
  using(var bitmap=new Bitmap(framePlot.Width,framePlot.Height))using(var buffer=new MemoryStream()){framePlot.DrawToBitmap(bitmap,new Rectangle(Point.Empty,bitmap.Size));bitmap.Save(buffer,System.Drawing.Imaging.ImageFormat.Png);
   string html="<!doctype html><html lang='pt-BR'><meta charset='utf-8'><title>Luke Optimizer 4 — comparação</title><style>body{background:#10151d;color:#e8f0f5;font:16px system-ui;margin:40px;line-height:1.5}pre{white-space:pre-wrap}img{max-width:100%}a{color:#8de9b8}</style><h1>Comparação de frametimes</h1><p>Exportado em "+DateTime.Now.ToString("g")+"</p><img alt='Picos de frametime' src='data:image/png;base64,"+Convert.ToBase64String(buffer.ToArray())+"'><pre>"+System.Web.HttpUtility.HtmlEncode(frameText.Text)+"</pre><p>Métricas de origem: <a href='https://github.com/GameTechDev/PresentMon/blob/main/README-ConsoleApplication.md'>PresentMon</a>. Resultados importados; não é teste de input lag físico.</p></html>";
   File.WriteAllText(dialog.FileName,html,new UTF8Encoding(false));footer.Text="Comparação exportada.";}
 }catch(Exception e){MessageBox.Show(e.Message,Text);}}
 void BuildHardwareLab(){
  var page=Page("Hardware e rede");var root=Rows(55,56,-1,56,118);page.Controls.Add(root);ScrollPage(page,root,630);root.Controls.Add(Theme.Label("CPU, RAM, GPU, BIOS, discos e inicialização em uma leitura local.\r\nIdentifique limitações antes de aplicar ajustes. Relatório pode conter nomes de apps e caminhos locais.",10,Theme.Muted),0,0);
  var actions=ActionRow();root.Controls.Add(actions,0,1);actions.Controls.Add(V4Button("Analisar hardware completo",async(s,e)=>await V4Read(async()=>{labReport.Text="Consultando hardware…";labReport.Text=await Task.Run(()=>HardwareLab.Report());}),true,255));
  actions.Controls.Add(V4Button("Medir recursos por 15 s",async(s,e)=>await SampleSession(),false,215));actions.Controls.Add(V4Button("Exportar relatório",(s,e)=>ExportLab(),false,175));
  cancelLab=Theme.Button("Cancelar medição");cancelLab.Width=165;cancelLab.Enabled=false;cancelLab.Click+=(s,e)=>{if(labCancel!=null)labCancel.Cancel();};actions.Controls.Add(cancelLab);
  labReport=Theme.ReadBox();labReport.Text="Clique em Analisar hardware completo. Temperatura, VRAM usada, throttling e potência da fonte não serão estimados a partir de dados insuficientes.";root.Controls.Add(labReport,0,2);
  var net=ActionRow();root.Controls.Add(net,0,3);networkHost=Field();networkHost.Dock=DockStyle.None;networkHost.Width=240;networkHost.AccessibleName="IP ou host para ping";networkHost.Text=HardwareLab.Gateway();net.Controls.Add(networkHost);
  net.Controls.Add(V4Button("Usar gateway",(s,e)=>networkHost.Text=HardwareLab.Gateway(),false,150));net.Controls.Add(V4Button("Medir ping / perda",async(s,e)=>await PingUi(),false,180));net.Controls.Add(V4Button("Adaptadores de rede",(s,e)=>OpenSystem("control.exe","ncpa.cpl"),false,200));
  networkReport=Theme.ReadBox();networkReport.Text="Informe um IP/host ou use o gateway. A medição envia 12 pings apenas ao destino informado. Nenhum DNS/TCP é alterado.";root.Controls.Add(networkReport,0,4);
 }
 async Task V4Read(Func<Task> work){if(busy||scanning||resourceScanning||easyRunning)return;resourceScanning=true;scan.Enabled=false;SetActions();
  try{await work();}catch(OperationCanceledException){footer.Text="Medição cancelada.";}catch(Exception e){footer.Text=e.Message;MessageBox.Show(e.Message,Text);}finally{resourceScanning=false;scan.Enabled=true;SetActions();}
 }
 async Task PingUi(){string host=networkHost.Text.Trim();await V4Read(async()=>{
  using(labCancel=new CancellationTokenSource()){cancelLab.Enabled=true;try{networkReport.Text="Medindo "+host+"…";networkReport.Text=(await HardwareLab.PingHost(host,labCancel.Token)).ToString();}catch(OperationCanceledException){networkReport.Text="Medição cancelada.";throw;}finally{cancelLab.Enabled=false;labCancel=null;}}
 });}
 async Task SampleSession(){await V4Read(async()=>{
  using(labCancel=new CancellationTokenSource()){cancelLab.Enabled=true;var samples=new List<ResourceSample>();try{
   for(int i=0;i<10;i++){labCancel.Token.ThrowIfCancellationRequested();samples.Add(await Task.Run(()=>ResourceMonitor.Measure(1500)));footer.Text="Amostra de recursos "+(i+1)+"/10";}
   var cpus=samples.Where(s=>s.CpuKnown).ToArray();var memory=samples.Where(s=>s.MemoryKnown).ToArray();labReport.Text="SESSÃO DE RECURSOS · "+DateTime.Now.ToString("g")+"\r\n"+
    (cpus.Length==0?"CPU indisponível":"CPU média "+cpus.Average(s=>s.CpuPercent).ToString("0.0")+"% · pico "+cpus.Max(s=>s.CpuPercent).ToString("0.0")+"%")+"\r\n"+
    (memory.Length==0?"RAM indisponível":"Menor RAM disponível: "+memory.Min(s=>s.AvailableMB).ToString("0")+" MB")+"\r\nProcessos: "+samples.Min(s=>s.Processes)+"–"+samples.Max(s=>s.Processes)+"\r\n\r\n"+
    String.Join("\r\n",samples.Select(ResourceMonitor.Describe))+"\r\n\r\nCPU total baixa não exclui limite em um único núcleo. Esta medição não inclui FPS/GPU/input lag; use CSV do jogo para frametimes.";
   }finally{cancelLab.Enabled=false;labCancel=null;}}
 });}
 void ExportLab(){using(var dialog=new SaveFileDialog{Filter="Relatório de texto|*.txt",FileName="LukeOptimizer-Hardware-"+DateTime.Now.ToString("yyyyMMdd-HHmm")+".txt"})if(dialog.ShowDialog(this)==DialogResult.OK)try{File.WriteAllText(dialog.FileName,labReport.Text+"\r\n\r\nREDE\r\n"+networkReport.Text,new UTF8Encoding(false));footer.Text="Relatório salvo localmente.";}catch(Exception e){MessageBox.Show(e.Message,Text);}}
}

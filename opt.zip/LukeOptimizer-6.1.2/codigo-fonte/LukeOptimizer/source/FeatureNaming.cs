using System;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;

// NOMES PARA HUMANOS — camada de apresentação, zero impacto em identidade.
//
// A regra do pedido: o usuário nunca deve ver nome de arquivo, chave de Registro ou
// comando como NOME de uma função. Detalhe técnico continua disponível, em Detalhes.
//
// O que esta camada NÃO faz, de propósito:
//
// 1. Não altera Id. Perfis, histórico, backup e desfazer gravados no PC das pessoas
//    referenciam IDs. Renomear identidade para arrumar texto quebraria restauração de
//    backups antigos — exatamente o que o pedido proíbe (item 4).
//
// 2. Não renomeia INVENTÁRIO. O catálogo tem 673 entradas, das quais 546 não são
//    funções: são os arquivos que a pessoa enviou (.bat, .reg) e instaladores de
//    terceiros (Optimizer-16.7.exe, memreduct, Autoruns, Dism++…). Para esses, o nome
//    do arquivo É a identidade: rebatizar "Optimizer-16.7.exe" como "Otimizador de
//    terceiros" impediria a pessoa de achar o arquivo na própria pasta. Inventário
//    precisa ser SEPARADO de função, não disfarçado de função.
//
// O que ela faz: dá nome limpo às CATEGORIAS (que é onde ".Bats", "Regedits" e os
// prefixos numéricos vazavam para a tela) e fornece a regra de violação que os testes
// aplicam sobre toda função executável.
static class FeatureNaming {
 // Tokens que nunca podem aparecer no NOME de uma função. Em TechnicalDescription,
 // Detalhes e log eles são bem-vindos — é lá que o usuário avançado audita.
 internal static readonly string[] Forbidden={
  ".reg",".bat",".cmd",".ps1",".exe",".lnk",".zip",".msi",
  "HKLM","HKCU","HKEY_","reg add","reg delete","regedit",
  "netsh","ipconfig","powercfg","wmic","schtasks","sfc /","DISM "
 };

 // Devolve o token ofensivo, ou null. Usado pelos testes e por quem cadastrar função nova.
 internal static string Violation(string displayName){
  if(String.IsNullOrEmpty(displayName))return null;
  foreach(string token in Forbidden)
   if(displayName.IndexOf(token,StringComparison.OrdinalIgnoreCase)>=0)return token;
  return null;
 }

 // Uma entrada é INVENTÁRIO quando não é executável: o LukeOptimizer não a aplica, só
 // a leu e explicou. São os arquivos da pessoa e programas de terceiros.
 internal static bool IsInventory(Item item){return item!=null&&!item.Native;}

 static readonly Regex Prefix=new Regex(@"^\s*-?\d+\s*-\s*",RegexOptions.Compiled);
 // "5 - Apps essenciais" -> "Apps essenciais"; "-4 - Personalização" -> "Personalização".
 internal static string StripPrefix(string raw){
  if(String.IsNullOrEmpty(raw))return "";
  return Prefix.Replace(raw,"").Trim();
 }

 // As 35 categorias brutas colapsam em nomes limpos. Várias são a MESMA coisa sob
 // prefixos diferentes ("-3 - Personalização" e "-4 - Personalização"); aqui elas viram
 // uma só, que é a unificação que o pedido chama de normalização.
 static readonly Dictionary<string,string> Map=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase){
  // Inventário: arquivos e programas que a pessoa trouxe. Nome honesto, sem fingir função.
  {".Bats","Arquivos que você enviou"},
  {"Regedits","Arquivos que você enviou"},
  {"Seus 14 BATs revisados","Arquivos que você enviou"},
  {"Apps essenciais","Programas de terceiros"},
  {"Ferramentas Luke (exclusivas)","Ferramentas do pacote"},
  {"Planos de Energia","Energia"},
  {"Dicas e Tutorials","Guias e referência"},
  {"IMPORTANTE","Leia primeiro"},
  // Funções, agrupadas pelo que fazem.
  {"Avançado: perde recursos","Avançado: perde recursos"},
  {"Debloater","Remover aplicativos"},
  {"Reverter Otimizações","Reverter alterações"},
  {"Personalização","Personalizar Windows"},
  {"Personalizar Windows","Personalizar Windows"},
  {"Privacidade opcional","Privacidade"},
  {"Fix Erros do Windows","Reparar Windows"},
  {"Reparos de acesso","Reparar Windows"},
  {"Otimizar Driver de Vídeo (AMD & NVIDIA)","GPU e drivers"},
  {"Otimizações especificas de jogos","Jogos"},
  {"Anti Stuttering","Jogos"},
  {"Otimização DirectX e Vulkan","Jogos"},
  {"Otimizar Navegadores","Navegadores"},
  {"Tweaks Avançados (Modo Agressivo)","Laboratório experimental"},
  {"Diagnósticar PC","Diagnóstico"},
  {"Windows leve","Windows leve"},
  {"Otimizar Rede (ping)","Rede"},
  {"Rede e downloads","Rede"},
  {"Apps e processos","Processos"},
  {"Entrada e preferências","Mouse e teclado"},
  {"Criar Ponto de Restauraçao","Backup e restauração"},
  {"Ajustes revisados","Ajustes revisados"},
  {"Windows","Windows"}
 };

 // Nome da categoria para a tela. Categoria desconhecida cai no nome sem prefixo, em vez
 // de sumir ou virar "Outros": perder um item por falta de tradução seria pior.
 internal static string Category(string raw){
  string name=StripPrefix(raw);
  string mapped;
  return Map.TryGetValue(name,out mapped)?mapped:name;
 }

 // Ordem de exibição: funções primeiro, inventário e referência por último. Categoria
 // fora da lista entra antes do inventário, para não ser escondida.
 static readonly string[] Order={
  "Leia primeiro","Ajustes revisados","Windows","Windows leve","Jogos","GPU e drivers",
  "Energia","Rede","Processos","Mouse e teclado","Personalizar Windows","Navegadores",
  "Privacidade","Remover aplicativos","Reparar Windows","Diagnóstico",
  "Backup e restauração","Reverter alterações","Avançado: perde recursos",
  "Laboratório experimental","Ferramentas do pacote","Programas de terceiros",
  "Guias e referência","Arquivos que você enviou"
 };
 internal static int Rank(string display){
  int index=Array.IndexOf(Order,display);
  return index<0?Order.Length-2:index;
 }

 // Categorias visíveis, já unificadas e ordenadas, com as categorias BRUTAS que cada
 // uma cobre — é isso que permite a tela filtrar sem depender do texto exibido.
 internal static List<KeyValuePair<string,string[]>> Groups(IEnumerable<Item> items){
  var map=new Dictionary<string,List<string>>(StringComparer.Ordinal);
  foreach(var item in items??new Item[0]){
   string raw=item.Category??"";
   string display=Category(raw);
   List<string> list;
   if(!map.TryGetValue(display,out list)){list=new List<string>();map[display]=list;}
   if(!list.Contains(raw))list.Add(raw);
  }
  return map.OrderBy(p=>Rank(p.Key)).ThenBy(p=>p.Key,StringComparer.CurrentCulture)
            .Select(p=>new KeyValuePair<string,string[]>(p.Key,p.Value.ToArray())).ToList();
 }
}

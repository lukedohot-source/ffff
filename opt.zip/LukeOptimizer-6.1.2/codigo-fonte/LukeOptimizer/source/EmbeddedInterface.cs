﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Threading.Tasks;

static class EmbeddedInterface {
 internal static IntPtr Parent;
 internal const int Navigate=0x8000+41,Ready=0x8000+42,Busy=0x8000+43,CurrentPage=0x8000+44;
 internal static readonly string[] Pages={"FPS e stutter","Apps e RAM","Manutenção","Energia avançada","Perfis de jogos","Hardware e rede","Rede e latência","Arquivos e referências","Seus 14 BATs","Catálogo"};
 internal static int Initial;
 [DllImport("user32.dll")] internal static extern bool IsWindow(IntPtr hwnd);
 [DllImport("user32.dll")] internal static extern uint GetWindowThreadProcessId(IntPtr hwnd,out uint pid);
 [DllImport("user32.dll")] internal static extern bool PostMessage(IntPtr hwnd,int msg,IntPtr w,IntPtr l);
 internal static bool Parse(string[] args){
  if(args.Length==0||args[0]!="--embedded")return false;
  long raw;int index;
  if(args.Length!=3||!Int64.TryParse(args[1],out raw)||!Int32.TryParse(args[2],out index)||index<0||index>=Pages.Length)throw new Exception("Página interna inválida.");
  var parent=new IntPtr(raw);uint pid;if(!IsWindow(parent))throw new Exception("A janela principal foi fechada.");GetWindowThreadProcessId(parent,out pid);
  using(var p=Process.GetProcessById((int)pid))if(p.SessionId!=Process.GetCurrentProcess().SessionId)throw new Exception("Janela pertence a outra sessão.");
  Parent=parent;Initial=index;App.ToolMode=true;return true;
 }
}
public partial class MainForm {
 System.Windows.Forms.Timer parentWatch;
 Panel inlineOverlay;Action inlineCancel;
 Task<bool> InlineReview(string heading,string content,bool confirmation,Control selection=null){
  if(inlineOverlay!=null)return Task.FromResult(false);
  var completion=new TaskCompletionSource<bool>();
  var previous=new System.Collections.Generic.Dictionary<Control,bool>();
  foreach(Control c in Controls){previous[c]=c.Enabled;c.Enabled=false;}
  var overlay=new Panel{Dock=DockStyle.Fill,BackColor=Theme.Bg,Padding=new Padding(20)};inlineOverlay=overlay;
  var rows=Rows(48,-1,56);overlay.Controls.Add(rows);rows.Controls.Add(Theme.Label(heading,17,Theme.Text,true),0,0);
  var text=Theme.ReadBox();text.Text=content;if(selection==null)rows.Controls.Add(text,0,1);else{var body=new Panel{Dock=DockStyle.Fill};body.Controls.Add(text);body.Controls.Add(selection);rows.Controls.Add(body,0,1);}var actions=ActionRow();actions.Padding=new Padding(0,10,0,0);rows.Controls.Add(actions,0,2);
  Action<bool> finish=answer=>{if(inlineOverlay!=overlay)return;Controls.Remove(overlay);inlineOverlay=null;inlineCancel=null;overlay.Dispose();foreach(var c in previous)if(!c.Key.IsDisposed)c.Key.Enabled=c.Value;completion.TrySetResult(answer);};
  inlineCancel=()=>finish(false);
  if(confirmation){var apply=Theme.Button("Confirmar e continuar",true);apply.Name="inline-accept";apply.Width=225;apply.Click+=(s,e)=>finish(true);actions.Controls.Add(apply);}
  var close=Theme.Button(confirmation?"Voltar sem aplicar":"Fechar leitura");close.Name="inline-cancel";close.Click+=(s,e)=>finish(false);actions.Controls.Add(close);
  Controls.Add(overlay);overlay.BringToFront();close.Focus();return completion.Task;
 }

 protected override void OnHandleCreated(EventArgs e){base.OnHandleCreated(e);if(EmbeddedInterface.Parent!=IntPtr.Zero)EmbeddedInterface.PostMessage(EmbeddedInterface.Parent,EmbeddedInterface.Ready,Handle,IntPtr.Zero);}
 protected override CreateParams CreateParams {get{var p=base.CreateParams;if(EmbeddedInterface.Parent!=IntPtr.Zero){p.Parent=EmbeddedInterface.Parent;p.Style=(p.Style&~unchecked((int)0x80000000))|0x40000000;p.ExStyle&=~0x40000;}return p;}}
 protected override void WndProc(ref Message m){
  if(EmbeddedInterface.Parent!=IntPtr.Zero){
   if(m.Msg==EmbeddedInterface.Navigate){int index=m.WParam.ToInt32();if(index>=0&&index<EmbeddedInterface.Pages.Length&&!EmbeddedBusy())ShowPage(EmbeddedInterface.Pages[index]);m.Result=IntPtr.Zero;return;}
   if(m.Msg==EmbeddedInterface.Busy){m.Result=EmbeddedBusy()?new IntPtr(1):IntPtr.Zero;return;}
   if(m.Msg==EmbeddedInterface.CurrentPage){m.Result=new IntPtr(Array.IndexOf(EmbeddedInterface.Pages,title.Text));return;}
  }base.WndProc(ref m);
 }
 bool EmbeddedBusy(){return inlineOverlay!=null||!ready||busy||scanning||resourceScanning||easyRunning||v5NetCancel!=null;}
 void PrepareEmbedded(){
  if(EmbeddedInterface.Parent==IntPtr.Zero)return;
  progress.Visible=false;TopLevel=false;FormBorderStyle=FormBorderStyle.None;ShowInTaskbar=false;MinimumSize=Size.Empty;StartPosition=FormStartPosition.Manual;Location=Point.Empty;
  ShowPage(EmbeddedInterface.Pages[EmbeddedInterface.Initial]);
  parentWatch=new System.Windows.Forms.Timer{Interval=1000};parentWatch.Tick+=(s,e)=>{if(!EmbeddedInterface.IsWindow(EmbeddedInterface.Parent)&&!EmbeddedBusy()){parentWatch.Stop();Close();Application.ExitThread();}};parentWatch.Start();FormClosed+=(s,e)=>parentWatch.Dispose();
  Shown+=(s,e)=>{ShowPage(EmbeddedInterface.Pages[EmbeddedInterface.Initial]);EmbeddedInterface.PostMessage(EmbeddedInterface.Parent,EmbeddedInterface.Ready,Handle,IntPtr.Zero);};
 }
}

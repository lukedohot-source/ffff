﻿using System;
using System.IO;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Threading;
using Microsoft.Win32.SafeHandles;

public class OfficialCommand {
 public string Id,Name,Category,Executable,Arguments,Description,Source;
 public int TimeoutSeconds;public bool Administrator;
}
public class ManagedCommandResult {public int ExitCode;public string Output,LogPath;public bool TimedOut,Cancelled;}
static class CommandTools {
 internal static List<OfficialCommand> Catalog(){return new List<OfficialCommand>{
  new OfficialCommand{Id="dism-check",Name="DISM · verificar estado",Category="Sistema",Executable="dism.exe",Arguments="/Online /Cleanup-Image /CheckHealth",TimeoutSeconds=120,Administrator=true,Description="Consulta se a imagem foi marcada como corrompida. Não repara nem remove componentes.",Source="https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/repair-a-windows-image"},
  new OfficialCommand{Id="dism-scan",Name="DISM · analisar imagem",Category="Sistema",Executable="dism.exe",Arguments="/Online /Cleanup-Image /ScanHealth",TimeoutSeconds=1200,Administrator=true,Description="Procura corrupção no repositório de componentes. Pode demorar e utilizar CPU/disco. Não usa ResetBase nem baixa arquivos.",Source="https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/repair-a-windows-image"},
  new OfficialCommand{Id="sfc-verify",Name="SFC · verificar arquivos",Category="Sistema",Executable="sfc.exe",Arguments="/verifyonly",TimeoutSeconds=1200,Administrator=true,Description="Verifica arquivos protegidos. Não executa reparo. O detalhe também fica no log CBS do Windows.",Source="https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/sfc"},
  new OfficialCommand{Id="dns-cache",Name="DNS · consultar cache",Category="Rede",Executable="ipconfig.exe",Arguments="/displaydns",TimeoutSeconds=30,Description="Mostra entradas DNS locais. O relatório contém nomes consultados; revise antes de compartilhar.",Source="https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig"},
  new OfficialCommand{Id="ip-config",Name="Rede · configuração completa",Category="Rede",Executable="ipconfig.exe",Arguments="/all",TimeoutSeconds=30,Description="Consulta adaptadores, DHCP, DNS e endereços. Não altera servidores DNS ou MTU.",Source="https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig"},
  new OfficialCommand{Id="tcp-state",Name="TCP · recursos ativos",Category="Rede",Executable="netsh.exe",Arguments="interface tcp show global",TimeoutSeconds=30,Description="Consulta RSS, autotuning e estado TCP. Não força offloads em hardware desconhecido.",Source="https://learn.microsoft.com/en-us/windows-server/networking/technologies/netsh/netsh-contexts"},
  new OfficialCommand{Id="driver-errors",Name="Dispositivos com problemas",Category="Drivers",Executable="pnputil.exe",Arguments="/enum-devices /problem",TimeoutSeconds=60,Description="Consulta dispositivos com problema no Plug and Play. Builds antigas podem informar comando indisponível. Não instala drivers.",Source="https://learn.microsoft.com/en-us/windows-hardware/drivers/devtest/pnputil-command-syntax"},
  new OfficialCommand{Id="energy-requests",Name="Energia · bloqueadores de suspensão",Category="Energia",Executable="powercfg.exe",Arguments="/requests",TimeoutSeconds=30,Administrator=true,Description="Mostra solicitações de energia. Não remove bloqueadores nem desativa USB ou adaptadores.",Source="https://learn.microsoft.com/en-us/windows-hardware/design/device-experiences/powercfg-command-line-options"}
 };}
 internal static OfficialCommand Resolve(string id){var command=Catalog().SingleOrDefault(c=>c.Id==id);if(command==null)throw new ArgumentException("Comando fora do catálogo permitido.");return command;}
 internal static ManagedCommandResult Run(string id,CancellationToken token){var command=Resolve(id);return ManagedCommand.Run(App.SystemExe(command.Executable),command.Arguments,command.TimeoutSeconds,token);}
}
// Start suspended, attach to a kill-on-close Job Object, then resume.
// No shell, no user-supplied executable, no output pipe that can deadlock.
static class ManagedCommand {
 [StructLayout(LayoutKind.Sequential)] struct Security {public int Length;public IntPtr Descriptor;[MarshalAs(UnmanagedType.Bool)]public bool Inherit;}
 [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)] struct Startup {public int Size;public string Reserved,Desktop,Title;public uint X,Y,XSize,YSize,XChars,YChars,Fill,Flags;public short Show,ReservedSize;public IntPtr ReservedPointer,Input,Output,Error;}
 [StructLayout(LayoutKind.Sequential)] struct ProcessInfo {public IntPtr Process,Thread;public uint Pid,Tid;}
 [StructLayout(LayoutKind.Sequential)] struct BasicLimit {public long ProcessTime,JobTime;public uint Flags;public UIntPtr Minimum,Maximum;public uint Active;public UIntPtr Affinity;public uint Priority,Scheduling;}
 [StructLayout(LayoutKind.Sequential)] struct IoCounters {public ulong ReadOperations,WriteOperations,OtherOperations,ReadBytes,WriteBytes,OtherBytes;}
 [StructLayout(LayoutKind.Sequential)] struct ExtendedLimit {public BasicLimit Basic;public IoCounters Io;public UIntPtr ProcessMemory,JobMemory,PeakProcessMemory,PeakJobMemory;}
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr CreateJobObject(IntPtr security,string name);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool SetInformationJobObject(IntPtr job,int type,ref ExtendedLimit info,int length);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool AssignProcessToJobObject(IntPtr job,IntPtr process);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool CreateProcess(string app,StringBuilder command,IntPtr processSecurity,IntPtr threadSecurity,bool inherit,uint flags,IntPtr environment,string directory,ref Startup startup,out ProcessInfo info);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern SafeFileHandle CreateFile(string path,uint access,uint sharing,ref Security security,uint creation,uint flags,IntPtr template);
 [DllImport("kernel32.dll",SetLastError=true)] static extern uint ResumeThread(IntPtr thread);
 [DllImport("kernel32.dll",SetLastError=true)] static extern uint WaitForSingleObject(IntPtr handle,uint milliseconds);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetExitCodeProcess(IntPtr process,out uint code);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool TerminateProcess(IntPtr process,uint code);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool TerminateJobObject(IntPtr job,uint code);
 [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
 static readonly object PruneGate=new object();
 static void PruneLogs(){lock(PruneGate){foreach(var file in new DirectoryInfo(ExecutionHub.LogsRoot).GetFiles("comando-*.log").OrderByDescending(f=>f.LastWriteTimeUtc).Skip(49))try{file.Delete();}catch{}}}
 internal static ManagedCommandResult Run(string executable,string arguments,int seconds,CancellationToken token,Encoding outputEncoding=null,int maximumCharacters=65536){
  if(!Path.IsPathRooted(executable)||!File.Exists(executable))throw new FileNotFoundException("Comando não encontrado.",executable);if(seconds<1||seconds>3600)throw new ArgumentException("Timeout inválido.");token.ThrowIfCancellationRequested();
  Directory.CreateDirectory(ExecutionHub.LogsRoot);PruneLogs();string log=Path.Combine(ExecutionHub.LogsRoot,"comando-"+Guid.NewGuid().ToString("N")+".log");
  var security=new Security{Length=Marshal.SizeOf(typeof(Security)),Inherit=true};var startup=new Startup{Size=Marshal.SizeOf(typeof(Startup)),Flags=0x100};var process=new ProcessInfo();IntPtr job=IntPtr.Zero;bool resumed=false;var result=new ManagedCommandResult{LogPath=log};
  try{using(var output=CreateFile(log,0x40000000,3,ref security,2,0x80,IntPtr.Zero))using(var input=CreateFile("NUL",0x80000000,3,ref security,3,0x80,IntPtr.Zero)){
   if(output.IsInvalid||input.IsInvalid)throw new Win32Exception(Marshal.GetLastWin32Error());startup.Output=startup.Error=output.DangerousGetHandle();startup.Input=input.DangerousGetHandle();
   job=CreateJobObject(IntPtr.Zero,null);if(job==IntPtr.Zero)throw new Win32Exception(Marshal.GetLastWin32Error());var limit=new ExtendedLimit();limit.Basic.Flags=0x2000;if(!SetInformationJobObject(job,9,ref limit,Marshal.SizeOf(typeof(ExtendedLimit))))throw new Win32Exception(Marshal.GetLastWin32Error());
   if(!CreateProcess(executable,new StringBuilder(App.Quote(executable)+" "+arguments),IntPtr.Zero,IntPtr.Zero,true,0x08000000|4,IntPtr.Zero,Path.GetDirectoryName(executable),ref startup,out process))throw new Win32Exception(Marshal.GetLastWin32Error());
   if(!AssignProcessToJobObject(job,process.Process))throw new Win32Exception(Marshal.GetLastWin32Error());if(ResumeThread(process.Thread)==UInt32.MaxValue)throw new Win32Exception(Marshal.GetLastWin32Error());resumed=true;
   var watch=Stopwatch.StartNew();while(true){uint wait=WaitForSingleObject(process.Process,100);if(wait==0)break;if(wait==UInt32.MaxValue)throw new Win32Exception(Marshal.GetLastWin32Error());if(token.IsCancellationRequested||watch.Elapsed.TotalSeconds>=seconds){result.Cancelled=token.IsCancellationRequested;result.TimedOut=!result.Cancelled;TerminateJobObject(job,1460);WaitForSingleObject(process.Process,5000);break;}}
   uint code;if(!GetExitCodeProcess(process.Process,out code))throw new Win32Exception(Marshal.GetLastWin32Error());result.ExitCode=unchecked((int)code);
  }}finally{if(process.Process!=IntPtr.Zero&&!resumed)TerminateProcess(process.Process,1);if(job!=IntPtr.Zero)CloseHandle(job);if(process.Thread!=IntPtr.Zero)CloseHandle(process.Thread);if(process.Process!=IntPtr.Zero)CloseHandle(process.Process);}
  using(var reader=new StreamReader(log,outputEncoding??Encoding.GetEncoding(System.Globalization.CultureInfo.CurrentCulture.TextInfo.OEMCodePage),true)){char[] buffer=new char[maximumCharacters];int count=reader.ReadBlock(buffer,0,buffer.Length);result.Output=new string(buffer,0,count)+(reader.Peek()>=0?Environment.NewLine+"Saída resumida. Log completo: "+log:"");}
  return result;
 }
}
static partial class App {
 internal static void RunOfficialCommand(string id){var command=CommandTools.Resolve(id);var r=NewRecord(command.Name,id,"Diagnóstico");r.RequestedAdmin=command.Administrator;Save(r);try{
  r.Status="executando";Save(r);var result=CommandTools.Run(id,CancellationToken.None);r.Status=result.TimedOut||result.Cancelled||result.ExitCode!=0?"leitura indisponível":"consulta concluída";
  r.OutcomeCode=result.TimedOut?"TIMEOUT":result.Cancelled?"CANCELLED":result.ExitCode!=0?"COMMAND_FAILED":"OK";r.Message=command.Description+"\r\nCódigo de saída: "+result.ExitCode+" · timeout: "+result.TimedOut+" · cancelado: "+result.Cancelled+"\r\n"+result.Output+"\r\nLog completo: "+result.LogPath+"\r\nFonte: "+command.Source;
 }catch(Exception e){r.Status="leitura indisponível";r.OutcomeCode=ErrorHelp.For(e).ErrorCode;r.Message=ErrorHelp.For(e).FriendlyError+"\r\n"+e;}Save(r);}
}

using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;

static partial class App {
 internal static string[] ValidateRemovalPayload(string payload){
  var parts=payload.Split(new[]{'|'});Guid id;
  if(parts.Length!=2||!Guid.TryParseExact(parts[1],"N",out id))throw new Exception("Pedido de remoção inválido.");
  AppRemoval.Resolve(parts[0]);return parts;
 }
 internal static string RemovalCancelPath(string id){Guid value;if(!Guid.TryParseExact(id,"N",out value))throw new Exception("Pedido inválido.");return Path.Combine(DataRoot,"removal-requests",id+".cancel");}
 internal static void RemoveSelectedApps(string payload){var parts=ValidateRemovalPayload(payload);AppRemoval.Remove(parts[0],RemovalCancelPath(parts[1]));}
}

public partial class MainForm {
 CatalogList removalList;TextBox removalSearch,removalDetail;Label removalSummary;
 Button removalScanButton,removalApplyButton,removalCancelButton,manualApplyButton,manualReadButton,historyVerifyButton,historyExportButton;
 List<AppRemovalState> removalStates=new List<AppRemovalState>();readonly HashSet<string> removalChecked=new HashSet<string>();
 readonly Dictionary<string,CheckBox> manualPicks=new Dictionary<string,CheckBox>();
 readonly Dictionary<string,NumericUpDown> manualValues=new Dictionary<string,NumericUpDown>();
 readonly Dictionary<string,Label> manualCurrent=new Dictionary<string,Label>();
 bool removalUpdating;string removalRequest;
#if TESTS
 internal Func<string,string,Task<bool>> TestElevation;
 internal Func<List<AppRemovalState>> TestRemovalScan;
#endif
 bool FeaturesReady(){return ready&&machine.Windows&&!busy&&!scanning&&!resourceScanning&&!easyRunning;}
 void BuildFunctionalPages(){BuildRemovalPage();BuildManualPage();}
 void UpdateFunctionalActions(){
  bool enabled=FeaturesReady();
  if(removalScanButton!=null){removalScanButton.Enabled=enabled;removalList.Enabled=enabled;removalSearch.Enabled=enabled;removalApplyButton.Enabled=enabled&&removalChecked.Count>0;removalCancelButton.Enabled=removalRequest!=null;}
  if(manualApplyButton!=null){manualReadButton.Enabled=enabled;manualApplyButton.Enabled=enabled&&manualPicks.Values.Any(p=>p.Checked);foreach(var p in manualPicks)p.Value.Enabled=enabled;foreach(var p in manualValues)p.Value.Enabled=enabled&&manualPicks[p.Key].Checked;}
  bool selected=history!=null&&history.SelectedItems.Count>0;
  if(historyVerifyButton!=null)historyVerifyButton.Enabled=enabled&&selected;
  if(historyExportButton!=null)historyExportButton.Enabled=!busy&&!scanning&&!resourceScanning&&selected;
 }
 async Task RestoreHomeSelection(){
  if(!FeaturesReady())return;
  string problem=null;
  try{
   var backup=records.FirstOrDefault(App.CanUndo);if(backup==null)throw new Exception("Nenhum backup disponível.");
   var ids=HomePayload(false);if(ids.Length==0)throw new Exception("Marque os ajustes que deseja restaurar.");
   string payload=backup.Id+"|"+String.Join(",",ids);
   var chosen=App.RestoreSelectionItems(payload);
   string review=backup.Name+"\r\nBackup: "+backup.Id+"\r\n\r\n"+String.Join("\r\n",chosen.Select(i=>i.ReviewTitle))+"\r\n\r\nRestaura somente os valores salvos destes ajustes. Mudanças posteriores são preservadas. Esta restauração também gera um backup e pode ser desfeita.";
   if(await InlineReview("Restaurar ajustes marcados",review,true))await Elevated("--restore-selection",payload);
  }catch(Exception e){problem=e.Message;}
  if(problem!=null)await InlineReview("Restauração não iniciada",problem,false);
 }
 void AddHistoryActions(FlowLayoutPanel actions){
  actions.AutoScroll=true;
  historyVerifyButton=Theme.Button("Conferir agora");historyVerifyButton.Name="history-verify";historyVerifyButton.Width=145;historyVerifyButton.Click+=async(s,e)=>await VerifySelectedHistory();actions.Controls.Add(historyVerifyButton);
  historyExportButton=Theme.Button("Salvar log TXT");historyExportButton.Name="history-export";historyExportButton.Width=145;historyExportButton.Click+=async(s,e)=>await ExportSelectedHistory();actions.Controls.Add(historyExportButton);
 }
 async Task VerifySelectedHistory(){
  if(!FeaturesReady()||history.SelectedItems.Count==0)return;var record=(Record)history.SelectedItems[0].Tag;
  busy=true;SetActions();string report;
  try{report=await Task.Run(()=>ChangeAudit.VerifyCurrent(record));}catch(Exception e){report=e.Message;}finally{busy=false;SetActions();}
  await InlineReview("Conferência atual",report,false);
 }
 async Task ExportSelectedHistory(){
  if(busy||history.SelectedItems.Count==0)return;
  string message,title="Log TXT salvo";try{var record=(Record)history.SelectedItems[0].Tag;message=ChangeAudit.Export(record);}catch(Exception e){title="Não foi possível salvar";message=e.Message;}await InlineReview(title,message,false);
 }
 void BuildRemovalPage(){
  var page=Page("Remover apps");var root=Rows(78,42,36,-1,115,50);page.Controls.Add(root);
  root.Controls.Add(Theme.Label("Selecione somente os apps que deseja desinstalar. Nenhum vem marcado.\r\nAppx: conta atual. WinGet pode afetar o PC. A remoção pode apagar dados e exige reinstalação; não tem desfazer automático.",10,Theme.Muted),0,0);
  removalSearch=new TextBox{Dock=DockStyle.Fill,Name="removal-search",BackColor=Theme.Card,ForeColor=Theme.Text};removalSearch.TextChanged+=(s,e)=>FilterRemoval();root.Controls.Add(removalSearch,0,1);
  removalSummary=Theme.Label("Clique em Atualizar lista para consultar os apps instalados.",10,Theme.Muted);root.Controls.Add(removalSummary,0,2);
  removalList=new CheckableList{CheckBoxes=true,Name="removal-list"};removalList.Columns.Add("App",310);removalList.Columns.Add("Método",90);removalList.Columns.Add("Estado",220);removalList.Resize+=(s,e)=>FitColumns(removalList);
  removalList.ItemCheck+=(s,e)=>{if(removalUpdating)return;var state=(AppRemovalState)removalList.Items[e.Index].Tag;if(e.NewValue==CheckState.Checked&&(!state.CanRemove||!FeaturesReady())){e.NewValue=CheckState.Unchecked;return;}if(e.NewValue==CheckState.Checked)removalChecked.Add(state.App.Id);else removalChecked.Remove(state.App.Id);UpdateRemovalSummary();UpdateFunctionalActions();};
  removalList.SelectedIndexChanged+=(s,e)=>{if(removalList.SelectedItems.Count==0){removalDetail.Text="";return;}var state=(AppRemovalState)removalList.SelectedItems[0].Tag;removalDetail.Text=state.App.Name+"\r\n"+state.App.Description+"\r\nIDs: "+String.Join(", ",state.App.PackageIds)+"\r\n"+state.State+"\r\n"+state.Detail;};root.Controls.Add(removalList,0,3);
  removalDetail=Theme.ReadBox();root.Controls.Add(removalDetail,0,4);
  var actions=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false,AutoScroll=true};root.Controls.Add(actions,0,5);
  removalScanButton=Theme.Button("Atualizar lista");removalScanButton.Name="removal-scan";removalScanButton.Width=150;removalScanButton.Click+=async(s,e)=>await RefreshRemoval();actions.Controls.Add(removalScanButton);
  removalApplyButton=Theme.Button("Remover selecionados",true);removalApplyButton.Name="removal-apply";removalApplyButton.Width=210;removalApplyButton.Click+=async(s,e)=>await RemoveChosenApps();actions.Controls.Add(removalApplyButton);
  removalCancelButton=Theme.Button("Parar após app atual");removalCancelButton.Name="removal-cancel";removalCancelButton.Width=200;removalCancelButton.Click+=(s,e)=>{if(removalRequest==null)return;try{string path=App.RemovalCancelPath(removalRequest);Directory.CreateDirectory(Path.GetDirectoryName(path));AtomicStore.Write(path,"1");footer.Text="Parada solicitada. A remoção atual terminará e será conferida.";}catch(Exception ex){footer.Text="Não foi possível solicitar parada: "+ex.Message;}};actions.Controls.Add(removalCancelButton);
  removalStates=AppRemoval.Catalog().Select(a=>new AppRemovalState{App=a,State="Ainda não consultado",Detail="Atualize a lista antes de selecionar."}).ToList();FilterRemoval();
 }
 void FilterRemoval(){
  if(removalList==null)return;string query=removalSearch.Text.Trim();removalUpdating=true;removalList.BeginUpdate();
  try{removalList.Items.Clear();foreach(var state in removalStates.Where(a=>(a.App.Name+" "+a.App.Id+" "+String.Join(" ",a.App.PackageIds)).IndexOf(query,StringComparison.OrdinalIgnoreCase)>=0)){var row=new ListViewItem(state.App.Name){Tag=state,Checked=removalChecked.Contains(state.App.Id),ForeColor=state.CanRemove?Theme.Text:Theme.Muted};row.SubItems.Add(state.App.Method);row.SubItems.Add(state.State);removalList.Items.Add(row);}}
  finally{removalList.EndUpdate();removalUpdating=false;}
  UpdateRemovalSummary();UpdateFunctionalActions();
 }
 void UpdateRemovalSummary(){removalSummary.Text=removalStates.Count+" definições · "+removalStates.Count(a=>a.Installed)+" instaladas · "+removalStates.Count(a=>!a.Known)+" não confirmadas · "+removalChecked.Count+" selecionadas";}
 async Task RefreshRemoval(){
  if(!FeaturesReady())return;busy=true;SetActions();footer.Text="Consultando apps instalados…";
  try{
#if TESTS
   if(TestRemovalScan!=null)removalStates=TestRemovalScan();else
#endif
   removalStates=await Task.Run(()=>AppRemoval.Scan());
   removalChecked.RemoveWhere(id=>!removalStates.Any(a=>a.App.Id==id&&a.CanRemove));FilterRemoval();footer.Text="Lista de apps atualizada. Revise os itens antes de remover.";
  }catch(Exception e){footer.Text="Consulta de apps não concluída: "+e.Message;}finally{busy=false;SetActions();}
 }
 async Task RemoveChosenApps(){
  if(!FeaturesReady())return;
  var selected=removalStates.Where(a=>removalChecked.Contains(a.App.Id)&&a.CanRemove).ToArray();if(selected.Length==0)return;
  string review=String.Join("\r\n",selected.Select(a=>a.App.Name+" · "+a.App.Method))+"\r\n\r\nA remoção pode apagar dados e não possui desfazer automático. O estado será consultado novamente antes e depois. Appx afeta a conta atual; WinGet pode afetar o PC.";
  if(!await InlineReview("Confirmar remoção de apps",review,true))return;
  removalRequest=Guid.NewGuid().ToString("N");UpdateFunctionalActions();
  try{if(await Elevated("--remove-apps",String.Join(",",selected.Select(a=>a.App.Id))+"|"+removalRequest)){foreach(var app in selected)removalChecked.Remove(app.App.Id);await RefreshRemoval();}}
  finally{removalRequest=null;SetActions();}
 }
 void BuildManualPage(){
  var page=Page("Ajustes manuais");var root=Rows(100,100,100,55,-1);page.Controls.Add(root);
  root.Controls.Add(Theme.Label("Controles avançados: valores decimais explícitos, sem seleção automática.\r\nAlteram o agendamento do Windows e podem piorar a resposta dos aplicativos. Exigem administrador e podem exigir reiniciar. Consulte o estado atual; o backup preserva o valor exato anterior.",10,Theme.Muted),0,0);
  int index=1;foreach(string id in new[]{"responsiveness","priority"}){
   var row=Rows(38,45);var pick=new ReadableCheckBox{Text=id=="responsiveness"?"Alterar SystemResponsiveness (0–100)":"Alterar Win32PrioritySeparation (0–63)",Dock=DockStyle.Fill,ForeColor=Theme.Text,Name="manual-"+id+"-enabled"};manualPicks.Add(id,pick);row.Controls.Add(pick,0,0);
   var fields=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false};var value=new NumericUpDown{Minimum=0,Maximum=id=="responsiveness"?100:63,Width=100,Name="manual-"+id+"-value",BackColor=Theme.Card,ForeColor=Theme.Text};manualValues.Add(id,value);fields.Controls.Add(value);var current=Theme.Label("Atual: ainda não consultado",10,Theme.Muted);current.Dock=DockStyle.None;current.Width=550;current.Height=34;manualCurrent.Add(id,current);fields.Controls.Add(current);row.Controls.Add(fields,0,1);root.Controls.Add(row,0,index++);pick.CheckedChanged+=(s,e)=>UpdateFunctionalActions();
  }
  var actions=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false};root.Controls.Add(actions,0,3);
  manualReadButton=Theme.Button("Consultar valores atuais");manualReadButton.Name="manual-read";manualReadButton.Width=225;manualReadButton.Click+=async(s,e)=>await ReadManualValues();actions.Controls.Add(manualReadButton);
  manualApplyButton=Theme.Button("Aplicar campos marcados",true);manualApplyButton.Name="manual-apply";manualApplyButton.Width=250;manualApplyButton.Click+=async(s,e)=>await ApplyManualValues();actions.Controls.Add(manualApplyButton);
 }
 async Task ReadManualValues(){
  if(!FeaturesReady())return;busy=true;SetActions();
  try{foreach(string id in manualCurrent.Keys){try{var value=await Task.Run(()=>App.Capture(ExtraSettings.Target(id)).Before);manualCurrent[id].Text="Atual: "+ChangeAudit.Value(value);decimal n;if(!value.Delete&&decimal.TryParse(value.Data,out n)&&n>=manualValues[id].Minimum&&n<=manualValues[id].Maximum)manualValues[id].Value=n;}catch(Exception e){manualCurrent[id].Text="Leitura indisponível: "+e.Message;}}}finally{busy=false;SetActions();}
 }
 async Task ApplyManualValues(){
  if(!FeaturesReady())return;string payload=String.Join(",",manualPicks.Where(p=>p.Value.Checked).Select(p=>p.Key+"="+manualValues[p.Key].Value.ToString(System.Globalization.CultureInfo.InvariantCulture)));if(payload.Length==0)return;
  string problem=null;try{var items=ExtraSettings.Manual(payload);if(await InlineReview("Confirmar ajustes manuais",String.Join("\r\n",items.Select(i=>i.ReviewTitle))+"\r\n\r\nPode piorar o desempenho. O backup será salvo antes das alterações; Desfazer restaura o estado anterior.",true))await Elevated("--apply-custom",payload);}catch(Exception e){problem=e.Message;}if(problem!=null)await InlineReview("Ajuste manual não iniciado",problem,false);
 }
}

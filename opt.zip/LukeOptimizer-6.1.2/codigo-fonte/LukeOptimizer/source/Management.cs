using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.ServiceProcess;
using System.Runtime.InteropServices;
using System.ComponentModel;

public class StartupEntry {
 public string Name {get;set;} public string Command {get;set;} public string Kind {get;set;}
 public string AppName {get;set;} public string Reason {get;set;} public bool Allowed {get;set;}
 public override string ToString(){return Name;}
}
public class OperationRequest {
 public string Sid {get;set;} public string Created {get;set;}
 public List<StartupEntry> Startup {get;set;} public ProcessToken Target {get;set;}
 public string[] PowerOptions {get;set;} public string PowerScheme {get;set;} public GameProfile Game {get;set;}
}
public class ServiceSaved {public string Name {get;set;} public bool Running {get;set;}}
public class ServiceState {public string State {get;set;} public bool CanStop {get;set;} public bool DependentsRunning {get;set;}}
public class PrioritySaved {public ProcessToken Target {get;set;} public string Before {get;set;} public string After {get;set;}}
static partial class App {
 [DllImport("advapi32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr OpenSCManager(string machine,string database,uint access);
 [DllImport("advapi32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr OpenService(IntPtr manager,string name,uint access);
 [DllImport("advapi32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool ChangeServiceConfig(IntPtr service,uint type,uint start,uint error,string binary,string group,IntPtr tag,string dependencies,string user,string password,string display);
 [DllImport("advapi32.dll",SetLastError=true)] static extern bool CloseServiceHandle(IntPtr handle);
 internal const string RunKey=@"Software\Microsoft\Windows\CurrentVersion\Run";
 internal static readonly Dictionary<string,string> OptionalServices=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase) {
  {"WSearch","Indexação da pesquisa — pode deixar buscas de arquivos/Outlook mais lentas."},
  {"Spooler","Impressão — desativa impressoras e impressão em PDF enquanto estiver desativado."},
  {"DiagTrack","Diagnóstico conectado — reduz coleta de diagnóstico; não há ganho de FPS comprovado."},
  {"Fax","Fax — use apenas se você não utiliza envio/recebimento de fax."},
  {"MapsBroker","Mapas baixados — interrompe acesso/atualização de mapas offline."},
  {"RetailDemo","Demonstração de varejo — dispensável em um PC pessoal que não usa modo de loja."},
  {"WMPNetworkSvc","Compartilhamento do Windows Media Player — interrompe streaming DLNA para outros aparelhos."},
  {"RemoteRegistry","Registro remoto — impede administração remota por esse serviço. Não altera acesso local."},
  {"WerSvc","Relatórios de erros — dificulta diagnóstico de falhas. Deixe ativo ao investigar crashes."},
  {"PhoneSvc","Telefonia / integração com telefone — pode afetar recursos de conexão com celular."}
 };
#if TESTS
 internal static Func<string,ServiceState> TestServiceRead;
 internal static Action<string,bool> TestServiceChange;
#endif
 internal static string RequestRoot {get{return Path.Combine(DataRoot,"pedidos-v3");}}
 internal static string RequestPath(string id) {Guid g;if(!Guid.TryParseExact(id,"N",out g))throw new Exception("Pedido inválido.");return Path.Combine(RequestRoot,id+".json");}
 internal static string SaveRequest(OperationRequest request) {
  Directory.CreateDirectory(RequestRoot);request.Sid=Sid;request.Created=DateTime.UtcNow.ToString("o");string id=Guid.NewGuid().ToString("N");
  File.WriteAllText(RequestPath(id),Json.Serialize(request));return id;
 }
 internal static OperationRequest ReadRequest(string id) {
  string path=RequestPath(id);if(!File.Exists(path)||new FileInfo(path).Length>256000)throw new Exception("Pedido ausente ou muito grande.");
  var r=Json.Deserialize<OperationRequest>(File.ReadAllText(path));DateTime created;
  if(r==null||r.Sid!=Sid||!DateTime.TryParse(r.Created,null,System.Globalization.DateTimeStyles.RoundtripKind,out created)||
   DateTime.UtcNow-created.ToUniversalTime()>TimeSpan.FromMinutes(10)||created.ToUniversalTime()>DateTime.UtcNow.AddSeconds(5))throw new Exception("Pedido expirado ou de outro usuário. Analise novamente.");
  return r;
 }
 internal static string StartupExecutable(string command) {
  if(String.IsNullOrWhiteSpace(command)||command.IndexOfAny(new[]{'\r','\n'})>=0)return "";
  string c=Environment.ExpandEnvironmentVariables(command).Trim(),exe;
  if(c.StartsWith("\"")){int end=c.IndexOf('"',1);if(end<2)return "";exe=c.Substring(1,end-1);}
  else {int end=c.IndexOf(' ');exe=end<0?c:c.Substring(0,end);}
  bool windowsAbsolute=exe.Length>=3&&Char.IsLetter(exe[0])&&exe[1]==':'&&(exe[2]=='\\'||exe[2]=='/')||exe.StartsWith("\\\\",StringComparison.Ordinal);
  if((!Path.IsPathRooted(exe)&&!windowsAbsolute)||!exe.EndsWith(".exe",StringComparison.OrdinalIgnoreCase))return "";
  return exe;
 }
 internal static bool StartupAllowed(string command) {
  string exe=StartupExecutable(command);if(exe.Length==0)return false;
  if(ResourceMonitor.Within(exe,Environment.GetFolderPath(Environment.SpecialFolder.Windows)))return false;
  string normalized=exe.Replace('/','\\');int slash=normalized.LastIndexOf('\\');string name=(slash>=0?normalized.Substring(slash+1):normalized);if(name.EndsWith(".exe",StringComparison.OrdinalIgnoreCase))name=name.Substring(0,name.Length-4);
  return ResourceMonitor.Closable.Contains(name)||new[]{"OneDrive","steam","EpicGamesLauncher"}.Contains(name,StringComparer.OrdinalIgnoreCase);
 }
 internal static List<StartupEntry> ScanStartup() {
  var rows=new List<StartupEntry>();if(!IsWindows)return rows;
  using(var h=Hive("HKEY_CURRENT_USER"))using(var key=h.OpenSubKey(RunKey,false)) {
   if(key==null)return rows;
   foreach(string name in key.GetValueNames()) {
    var kind=key.GetValueKind(name);string command=Convert.ToString(key.GetValue(name,"",Microsoft.Win32.RegistryValueOptions.DoNotExpandEnvironmentNames));
    bool allowed=(kind==Microsoft.Win32.RegistryValueKind.String||kind==Microsoft.Win32.RegistryValueKind.ExpandString)&&StartupAllowed(command);
    rows.Add(new StartupEntry {Name=name,Command=command,Kind=kind.ToString(),Allowed=allowed,AppName=Path.GetFileNameWithoutExtension(StartupExecutable(command)),
     Reason=allowed?"Opcional: não abrirá no próximo login. Backup exato do valor; sincronização/avisos podem parar até abrir o app.":"Protegido / comando não classificado. Use a Inicialização do Windows para revisar."});
   }
  }
  return rows.OrderByDescending(x=>x.Allowed).ThenBy(x=>x.Name).ToList();
 }
 internal static void DisableStartup(string requestId) {
  var req=ReadRequest(requestId);if(req.Startup==null||req.Startup.Count==0||req.Startup.Count>50)throw new Exception("Seleção de inicialização inválida.");
  var ops=new List<RegOp>();
  foreach(var e in req.Startup) {
   if(String.IsNullOrWhiteSpace(e.Name)||e.Name.Length>16383||!StartupAllowed(e.Command))throw new Exception("Entrada de inicialização não autorizada.");
   var op=new RegOp {Hive="HKEY_CURRENT_USER",Key=RunKey,Name=e.Name,Kind=e.Kind,Data=e.Command,Delete=true};
   var current=Capture(op).Before;
   if(current.Delete||current.Kind!=e.Kind||current.Data!=e.Command)throw new Exception("A inicialização mudou desde a análise: "+e.Name+". Analise novamente.");
   ops.Add(op);
  }
  var item=new Item {Id="startup-v3",Name="Desativar inicialização selecionada",ReviewTitle="Inicialização de apps selecionados",ActionCode="startup",Native=false,
   Operations=ops.ToArray(),Text="",Path="Inicialização do usuário",ReviewLevel="Revisado"};
  ApplyTransaction(new[]{item},"Integrado","Desativar inicialização de "+ops.Count+" app(s)");
 }
 static ServiceState ReadService(string name) {
#if TESTS
  if(TestServiceRead!=null)return TestServiceRead(name);
#endif
  using(var s=new ServiceController(name)) {
   s.Refresh();bool dependent=false;var deps=s.DependentServices;
   foreach(var d in deps)using(d){if(d.Status!=ServiceControllerStatus.Stopped)dependent=true;}
   return new ServiceState {State=s.Status.ToString(),CanStop=s.CanStop,DependentsRunning=dependent};
  }
 }
 static void ChangeService(string name,bool run) {
#if TESTS
  if(TestServiceChange!=null){TestServiceChange(name,run);return;}
#endif
  using(var s=new ServiceController(name)) {
   s.Refresh();var wanted=run?ServiceControllerStatus.Running:ServiceControllerStatus.Stopped;
   if(s.Status==wanted)return;
   if(!run) {
    var state=ReadService(name);if(!state.CanStop||state.DependentsRunning)throw new Exception("Serviço não pode parar sem afetar dependentes: "+name);
    s.Stop();
   } else s.Start();
   s.WaitForStatus(wanted,TimeSpan.FromSeconds(12));s.Refresh();
   if(s.Status!=wanted)throw new Exception("Estado do serviço não conferido: "+name);
  }
 }
 internal static string OptionalServiceStatus(string name) {
  if(!IsWindows)return "Abra no Windows para consultar.";
  try {var state=ReadService(name);var start=Capture(ServiceStart(name)).Before;return state.State+" | Start="+start.Data+(state.DependentsRunning?" | dependentes ativos":"");}
  catch(Exception e){return "Indisponível: "+e.Message;}
 }
 internal static RegOp ServiceStart(string name) {
  if(!OptionalServices.ContainsKey(name))throw new Exception("Serviço fora da lista opcional. Nenhuma alteração.");
  return new RegOp {Hive="HKEY_LOCAL_MACHINE",Key=@"SYSTEM\CurrentControlSet\Services\"+name,Name="Start",Kind="DWord",Data="4"};
 }
 static void SetServiceStart(string name,string start) {
  var op=ServiceStart(name);if(!new[]{"2","3","4"}.Contains(start))throw new Exception("Modo de inicialização não autorizado.");op.Data=start;
#if TESTS
  if(TestWrite!=null){WriteValue(op);return;}
#endif
  IntPtr manager=OpenSCManager(null,null,1),service=IntPtr.Zero;
  if(manager==IntPtr.Zero)throw new Win32Exception(Marshal.GetLastWin32Error());
  try {service=OpenService(manager,name,2);if(service==IntPtr.Zero)throw new Win32Exception(Marshal.GetLastWin32Error());
   if(!ChangeServiceConfig(service,UInt32.MaxValue,UInt32.Parse(start),UInt32.MaxValue,null,null,IntPtr.Zero,null,null,null,null))throw new Win32Exception(Marshal.GetLastWin32Error());
  }finally{if(service!=IntPtr.Zero)CloseServiceHandle(service);CloseServiceHandle(manager);}
 }
 internal static void DisableOptionalServices(string[] names) {
  if(names.Length==0||names.Length>OptionalServices.Count||names.Distinct(StringComparer.OrdinalIgnoreCase).Count()!=names.Length)throw new Exception("Seleção de serviços inválida.");
  foreach(string name in names)ServiceStart(name); // entire allowlist check before any record or mutation
  var rec=NewRecord("Desativar serviços opcionais selecionados","services-v3","Serviços");rec.ServiceValues=new List<ServiceSaved>();Save(rec);
  try {
   foreach(string name in names) {
    var value=Capture(ServiceStart(name));var state=ReadService(name);
    if(value.Before.Delete||value.Before.Kind!="DWord"||!new[]{"2","3","4"}.Contains(value.Before.Data))throw new Exception("Inicialização não reconhecida: "+name);
    if(value.Before.Data=="4"&&state.State=="Running")throw new Exception("Serviço em estado incomum (desativado, mas executando): "+name+". Estado preservado para diagnóstico manual.");
    if(state.State!="Running"&&state.State!="Stopped")throw new Exception("Serviço em transição/pausado: "+name+". Tente após estabilizar.");
    if(state.DependentsRunning||(state.State=="Running"&&!state.CanStop))throw new Exception("Serviço em uso por dependentes ou não pode parar: "+name);
    if(!Same(value.Before,value.After)||state.State=="Running"){rec.Values.Add(value);rec.ServiceValues.Add(new ServiceSaved {Name=name,Running=state.State=="Running"});}
    rec.Steps.Add(new StepResult {Id=name,Name=name,Status="preparando",Message=OptionalServices[name]});
   }
   Save(rec);
   if(rec.ServiceValues.Count==0){rec.Status="sem alterações";rec.Message="Os serviços selecionados já estavam desativados/parados.";Save(rec);return;}
   rec.Status="aplicando";rec.ChangesStarted=true;Save(rec);
   foreach(var svc in rec.ServiceValues) {
    WriteProgress(30,"Desativando serviço opcional",svc.Name);ChangeService(svc.Name,false);SetServiceStart(svc.Name,"4");
    if(ReadService(svc.Name).State!="Stopped"||!Same(Capture(ServiceStart(svc.Name)).Before,ServiceStart(svc.Name)))throw new Exception("Não foi possível conferir "+svc.Name);
    rec.Steps.Single(x=>x.Id==svc.Name).Status="conferido";Save(rec);
   }
   foreach(var step in rec.Steps.Where(x=>x.Status=="preparando"))step.Status="já configurado";
   rec.Status="aplicado";rec.Message="Estado parado e inicialização desativada conferidos. As funções selecionadas ficam indisponíveis até desfazer. Nenhum ganho de FPS medido.";Save(rec);
  }catch(Exception e) {
   if(rec.ChangesStarted){try{RestoreOptionalServices(rec);rec.Status="falhou e foi desfeito";}catch(Exception undo){rec.Status="falha na restauração";e=new Exception(e.Message+" | "+undo.Message);}}
   else rec.Status="falhou antes de alterar";
   rec.Message=e.Message;Save(rec);throw;
  }
 }
 internal static void RestoreOptionalServices(Record rec) {
  foreach(var svc in rec.ServiceValues??new List<ServiceSaved>())ServiceStart(svc.Name);
  foreach(var value in rec.Values){var now=Capture(value.After).Before;if(!Same(now,value.Before)&&!Same(now,value.After))throw new Exception("Configuração posterior detectada: "+value.After.Key);}
  foreach(var svc in rec.ServiceValues??new List<ServiceSaved>())if(!svc.Running&&ReadService(svc.Name).State!="Stopped")throw new Exception("Serviço foi iniciado depois; estado atual preservado: "+svc.Name);
  rec.Status="restaurando";Save(rec);
  try {
   foreach(var svc in rec.ServiceValues??new List<ServiceSaved>()) {
    var saved=rec.Values.Single(v=>SameTarget(v.Before,ServiceStart(svc.Name)));SetServiceStart(svc.Name,saved.Before.Data);
   }
   foreach(var svc in rec.ServiceValues??new List<ServiceSaved>()) {
    if(svc.Running)ChangeService(svc.Name,true); // never stop an independently restarted service while undoing
    else if(ReadService(svc.Name).State!="Stopped")throw new Exception("Serviço foi iniciado depois; estado atual preservado: "+svc.Name);
   }
   foreach(var v in rec.Values)if(!Same(Capture(v.Before).Before,v.Before))throw new Exception("Restauração não conferida: "+v.Before.Key);
   rec.Status="desfeito";rec.Message="Inicialização original e estado anterior dos serviços restaurados. Valores de inicialização atrasada não foram alterados.";Save(rec);
  }catch(Exception e){rec.Status="falha na restauração";rec.Message=e.Message;Save(rec);throw;}
 }
 internal static bool FocusAllowed(ProcessToken token) {
  if(token==null||token.UserSid!=Sid||!ResourceMonitor.Focusable.Contains(token.Name)||String.IsNullOrEmpty(token.Path)||token.Started<=0)return false;
  using(var self=Process.GetCurrentProcess())return token.Pid!=self.Id&&token.Session==self.SessionId&&!ResourceMonitor.Within(token.Path,Environment.GetFolderPath(Environment.SpecialFolder.Windows));
 }
 internal static void ApplyFocus(string requestId) {
  var requested=ReadRequest(requestId).Target;if(!FocusAllowed(requested))throw new Exception("Jogo/app fora da lista de foco.");
  using(var p=Process.GetProcessById(requested.Pid)) {
   var current=ResourceMonitor.Identify(p);if(!ResourceMonitor.SameIdentity(requested,current)||!FocusAllowed(current))throw new Exception("Processo mudou desde a seleção.");
   var rec=NewRecord("Foco: "+current.Name,"focus-v3","Foco");
   if(p.PriorityClass!=ProcessPriorityClass.Normal){rec.Status="sem alterações";rec.Message="Prioridade diferente de Normal: preferência atual preservada.";Save(rec);return;}
   rec.PriorityValue=new PrioritySaved {Target=current,Before="Normal",After="AboveNormal"};rec.Status="aplicando";Save(rec);
   try {p.PriorityClass=ProcessPriorityClass.AboveNormal;if(p.PriorityClass!=ProcessPriorityClass.AboveNormal)throw new Exception("Prioridade recusada pelo Windows/jogo.");
    rec.Status="aplicado";rec.Message="AboveNormal conferida, somente nesta instância do processo. Termina ao fechar o jogo/app ou ao desfazer. Não usa High/Realtime e não muda afinidade. FPS não medido.";Save(rec);
   }catch(Exception e){try{RestoreFocus(rec);rec.Status="falhou e foi desfeito";}catch{rec.Status="falha na restauração";}rec.Message=e.Message;Save(rec);throw;}
  }
 }
 internal static void RestoreFocus(Record rec) {
  var saved=rec.PriorityValue;if(saved==null||!FocusAllowed(saved.Target)||saved.Before!="Normal"||saved.After!="AboveNormal")throw new Exception("Backup de foco inválido.");
  Process p=null;
  try {
   try{p=Process.GetProcessById(saved.Target.Pid);}catch(ArgumentException){}
   if(p==null||p.HasExited||!ResourceMonitor.SameIdentity(saved.Target,ResourceMonitor.Identify(p))) {
    rec.Status="desfeito";rec.Message="A instância original já terminou. Nenhum outro processo foi alterado.";Save(rec);return;
   }
   if(p.PriorityClass!=ProcessPriorityClass.Normal&&p.PriorityClass!=ProcessPriorityClass.AboveNormal)throw new Exception("A prioridade mudou depois. Estado atual preservado.");
   p.PriorityClass=ProcessPriorityClass.Normal;if(p.PriorityClass!=ProcessPriorityClass.Normal)throw new Exception("Restauração da prioridade não conferida.");
   rec.Status="desfeito";rec.Message="Prioridade Normal restaurada e conferida.";Save(rec);
  }finally{if(p!=null)p.Dispose();}
 }
}

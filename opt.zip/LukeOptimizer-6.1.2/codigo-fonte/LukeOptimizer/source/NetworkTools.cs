using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Net;
using System.Net.NetworkInformation;
using System.Threading;

// Ações de rede do Windows, com allowlist fechada igual à de CommandTools: o cliente
// escolhe um Id, nunca um executável ou argumento. Separadas por consequência —
// quem só limpa cache não fica ao lado de quem derruba a conexão ou exige reiniciar.
//
// NENHUMA destas ações tem desfazer automático, e por isso "Rede" fica fora de
// App.CanUndo. Antes das duas destrutivas o aplicativo grava um despejo da
// configuração atual no registro do Histórico, para o usuário ter o que consultar.
public class NetworkAction {
 public string Id,Name,Category,Executable,Arguments,Effect,Tradeoff,Source,BackupArguments;
 public int TimeoutSeconds;
 public bool Administrator,Disconnects,NeedsRestart;
}
static class NetworkTools {
 internal static List<NetworkAction> Actions(){return new List<NetworkAction>{
  new NetworkAction{Id="net-flushdns",Name="DNS · limpar cache",Category="Cache",Executable="ipconfig.exe",Arguments="/flushdns",
   TimeoutSeconds=30,Administrator=true,
   Effect="Descarta o cache de resolução de nomes. A próxima visita a cada site consulta o servidor DNS de novo.",
   Tradeoff="Resolve site que mudou de endereço e continua abrindo errado. Não acelera a navegação: as primeiras consultas ficam um pouco mais lentas até o cache encher de novo. Não derruba a conexão.",
   Source="https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig"},

  new NetworkAction{Id="net-registerdns",Name="DNS · registrar nomes de novo",Category="Cache",Executable="ipconfig.exe",Arguments="/registerdns",
   TimeoutSeconds=60,Administrator=true,
   Effect="Renova o registro dinâmico deste computador no servidor DNS.",
   Tradeoff="Útil em rede com domínio quando o nome do PC não resolve. Em rede doméstica normalmente não muda nada. Não derruba a conexão.",
   Source="https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig"},

  new NetworkAction{Id="net-arp",Name="ARP · limpar tabela",Category="Cache",Executable="netsh.exe",Arguments="interface ip delete arpcache",
   TimeoutSeconds=30,Administrator=true,
   Effect="Descarta o mapeamento entre endereços IP e placas da rede local.",
   Tradeoff="Ajuda quando um aparelho trocou de placa ou de IP na mesma rede. A tabela é reconstruída sozinha em segundos. Pode causar uma pausa muito curta no tráfego local.",
   Source="https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/netsh-interface-ipv4"},

  new NetworkAction{Id="net-renew",Name="IP · renovar endereço (DHCP)",Category="Conexão",Executable="ipconfig.exe",Arguments="/renew",
   TimeoutSeconds=120,Administrator=true,Disconnects=true,
   Effect="Pede um endereço novo ao roteador para os adaptadores que usam DHCP.",
   Tradeoff="A CONEXÃO CAI POR ALGUNS SEGUNDOS. Downloads, chamadas e partidas em andamento podem quebrar. Não tem efeito em adaptador com IP fixo. Não altera DNS nem configuração do roteador.",
   Source="https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig"},

  new NetworkAction{Id="net-winsock",Name="Winsock · restaurar catálogo",Category="Reparo",Executable="netsh.exe",Arguments="winsock reset",
   TimeoutSeconds=120,Administrator=true,Disconnects=true,NeedsRestart=true,
   BackupArguments="winsock show catalog",
   Effect="Devolve o catálogo Winsock ao padrão do Windows, removendo camadas (LSP) que programas instalaram sobre a pilha de rede.",
   Tradeoff="EXIGE REINICIAR e NÃO TEM DESFAZER. É um reparo para conexão quebrada depois de VPN, proxy, antivírus ou adware — não é uma otimização e não aumenta velocidade. VPN, proxy e firewall de terceiros podem precisar ser reinstalados ou reconfigurados. O catálogo atual é gravado no Histórico antes da mudança.",
   Source="https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/netsh-winsock"},

  new NetworkAction{Id="net-ipreset",Name="TCP/IP · restaurar pilha",Category="Reparo",Executable="netsh.exe",Arguments="int ip reset",
   TimeoutSeconds=120,Administrator=true,Disconnects=true,NeedsRestart=true,
   BackupArguments="int ip show config",
   Effect="Reescreve as chaves de TCP/IP com os valores padrão do Windows.",
   Tradeoff="EXIGE REINICIAR e NÃO TEM DESFAZER. Apaga IP fixo, máscara, gateway e DNS configurados manualmente — anote-os antes se não usa DHCP. É reparo, não otimização: não aumenta velocidade nem reduz ping. A configuração atual é gravada no Histórico antes da mudança.",
   Source="https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/netsh-interface-ipv4"}
 };}

 internal static NetworkAction Resolve(string id){
  var found=Actions().SingleOrDefault(a=>a.Id==id);
  if(found==null)throw new ArgumentException("Ação de rede fora do catálogo permitido.");
  return found;
 }

 // ---------- diagnósticos, somente leitura ----------
 internal static readonly string[] Diagnostics={"netdiag-dns","netdiag-mtu","netdiag-quality"};
 internal static bool IsDiagnostic(string id){return Diagnostics.Contains(id);}
 internal static string DiagnosticTitle(string id){
  if(id=="netdiag-dns")return "Rede · servidores DNS configurados";
  if(id=="netdiag-mtu")return "Rede · descobrir MTU do caminho";
  if(id=="netdiag-quality")return "Rede · perda de pacotes e variação";
  throw new ArgumentException("Diagnóstico de rede desconhecido.");
 }
 internal static string DiagnosticDetail(string id){
  if(id=="netdiag-dns")return "Lista os servidores DNS de cada adaptador ativo e mede o tempo de ida e volta ICMP até cada um. IMPORTANTE: isso mede o caminho de rede até o servidor, NÃO o tempo de resposta a uma consulta DNS. Um servidor pode responder ICMP devagar e resolver nomes rápido, ou simplesmente não responder a ping. Não troca nenhum DNS.";
  if(id=="netdiag-mtu")return "Envia pacotes ICMP com o bit \"não fragmentar\" e tamanho variável até o gateway padrão, em busca do maior que passa inteiro. Soma 28 bytes de cabeçalho para chegar ao MTU. Muitos roteadores e firewalls descartam esse tipo de pacote em silêncio; nesse caso o resultado é inconclusivo e o app diz isso em vez de chutar. Nada é alterado.";
  if(id=="netdiag-quality")return "Envia uma sequência de pings e informa perda, mínimo, máximo, média e variação entre respostas consecutivas. Mede o caminho até o host escolhido neste momento; não mede o servidor do seu jogo, bufferbloat sob carga nem input lag.";
  throw new ArgumentException("Diagnóstico de rede desconhecido.");
 }

 // Gateway padrão IPv4 do primeiro adaptador ativo — é o alvo certo para MTU local.
 internal static IPAddress Gateway(){
  foreach(var n in NetworkInterface.GetAllNetworkInterfaces()){
   if(n.OperationalStatus!=OperationalStatus.Up||n.NetworkInterfaceType==NetworkInterfaceType.Loopback)continue;
   try{
    foreach(var g in n.GetIPProperties().GatewayAddresses){
     if(g.Address!=null&&g.Address.AddressFamily==System.Net.Sockets.AddressFamily.InterNetwork&&!g.Address.Equals(IPAddress.Any))return g.Address;
    }
   }catch{}
  }
  return null;
 }

 internal static List<IPAddress> DnsServers(){
  var list=new List<IPAddress>();
  foreach(var n in NetworkInterface.GetAllNetworkInterfaces()){
   if(n.OperationalStatus!=OperationalStatus.Up||n.NetworkInterfaceType==NetworkInterfaceType.Loopback)continue;
   try{
    foreach(var d in n.GetIPProperties().DnsAddresses)if(!list.Contains(d))list.Add(d);
   }catch{}
  }
  return list;
 }

 static string Rtt(IPAddress address,CancellationToken cancel){
  long total=0;int ok=0;
  try{
   using(var ping=new Ping()){
    for(int n=0;n<4;n++){
     if(cancel.IsCancellationRequested)break;
     try{
      var reply=ping.Send(address,1500);
      if(reply!=null&&reply.Status==IPStatus.Success){total+=reply.RoundtripTime;ok++;}
     }catch{}
    }
   }
  }catch(Exception e){return "consulta indisponível ("+e.Message+")";}
  if(ok==0)return "sem resposta a ICMP — não significa que o DNS esteja ruim";
  return (total/ok)+" ms em "+ok+" de 4 respostas (caminho até o servidor, não tempo de consulta DNS)";
 }

 internal static string ReadDnsServers(CancellationToken cancel){
  if(!App.IsWindows)throw new Exception("Requer Windows.");
  var servers=DnsServers();
  if(servers.Count==0)return "Nenhum servidor DNS informado pelos adaptadores ativos.";
  var report=new StringBuilder();
  foreach(var address in servers){
   report.AppendLine(address.ToString()+" — "+Rtt(address,cancel));
   if(cancel.IsCancellationRequested)break;
  }
  report.AppendLine();
  report.AppendLine("O aplicativo NÃO troca o servidor DNS. Trocar DNS pode mudar quem resolve seus nomes e para onde seus pedidos vão; é decisão sua, na tela de rede do Windows.");
  return report.ToString();
 }

 // MTU por busca binária com DontFragment. Carga útil máxima de 1472 corresponde a
 // MTU 1500 (20 bytes de IPv4 + 8 de ICMP). O piso de 548 é o mínimo prático do IPv4.
 // Perda e variação, em versão síncrona: este código roda no processo filho elevado,
 // sem laço de mensagens, então não há Task nem risco de travar esperando uma.
 internal static string ProbeQuality(string host,CancellationToken cancel){
  if(!App.IsWindows)throw new Exception("Requer Windows.");
  var times=new List<long>();int sent=0;
  try{
   using(var ping=new Ping()){
    for(int n=0;n<16&&!cancel.IsCancellationRequested;n++){
     sent++;
     try{
      var reply=ping.Send(host,1500);
      if(reply!=null&&reply.Status==IPStatus.Success)times.Add(reply.RoundtripTime);
     }catch{}
     Thread.Sleep(120);
    }
   }
  }catch(Exception e){return "Medição indisponível: "+e.Message;}
  if(sent==0)return "Nenhum pacote foi enviado.";
  var report=new StringBuilder();
  report.AppendLine("Alvo: "+host);
  report.AppendLine("Enviados: "+sent+" · recebidos: "+times.Count+" · perda: "+((sent-times.Count)*100.0/sent).ToString("0.0")+"%");
  if(times.Count==0){
   report.AppendLine("Sem resposta. Isso também acontece quando o host bloqueia ICMP; não é prova de conexão ruim.");
   return report.ToString();
  }
  double jitter=0;
  for(int n=1;n<times.Count;n++)jitter+=Math.Abs(times[n]-times[n-1]);
  if(times.Count>1)jitter/=(times.Count-1);
  report.AppendLine("Mínimo: "+times.Min()+" ms · máximo: "+times.Max()+" ms · média: "+times.Average().ToString("0.0")+" ms");
  report.AppendLine("Variação média entre respostas consecutivas: "+jitter.ToString("0.0")+" ms");
  return report.ToString();
 }

 internal const int HeaderBytes=28,MinPayload=548,MaxPayload=1472;
 internal static int MtuFromPayload(int payload){return payload+HeaderBytes;}
 internal static string ProbeMtu(CancellationToken cancel){
  if(!App.IsWindows)throw new Exception("Requer Windows.");
  var gateway=Gateway();
  if(gateway==null)return "Nenhum gateway IPv4 ativo foi encontrado. Sem alvo local, a sondagem não é confiável.";
  int low=MinPayload,high=MaxPayload,best=0,attempts=0,blocked=0;
  try{
   using(var ping=new Ping()){
    var options=new PingOptions(64,true);
    while(low<=high&&!cancel.IsCancellationRequested){
     int mid=(low+high)/2;attempts++;
     PingReply reply=null;
     try{reply=ping.Send(gateway,2000,new byte[mid],options);}catch{}
     if(reply!=null&&reply.Status==IPStatus.Success){best=mid;low=mid+1;}
     else if(reply!=null&&reply.Status==IPStatus.PacketTooBig)high=mid-1;
     else {blocked++;high=mid-1;}
    }
   }
  }catch(Exception e){return "Sondagem indisponível: "+e.Message;}
  var report=new StringBuilder();
  report.AppendLine("Gateway sondado: "+gateway);
  report.AppendLine("Tentativas: "+attempts+(blocked>0?" · "+blocked+" sem resposta clara":""));
  if(best==0){
   report.AppendLine("RESULTADO INCONCLUSIVO: nenhum tamanho passou. O gateway provavelmente descarta pacotes com o bit \"não fragmentar\", o que é comum. Não conclua que o MTU está errado.");
   report.AppendLine("Nada foi alterado.");
   return report.ToString();
  }
  report.AppendLine("Maior carga útil que passou inteira: "+best+" bytes");
  report.AppendLine("MTU correspondente do caminho: "+MtuFromPayload(best)+" bytes");
  if(blocked>0)report.AppendLine("Parte das sondagens não respondeu, então este número é um piso, não uma medida exata.");
  if(MtuFromPayload(best)>=1500)report.AppendLine("1500 é o padrão da Ethernet: não há o que ajustar.");
  else report.AppendLine("Abaixo de 1500 é normal em PPPoE, VPN e algumas operadoras. Alterar o MTU do adaptador à força pode PIORAR a conexão; o aplicativo não faz isso por você e apenas informa a medida.");
  return report.ToString();
 }
}

static partial class App {
 internal static Record RunNetworkDiagnostic(string id,CancellationToken token){
  if(!NetworkTools.IsDiagnostic(id))throw new ArgumentException("Diagnóstico de rede desconhecido.");
  var record=NewRecord(NetworkTools.DiagnosticTitle(id),id,"Diagnóstico");
  Save(record);
  try{
   string text;
   if(id=="netdiag-dns")text=NetworkTools.ReadDnsServers(token);
   else if(id=="netdiag-mtu")text=NetworkTools.ProbeMtu(token);
   else text=NetworkTools.ProbeQuality("1.1.1.1",token);
   record.Status="consulta concluída";record.Message=text;
  }catch(Exception e){
   record.Status="leitura indisponível";
   record.Message=ErrorHelp.For(e).FriendlyError+"\r\n"+e.Message;
  }
  record.Message+="\r\n\r\n"+NetworkTools.DiagnosticDetail(id);
  record.Steps.Add(new StepResult{Id=id,Name=record.Name,Status=record.Status,Message=record.Message});
  Save(record);return record;
 }

 // Ação de rede: sem desfazer automático. Antes das destrutivas grava um despejo da
 // configuração atual no registro, que é o mais próximo de backup que estes comandos têm.
 internal static Record RunNetworkAction(string id,CancellationToken token){
  var action=NetworkTools.Resolve(id);
  var record=NewRecord(action.Name,id,"Rede");
  record.RequestedAdmin=action.Administrator;
  Save(record);
  try{
   if(!String.IsNullOrEmpty(action.BackupArguments)){
    record.Status="gravando configuração atual";Save(record);
    var dump=ManagedCommand.Run(SystemExe(action.Executable),action.BackupArguments,60,token);
    record.Steps.Add(new StepResult{Id=id+"-backup",Name="Configuração antes da mudança",
     Status=dump.ExitCode==0?"gravada":"indisponível",
     Message=dump.ExitCode==0?dump.Output:"Não foi possível gravar o estado anterior: "+dump.Output});
    if(dump.ExitCode!=0){
     record.Status="cancelado antes de alterar";
     record.Message="A configuração atual não pôde ser gravada, então a alteração NÃO foi executada. Um reparo sem cópia do estado anterior é risco sem rede de segurança.";
     Save(record);return record;
    }
    Save(record);
   }
   record.Status="executando";record.ChangesStarted=true;Save(record);
   var result=ManagedCommand.Run(SystemExe(action.Executable),action.Arguments,action.TimeoutSeconds,token);
   record.OutcomeCode=result.TimedOut?"TIMEOUT":result.Cancelled?"CANCELLED":result.ExitCode!=0?"COMMAND_FAILED":"OK";
   record.Status=result.TimedOut?"tempo esgotado":result.Cancelled?"cancelado":result.ExitCode!=0?"falhou":"concluído";
   record.Steps.Add(new StepResult{Id=id,Name=action.Name,Status=record.Status,
    Message="Código de saída: "+result.ExitCode+"\r\n"+result.Output+"\r\nLog completo: "+result.LogPath});
   record.Message=action.Effect+"\r\n\r\n"+action.Tradeoff+
    "\r\n\r\nEsta ação NÃO tem desfazer automático."+
    (action.NeedsRestart?"\r\nREINICIE O COMPUTADOR para que a mudança tenha efeito.":"")+
    "\r\nFonte: "+action.Source;
  }catch(Exception e){
   record.Status="falhou";
   record.OutcomeCode=ErrorHelp.For(e).ErrorCode;
   record.Message=ErrorHelp.For(e).FriendlyError+"\r\n"+e;
  }
  Save(record);return record;
 }
}

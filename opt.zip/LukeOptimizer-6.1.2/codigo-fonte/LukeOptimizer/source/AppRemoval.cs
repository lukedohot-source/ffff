using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Diagnostics;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;

public class DebloatApp {public string Id,Name,Description,Method,Recommendation;public string[] PackageIds;}
public class InstalledApp {public string Name,PackageFullName,Version;public bool NonRemovable,IsFramework;}
public class AppRemovalState {public DebloatApp App;public string State,Detail;public bool Installed,CanRemove,Known;public List<InstalledApp> Packages=new List<InstalledApp>();public List<string> WingetIds=new List<string>();}
public class RemovalEvidence {public string Id,Name,Method,Scope,Before,After,Status,Error,Started,Checked;public bool Attempted,AfterKnown;}
public class CommandResult {public int ExitCode;public string Output;}
static class AppRemoval {
 static List<DebloatApp> catalog;
 internal static List<DebloatApp> Catalog(){
  if(catalog!=null)return catalog;string text;
  using(var s=Assembly.GetExecutingAssembly().GetManifestResourceStream("debloat-apps.json"))using(var r=new StreamReader(s,Encoding.UTF8))text=r.ReadToEnd();
  var data=App.Json.Deserialize<Dictionary<string,object>>(text);var result=new List<DebloatApp>();
  foreach(Dictionary<string,object> raw in (IEnumerable)data["Apps"]){
   object id=raw["AppId"];var ids=id is string?new[]{(string)id}:((IEnumerable)id).Cast<object>().Select(Convert.ToString).ToArray();
   if(ids.Length==0||ids.Any(x=>!Regex.IsMatch(x,@"\A[A-Za-z0-9][A-Za-z0-9._-]{1,180}\z")))throw new Exception("Identificador inválido no catálogo de apps.");
   string method=Convert.ToString(raw["RemovalMethod"]);if(method!="Appx"&&method!="WinGet")throw new Exception("Método de remoção desconhecido.");
   result.Add(new DebloatApp{Id="debloat-"+result.Count.ToString("000"),Name=Convert.ToString(raw["FriendlyName"]),Description=Convert.ToString(raw["Description"]),Method=method,Recommendation=Convert.ToString(raw["Recommendation"]),PackageIds=ids});
  }
  return catalog=result;
 }
 internal static List<DebloatApp> Resolve(string ids){
  var keys=ids.Split(new[]{','});if(keys.Length==0||keys.Length>Catalog().Count||keys.Distinct().Count()!=keys.Length)throw new Exception("Seleção de apps inválida.");
  return keys.Select(k=>Catalog().SingleOrDefault(a=>a.Id==k)??ThrowUnknown()).ToList();
 }
 static DebloatApp ThrowUnknown(){throw new Exception("App não reconhecido no catálogo enviado.");}
 internal static CommandResult Run(string exe,string arguments,int timeout=120000){
  var result=ManagedCommand.Run(exe,arguments,Math.Max(1,timeout/1000),System.Threading.CancellationToken.None,Encoding.UTF8,16000000);
  if(result.TimedOut||result.Cancelled)throw new TimeoutException("O comando excedeu o tempo. A remoção não foi confirmada; confira a lista antes de repetir. Log: "+result.LogPath);
  return new CommandResult{ExitCode=result.ExitCode,Output=result.Output};
 }
 internal static CommandResult PowerShell(string body){
  string source="$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; [Console]::OutputEncoding=[Text.UTF8Encoding]::new($false); try { "+body+" } catch { [Console]::Error.WriteLine($_.Exception.ToString()); exit 1 }";
  return Run(App.SystemExe(@"WindowsPowerShell\v1.0\powershell.exe"),"-NoProfile -NonInteractive -EncodedCommand "+Convert.ToBase64String(Encoding.Unicode.GetBytes(source)));
 }
 internal static List<InstalledApp> ReadAppx(){
  var r=PowerShell("$items=@(Get-AppxPackage -ErrorAction Stop | Select-Object Name,PackageFullName,@{N='Version';E={$_.Version.ToString()}},NonRemovable,IsFramework); ConvertTo-Json -InputObject $items -Depth 4 -Compress");
  if(r.ExitCode!=0)throw new Exception("Não foi possível consultar os apps: "+r.Output);return App.Json.Deserialize<List<InstalledApp>>(r.Output.Trim())??new List<InstalledApp>();
 }
 static string WingetPath {get{return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),@"Microsoft\WindowsApps\winget.exe");}}
 static bool WingetInstalled(string id){
  if(!File.Exists(WingetPath))throw new Exception("WinGet não encontrado. Instale/atualize o Instalador de Aplicativos pela Microsoft Store.");
  var r=Run(WingetPath,"list --id "+App.Quote(id)+" --exact --disable-interactivity",45000);
  if(r.ExitCode==0)return true;
  if(unchecked((uint)r.ExitCode)==0x8A150014)return false;
  throw new Exception("WinGet não confirmou a instalação (0x"+r.ExitCode.ToString("X8")+"): "+r.Output);
 }
 internal static AppRemovalState Match(DebloatApp app,List<InstalledApp> packages,string scanError=null){
  var s=new AppRemovalState{App=app};
  if(scanError!=null){s.State="Leitura indisponível";s.Detail=scanError;return s;}
  s.Known=true;s.Packages=packages.Where(p=>app.PackageIds.Any(id=>String.Equals(id,p.Name,StringComparison.OrdinalIgnoreCase))).ToList();s.Installed=s.Packages.Count>0;
  s.CanRemove=s.Installed&&s.Packages.All(p=>!p.NonRemovable&&!p.IsFramework);
  s.State=!s.Installed?"Não instalado":s.CanRemove?"Instalado":"Protegido pelo Windows";
  s.Detail=String.Join("\n",s.Packages.Select(p=>p.PackageFullName));if(!s.CanRemove&&s.Installed)s.Detail+="\nO Windows marca este pacote como componente não removível ou biblioteca compartilhada.";
  return s;
 }
 internal static AppRemovalState ReadOne(DebloatApp app){
  if(app.Method=="Appx")return Match(app,ReadAppx());
  var s=new AppRemovalState{App=app,Known=true};foreach(string id in app.PackageIds)if(WingetInstalled(id))s.WingetIds.Add(id);
  s.Installed=s.CanRemove=s.WingetIds.Count>0;s.State=s.Installed?"Instalado via WinGet":"Não instalado";s.Detail=String.Join(", ",s.WingetIds);return s;
 }
 internal static List<AppRemovalState> Scan(){
  List<InstalledApp> packages=null;string error=null;try{packages=ReadAppx();}catch(Exception e){error=e.Message;}
  var states=new List<AppRemovalState>();foreach(var a in Catalog()){
   if(a.Method=="Appx")states.Add(Match(a,packages,error));else try{states.Add(ReadOne(a));}catch(Exception e){states.Add(new AppRemovalState{App=a,State="Leitura indisponível",Detail=e.Message});}
  }return states;
 }
 internal static string Rows(List<AppRemovalState> states){
  var b=new StringBuilder();foreach(var s in states)b.Append(LiquidProtocol.Row("app",s.App.Id,s.App.Name,s.App.Description,s.App.Recommendation,s.App.Method,String.Join(", ",s.App.PackageIds),s.State,s.Detail,s.CanRemove?"1":"0",s.Installed?"1":"0"));
  return b.Append(LiquidProtocol.Row("apps_checked",DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"))).ToString();
 }
 internal static string Describe(AppRemovalState state){return !state.Known?"Leitura indisponível":!state.Installed?"Não instalado":state.App.Method=="Appx"?String.Join("\n",state.Packages.Select(p=>p.PackageFullName)):String.Join(", ",state.WingetIds);}
 internal static void Execute(AppRemovalState before){
  if(!before.CanRemove)throw new Exception("O app não está disponível para remoção.");
  if(before.App.Method=="Appx"){
   foreach(var package in before.Packages){
    var token=Convert.ToBase64String(Encoding.UTF8.GetBytes(package.PackageFullName));
    var r=PowerShell("$name=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('"+token+"')); $p=@(Get-AppxPackage -ErrorAction Stop | Where-Object {$_.PackageFullName -eq $name}); if($p.Count -ne 1){throw 'A identidade instalada mudou; atualize a lista.'}; if($p[0].NonRemovable -or $p[0].IsFramework){throw 'Componente protegido pelo Windows.'}; Remove-AppxPackage -Package $p[0].PackageFullName -ErrorAction Stop");
    if(r.ExitCode!=0)throw new Exception("Windows recusou a remoção: "+r.Output);
   }
  }else foreach(string id in before.WingetIds){var r=Run(WingetPath,"uninstall --id "+App.Quote(id)+" --exact --silent --disable-interactivity --accept-source-agreements");if(r.ExitCode!=0)throw new Exception("Desinstalador retornou 0x"+r.ExitCode.ToString("X8")+": "+r.Output);}
 }
 internal static void RemoveItems(Record r,List<DebloatApp> selected,Func<DebloatApp,AppRemovalState> read,Action<AppRemovalState> remove,Func<bool> cancel){
  r.Removals=new List<RemovalEvidence>();r.Schema=4;App.Save(r);
  foreach(var app in selected){
   if(cancel()){r.Message="Interrompido a pedido do usuário após a operação atual.";break;}
   var e=new RemovalEvidence{Id=app.Id,Name=app.Name,Method=app.Method,Scope=app.Method=="Appx"?"Conta atual":"Instalação identificada pelo WinGet; pode abranger o PC",Started=ChangeAudit.Now(),Status="Consultando"};r.Removals.Add(e);App.Save(r);
   App.WriteProgress(r.Removals.Count*100/selected.Count,"Removendo apps",app.Name);
   try{
    var before=read(app);e.Before=Describe(before);if(!before.Known)throw new Exception("Não foi possível confirmar o estado anterior.");
    if(!before.Installed){e.After=e.Before;e.AfterKnown=true;e.Status="Já não estava instalado";continue;}
    if(!before.CanRemove){e.Status="Não removido: protegido pelo Windows";e.After=e.Before;e.AfterKnown=true;continue;}
    e.Attempted=true;e.Status="Removendo";App.Save(r);
    try{remove(before);}catch(Exception ex){e.Error=ChangeAudit.Error(ex);}
    var after=read(app);e.After=Describe(after);e.AfterKnown=after.Known;
    e.Status=!after.Known?"Remoção não confirmada":after.Installed?"Não removido / ainda instalado":"Removido e conferido";
   }catch(Exception ex){e.Error=ChangeAudit.Error(ex);e.Status="Não foi possível confirmar";}
   finally{e.Checked=ChangeAudit.Now();App.Save(r);}
  }
  int removed=r.Removals.Count(x=>x.Status=="Removido e conferido"),failed=r.Removals.Count(x=>x.Attempted&&x.Status!="Removido e conferido"||x.Status=="Não foi possível confirmar");
  r.Status=selected.Count!=r.Removals.Count?"remoção interrompida":failed>0?"remoção com pendências":"remoção concluída";r.Message=removed+" app(s) removido(s) e conferido(s); "+failed+" pendência(s); "+(selected.Count-r.Removals.Count)+" não processado(s). "+r.Message+" A remoção pode apagar dados do app e exige reinstalação para recuperar o programa; não há desfazer automático.";App.Save(r);
 }
 internal static string Verify(Record r){var b=new StringBuilder("CONFERÊNCIA ATUAL DE APPS — "+ChangeAudit.Now()+" UTC\r\n");foreach(var e in r.Removals){try{var app=Catalog().Single(x=>x.Id==e.Id);var current=ReadOne(app);b.AppendLine(e.Name+": "+current.State).AppendLine(Describe(current));}catch(Exception ex){b.AppendLine(e.Name+": não confirmado. "+ex.Message);}}return b.ToString();}
 internal static Record Remove(string ids,string cancelFile){
  var selected=Resolve(ids);var r=new Record{Id=Guid.NewGuid().ToString("N"),UserSid=App.Sid,Name="Remover apps escolhidos ("+selected.Count+")",Kind="Remoção de apps",ItemIds=selected.Select(x=>x.Id).ToArray(),Time=ChangeAudit.Now(),Status="preparando",Message=""};
  RemoveItems(r,selected,ReadOne,Execute,()=>File.Exists(cancelFile));return r;
 }
}

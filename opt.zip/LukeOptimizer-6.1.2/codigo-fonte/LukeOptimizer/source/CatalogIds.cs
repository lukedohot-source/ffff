using System;
using System.Linq;
using System.Collections.Generic;

static class CatalogIds {
 static Dictionary<string,string> cache;
 internal static Dictionary<string,string> Aliases(){
  if(cache!=null)return cache;
  var result=new Dictionary<string,string>(StringComparer.Ordinal);
  foreach(var e in PerformanceLibrary.Load().Where(e=>e.Action=="native")){
   string existing;if(result.TryGetValue(e.Id,out existing)&&existing!=e.Target)throw new Exception("ID da interface com destinos diferentes: "+e.Id);
   result[e.Id]=e.Target;
  }
  // Accept historical v5-option IDs only for an actual v5-native implementation.
  foreach(var i in V5Options.Items().Concat(V5InputItems.Create()))if(i.Id.StartsWith("v5-native-",StringComparison.Ordinal))result["v5-option-"+i.Id.Substring(10)]=i.Id;
  cache=result;return result;
 }
 internal static string Canonical(string id){string target;return id!=null&&Aliases().TryGetValue(id,out target)?target:id;}
 internal static string[] Migrations(string payload){return (payload??"").Split(new[]{','}).Where(id=>Canonical(id)!=id).Select(id=>id+" -> "+Canonical(id)).ToArray();}
 internal static List<Item> NativeItems(){return Builtins.Create().Concat(V5Options.Items()).Concat(V5InputItems.Create()).Concat(ImportedOptions.Items()).Concat(ExtraSettings.Items()).Concat(ReviewedFeatures.Items()).Concat(WindowsSettings.AsCatalogItems()).ToList();}
 internal static void Validate(){
  var items=NativeItems();var all=PerformanceLibrary.Load();
  if(items.Select(i=>i.Id).Distinct().Count()!=items.Count||all.Select(i=>i.Id).Distinct().Count()!=all.Count)throw new Exception("Catálogo contém IDs duplicados.");
  foreach(var entry in all.Where(e=>e.Action=="native"))if(!items.Any(i=>i.Id==Canonical(entry.Target)))throw new Exception("Ação da interface sem implementação: "+entry.Id);
 }
}

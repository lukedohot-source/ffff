using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Threading;

public class BackupAttachment {public string Kind {get;set;} public string Path {get;set;} public string Hash {get;set;} public string Description {get;set;}}
static class BackupBundle {
 internal static bool NetworkAction(Item item){return (item.Operations??new RegOp[0]).Any(o=>new[]{"Tcpip","Dnscache","Ndis","Afd","Network"}.Any(word=>o.Key.IndexOf(word,StringComparison.OrdinalIgnoreCase)>=0));}
 internal static void Capture(Record record,IEnumerable<Item> items){
  var selected=items.ToList();if(!selected.Any(i=>NetworkAction(i)||i.ActionCode=="power"))return;
  if(record.Attachments==null)record.Attachments=new List<BackupAttachment>();if(record.Attachments.Count>0)return;
#if TESTS
  if(App.TestCapture!=null||App.TestPlanGet!=null){record.Attachments.Add(new BackupAttachment{Kind="Simulado",Description="Backend de teste: nenhum comando de configuração/exportação do Windows executado."});return;}
#endif
  string root=Path.Combine(App.DataRoot,"backups-complementares",record.Id);Directory.CreateDirectory(root);
  if(selected.Any(NetworkAction)){
   foreach(string family in new[]{"ipv4","ipv6"}){var command=ManagedCommand.Run(App.SystemExe("netsh.exe"),"interface "+family+" dump",45,CancellationToken.None,null,1000000);if(command.ExitCode!=0||command.TimedOut)throw new IOException("Não foi possível salvar a configuração "+family+" antes da alteração. Nenhuma gravação desta ação foi iniciada. "+command.Output);
    string path=Path.Combine(root,"rede-"+family+".txt");AtomicStore.Write(path,command.Output);record.Attachments.Add(new BackupAttachment{Kind="Rede",Path=path,Hash=App.Digest(path),Description="Referência integral do netsh. A reversão automática usa os valores específicos do histórico; não reaplica este dump cegamente."});
   }
  }
  if(selected.Any(i=>i.ActionCode=="power")){string guid=App.ActivePlan();Guid parsed;if(!Guid.TryParse(guid,out parsed))throw new IOException("Plano de energia não identificado.");string path=Path.Combine(root,"energia-anterior.pow");var command=ManagedCommand.Run(App.SystemExe("powercfg.exe"),"/export "+App.Quote(path)+" "+parsed.ToString("D"),45,CancellationToken.None);if(command.ExitCode!=0||command.TimedOut||!File.Exists(path))throw new IOException("Não foi possível exportar o plano de energia antes da alteração. "+command.Output);record.Attachments.Add(new BackupAttachment{Kind="Energia",Path=path,Hash=App.Digest(path),Description="Plano exportado antes da mudança. O desfazer reativa o GUID anterior e preserva alterações posteriores."});}
 }
}

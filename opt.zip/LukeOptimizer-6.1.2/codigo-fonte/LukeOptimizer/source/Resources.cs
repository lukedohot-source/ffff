using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Security.Principal;

public class ResourceSample {
 public string Time {get;set;} public double TotalMB {get;set;} public double AvailableMB {get;set;}
 public double CpuPercent {get;set;} public int Processes {get;set;} public bool MemoryKnown {get;set;}
 public bool CpuKnown {get;set;} public double Seconds {get;set;} public string Error {get;set;}
}
public class ProcessToken {
 public int Pid {get;set;} public long Started {get;set;} public int Session {get;set;}
 public string Name {get;set;} public string Path {get;set;} public double MemoryMB {get;set;}
 public string UserSid {get;set;}
 public bool MemoryKnown {get;set;}
 public double CpuPercent {get;set;} public bool CpuKnown {get;set;} public bool HasWindow {get;set;}
 public string Protection {get;set;}
}
public class ProcessGroup {
 public string Name {get;set;} public List<ProcessToken> Processes {get;set;}
 public double MemoryMB {get{return Processes.Sum(p=>p.MemoryMB);}}
 public double CpuPercent {get{return Processes.Sum(p=>p.CpuPercent);}}
 public bool CanClose {get{return Processes.Count>0&&Processes.All(p=>String.IsNullOrEmpty(p.Protection));}}
 public override string ToString(){return Name;}
}
static class ResourceMonitor {
 [StructLayout(LayoutKind.Sequential)] struct MemoryStatus {
  public uint Length,Load;public ulong TotalPhysical,AvailablePhysical,TotalPage,AvailablePage,TotalVirtual,AvailableVirtual,Extended;
 }
 [StructLayout(LayoutKind.Sequential)] struct FT {public uint Low,High;public ulong Value {get{return ((ulong)High<<32)|Low;}}}
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GlobalMemoryStatusEx(ref MemoryStatus status);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetSystemTimes(out FT idle,out FT kernel,out FT user);
 [DllImport("advapi32.dll",SetLastError=true)] static extern bool OpenProcessToken(IntPtr process,uint access,out IntPtr token);
 [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
 internal static readonly HashSet<string> Closable=new HashSet<string>(new[]{
  "chrome","msedge","firefox","brave","opera","spotify","discord","telegram","slack","teams","ms-teams","zoom","skype",
  "vivaldi","waterfox","librewolf","floorp","zen","thunderbird","WhatsApp","Signal","DiscordCanary","DiscordPTB",
  "obs64","Streamlabs OBS","Overwolf","OverwolfBrowser","Medal","ShareX","ScreenToGif","CamtasiaStudio",
  "vlc","mpv","PotPlayerMini64","iTunes","Deezer","Amazon Music","TIDAL","qBittorrent","uTorrent",
  "notion","Obsidian","Todoist","Evernote","CapCut","Canva"
 },StringComparer.OrdinalIgnoreCase);
 internal static readonly HashSet<string> Focusable=new HashSet<string>(new[]{
  "cs2","csgo","FortniteClient-Win64-Shipping","RobloxPlayerBeta","GTA5","GTA5_Enhanced","VALORANT-Win64-Shipping",
  "League of Legends","acad","Revit","SketchUp","Lumion","3dsmax","blender","vray",
  "r5apex","RainbowSix","RainbowSix_Vulkan","RocketLeague","Overwatch","dota2","eldenring","Cyberpunk2077",
  "RDR2","ForzaHorizon5","TslGame","BaldursGate3","bg3","bg3_dx11","HogwartsLegacy","Starfield","re4","ACValhalla",
  "witcher3","DOOMEternalx64vk","MonsterHunterWilds","Palworld-Win64-Shipping"
 },StringComparer.OrdinalIgnoreCase);
 internal static string Protection(ProcessToken p,int ownPid,int session,string windowsDirectory) {
  if(p.Pid<=4||p.Pid==ownPid)return "Windows / próprio otimizador";
  if(p.Session!=session)return "Outra sessão / serviço";
  if(String.IsNullOrEmpty(p.UserSid)||p.UserSid!=App.Sid)return "Outro usuário / proprietário não verificado";
  if(String.IsNullOrEmpty(p.Path)||p.Started<=0)return "Identidade não verificável";
  if(!String.IsNullOrEmpty(windowsDirectory)&&Within(p.Path,windowsDirectory))return "Componente do Windows";
  if(!Closable.Contains(p.Name))return "Preservado: sistema, jogo, driver, sincronização ou app não autorizado";
  return "";
 }
 internal static bool Within(string path,string directory) {
  try {string root=(directory??"").Replace('/','\\').TrimEnd('\\');string full=(path??"").Replace('/','\\');
   if(root.Length==0||full.Length==0)return false;return String.Equals(root,full,StringComparison.OrdinalIgnoreCase)||full.StartsWith(root+"\\",StringComparison.OrdinalIgnoreCase);
  }catch{return false;}
 }
 internal static double Cpu(ulong idleA,ulong totalA,ulong idleB,ulong totalB) {
  if(totalB<=totalA||idleB<idleA)return -1;double total=totalB-totalA,idle=idleB-idleA;
  if(idle>total)return -1;return Math.Max(0,Math.Min(100,100*(total-idle)/total));
 }
 internal static ResourceSample Measure(int milliseconds=1500) {
  var sample=new ResourceSample {Time=DateTime.UtcNow.ToString("o"),Error="",Seconds=milliseconds/1000.0};
  if(!App.IsWindows){sample.Error="Medição disponível apenas no Windows. Nenhum resultado simulado.";return sample;}
  FT i1,k1,u1,i2,k2,u2;bool first=GetSystemTimes(out i1,out k1,out u1);Thread.Sleep(milliseconds);
  if(first&&GetSystemTimes(out i2,out k2,out u2)){sample.CpuPercent=Cpu(i1.Value,k1.Value+u1.Value,i2.Value,k2.Value+u2.Value);sample.CpuKnown=sample.CpuPercent>=0;}
  var memory=new MemoryStatus {Length=(uint)Marshal.SizeOf(typeof(MemoryStatus))};
  if(GlobalMemoryStatusEx(ref memory)){sample.MemoryKnown=true;sample.TotalMB=memory.TotalPhysical/1048576.0;sample.AvailableMB=memory.AvailablePhysical/1048576.0;}
  else sample.Error="O Windows não retornou a memória disponível.";
  var list=Process.GetProcesses();sample.Processes=list.Length;foreach(var p in list)p.Dispose();return sample;
 }
 internal static string Describe(ResourceSample s) {
  if(s==null)return "Ainda não medido.";
  return (s.MemoryKnown?"RAM disponível: "+(s.AvailableMB/1024).ToString("0.00")+" / "+(s.TotalMB/1024).ToString("0.00")+" GB":"RAM: não consultada")+
   " | CPU: "+(s.CpuKnown?s.CpuPercent.ToString("0.0")+"%":"não consultada")+" | "+s.Processes+" processos";
 }
 internal static string Compare(ResourceSample a,ResourceSample b) {
  string delta=a!=null&&b!=null&&a.MemoryKnown&&b.MemoryKnown?(b.AvailableMB-a.AvailableMB).ToString("+0;-0;0")+" MB de variação na RAM disponível":"RAM não comparável";
  return "ANTES: "+Describe(a)+"\r\nDEPOIS: "+Describe(b)+"\r\n"+delta+".\r\nAmostras curtas: outros apps também alteram o resultado. Isso NÃO é medição de FPS, 1% low ou input lag.";
 }
 internal static ProcessToken Identify(Process process) {
  IntPtr token;if(!OpenProcessToken(process.Handle,8,out token))throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
  string sid;try{using(var identity=new WindowsIdentity(token))sid=identity.User.Value;}finally{CloseHandle(token);}
  return new ProcessToken {Pid=process.Id,Started=process.StartTime.ToUniversalTime().Ticks,Session=process.SessionId,
   Name=process.ProcessName,Path=process.MainModule.FileName,UserSid=sid,MemoryKnown=true,MemoryMB=process.WorkingSet64/1048576.0,HasWindow=process.MainWindowHandle!=IntPtr.Zero};
 }
 internal static bool SameIdentity(ProcessToken a,ProcessToken b) {
  return a!=null&&b!=null&&a.Pid==b.Pid&&a.Started==b.Started&&a.Session==b.Session&&a.UserSid==b.UserSid&&
   String.Equals(a.Name,b.Name,StringComparison.OrdinalIgnoreCase)&&String.Equals(a.Path,b.Path,StringComparison.OrdinalIgnoreCase);
 }
 internal static List<ProcessToken> ScanProcesses() {
  var result=new List<ProcessToken>();if(!App.IsWindows)return result;
  int own,session;using(var p=Process.GetCurrentProcess()){own=p.Id;session=p.SessionId;}
  string windows=Environment.GetFolderPath(Environment.SpecialFolder.Windows);
  var times=new Dictionary<int,double>();var clock=Stopwatch.StartNew();
  foreach(var p in Process.GetProcesses())using(p) {
   try {var token=Identify(p);token.Protection=Protection(token,own,session,windows);result.Add(token);times[p.Id]=p.TotalProcessorTime.TotalMilliseconds;}
   catch {try{result.Add(new ProcessToken {Pid=p.Id,Name=p.ProcessName,Path="",Protection="Acesso negado / processo protegido"});}catch{}}
  }
  Thread.Sleep(1000);double elapsed=clock.Elapsed.TotalMilliseconds;
  foreach(var token in result) {
   double before;if(!times.TryGetValue(token.Pid,out before))continue;
   try {using(var p=Process.GetProcessById(token.Pid)) {
    if(!SameIdentity(token,Identify(p)))continue;
    token.CpuPercent=Math.Max(0,Math.Min(100,(p.TotalProcessorTime.TotalMilliseconds-before)/elapsed/Environment.ProcessorCount*100));token.CpuKnown=true;
   }}catch{}
  }
  return result.OrderByDescending(p=>p.MemoryMB).ToList();
 }
 internal static List<ProcessGroup> Groups(List<ProcessToken> list) {
  return list.GroupBy(p=>p.Name,StringComparer.OrdinalIgnoreCase).Select(g=>new ProcessGroup {Name=g.Key,Processes=g.ToList()}).OrderByDescending(g=>g.MemoryMB).ToList();
 }
 // A closing permission is per captured PID + start time + path, never a wildcard/name kill.
 internal static List<StepResult> CloseSelected(IList<ProcessToken> selected,bool force,Action<string> progress) {
  if(!App.IsWindows)throw new Exception("Requer Windows.");
  if(selected.Count==0||selected.Count>300)throw new Exception("Selecione de 1 a 300 processos de apps autorizados.");
  int own,session;using(var self=Process.GetCurrentProcess()){own=self.Id;session=self.SessionId;}
  string windows=Environment.GetFolderPath(Environment.SpecialFolder.Windows);var outcomes=new List<StepResult>();
  var waiting=new List<Tuple<ProcessToken,Process,StepResult>>();
  try {
   foreach(var token in selected.GroupBy(p=>p.Pid).Select(g=>g.First())) {
    var step=new StepResult {Id=token.Pid.ToString(),Name=token.Name+" ("+token.Pid+")",Status="ignorado",Message=""};outcomes.Add(step);Process p=null;
    try {
     p=Process.GetProcessById(token.Pid);var now=Identify(p);string reason=Protection(now,own,session,windows);
     if(!SameIdentity(token,now)||!String.IsNullOrEmpty(reason)){step.Message="Identidade mudou ou processo protegido. "+reason;continue;}
     progress("Fechando "+token.Name);
     if(force){p.Kill();step.Message="Encerramento forçado solicitado após confirmação explícita.";}
     else if(p.CloseMainWindow())step.Message="Fechamento normal solicitado; diálogos de salvar não são ignorados.";
     else {step.Message="Sem janela principal. Não foi forçado; feche pelo próprio app ou use a opção separada de forçar.";continue;}
     step.Status="aguardando";waiting.Add(Tuple.Create(token,p,step));p=null;
    }catch(ArgumentException){step.Status="já encerrado";step.Message="Processo não está mais em execução.";}
     catch(Exception e){step.Status="não encerrado";step.Message=e.Message;}
    finally{if(p!=null)p.Dispose();}
   }
   var deadline=Stopwatch.StartNew();
   while(deadline.ElapsedMilliseconds<4000&&waiting.Any(t=>{try{return !t.Item2.HasExited;}catch{return false;}}))Thread.Sleep(200);
   foreach(var entry in waiting) {
    try {entry.Item3.Status=entry.Item2.HasExited?"encerrado":"permaneceu aberto";if(!entry.Item2.HasExited)entry.Item3.Message="App permaneceu aberto, recusou o fechamento ou está aguardando salvar. Nenhuma tentativa adicional.";}
    catch(Exception e){entry.Item3.Status="não verificado";entry.Item3.Message=e.Message;}
   }
   return outcomes;
  }finally{foreach(var entry in waiting)entry.Item2.Dispose();}
 }
}

static partial class App {
 internal static Record CloseApps(List<ProcessToken> selected,bool force,Action<string> progress) {
  var rec=NewRecord(force?"Encerrar apps selecionados (forçado)":"Liberar RAM fechando apps selecionados","apps","Apps e RAM");
  Save(rec);try {
   rec.BeforeSample=ResourceMonitor.Measure();rec.Status="executando";Save(rec);
   rec.Steps=ResourceMonitor.CloseSelected(selected,force,progress);rec.AfterSample=ResourceMonitor.Measure();
   rec.Status=rec.Steps.Any(s=>s.Status!="encerrado"&&s.Status!="já encerrado")?"concluído com avisos":"concluído";
   rec.Message=ResourceMonitor.Compare(rec.BeforeSample,rec.AfterSample)+"\r\nFechar apps não possui desfazer: reabra-os manualmente. Não há limpeza periódica de cache/working set.";Save(rec);return rec;
  }catch(Exception e){rec.Status="falhou";rec.Message=e.Message+"\r\nApps já fechados não são reabertos automaticamente.";Save(rec);throw;}
 }
}

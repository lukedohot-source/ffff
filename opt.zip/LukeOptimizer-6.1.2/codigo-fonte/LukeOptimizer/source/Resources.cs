using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Security.Principal;

public class ResourceSample {
 public string Time {get;set;} public double TotalMB {get;set;} public double AvailableMB {get;set;}
 public double CpuPercent {get;set;} public int Processes {get;set;} public bool MemoryKnown {get;set;}
 public bool CpuKnown {get;set;} public double Seconds {get;set;} public string Error {get;set;}
}
public class ProcessToken {
 public int Pid {get;set;} public long Started {get;set;} public int Session {get;set;}
 public string Name {get;set;} public string Path {get;set;} public double MemoryMB {get;set;}
 public string UserSid {get;set;}
 public bool MemoryKnown {get;set;}
 public double CpuPercent {get;set;} public bool CpuKnown {get;set;} public bool HasWindow {get;set;}
 public string Protection {get;set;}
}
public class ProcessGroup {
 public string Name {get;set;} public List<ProcessToken> Processes {get;set;}
 public double MemoryMB {get{return Processes.Sum(p=>p.MemoryMB);}}
 public double CpuPercent {get{return Processes.Sum(p=>p.CpuPercent);}}
 public bool CanClose {get{return Processes.Count>0&&Processes.All(p=>String.IsNullOrEmpty(p.Protection));}}
 public override string ToString(){return Name;}
}
static class ResourceMonitor {
 [StructLayout(LayoutKind.Sequential)] struct MemoryStatus {
  public uint Length,Load;public ulong TotalPhysical,AvailablePhysical,TotalPage,AvailablePage,TotalVirtual,AvailableVirtual,Extended;
 }
 [StructLayout(LayoutKind.Sequential)] struct FT {public uint Low,High;public ulong Value {get{return ((ulong)High<<32)|Low;}}}
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GlobalMemoryStatusEx(ref MemoryStatus status);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetSystemTimes(out FT idle,out FT kernel,out FT user);
 [DllImport("advapi32.dll",SetLastError=true)] static extern bool OpenProcessToken(IntPtr process,uint access,out IntPtr token);
 [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
 // Nível 1 — apps de usuário: fechar custa no máximo reabrir o programa.
 static readonly string[] LightProcesses={
  "chrome","msedge","firefox","brave","opera","spotify","discord","telegram","slack","teams","ms-teams","zoom","skype",
  "vivaldi","waterfox","librewolf","floorp","zen","thunderbird","WhatsApp","Signal","DiscordCanary","DiscordPTB","msteams",
  "obs64","Streamlabs OBS","Overwolf","OverwolfBrowser","Medal","ShareX","ScreenToGif","CamtasiaStudio",
  "vlc","mpv","PotPlayerMini64","iTunes","Deezer","Amazon Music","TIDAL","qBittorrent","uTorrent",
  "notion","Obsidian","Todoist","Evernote","CapCut","Canva"
 };
 // Nível 2 — acompanhantes e sincronização: param de sincronizar, atualizar ou notificar
 // até serem reabertos. Nada some do disco; nada é desinstalado.
 static readonly string[] AggressiveProcesses={
  "OneDrive","Dropbox","GoogleDriveFS","googledrivesync","MEGAsync","pCloud","Creative Cloud",
  "CCXProcess","CCLibrary","Adobe Desktop Service","AdobeIPCBroker","AdobeNotificationClient",
  "GoogleUpdate","MicrosoftEdgeUpdate","jusched","AcrobatNotificationClient","OfficeClickToRun",
  "Cortana","SearchApp","YourPhone","PhoneExperienceHost","Widgets","WidgetService",
  "olk","OUTLOOK","EXCEL","WINWORD","POWERPNT","Todo","OneNote",
  "SnippingTool","StickyNotes","Microsoft.Notes","GameBar","GameBarFTServer","XboxPcApp","XboxPcAppFT"
 };
 // Nível 3 — launchers, periféricos e overlays. Fechar um launcher pode encerrar o jogo
 // aberto por ele e derrubar macros, RGB e software de mouse/teclado. Nunca entra em
 // ação de um clique; exige seleção explícita e a confirmação avisa disso.
 static readonly string[] ExtremeProcesses={
  "steam","steamwebhelper","EpicGamesLauncher","EpicWebHelper","GalaxyClient","GalaxyClientService",
  "Battle.net","UbisoftConnect","UplayWebCore","upc","EADesktop","EABackgroundService","Origin",
  "RiotClientServices","RiotClientUx","RiotClientUxRender","Rockstar-Games-Launcher","SocialClubHelper",
  "itch","PlayniteDesktop","HeroicGamesLauncher",
  "RazerAppEngine","Razer Synapse 3","RzSDKService","LogiOverlay","LogiOptionsMgr","lghub","lghub_agent",
  "iCUE","CorsairService","Armoury Crate","ArmouryCrate.UserSessionHelper","MSI Center","LightKeeper",
  "SteelSeriesGG","SteelSeriesEngine","OpenRGB","SignalRgb","NZXT CAM","FanControl",
  "NVIDIA Share","NVIDIA Web Helper","nvcontainer","RadeonSoftware","AMDRSServ","AMDRSSrcExt"
 };
 internal static readonly HashSet<string> Closable=new HashSet<string>(
  LightProcesses.Concat(AggressiveProcesses).Concat(ExtremeProcesses),StringComparer.OrdinalIgnoreCase);
 static readonly HashSet<string> AggressiveSet=new HashSet<string>(AggressiveProcesses,StringComparer.OrdinalIgnoreCase);
 static readonly HashSet<string> ExtremeSet=new HashSet<string>(ExtremeProcesses,StringComparer.OrdinalIgnoreCase);
 // "leve" | "agressivo" | "extremo" | "" (fora da lista, nunca fechável)
 internal static string Tier(string processName){
  if(String.IsNullOrEmpty(processName))return "";
  if(ExtremeSet.Contains(processName))return "extremo";
  if(AggressiveSet.Contains(processName))return "agressivo";
  return Closable.Contains(processName)?"leve":"";
 }
 internal static bool WithinTier(string processName,string tier){
  string actual=Tier(processName);
  if(actual.Length==0)return false;
  if(tier=="extremo")return true;
  if(tier=="agressivo")return actual!="extremo";
  return actual=="leve";
 }
 // Tamanho do array de origem, não do conjunto final: é o que permite provar que os
 // três níveis não se sobrepõem (a soma tem de bater com Closable.Count).
 internal static int TierSourceCount(string tier){
  if(tier=="leve")return LightProcesses.Length;
  if(tier=="agressivo")return AggressiveProcesses.Length;
  if(tier=="extremo")return ExtremeProcesses.Length;
  throw new ArgumentException("Nível de processo inválido.");
 }
 internal static string TierWarning(string tier){
  if(tier=="leve")return "Fecha apenas apps de usuário: navegador, mensageiro, player, gravador. Reabra quando quiser; nada é desinstalado.";
  if(tier=="agressivo")return "Inclui sincronização de nuvem (OneDrive, Drive, Dropbox), atualizadores e apps do Office. Arquivos param de sincronizar e notificações param de chegar até você reabrir. Nenhum arquivo local é apagado.";
  if(tier=="extremo")return "Inclui launchers de jogos e software de periférico. FECHAR UM LAUNCHER PODE ENCERRAR O JOGO ABERTO POR ELE, e perfis de mouse, teclado e RGB voltam ao padrão até o software reabrir. Anticheat em execução não é tocado. Use com o jogo fechado.";
  return "Nível desconhecido.";
 }
 internal static readonly HashSet<string> Focusable=new HashSet<string>(new[]{
  "cs2","csgo","FortniteClient-Win64-Shipping","RobloxPlayerBeta","GTA5","GTA5_Enhanced","VALORANT-Win64-Shipping",
  "League of Legends","acad","Revit","SketchUp","Lumion","3dsmax","blender","vray",
  "r5apex","RainbowSix","RainbowSix_Vulkan","RocketLeague","Overwatch","dota2","eldenring","Cyberpunk2077",
  "RDR2","ForzaHorizon5","TslGame","BaldursGate3","bg3","bg3_dx11","HogwartsLegacy","Starfield","re4","ACValhalla",
  "witcher3","DOOMEternalx64vk","MonsterHunterWilds","Palworld-Win64-Shipping"
 },StringComparer.OrdinalIgnoreCase);
 internal static string Protection(ProcessToken p,int ownPid,int session,string windowsDirectory) {
  if(p.Pid<=4||p.Pid==ownPid)return "Windows / próprio otimizador";
  if(p.Session!=session)return "Outra sessão / serviço";
  if(String.IsNullOrEmpty(p.UserSid)||p.UserSid!=App.Sid)return "Outro usuário / proprietário não verificado";
  if(String.IsNullOrEmpty(p.Path)||p.Started<=0)return "Identidade não verificável";
  if(!String.IsNullOrEmpty(windowsDirectory)&&Within(p.Path,windowsDirectory))return "Componente do Windows";
  if(!Closable.Contains(p.Name))return "Preservado: sistema, jogo, driver, sincronização ou app não autorizado";
  return "";
 }
 internal static bool Within(string path,string directory) {
  try {string root=(directory??"").Replace('/','\\').TrimEnd(new[]{'\\'});string full=(path??"").Replace('/','\\');
   if(root.Length==0||full.Length==0)return false;return String.Equals(root,full,StringComparison.OrdinalIgnoreCase)||full.StartsWith(root+"\\",StringComparison.OrdinalIgnoreCase);
  }catch{return false;}
 }
 internal static double Cpu(ulong idleA,ulong totalA,ulong idleB,ulong totalB) {
  if(totalB<=totalA||idleB<idleA)return -1;double total=totalB-totalA,idle=idleB-idleA;
  if(idle>total)return -1;return Math.Max(0,Math.Min(100,100*(total-idle)/total));
 }
 internal static ResourceSample Measure(int milliseconds=1500) {
  var sample=new ResourceSample {Time=DateTime.UtcNow.ToString("o"),Error="",Seconds=milliseconds/1000.0};
  if(!App.IsWindows){sample.Error="Medição disponível apenas no Windows. Nenhum resultado simulado.";return sample;}
  FT i1,k1,u1,i2,k2,u2;bool first=GetSystemTimes(out i1,out k1,out u1);Thread.Sleep(milliseconds);
  if(first&&GetSystemTimes(out i2,out k2,out u2)){sample.CpuPercent=Cpu(i1.Value,k1.Value+u1.Value,i2.Value,k2.Value+u2.Value);sample.CpuKnown=sample.CpuPercent>=0;}
  var memory=new MemoryStatus {Length=(uint)Marshal.SizeOf(typeof(MemoryStatus))};
  if(GlobalMemoryStatusEx(ref memory)){sample.MemoryKnown=true;sample.TotalMB=memory.TotalPhysical/1048576.0;sample.AvailableMB=memory.AvailablePhysical/1048576.0;}
  else sample.Error="O Windows não retornou a memória disponível.";
  var list=Process.GetProcesses();sample.Processes=list.Length;foreach(var p in list)p.Dispose();return sample;
 }
 internal static string Describe(ResourceSample s) {
  if(s==null)return "Ainda não medido.";
  return (s.MemoryKnown?"RAM disponível: "+(s.AvailableMB/1024).ToString("0.00")+" / "+(s.TotalMB/1024).ToString("0.00")+" GB":"RAM: não consultada")+
   " | CPU: "+(s.CpuKnown?s.CpuPercent.ToString("0.0")+"%":"não consultada")+" | "+s.Processes+" processos";
 }
 internal static string Compare(ResourceSample a,ResourceSample b) {
  string delta=a!=null&&b!=null&&a.MemoryKnown&&b.MemoryKnown?(b.AvailableMB-a.AvailableMB).ToString("+0;-0;0")+" MB de variação na RAM disponível":"RAM não comparável";
  return "ANTES: "+Describe(a)+"\r\nDEPOIS: "+Describe(b)+"\r\n"+delta+".\r\nAmostras curtas: outros apps também alteram o resultado. Isso NÃO é medição de FPS, 1% low ou input lag.";
 }
 internal static ProcessToken Identify(Process process) {
  IntPtr token;if(!OpenProcessToken(process.Handle,8,out token))throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
  string sid;try{using(var identity=new WindowsIdentity(token))sid=identity.User.Value;}finally{CloseHandle(token);}
  return new ProcessToken {Pid=process.Id,Started=process.StartTime.ToUniversalTime().Ticks,Session=process.SessionId,
   Name=process.ProcessName,Path=process.MainModule.FileName,UserSid=sid,MemoryKnown=true,MemoryMB=process.WorkingSet64/1048576.0,HasWindow=process.MainWindowHandle!=IntPtr.Zero};
 }
 internal static bool SameIdentity(ProcessToken a,ProcessToken b) {
  return a!=null&&b!=null&&a.Pid==b.Pid&&a.Started==b.Started&&a.Session==b.Session&&a.UserSid==b.UserSid&&
   String.Equals(a.Name,b.Name,StringComparison.OrdinalIgnoreCase)&&String.Equals(a.Path,b.Path,StringComparison.OrdinalIgnoreCase);
 }
 internal static List<ProcessToken> ScanProcesses() {
  var result=new List<ProcessToken>();if(!App.IsWindows)return result;
  int own,session;using(var p=Process.GetCurrentProcess()){own=p.Id;session=p.SessionId;}
  string windows=Environment.GetFolderPath(Environment.SpecialFolder.Windows);
  var times=new Dictionary<int,double>();var clock=Stopwatch.StartNew();
  foreach(var p in Process.GetProcesses())using(p) {
   try {var token=Identify(p);token.Protection=Protection(token,own,session,windows);result.Add(token);times[p.Id]=p.TotalProcessorTime.TotalMilliseconds;}
   catch {try{result.Add(new ProcessToken {Pid=p.Id,Name=p.ProcessName,Path="",Protection="Acesso negado / processo protegido"});}catch{}}
  }
  Thread.Sleep(1000);double elapsed=clock.Elapsed.TotalMilliseconds;
  foreach(var token in result) {
   double before;if(!times.TryGetValue(token.Pid,out before))continue;
   try {using(var p=Process.GetProcessById(token.Pid)) {
    if(!SameIdentity(token,Identify(p)))continue;
    token.CpuPercent=Math.Max(0,Math.Min(100,(p.TotalProcessorTime.TotalMilliseconds-before)/elapsed/Environment.ProcessorCount*100));token.CpuKnown=true;
   }}catch{}
  }
  return result.OrderByDescending(p=>p.MemoryMB).ToList();
 }
 internal static List<ProcessGroup> Groups(List<ProcessToken> list) {
  return list.GroupBy(p=>p.Name,StringComparer.OrdinalIgnoreCase).Select(g=>new ProcessGroup {Name=g.Key,Processes=g.ToList()}).OrderByDescending(g=>g.MemoryMB).ToList();
 }
 // A closing permission is per captured PID + start time + path, never a wildcard/name kill.
 internal static List<StepResult> CloseSelected(IList<ProcessToken> selected,bool force,Action<string> progress) {
  if(!App.IsWindows)throw new Exception("Requer Windows.");
  if(selected.Count==0||selected.Count>300)throw new Exception("Selecione de 1 a 300 processos de apps autorizados.");
  int own,session;using(var self=Process.GetCurrentProcess()){own=self.Id;session=self.SessionId;}
  string windows=Environment.GetFolderPath(Environment.SpecialFolder.Windows);var outcomes=new List<StepResult>();
  var waiting=new List<Tuple<ProcessToken,Process,StepResult>>();
  try {
   foreach(var token in selected.GroupBy(p=>p.Pid).Select(g=>g.First())) {
    var step=new StepResult {Id=token.Pid.ToString(),Name=token.Name+" ("+token.Pid+")",Status="ignorado",Message=""};outcomes.Add(step);Process p=null;
    try {
     p=Process.GetProcessById(token.Pid);var now=Identify(p);string reason=Protection(now,own,session,windows);
     if(!SameIdentity(token,now)||!String.IsNullOrEmpty(reason)){step.Message="Identidade mudou ou processo protegido. "+reason;continue;}
     progress("Fechando "+token.Name);
     if(force){p.Kill();step.Message="Encerramento forçado solicitado após confirmação explícita.";}
     else if(p.CloseMainWindow())step.Message="Fechamento normal solicitado; diálogos de salvar não são ignorados.";
     else {step.Message="Sem janela principal. Não foi forçado; feche pelo próprio app ou use a opção separada de forçar.";continue;}
     step.Status="aguardando";waiting.Add(Tuple.Create(token,p,step));p=null;
    }catch(ArgumentException){step.Status="já encerrado";step.Message="Processo não está mais em execução.";}
     catch(Exception e){step.Status="não encerrado";step.Message=e.Message;}
    finally{if(p!=null)p.Dispose();}
   }
   var deadline=Stopwatch.StartNew();
   while(deadline.ElapsedMilliseconds<4000&&waiting.Any(t=>{try{return !t.Item2.HasExited;}catch{return false;}}))Thread.Sleep(200);
   foreach(var entry in waiting) {
    try {entry.Item3.Status=entry.Item2.HasExited?"encerrado":"permaneceu aberto";if(!entry.Item2.HasExited)entry.Item3.Message="App permaneceu aberto, recusou o fechamento ou está aguardando salvar. Nenhuma tentativa adicional.";}
    catch(Exception e){entry.Item3.Status="não verificado";entry.Item3.Message=e.Message;}
   }
   return outcomes;
  }finally{foreach(var entry in waiting)entry.Item2.Dispose();}
 }
}

static partial class App {
 internal static Record CloseApps(List<ProcessToken> selected,bool force,Action<string> progress) {
  var rec=NewRecord(force?"Encerrar apps selecionados (forçado)":"Liberar RAM fechando apps selecionados","apps","Apps e RAM");
  Save(rec);try {
   rec.BeforeSample=ResourceMonitor.Measure();rec.Status="executando";Save(rec);
   rec.Steps=ResourceMonitor.CloseSelected(selected,force,progress);rec.AfterSample=ResourceMonitor.Measure();
   // Guarda o executável de cada app efetivamente encerrado, para permitir reabrir depois.
   // Só o caminho: linha de comando e argumentos não são reproduzidos.
   rec.ClosedApps=new List<ClosedApp>();
   foreach(var token in selected.GroupBy(p=>p.Pid).Select(g=>g.First())){
    var step=rec.Steps.FirstOrDefault(s=>s.Id==token.Pid.ToString());
    if(step==null||step.Status!="encerrado")continue;
    if(String.IsNullOrEmpty(token.Path)||!ResourceMonitor.Closable.Contains(token.Name))continue;
    if(rec.ClosedApps.Any(a=>String.Equals(a.Path,token.Path,StringComparison.OrdinalIgnoreCase)))continue;
    rec.ClosedApps.Add(new ClosedApp{Name=token.Name,Path=token.Path,Tier=ResourceMonitor.Tier(token.Name)});
   }
   rec.Status=rec.Steps.Any(s=>s.Status!="encerrado"&&s.Status!="já encerrado")?"concluído com avisos":"concluído";
   rec.Message=ResourceMonitor.Compare(rec.BeforeSample,rec.AfterSample)+
    "\r\n"+rec.ClosedApps.Count+" app(s) podem ser reabertos por Reabrir apps fechados, no Histórico. "+
    "Reabrir inicia o programa de novo: janelas, abas e trabalho não salvo NÃO voltam. Não há limpeza periódica de cache/working set.";
   Save(rec);return rec;
  }catch(Exception e){rec.Status="falhou";rec.Message=e.Message+"\r\nApps já fechados não são reabertos automaticamente.";Save(rec);throw;}
 }
 // Reabrir NÃO é desfazer: não entra em CanUndo nem na cadeia de Undo, porque não
 // restaura estado do Windows. É uma ação separada e explícita sobre um registro.
 // Formato de caminho seguro, com resposta IDÊNTICA em qualquer plataforma.
 //
 // Path.GetInvalidPathChars() não serve para isto: no Windows ele inclui aspas, |, < e >;
 // fora dele devolve praticamente só o caractere nulo. Uma verificação de segurança que
 // muda de resultado conforme o sistema é uma verificação que não se pode testar.
 // Esta lista é explícita e fechada, então o teste significa a mesma coisa nos dois lados.
 //
 // É operação de string pura: nunca lança. Por isso vem ANTES de qualquer API de caminho.
 internal static readonly char[] RejectedPathChars={'\0','\r','\n','\t','"','|','<','>','*','?'};
 internal static bool PathShapeSafe(string path){
  return !String.IsNullOrWhiteSpace(path)&&path.IndexOfAny(RejectedPathChars)<0;
 }
 internal static Record ReopenClosedApps(string recordId){
  var source=Json.Deserialize<Record>(AtomicStore.Read(RecordPath(recordId)));
  if(source==null||source.UserSid!=Sid)throw new Exception("Este registro pertence a outro usuário.");
  if(source.Kind!="Apps e RAM")throw new Exception("Este registro não fechou aplicativos.");
  var apps=source.ClosedApps??new List<ClosedApp>();
  if(apps.Count==0||apps.Count>300)throw new Exception("Nenhum aplicativo reabrível neste registro.");
  var rec=NewRecord("Reabrir apps fechados","reopen-apps","Apps e RAM");
  rec.Status="executando";Save(rec);
  string windows=Environment.GetFolderPath(Environment.SpecialFolder.Windows);
  foreach(var app in apps){
   var step=new StepResult{Id=app.Path,Name=app.Name,Status="ignorado",Message=""};rec.Steps.Add(step);
   try{
    // O registro fica no perfil do próprio usuário, mas nunca confiamos nele para
    // executar: o caminho é revalidado contra a mesma allowlist e as mesmas regras
    // que autorizaram o fechamento.
    if(!ResourceMonitor.Closable.Contains(app.Name)){step.Message="Aplicativo fora da lista autorizada.";continue;}
    // A ORDEM destas duas verificações importa, e estava invertida.
    //
    // Path.IsPathRooted LANÇA ArgumentException, no .NET Framework, quando o caminho
    // contém caractere inválido — e aspas são inválidas no Windows. Chamá-lo ANTES da
    // checagem de caracteres fazia um registro adulterado com aspas sair pelo catch como
    // "não reaberto" + mensagem crua do .NET, em vez de recusa limpa com motivo legível.
    // Nada era executado nos dois caminhos, mas o usuário via um erro do framework.
    //
    // Fora do Windows aspas são caractere válido de caminho, IsPathRooted não lança, e o
    // defeito ficava invisível: só apareceu ao rodar a suíte num Windows de verdade.
    // Gaming.cs:ValidateExecutable já fazia na ordem certa; aqui tinha escapado.
    if(!App.PathShapeSafe(app.Path)||!Path.IsPathRooted(app.Path)){step.Message="Caminho inválido.";continue;}
    if(!app.Path.EndsWith(".exe",StringComparison.OrdinalIgnoreCase)){step.Message="Somente executáveis são reabertos.";continue;}
    if(!File.Exists(app.Path)){step.Message="O executável não está mais neste caminho.";continue;}
    if(!String.IsNullOrEmpty(windows)&&ResourceMonitor.Within(app.Path,windows)){step.Message="Componente do Windows: não é reaberto por aqui.";continue;}
    if(!String.Equals(Path.GetFileNameWithoutExtension(app.Path),app.Name,StringComparison.OrdinalIgnoreCase)){step.Message="O nome do processo não corresponde ao executável gravado.";continue;}
    using(Process.Start(new ProcessStartInfo(app.Path){UseShellExecute=true,WorkingDirectory=Path.GetDirectoryName(app.Path)})){}
    step.Status="reaberto";step.Message="Programa iniciado. Abas, janelas e trabalho não salvo não são restaurados.";
   }catch(Exception e){step.Status="não reaberto";step.Message=e.Message;}
   Save(rec);
  }
  int reopened=rec.Steps.Count(s=>s.Status=="reaberto");
  rec.Status=reopened==rec.Steps.Count?"concluído":reopened==0?"falhou":"concluído com avisos";
  rec.Message=reopened+" de "+rec.Steps.Count+" aplicativo(s) reaberto(s) a partir do registro "+recordId+
   ".\r\nCada um foi iniciado do zero, sem argumentos de linha de comando e sem restaurar sessão.";
  Save(rec);return rec;
 }
}

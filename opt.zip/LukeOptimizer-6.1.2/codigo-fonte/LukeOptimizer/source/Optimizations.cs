using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

// CONTRATO ÚNICO DE OTIMIZAÇÃO — a fundação da FASE 2.
//
// Hoje os dados de uma mesma otimização estão em quatro lugares: Item (o que escrever),
// OptionInfo (classificação, risco, reinício), PerformanceEntry (efeito, custo, fonte) e
// texto solto na interface. Nada disso é substituído aqui. OptimizationDescriptor é uma
// PROJEÇÃO somente leitura que reúne os quatro sob o mesmo Id e acrescenta o que faltava:
// nível de evidência, confiança (separada do risco), estágio de maturidade, requisitos de
// hardware e escopo de reinício.
//
// Por que projeção e não substituição: IDs, perfis, histórico e desfazer já dependem das
// estruturas atuais. Trocar o modelo quebraria backups gravados no PC das pessoas. O
// caminho é este — nova camada por cima, migração item a item depois.

// ---------------------------------------------------------------------------
// Evidência: de onde vem a afirmação. NÃO é o risco, e NÃO é a confiança.
// ---------------------------------------------------------------------------
static class Evidence {
 internal const string Microsoft="Documentada pela Microsoft";
 internal const string Vendor="Documentada pelo fabricante";
 internal const string Technical="Tecnicamente justificada";
 // Separado de "tecnicamente justificada" de propósito. 64 das 127 opções executáveis
 // vieram de um projeto de otimizador no GitHub. O código é auditável — e isso vale mais
 // que um vídeo — mas continua sendo prioridade 7 na hierarquia de fontes, não medição.
 // Dobrar isso dentro de "técnica" seria dizer ao usuário algo mais bonito que a verdade.
 internal const string OpenSource="Adaptada de projeto de código aberto (auditável, sem medição própria)";
 internal const string HardwareDependent="Dependente de hardware";
 internal const string Experimental="Experimental / teste A/B";
 internal const string Convenience="Somente conveniência";
 internal const string NotRecommended="Não recomendada";
 internal static readonly string[] Levels={Microsoft,Vendor,Technical,OpenSource,HardwareDependent,Experimental,Convenience,NotRecommended};

 internal const string High="Alta";
 internal const string Medium="Média";
 internal const string Low="Experimental";
 internal static readonly string[] Confidences={High,Medium,Low};

 // Itens cuja evidência NÃO pode ser deduzida da fonte, porque o problema não é a fonte:
 // é o efeito. Estes são exatamente os ajustes que o pedido manda olhar com lupa.
 static readonly Dictionary<string,string> Overrides=new Dictionary<string,string>(StringComparer.Ordinal){
  {"opt-disablenetworkthrottling",Experimental},   // NetworkThrottlingIndex: efeito real só com política de QoS
  {"extra-memory-compression",Experimental},       // Disable-MMAgent: pode aumentar paginação
  {"pack-e8ea680d9741",Experimental},              // execução global em segundo plano
  {"manual-responsiveness",Experimental},          // SystemResponsiveness
  {"manual-priority",Experimental},                // Win32PrioritySeparation
  {"opt-disablesmartscreen",NotRecommended},
  {"opt-disablevirtualizationbasedsecurity",NotRecommended},
  {"opt-userhvci",NotRecommended},
  {"opt-disabletpmcheck",NotRecommended},
  {"opt-disablesmb2",NotRecommended},
  {"opt-disablemodernstandby",NotRecommended}
 };

 // Deduz o nível pela fonte declarada no próprio item. Determinístico e testável: a mesma
 // URL sempre dá o mesmo nível. Sem fonte não vira "técnico" por bondade — vira o que a
 // classificação disser, e a classificação vem do risco real.
 internal static string Level(Item item,OptionInfo info){
  if(item==null)return Technical;
  string over;
  if(item.Id!=null&&Overrides.TryGetValue(item.Id,out over))return over;
  if(info!=null){
   if(info.Classification=="Não recomendada")return NotRecommended;
   if(info.Classification=="Experimental")return Experimental;
  }
  string url=(item.Url??"").ToLowerInvariant();
  if(url.Contains("learn.microsoft.com")||url.Contains("support.microsoft.com")||url.Contains("docs.microsoft.com")||url.Contains("devblogs.microsoft.com")||url.Contains("blogs.windows.com"))return Microsoft;
  if(url.Contains("nvidia.com")||url.Contains("amd.com")||url.Contains("intel.com")
   ||url.Contains("chromeenterprise.google")||url.Contains("mozilla.org")||url.Contains("support.google.com"))return Vendor;
  // github.com/microsoft/... continua sendo Microsoft publicando código; o resto do
  // GitHub é projeto de terceiro, e o rótulo tem de dizer isso.
  if(url.Contains("github.com/microsoft/"))return Microsoft;
  if(url.Contains("github.com")||url.Contains("gitlab.com"))return OpenSource;
  if(url.StartsWith("https://"))return Technical;
  return Convenience;
 }

 // Confiança é sobre a EVIDÊNCIA, não sobre o estrago que o ajuste pode causar. Um item
 // de alta confiança pode ter risco alto (está bem documentado que desativa proteção), e
 // um item de baixa confiança pode ter risco baixo (reversível, mas sem medição). Misturar
 // os dois é como a maioria dos "otimizadores" engana o usuário.
 internal static string Confidence(string level){
  if(level==Microsoft||level==Vendor)return High;
  if(level==Technical||level==OpenSource||level==HardwareDependent||level==NotRecommended)return Medium;
  return Low;
 }
}

// ---------------------------------------------------------------------------
// Estágio de maturidade — feature flags (item 28 do pedido).
// ---------------------------------------------------------------------------
static class Stage {
 internal const string Stable="Estável";
 internal const string Beta="Beta";
 internal const string Experimental="Experimental";
 internal const string Developer="Desenvolvedor";
 internal static readonly string[] All={Stable,Beta,Experimental,Developer};
 // Um estágio só entra automaticamente em perfil se for Estável. Beta e Experimental
 // exigem que a pessoa marque; Desenvolvedor nem aparece fora do modo avançado.
 internal static bool AutomaticAllowed(string stage){return stage==Stable;}
 internal static string Of(string evidenceLevel){
  if(evidenceLevel==Evidence.Experimental)return Experimental;
  if(evidenceLevel==Evidence.NotRecommended)return Developer;
  return Stable;
 }
}

// ---------------------------------------------------------------------------
// Escopo de reinício, acumulado uma vez no fim (item 43).
// ---------------------------------------------------------------------------
public class RestartPlan {
 public bool Explorer,SignOut,WindowsRestart;
 public bool Any(){return Explorer||SignOut||WindowsRestart;}
 public string Text(){
  if(WindowsRestart)return "Reinicie o Windows para o efeito valer por completo.";
  if(SignOut)return "Saia da conta e entre de novo para o efeito valer.";
  if(Explorer)return "Reabra o Explorador de Arquivos (ou o aplicativo afetado) para ver a mudança.";
  return "Nenhum reinício necessário.";
 }
}
static class RestartScope {
 internal const string None="nenhum",Explorer="explorer",SignOut="sessão",Windows="reiniciar";
 // Deduzido do alvo real da gravação, não de um campo escrito à mão: HKLM\SYSTEM só vale
 // depois de reiniciar; o resto do Explorer/Shell precisa de nova sessão ou do Explorer
 // reiniciado. É a mesma regra que OptionInfo.Restart já usava, agora em forma de dado.
 internal static string For(Item item){
  var ops=item==null?new RegOp[0]:(item.Operations??new RegOp[0]);
  if(ops.Any(o=>o.Key!=null&&o.Key.StartsWith(@"SYSTEM\",StringComparison.OrdinalIgnoreCase)))return Windows;
  if(ops.Any(o=>o.Key!=null&&o.Key.IndexOf(@"Explorer",StringComparison.OrdinalIgnoreCase)>=0))return Explorer;
  if(ops.Length==0)return None;
  return SignOut;
 }
 internal static RestartPlan Aggregate(IEnumerable<OptimizationDescriptor> chosen){
  var plan=new RestartPlan();
  foreach(var d in chosen??new OptimizationDescriptor[0]){
   if(d==null)continue;
   if(d.Restart==Windows)plan.WindowsRestart=true;
   else if(d.Restart==SignOut)plan.SignOut=true;
   else if(d.Restart==Explorer)plan.Explorer=true;
  }
  return plan;
 }
}

// ---------------------------------------------------------------------------
// Requisitos de hardware/plataforma que uma otimização pode declarar.
// Vazio/zero significa "não exige" — nunca "exige algo que eu não sei conferir".
// ---------------------------------------------------------------------------
public class OptimizationRequirements {
 public int MinBuild,MaxBuild;
 public string CpuVendor="",GpuVendor="",StorageMedia="";
 public long MinRamBytes;
 public bool RequiresDesktop,RequiresAC,RequiresSmt;
 public bool Empty(){
  return MinBuild==0&&MaxBuild==0&&CpuVendor.Length==0&&GpuVendor.Length==0
   &&StorageMedia.Length==0&&MinRamBytes==0&&!RequiresDesktop&&!RequiresAC&&!RequiresSmt;
 }
}

public class OptimizationDescriptor {
 public string Id="",Title="",Category="",Subcategory="",Risk="",Confidence="",EvidenceLevel="",
               Source="",Effect="",Tradeoff="",Steps="",Classification="",Restart="",Undo="",
               CompatibilityText="",BackupStrategy="",StageName="";
 public bool Administrator,Reversible,Native,AutomaticEligible;
 public OptimizationRequirements Requirements=new OptimizationRequirements();
 public string[] Tags=new string[0];
}

public class CompatibilityResult {
 public string State="",Reason="";
 public bool Executable(){return State==CompatibilityEngine.Compatible||State==CompatibilityEngine.Experimental;}
}

// ---------------------------------------------------------------------------
// Motor de compatibilidade (item 6): quatro estados, nunca dois.
// "Não detectado" NÃO é "não compatível" e NÃO é "compatível". É a resposta honesta
// quando a máquina não contou o que precisa ser conferido — e ela bloqueia a aplicação
// automática do mesmo jeito, porque aplicar às cegas é o que o pedido proíbe.
// ---------------------------------------------------------------------------
static class CompatibilityEngine {
 internal const string Compatible="Compatível";
 internal const string Incompatible="Não compatível";
 internal const string Undetected="Não detectado";
 internal const string Experimental="Experimental";

 internal static CompatibilityResult Evaluate(OptimizationDescriptor d,MachineProfile p){
  if(d==null)return Result(Incompatible,"Otimização desconhecida.");
  if(p==null||!p.Windows)return Result(Undetected,"Sem leitura deste PC: execute Analisar este PC antes de aplicar.");
  var r=d.Requirements??new OptimizationRequirements();

  if(r.MinBuild>0&&p.Build>0&&p.Build<r.MinBuild)return Result(Incompatible,"Exige Windows build "+r.MinBuild+" ou posterior; este PC está na build "+p.Build+".");
  if(r.MaxBuild>0&&p.Build>0&&p.Build>r.MaxBuild)return Result(Incompatible,"Válida até a build "+r.MaxBuild+"; esta versão do Windows não expõe mais essa configuração.");
  if((r.MinBuild>0||r.MaxBuild>0)&&p.Build<=0)return Result(Undetected,"A build do Windows não foi lida, e esta opção depende da versão.");

  if(r.CpuVendor.Length>0){
   if(p.CpuVendor.Length==0)return Result(Undetected,"O fabricante da CPU não foi identificado, e esta opção só vale em CPU "+r.CpuVendor+".");
   if(!String.Equals(p.CpuVendor,r.CpuVendor,StringComparison.OrdinalIgnoreCase))return Result(Incompatible,"Só se aplica a CPU "+r.CpuVendor+"; este PC tem "+p.CpuVendor+".");
  }
  if(r.GpuVendor.Length>0){
   if(p.GpuVendor.Length==0)return Result(Undetected,"O fabricante da GPU não foi identificado, e esta opção só vale em GPU "+r.GpuVendor+".");
   if(!String.Equals(p.GpuVendor,r.GpuVendor,StringComparison.OrdinalIgnoreCase))return Result(Incompatible,"Só se aplica a GPU "+r.GpuVendor+"; este PC tem "+p.GpuVendor+".");
  }
  if(r.StorageMedia.Length>0){
   if(p.SystemDriveMedia.Length==0)return Result(Undetected,"O tipo de mídia do disco do sistema não foi reconhecido, e esta opção depende disso.");
   if(r.StorageMedia=="SSD"&&!p.SolidState())return Result(Incompatible,"Indicada para SSD/NVMe; o disco do sistema é "+p.SystemDriveMedia+".");
   if(r.StorageMedia=="HD"&&p.SolidState())return Result(Incompatible,"Indicada para disco mecânico; o disco do sistema é "+p.SystemDriveMedia+".");
  }
  if(r.MinRamBytes>0){
   if(!p.RamKnown)return Result(Undetected,"A quantidade de RAM não foi lida, e esta opção depende disso.");
   if(p.RamBytes<r.MinRamBytes)return Result(Incompatible,"Exige pelo menos "+(r.MinRamBytes/1073741824L)+" GB de RAM.");
  }
  if(r.RequiresDesktop){
   if(!p.PortableKnown)return Result(Undetected,"Não foi possível distinguir desktop de notebook, e esta opção é só para desktop.");
   if(p.Portable)return Result(Incompatible,"Só para desktop: em notebook isso afeta bateria e temperatura.");
  }
  if(r.RequiresAC){
   if(!p.PowerKnown)return Result(Undetected,"O estado de energia não foi lido, e esta opção exige o PC na tomada.");
   if(!p.OnAC)return Result(Incompatible,"Exige o PC ligado à tomada.");
  }
  if(r.RequiresSmt){
   if(!p.SmtKnown)return Result(Undetected,"SMT/Hyper-Threading não foi detectado, e esta opção depende disso.");
   if(!p.Smt)return Result(Incompatible,"Exige SMT/Hyper-Threading ativo.");
  }
  // Compatível não significa recomendado. Experimental continua experimental mesmo
  // rodando num PC que atende a tudo — é isso que impede o perfil automático de engoli-lo.
  if(d.StageName==Stage.Experimental||d.EvidenceLevel==Evidence.Experimental)
   return Result(Experimental,"Compatível com este PC, mas sem medição que comprove ganho. Use teste A/B e compare antes/depois.");
  return Result(Compatible,r.Empty()?"Sem requisito de hardware; compatível com Windows 10/11 de 64 bits.":"Requisitos conferidos neste PC.");
 }
 static CompatibilityResult Result(string state,string reason){return new CompatibilityResult{State=state,Reason=reason};}
}

// ---------------------------------------------------------------------------
// Registro: monta os descritores e CONFERE OS INVARIANTES.
// ---------------------------------------------------------------------------
static class OptimizationRegistry {
 // Requisitos declarados só onde EXISTEM de verdade. A tentação aqui é inventar
 // requisito para parecer sofisticado; requisito falso vira "Não compatível" falso.
 static readonly Dictionary<string,OptimizationRequirements> Declared=new Dictionary<string,OptimizationRequirements>(StringComparer.Ordinal){
  // Plano Alto desempenho: já é recusado em notebook e fora da tomada por App.Compatibility.
  // Aqui o mesmo requisito vira dado, para a tela poder explicar ANTES de a pessoa marcar.
  {"native-power",new OptimizationRequirements{RequiresDesktop=true,RequiresAC=true}}
 };

 // As faixas de build NÃO são digitadas aqui. ImportedOptions e V5Options já declaram
 // Minimum/Maximum por regra, e App.Compatibility já barra fora dessa faixa na hora de
 // aplicar. Copiar os números para uma segunda tabela criaria duas verdades que
 // divergiriam no primeiro ajuste. O contrato lê a fonte que já existe.
 static OptimizationRequirements RequirementsFor(Item item){
  OptimizationRequirements declared;
  if(Declared.TryGetValue(item.Id,out declared))return declared;
  var imported=ImportedOptions.Rules().FirstOrDefault(r=>r.Id==item.Id);
  if(imported!=null)return new OptimizationRequirements{
   MinBuild=imported.Minimum<=10240?0:imported.Minimum,
   MaxBuild=imported.Maximum==Int32.MaxValue?0:imported.Maximum};
  int minimum,maximum;
  if(V5Options.BuildRange(item.Id,out minimum,out maximum))return new OptimizationRequirements{MinBuild=minimum,MaxBuild=maximum};
  return new OptimizationRequirements();
 }

 static List<OptimizationDescriptor> all;
 static readonly object Gate=new object();
 internal static void Invalidate(){lock(Gate)all=null;}

 internal static List<OptimizationDescriptor> All(){
  lock(Gate){if(all==null)all=Build();return all;}
 }
 internal static OptimizationDescriptor For(string id){
  return All().FirstOrDefault(d=>String.Equals(d.Id,id,StringComparison.Ordinal));
 }

 static List<OptimizationDescriptor> Build(){
  var library=PerformanceLibrary.Load().Where(e=>e.Action=="native").ToDictionary(e=>e.Target,e=>e,StringComparer.Ordinal);
  var result=new List<OptimizationDescriptor>();
  foreach(var item in CatalogIds.NativeItems()){
   var info=OptionInfo.For(item);
   string level=Evidence.Level(item,info);
   PerformanceEntry entry;library.TryGetValue(item.Id,out entry);
   OptimizationRequirements req=RequirementsFor(item);
   var review=item.Review??new string[0];
   result.Add(new OptimizationDescriptor{
    Id=item.Id,
    Title=item.ReviewTitle??item.Name??item.Id,
    Category=entry==null?(item.Category??""):entry.Category,
    Subcategory=item.Path??"",
    Risk=info.Risk,
    EvidenceLevel=level,
    Confidence=Evidence.Confidence(level),
    StageName=Stage.Of(level),
    Source=item.Url??"",
    Effect=entry==null?(review.Length>0?review[0]:""):entry.Effect,
    Tradeoff=entry==null?(review.Length>1?review[1]:""):entry.Tradeoff,
    Steps=entry==null?"":entry.Steps,
    Classification=info.Classification,
    Restart=RestartScope.For(item),
    // Toda opção nativa passa por ApplyTransaction: o valor anterior, o tipo anterior e a
    // AUSÊNCIA anterior são gravados antes de escrever. É isso que sustenta Reversible.
    Undo=info.Undo,
    BackupStrategy="SavedValue (valor, tipo e ausência anteriores) gravado por ApplyTransaction antes da escrita; restauração verificada por ChangeAudit",
    CompatibilityText=info.Compatibility,
    Administrator=info.Admin,
    Reversible=true,
    Native=true,
    AutomaticEligible=info.Automatic&&Stage.AutomaticAllowed(Stage.Of(level)),
    Requirements=req,
    Tags=Tags(item,info,level)
   });
  }
  return result;
 }

 // Etiquetas para a busca global (item 95): derivadas do próprio conteúdo, para não
 // envelhecerem separadas do item.
 static string[] Tags(Item item,OptionInfo info,string level){
  var tags=new List<string>();
  string text=((item.ReviewTitle??"")+" "+(item.Name??"")+" "+(item.Category??"")+" "+String.Join(" ",item.Review??new string[0])).ToLowerInvariant();
  Action<string,string> add=delegate(string needle,string tag){if(text.Contains(needle)&&!tags.Contains(tag))tags.Add(tag);};
  add("mouse","mouse");add("ponteiro","mouse");add("tecl","teclado");
  add("jogo","jogos");add("game","jogos");add("fps","fps");
  add("energia","energia");add("plano","energia");
  add("rede","rede");add("dns","rede");add("tcp","rede");
  add("anima","interface");add("transpar","interface");add("barra","interface");add("explorer","explorer");
  add("privacidade","privacidade");add("sugest","privacidade");
  add("mem","memória");add("ram","memória");
  add("servi","serviços");add("segundo plano","processos");
  add("disco","armazenamento");add("ssd","armazenamento");add("ntfs","armazenamento");
  if(info.Admin)tags.Add("administrador");
  if(level==Evidence.Experimental)tags.Add("experimental");
  if(level==Evidence.NotRecommended)tags.Add("não recomendada");
  return tags.ToArray();
 }

 // INVARIANTES. Quebrar qualquer um destes é erro de cadastro, não opinião de estilo.
 // Roda nos testes e no início do processo, junto de CatalogIds.Validate().
 internal static void Validate(){
  var list=All();
  var duplicated=list.GroupBy(d=>d.Id).Where(g=>g.Count()>1).Select(g=>g.Key).ToArray();
  if(duplicated.Length>0)throw new Exception("IDs de otimização duplicados: "+String.Join(", ",duplicated));
  foreach(var d in list){
   if(String.IsNullOrWhiteSpace(d.Id))throw new Exception("Otimização sem Id.");
   if(String.IsNullOrWhiteSpace(d.Title))throw new Exception("Otimização sem título: "+d.Id);
   // "Uma opção reversível NÃO pode ser cadastrada sem estratégia de backup."
   if(d.Reversible&&String.IsNullOrWhiteSpace(d.BackupStrategy))throw new Exception("Otimização reversível sem estratégia de backup: "+d.Id);
   if(String.IsNullOrWhiteSpace(d.Effect))throw new Exception("Otimização sem efeito declarado: "+d.Id);
   if(String.IsNullOrWhiteSpace(d.Tradeoff))throw new Exception("Otimização sem custo/contrapartida declarado: "+d.Id);
   if(!Evidence.Levels.Contains(d.EvidenceLevel))throw new Exception("Nível de evidência inválido em "+d.Id+": "+d.EvidenceLevel);
   if(!Evidence.Confidences.Contains(d.Confidence))throw new Exception("Confiança inválida em "+d.Id+": "+d.Confidence);
   if(!Stage.All.Contains(d.StageName))throw new Exception("Estágio inválido em "+d.Id+": "+d.StageName);
   if(d.Restart!=RestartScope.None&&d.Restart!=RestartScope.Explorer&&d.Restart!=RestartScope.SignOut&&d.Restart!=RestartScope.Windows)
    throw new Exception("Escopo de reinício inválido em "+d.Id+": "+d.Restart);
   // Fonte obrigatória para tudo que não é mera conveniência.
   if(d.EvidenceLevel!=Evidence.Convenience&&!d.Source.StartsWith("https://",StringComparison.OrdinalIgnoreCase))
    throw new Exception("Otimização sem fonte técnica: "+d.Id);
   // Experimental nunca entra em perfil automático, e não recomendada muito menos.
   if(d.AutomaticEligible&&(d.EvidenceLevel==Evidence.Experimental||d.EvidenceLevel==Evidence.NotRecommended))
    throw new Exception("Otimização experimental ou não recomendada marcada como automática: "+d.Id);
  }
 }

 // Painel “estado das recomendações” (item 11): NÃO é nota de desempenho, e o texto
 // que acompanha diz isso. É a contagem de quantas recomendações aplicáveis a ESTE PC
 // já estão configuradas — nada a ver com benchmark.
 internal static string Score(MachineProfile profile,Func<string,bool> applied){
  var list=All();int applicable=0,done=0;
  foreach(var d in list){
   var compat=CompatibilityEngine.Evaluate(d,profile);
   if(compat.State!=CompatibilityEngine.Compatible)continue;
   if(!d.AutomaticEligible)continue;
   applicable++;if(applied!=null&&applied(d.Id))done++;
  }
  if(applicable==0)return "Nenhuma recomendação aplicável foi confirmada para este PC. Isto não é uma nota de desempenho.";
  return done+"/"+applicable+" recomendações aplicáveis a este PC já estão configuradas. Isto NÃO é benchmark nem nota de desempenho: é a contagem das recomendações do próprio LukeOptimizer.";
 }

 // Ficha completa de uma otimização, para o botão “O que isso faz?” (itens 23 e 122).
 internal static string Details(string id,MachineProfile profile){
  var d=For(id);
  if(d==null)return "Otimização não encontrada: "+id;
  var compat=CompatibilityEngine.Evaluate(d,profile);
  var b=new StringBuilder();
  b.AppendLine(d.Title).AppendLine();
  b.AppendLine("O que muda: "+d.Effect);
  b.AppendLine("Possível desvantagem: "+d.Tradeoff);
  if(d.Steps.Length>0)b.AppendLine("Como é feito: "+d.Steps);
  b.AppendLine();
  b.AppendLine("Evidência: "+d.EvidenceLevel+"  ·  Confiança: "+d.Confidence+"  ·  Risco: "+d.Risk);
  b.AppendLine("Estágio: "+d.StageName+"  ·  Classificação: "+d.Classification);
  b.AppendLine("Compatibilidade neste PC: "+compat.State+" — "+compat.Reason);
  b.AppendLine("Precisa de administrador: "+(d.Administrator?"sim":"não"));
  b.AppendLine("Reinício: "+new RestartPlan{
   Explorer=d.Restart==RestartScope.Explorer,SignOut=d.Restart==RestartScope.SignOut,WindowsRestart=d.Restart==RestartScope.Windows}.Text());
  b.AppendLine("Como será restaurado: "+d.BackupStrategy);
  b.AppendLine("Desfazer: "+d.Undo);
  b.AppendLine("Fonte técnica: "+(d.Source.Length>0?d.Source:"sem fonte externa; preferência de conveniência"));
  b.AppendLine("ID preservado: "+d.Id);
  return b.ToString();
 }
}

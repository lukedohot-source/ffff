using System;
using System.Linq;
using System.Collections.Generic;
class OptionInfo {
 public string Id,Classification,Risk,AutomaticReason,Restart,Undo,Compatibility;
 public bool Automatic,Admin;
 internal static OptionInfo For(Item item){
  var automatic=new HashSet<string>(ExtremeProfile.Groups().Where(g=>g.Selected).SelectMany(g=>g.Items));
  var high=new HashSet<string>(new[]{"opt-disablesmartscreen","opt-disablevirtualizationbasedsecurity","opt-userhvci","opt-disabletpmcheck","opt-disablesmb2","opt-disablemodernstandby"});
  var experimental=new HashSet<string>(new[]{"extra-memory-compression","pack-e8ea680d9741","opt-disablenetworkthrottling","pack-f06301afb713","pack-a137e56bbd0e","pack-b735bf30fb1a"});
  bool policy=(item.Operations??new RegOp[0]).Any(App.IsPolicy);
  bool auto=automatic.Contains(item.Id)&&ExtremeProfile.IsReviewed(item),risk=high.Contains(item.Id),test=experimental.Contains(item.Id);
  var imported=ImportedOptions.Rules().FirstOrDefault(x=>x.Id==item.Id);
  return new OptionInfo{Id=item.Id,Automatic=auto,Admin=LiquidProtocol.NeedsAdmin(new[]{item}),
   Classification=policy?"Manual":risk?"Não recomendada":test?"Experimental":auto?"Recomendada para o perfil":"Condicional / escolha individual",
   Risk=risk?"Alto":test||((item.Operations??new RegOp[0]).Any(o=>o.Key.StartsWith(@"SYSTEM\CurrentControlSet\Services\",StringComparison.OrdinalIgnoreCase)))?"Moderado":"Baixo",
   AutomaticReason=policy?"Política protegida: somente escolha manual, fora da Otimização extrema. Permissões verificadas antes das alterações.":auto?"Incluída no perfil; depende da compatibilidade e da leitura deste PC.":risk?"Reduz proteção ou afeta funções do sistema. Exige escolha individual.":test?"Depende de teste A/B. Pode piorar o desempenho.":"Preferência pessoal, recurso opcional ou reparo. Escolha individual necessária.",
   Restart=(item.Operations??new RegOp[0]).Any(o=>o.Key.StartsWith(@"SYSTEM\",StringComparison.OrdinalIgnoreCase))?"Reiniciar para validar o efeito":"Pode exigir reabrir o app ou entrar novamente no Windows",
   Undo="Valores anteriores salvos no Histórico; desfazer transacional",Compatibility=imported==null?"Windows 10/11; versão, edição e componente conferidos pela engine":"Windows build "+imported.Minimum+" a "+(imported.Maximum==Int32.MaxValue?"posterior":imported.Maximum.ToString())+"; componente conferido antes de alterar"};
 }
 internal static string Rows(){return String.Concat(CatalogIds.NativeItems().Select(i=>{var m=For(i);return LiquidProtocol.Row("metadata",m.Id,m.Classification,m.Risk,m.Automatic?"1":"0",m.AutomaticReason,m.Restart,m.Undo,m.Compatibility);}));}
}

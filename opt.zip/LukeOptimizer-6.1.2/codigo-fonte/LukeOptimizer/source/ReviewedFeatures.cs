﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.NetworkInformation;

static class ReviewedFeatures {
 internal const string SpiSource="https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-systemparametersinfow";
 internal static List<Item> Items(){return new[]{
  Make("dragoutline","Arrastar janelas pelo contorno","Reduz o redesenho de conteúdo durante o arraste usando SPI_SETDRAGFULLWINDOWS. Pode ajudar em sessões remotas ou interfaces pesadas. O conteúdo reaparece ao soltar a janela; não mede FPS."),
  Make("cursorshadow","Desativar sombra do ponteiro","Desativa a sombra via SPI_SETCURSORSHADOW. É uma preferência visual: não muda polling, Raw Input ou a latência física. Pode reduzir a visibilidade do ponteiro.")
 }.ToList();}
 static Item Make(string code,string title,string effect){return new Item{Id="native-"+code,Name=title,ReviewTitle=title,Category="-5 - Windows",Path="API oficial / "+title,Mode="Nativo",Type="Nativo",Native=true,ActionCode=code,Available=true,ManualAllowed=true,MaxEligible=false,DefaultSelected=false,Notes=new string[0],Operations=new RegOp[0],ReviewLevel="Revisado",Review=new[]{effect,"Backup da preferência pela mesma API; desfazer restaura e relê o estado anterior."},Conflicts=new string[0],SameTargets=new string[0],Asset="",Hash="",Text="",Url=SpiSource,Blocked=""};}
 internal static List<PerformanceEntry> Library(){var entries=Items().Select(i=>new PerformanceEntry{Id="reviewed54-"+i.Id,Title=i.Name,Category="Windows",Mode="Aplicável com backup",Effect=i.Review[0],Tradeoff=i.Review[1],Steps="Selecionar e aplicar com backup. Preferência individual.",Action="native",Target=i.Id,Source=i.Url}).ToList();
  entries.AddRange(ReviewedDiagnostics.Ids.Select(id=>new PerformanceEntry{Id=id,Title=ReviewedDiagnostics.Title(id),Category=ReviewedDiagnostics.Category(id),Mode="Diagnóstico",Effect=ReviewedDiagnostics.Detail(id),Tradeoff="Somente leitura; não exige desfazer. Falhas de acesso são registradas individualmente.",Steps="Marque na página Otimizações e clique em Aplicar selecionadas.",Action="page",Target="Otimizações",Source=ReviewedDiagnostics.Source(id)}));return entries;}
}
static class ReviewedDiagnostics {
 internal static readonly string[] Ids={"diag54-tcp","diag54-storage","diag54-power","diag54-stability"};
 internal static string Title(string id){return id==Ids[0]?"Diagnosticar retransmissões TCP":id==Ids[1]?"Analisar espaço das unidades":id==Ids[2]?"Diagnosticar energia":"Verificar estabilidade recente";}
 internal static string Category(string id){return id==Ids[0]?"Rede":id==Ids[1]?"SSD":id==Ids[2]?"Energia":"Diagnóstico";}
 internal static string Source(string id){return id==Ids[0]?"https://learn.microsoft.com/en-us/dotnet/api/system.net.networkinformation.tcpstatistics?view=net-10.0":id==Ids[1]?"https://learn.microsoft.com/en-us/dotnet/api/system.io.driveinfo.availablefreespace?view=netframework-4.8.1":id==Ids[2]?"https://learn.microsoft.com/en-us/windows-hardware/design/device-experiences/powercfg-command-line-options":"https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/wevtutil";}
 internal static string Detail(string id){return id==Ids[0]?"Amostra contadores TCP IPv4 por 1 segundo, sem gerar tráfego. Registra segmentos enviados, retransmitidos e recebidos. Não mede UDP, ping do jogo ou perda na rede; não atribui uma causa a retransmissões.":id==Ids[1]?"Consulta espaço total e disponível nas unidades fixas prontas. Respeita quotas do usuário. Não exclui arquivos, executa TRIM ou afirma a saúde física do SSD.":id==Ids[2]?"Consulta o plano ativo e as solicitações de energia (powercfg /getactivescheme e /requests). Identifica bloqueadores de suspensão; não altera planos ou remove solicitações.":"Lê até 50 erros/críticos recentes por log (System e Application), nos últimos 7 dias. Mostra data, provedor e ID do evento. Um evento não prova a causa de stutter ou falha de hardware.";}
 internal static bool Valid(string id){return Ids.Contains(id);}
 internal static string TcpDelta(long sentBefore,long sentAfter,long resentBefore,long resentAfter,long receivedBefore,long receivedAfter){
  if(sentAfter<sentBefore||resentAfter<resentBefore||receivedAfter<receivedBefore)return "Contadores reiniciados durante a amostra; repita a leitura.";
  return "Amostra TCP IPv4 (1 segundo):\r\nEnviados: "+(sentAfter-sentBefore)+"\r\nRetransmitidos: "+(resentAfter-resentBefore)+"\r\nRecebidos: "+(receivedAfter-receivedBefore)+"\r\n"+(sentAfter==sentBefore?"Sem segmentos enviados na amostra. ":"")+"Contadores do PC inteiro. Não são porcentagem de perda nem latência do jogo.";
 }
 internal static string Read(string id){
  if(!Valid(id))throw new ArgumentException("Diagnóstico desconhecido.");
  if(!App.IsWindows)throw new Exception("Requer Windows.");
  if(id==Ids[0]){var props=IPGlobalProperties.GetIPGlobalProperties();var a=props.GetTcpIPv4Statistics();long sent=a.SegmentsSent,resent=a.SegmentsResent,received=a.SegmentsReceived;System.Threading.Thread.Sleep(1000);var b=props.GetTcpIPv4Statistics();return TcpDelta(sent,b.SegmentsSent,resent,b.SegmentsResent,received,b.SegmentsReceived);}
  if(id==Ids[1]){var report=new StringBuilder();foreach(var drive in DriveInfo.GetDrives().Where(d=>d.DriveType==DriveType.Fixed)){try{if(!drive.IsReady){report.AppendLine(drive.Name+" — indisponível");continue;}report.AppendLine(drive.Name+" · "+drive.DriveFormat+" · "+(drive.AvailableFreeSpace/1073741824d).ToString("0.0")+" GiB disponíveis / "+(drive.TotalSize/1073741824d).ToString("0.0")+" GiB totais");}catch(Exception e){report.AppendLine(drive.Name+" — leitura indisponível: "+e.Message);}}return report.Length==0?"Nenhuma unidade fixa disponível para consulta.":report.ToString();}
  if(id==Ids[2])return PowerRead("/getactivescheme")+"\r\nSOLICITAÇÕES DE ENERGIA\r\n"+PowerRead("/requests");
  var events=new StringBuilder();foreach(var log in new[]{"System","Application"}){
   events.AppendLine(log+" · últimos 7 dias (máximo 50 eventos)");
   try{using(var process=new Process{StartInfo=new ProcessStartInfo(App.SystemExe("wevtutil.exe"),StabilityArguments(log)){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true}}){
    process.Start();var output=process.StandardOutput.ReadToEndAsync();var error=process.StandardError.ReadToEndAsync();
    if(!process.WaitForExit(15000)){try{process.Kill();}catch{}events.AppendLine("Consulta excedeu 15 segundos.");}
    else if(process.ExitCode==0)events.AppendLine(String.IsNullOrWhiteSpace(output.Result)?"Nenhum evento de erro/crítico encontrado no período.":output.Result.Trim());
    else events.AppendLine("Leitura indisponível: "+error.Result);
   }}
   catch(Exception e){events.AppendLine("Leitura indisponível: "+e.Message);}
  }return events.ToString();
 }
 internal static string StabilityArguments(string log){
  if(log!="System"&&log!="Application")throw new ArgumentException("Log não permitido.");
  return "qe "+log+" /q:\"*[System[(Level=1 or Level=2) and TimeCreated[timediff(@SystemTime) <= 604800000]]]\" /f:text /c:50 /rd:true";
 }
 static string PowerRead(string argument){
  if(argument!="/getactivescheme"&&argument!="/requests")throw new ArgumentException();
  using(var process=new Process{StartInfo=new ProcessStartInfo(App.SystemExe("powercfg.exe"),argument){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true}}){process.Start();var output=process.StandardOutput.ReadToEndAsync();var error=process.StandardError.ReadToEndAsync();if(!process.WaitForExit(15000)){try{process.Kill();}catch{}return "Consulta excedeu 15 segundos.";}return process.ExitCode==0?output.Result:"Consulta indisponível ("+process.ExitCode+"): "+output.Result+error.Result;}
 }
}
static partial class App {
 internal static Record RunReviewedDiagnostic(string id){
  if(!ReviewedDiagnostics.Valid(id))throw new ArgumentException("Diagnóstico desconhecido.");
  var record=NewRecord(ReviewedDiagnostics.Title(id),id,"Diagnóstico");Save(record);
  try{record.Message=ReviewedDiagnostics.Read(id);record.Status=record.Message.Contains("indisponível")||record.Message.Contains("excedeu")?"consulta parcial":"consulta concluída";}catch(Exception e){record.Status="leitura indisponível";record.Message=e.Message;}
  record.Steps.Add(new StepResult{Id=id,Name=record.Name,Status=record.Status,Message=record.Message});record.Message+="\r\n\r\n"+ReviewedDiagnostics.Detail(id)+"\r\nFonte: "+ReviewedDiagnostics.Source(id);Save(record);return record;
 }
}

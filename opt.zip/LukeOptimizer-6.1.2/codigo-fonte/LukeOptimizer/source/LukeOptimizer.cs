using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Reflection;
using System.Security.Principal;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.Script.Serialization;
using System.Management;
using Microsoft.Win32;

[assembly: AssemblyVersion("6.1.2.0")]
[assembly: AssemblyFileVersion("6.1.2.0")]
[assembly: AssemblyTitle("Luke Optimizer")]
[assembly: System.Runtime.Versioning.TargetFramework(".NETFramework,Version=v4.8")]

public class RegOp {
 public string Hive {get;set;} public string Key {get;set;} public string Name {get;set;}
 public string Kind {get;set;} public string Data {get;set;} public bool Delete {get;set;}
}
public class Item {
 public string Id {get;set;} public string Name {get;set;} public string Category {get;set;}
 public string Path {get;set;} public string Url {get;set;} public string Type {get;set;}
 public string Mode {get;set;} public string Asset {get;set;} public string Hash {get;set;}
 public long Bytes {get;set;} public string Text {get;set;} public string[] Notes {get;set;}
 public string Blocked {get;set;} public RegOp[] Operations {get;set;}
 public string DuplicateOf {get;set;} public bool Available {get;set;}
 public string ReviewLevel {get;set;} public string ReviewTitle {get;set;} public string[] Review {get;set;}
 public bool ManualAllowed {get;set;} public string ReplacementId {get;set;} public string[] Conflicts {get;set;}
 public string[] SameTargets {get;set;} public bool MaxEligible {get;set;} public string ActionCode {get;set;}
 public bool DefaultSelected {get;set;} public bool Native {get;set;}
 public RegOp[] Expected {get;set;}
 public NativeSaved[] RestoreNative {get;set;} public string RestorePlan {get;set;}
}
public class SavedValue {
 public RegOp Before {get;set;} public RegOp After {get;set;} public bool KeyExisted {get;set;}
 public string[] AbsentKeys {get;set;}
}
// Executável de um app encerrado, guardado para permitir reabri-lo depois.
// Só caminho e nome: linha de comando, argumentos e sessão não são reproduzidos.
public class ClosedApp {
 public string Name {get;set;} public string Path {get;set;} public string Tier {get;set;}
}
public class Record {
 public string OutcomeCode {get;set;} public bool? RequestedAdmin {get;set;} public List<BackupAttachment> Attachments {get;set;} public bool ExecutionCancelled {get;set;}
 public PlatformSnapshot Platform {get;set;} public ExecutionReport Result {get;set;} public string LogError {get;set;}
 public string Id {get;set;} public string ItemId {get;set;} public string Name {get;set;}
 public string Time {get;set;} public string Kind {get;set;} public string Status {get;set;}
 public string Message {get;set;} public string UserSid {get;set;}
 public string PreviousPlan {get;set;} public string NewPlan {get;set;}
 public List<SavedValue> Values {get;set;}
 public List<NativeSaved> NativeValues {get;set;} public List<StepResult> Steps {get;set;}
 public bool PlanReused {get;set;} public int Schema {get;set;} public string[] ItemIds {get;set;}
 public string Updated {get;set;} public bool ChangesStarted {get;set;}
 public List<ServiceSaved> ServiceValues {get;set;}
 public List<ClosedApp> ClosedApps {get;set;}
 public PrioritySaved PriorityValue {get;set;}
 public ResourceSample BeforeSample {get;set;} public ResourceSample AfterSample {get;set;}
 public List<SettingEvidence> Evidence {get;set;}
 public string FailureStage {get;set;} public string FailureDetail {get;set;}
 public List<RemovalEvidence> Removals {get;set;}
 public string[] IdMigrations {get;set;}
 public List<Record> IsolatedSteps {get;set;}
}
static partial class App {
 internal const string Version="6.1.2";
 internal static readonly bool IsWindows=Environment.OSVersion.Platform==PlatformID.Win32NT;
 internal static string PreviewOutput;
 internal static JavaScriptSerializer Json {get{return new JavaScriptSerializer {MaxJsonLength=32000000,RecursionLimit=100};}}
 #if TESTS
 internal static readonly string DataRoot=System.IO.Path.Combine(System.IO.Path.GetTempPath(),"LukeOptimizer-Tests",Guid.NewGuid().ToString("N"));
#else
 internal static readonly string DataRoot=System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"LukeOptimizer");
#endif
 internal static readonly string PackRoot=System.IO.Path.Combine(DataRoot,"pack-20260910-v1");
 internal static readonly string RecordsRoot=System.IO.Path.Combine(DataRoot,"historico");
 static string CurrentSid(){if(!IsWindows)return "preview";try{var identity=WindowsIdentity.GetCurrent();return identity.User==null?Environment.UserName:identity.User.Value;}catch{return Environment.UserName;}}
 internal static readonly string Sid=CurrentSid();
 internal static List<Item> Items;
 // Índice por ID. Items tem 673 entradas e a interface consultava cada opção com
 // App.Items.Single(...) dentro de laços por opção — 131 varreduras lineares por
 // tecla digitada na busca.
 // O índice se invalida sozinho: testes e utilitários trocam App.Items por atribuição
 // (muda a referência) ou por AddRange (muda a contagem), e nenhum deles chamaria
 // ResetIndex. Comparar referência e contagem cobre os dois casos sem tocar nesses
 // arquivos; este catálogo nunca substitui um elemento no lugar.
 static Dictionary<string,Item> itemIndex;
 static List<Item> indexedSource;
 static int indexedCount=-1;
 static readonly object IndexGate=new object();
 static bool IndexStale(List<Item> source){return itemIndex==null||!ReferenceEquals(indexedSource,source)||indexedCount!=source.Count;}
 internal static Item ById(string id){
  var source=Items;
  if(id==null||source==null)return null;
  Dictionary<string,Item> index;
  lock(IndexGate){
   if(IndexStale(source)){
    var built=new Dictionary<string,Item>(StringComparer.Ordinal);
    foreach(var item in source)built[item.Id]=item; // último vence, como SingleOrDefault fazia na prática
    itemIndex=built;indexedSource=source;indexedCount=source.Count;
    OptionInfo.Invalidate();
   }
   index=itemIndex;
  }
  Item found;return index.TryGetValue(id,out found)?found:null;
 }
 // Escape hatch explícito, para quando Items mudar sem alterar referência nem contagem.
 internal static void ResetIndex(){lock(IndexGate){itemIndex=null;indexedSource=null;indexedCount=-1;}OptionInfo.Invalidate();}
#if TESTS
 internal static bool TestUiRendering;
#endif
 internal static bool IsUiTest(){
#if TESTS
  return TestUiRendering;
#else
  return false;
#endif
 }
 static long lastRecordTicks;static readonly object RecordClock=new object();
 static string RecordTime(){lock(RecordClock){lastRecordTicks=Math.Max(DateTime.UtcNow.Ticks,lastRecordTicks+1);return new DateTime(lastRecordTicks,DateTimeKind.Utc).ToString("o");}}
 static void LogFatal(Exception e){try{File.WriteAllText(Path.Combine(Path.GetTempPath(),"LukeOptimizer-startup.log"),DateTime.UtcNow.ToString("o")+"\r\n"+e);}catch{}try{MessageBox.Show(ErrorHelp.For(e).FriendlyError+"\r\n\r\n"+e.Message+"\r\nLog: "+Path.Combine(Path.GetTempPath(),"LukeOptimizer-startup.log"),"Luke Optimizer - erro",MessageBoxButtons.OK,MessageBoxIcon.Error);}catch{}}
 internal static string SystemExe(string file) {return System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),file);}
 internal static string Quote(string s) {if(s.Contains("\"")||s.Contains("\r")||s.Contains("\n"))throw new Exception("Argumento inválido.");return "\""+s+"\"";}
 internal static string LocalAsset(string relative) {
  string p=System.IO.Path.GetFullPath(System.IO.Path.Combine(PackRoot,relative.Replace('/',System.IO.Path.DirectorySeparatorChar)));
  if(!p.StartsWith(PackRoot+System.IO.Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase))throw new Exception("Caminho fora do pacote.");return p;
 }
 [STAThread] static int Main(string[] args) {
  try {
   Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
   Application.ThreadException+=(s,e)=>LogFatal(e.Exception);
   AppDomain.CurrentDomain.UnhandledException+=(s,e)=>LogFatal(e.ExceptionObject as Exception??new Exception(String.Concat(e.ExceptionObject)));
   TaskScheduler.UnobservedTaskException+=(s,e)=>{LogFatal(e.Exception);e.SetObserved();};
   Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
   using(var s=Assembly.GetExecutingAssembly().GetManifestResourceStream("catalog.json"))
   using(var r=new StreamReader(s,Encoding.UTF8))Items=Json.Deserialize<List<Item>>(r.ReadToEnd());
   Items.AddRange(Builtins.Create());
   Items.AddRange(V5Options.Items());
   Items.AddRange(V5InputItems.Create());
   Items.AddRange(ImportedOptions.Items());
   Items.AddRange(ExtraSettings.Items());
   Items.AddRange(ReviewedFeatures.Items());
   ImportedScripts.Load();
   Items.AddRange(ImportedScripts.AsCatalogItems());
   ResetIndex();
   Directory.CreateDirectory(RecordsRoot);
   if(args.Length>0&&args[0]=="--liquid")return LiquidProtocol.Run(args);
   if(EmbeddedInterface.Parse(args)){Application.Run(new MainForm());return 0;}
   if(ReadUiArguments(args)){Application.Run(new MainForm());return 0;}
   if(args.Length>=2 && args[0]=="--preview" && !IsWindows) {PreviewOutput=args[1];Application.Run(new MainForm());return 0;}
   if(args.Length>0) {
    if(!IsWindows)throw new Exception("As alterações exigem Windows 10/11 de 64 bits.");
    if(args.Length!=3 || args[2]!=Sid)throw new Exception("Use a elevação na mesma conta que abriu o app. Outra conta alteraria as preferências do usuário errado.");
    if(ActionNeedsAdmin(args[0],args[1])&&!new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator))throw new Exception("Esta operação precisa de administrador.");
    bool acquired=false;
    using(var gate=new Mutex(false,"Global\\LukeOptimizer-Change-20260910")) {
     try {try{acquired=gate.WaitOne(0);}catch(AbandonedMutexException){acquired=true;}
      if(!acquired)throw new Exception("Já existe uma alteração em execução. Aguarde terminar.");
      if(args[0]=="--execute-profile"||args[0]=="--silent-execute")ExecutionControl.Run(args[1]);
      else if(args[0]=="--diagnostic-command")RunOfficialCommand(args[1]);
      else if(args[0]=="--max")ApplyMaximum(args[1].Split(new[]{','}));
      else if(args[0]=="--extreme")ExtremeProfile.Apply(args[1]);
      else if(args[0]=="--apply-many")ApplyMany(args[1].Split(new[]{','}));
      else if(args[0]=="--apply"){var item=Items.SingleOrDefault(x=>x.Id==CatalogIds.Canonical(args[1]));if(item==null)throw new Exception("Opção não encontrada: "+args[1]);if(item.Native)ApplyMany(new[]{args[1]});else Apply(item);}
      else if(args[0]=="--undo")Undo(args[1]);
      else if(args[0]=="--undo-last")UndoLatest();
      else if(args[0]=="--restorepoint")RestorePoint();
      else if(args[0]=="--startup")DisableStartup(args[1]);
      else if(args[0]=="--services")DisableOptionalServices(args[1].Split(new[]{','}));
      else if(args[0]=="--services-tier")DisableOptionalServices(ServicesInTier(args[1]));
      else if(args[0]=="--reopen-apps")ReopenClosedApps(args[1]);
      else if(args[0]=="--priority")ApplyFocus(args[1]);
      else if(args[0]=="--restore-selection")ApplyTransaction(RestoreSelectionItems(args[1]),"Perfil","Restaurar seleção do backup");
      else if(args[0]=="--apply-custom")ApplyTransaction(ExtraSettings.Manual(args[1]),"Perfil","Ajustes manuais escolhidos");
      else if(args[0]=="--remove-apps")RemoveSelectedApps(args[1]);
      else if(args[0]=="--poweroptions")ApplyPowerOptions(args[1]);
      else if(args[0]=="--gameprofile")ApplyGameProfile(args[1]);
      else throw new Exception("Operação desconhecida.");
     }finally{if(acquired)gate.ReleaseMutex();}
    }
    return ExecutionControl.LastExitCode;
   }
   Application.Run(new MainForm());return 0;
  }catch(Exception e) {if(args.Length>0&&args[0]=="--silent-execute"){try{ExecutionHub.Log("silent-failure",e.ToString());}catch{}return 1;}LogFatal(e);return 1;}
 }
 internal static void Extract(Action<int> progress) {
  Directory.CreateDirectory(PackRoot);
  string marker=System.IO.Path.Combine(PackRoot,".ready");
  if(File.Exists(marker)){progress(100);return;}
  using(var s=Assembly.GetExecutingAssembly().GetManifestResourceStream("payload.zip"))
  using(var zip=new ZipArchive(s,ZipArchiveMode.Read)) {
   int i=0;
   foreach(var e in zip.Entries) {
    string target=LocalAsset(e.FullName);Directory.CreateDirectory(System.IO.Path.GetDirectoryName(target));
    string temp=target+".preparing";
    using(var input=e.Open())using(var output=new FileStream(temp,FileMode.Create,FileAccess.Write,FileShare.None))input.CopyTo(output);
    if(File.Exists(target))File.Delete(target);File.Move(temp,target);
    progress(++i*100/zip.Entries.Count);
   }
  }
  File.WriteAllText(marker,"1");
 }
 internal static string Digest(string p) {using(var h=SHA256.Create())using(var f=File.OpenRead(p))return BitConverter.ToString(h.ComputeHash(f)).Replace("-","").ToLowerInvariant();}
 internal static void Verify(Item item) {
  string p=LocalAsset(item.Asset);
  if(!File.Exists(p)||Digest(p)!=item.Hash)throw new Exception("Arquivo ausente ou modificado: "+item.Name+". Feche o app, apague somente a pasta pack-20260910-v1 dentro de "+DataRoot+" e abra novamente para repor o pacote.");
 }
 internal static void VerifyGroup(Item item) {
  string prefix=item.Asset.Split(new[]{'/'})[0]+"/";
  foreach(var i in Items.Where(x=>x.Available && x.Hash.Length>0 && x.Asset.StartsWith(prefix))) {
   if(i.Category.StartsWith("0 - ")||i.Blocked.StartsWith("Ativação"))continue;
   Verify(i);
  }
 }
 internal static string RecordPath(string id) {
  Guid parsed;if(!Guid.TryParseExact(id,"N",out parsed))throw new Exception("Identificador de histórico inválido.");
  return System.IO.Path.Combine(RecordsRoot,id+".json");
 }
 static PlatformSnapshot executionPlatform;
 internal static PlatformSnapshot ExecutionPlatform {get{return executionPlatform??(executionPlatform=PlatformSnapshot.Read());}}
 internal static void Save(Record r) {
  string p=RecordPath(r.Id);
  r.Updated=DateTime.UtcNow.ToString("o");
  if(r.Platform==null)r.Platform=ExecutionPlatform;
  r.Result=ExecutionHub.Project(r);
  AtomicStore.Write(p,Json.Serialize(r));
  if(r.Status!="preparando"&&r.Status!="aplicando"&&r.Status!="restaurando"&&r.Status!="executando")try{ExecutionHub.Log(r.Id,Json.Serialize(r.Result));}catch(Exception e){r.LogError="Falha ao salvar log complementar: "+e.Message;AtomicStore.Write(p,Json.Serialize(r));}
 }
 internal static List<Record> History() {
  var list=new List<Record>();
  foreach(string p in Directory.GetFiles(RecordsRoot,"*.json"))try{list.Add(Json.Deserialize<Record>(AtomicStore.Read(p)));}catch{}
  return list.OrderByDescending(x=>x.Time).ToList();
 }
 internal static bool CanUndo(Record r) {return r!=null&&((r.Values!=null&&r.Values.Count>0)||(r.NativeValues!=null&&r.NativeValues.Count>0)||!String.IsNullOrEmpty(r.NewPlan)||(r.ServiceValues!=null&&r.ServiceValues.Count>0)||r.PriorityValue!=null)&&(r.Status=="aplicado"||r.Status=="falha na restauração"||r.Status=="aplicando"||r.Status=="restaurando")&&(r.Kind=="Integrado"||r.Kind=="Energia"||r.Kind=="Perfil"||r.Kind=="Nativo"||r.Kind=="Serviços"||r.Kind=="Foco");}
 internal static void RecordLaunchFailure(string action,string payload,Exception error,bool needsAdmin){var r=NewRecord("Execução não iniciada",payload,"Execução");r.RequestedAdmin=needsAdmin;r.OutcomeCode=ErrorHelp.For(error).ErrorCode;r.Status=ErrorHelp.For(error).ErrorCode=="CANCELLED"?"cancelado":"falhou antes de alterar";r.Message=ErrorHelp.For(error).FriendlyError;r.FailureDetail=error.ToString();r.Steps.Add(new StepResult{Id=payload,Name=action,Status=r.Status,Message=r.Message});Save(r);}
 static Record NewRecord(string name,string itemId,string kind) {return new Record {Id=Guid.NewGuid().ToString("N"),ItemId=itemId,Name=name,Time=RecordTime(),Kind=kind,Status="preparando",Message="",UserSid=Sid,Values=new List<SavedValue>(),NativeValues=new List<NativeSaved>(),Steps=new List<StepResult>(),Schema=3,ItemIds=new[]{itemId}};}
 static RegistryKey Hive(string name) {
  RegistryHive h=name=="HKEY_LOCAL_MACHINE"?RegistryHive.LocalMachine:name=="HKEY_CURRENT_USER"?RegistryHive.CurrentUser:throwHive();
  return RegistryKey.OpenBaseKey(h,RegistryView.Registry64);
 }
 static RegistryHive throwHive() {throw new Exception("Raiz de registro não suportada.");}
 static string EncodeValue(object value,RegistryValueKind kind) {
  switch(kind) {
   case RegistryValueKind.Binary:case RegistryValueKind.None:return Convert.ToBase64String((byte[])value);
   case RegistryValueKind.DWord:return unchecked((uint)(int)value).ToString(System.Globalization.CultureInfo.InvariantCulture);
   case RegistryValueKind.QWord:return unchecked((ulong)(long)value).ToString(System.Globalization.CultureInfo.InvariantCulture);
   case RegistryValueKind.MultiString:return Json.Serialize((string[])value);
   default:return Convert.ToString(value,System.Globalization.CultureInfo.InvariantCulture);
  }
 }
 static object DecodeValue(RegOp op) {
  switch(op.Kind) {
   case "Binary":case "None":return Convert.FromBase64String(op.Data);
   case "DWord":return unchecked((int)UInt32.Parse(op.Data,System.Globalization.CultureInfo.InvariantCulture));
   case "QWord":return unchecked((long)UInt64.Parse(op.Data,System.Globalization.CultureInfo.InvariantCulture));
   case "MultiString":return Json.Deserialize<string[]>(op.Data);
   case "String":case "ExpandString":return op.Data;
   default:throw new Exception("Tipo de valor não suportado: "+op.Kind);
  }
 }
 internal static SavedValue Capture(RegOp op) {
#if TESTS
  if(TestCapture!=null)return TestCapture(op);
#endif
  var before=new RegOp {Hive=op.Hive,Key=op.Key,Name=op.Name,Kind="String",Data="",Delete=true};bool keyExists;
  using(var h=Hive(op.Hive))using(var k=h.OpenSubKey(op.Key,false)) {
   keyExists=k!=null;
   if(k!=null && k.GetValueNames().Contains(op.Name,StringComparer.OrdinalIgnoreCase)) {
    RegistryValueKind kind=k.GetValueKind(op.Name);before.Kind=kind.ToString();before.Data=EncodeValue(k.GetValue(op.Name,null,RegistryValueOptions.DoNotExpandEnvironmentNames),kind);before.Delete=false;
   }
  }
  var absent=new List<string>();
  if(!keyExists)using(var h=Hive(op.Hive)){
   string path=op.Key;while(!String.IsNullOrEmpty(path)){using(var key=h.OpenSubKey(path,false)){if(key!=null)break;}absent.Add(path);int cut=path.LastIndexOf('\\');if(cut<0)break;path=path.Substring(0,cut);}
  }
  return new SavedValue {Before=before,After=op,KeyExisted=keyExists,AbsentKeys=absent.ToArray()};
 }
 static void WriteValue(RegOp op) {
#if TESTS
  if(TestWrite!=null){TestWrite(op);return;}
#endif
  using(var h=Hive(op.Hive)) {
   // Existing keys need SetValue, not the broader access requested by CreateSubKey.
   using(var existing=h.OpenSubKey(op.Key,RegistryKeyPermissionCheck.ReadWriteSubTree,System.Security.AccessControl.RegistryRights.SetValue)){
    if(existing!=null){if(op.Delete)existing.DeleteValue(op.Name,false);else existing.SetValue(op.Name,DecodeValue(op),(RegistryValueKind)Enum.Parse(typeof(RegistryValueKind),op.Kind));return;}
   }
   if(!op.Delete)using(var k=h.CreateSubKey(op.Key)){if(k==null)throw new Exception("Não foi possível criar a chave "+op.Key);k.SetValue(op.Name,DecodeValue(op),(RegistryValueKind)Enum.Parse(typeof(RegistryValueKind),op.Kind));}
  }
 }
 internal static bool RequiresAdmin(RegOp op){return op.Hive=="HKEY_LOCAL_MACHINE"||op.Key.StartsWith(@"Software\Policies\",StringComparison.OrdinalIgnoreCase)||op.Key.StartsWith(@"Software\Microsoft\Windows\CurrentVersion\Policies\",StringComparison.OrdinalIgnoreCase);}
 internal static void CheckWriteAccess(RegOp op){
#if TESTS
  if(TestAccess!=null){TestAccess(op);return;}
  if(TestCapture!=null)return;
#endif
  // Opening a handle requests access without creating, deleting or changing a key/ACL.
  try{using(var h=Hive(op.Hive)){
   using(var key=h.OpenSubKey(op.Key,RegistryKeyPermissionCheck.ReadWriteSubTree,System.Security.AccessControl.RegistryRights.SetValue))if(key!=null||op.Delete)return;
   if(IsPolicy(op))throw new UnauthorizedAccessException("Política ausente ou protegida; use a configuração oficial do Windows.");
   string parent=op.Key;
   while(parent.LastIndexOf('\\')>0){parent=parent.Substring(0,parent.LastIndexOf('\\'));
    using(var read=h.OpenSubKey(parent,false)){if(read==null)continue;}
    // Inherited ACLs can still reject a new child at apply time. The individual
    // transaction handles that race; the preflight must never create probe keys.
    using(var writable=h.OpenSubKey(parent,RegistryKeyPermissionCheck.ReadWriteSubTree,System.Security.AccessControl.RegistryRights.CreateSubKey|System.Security.AccessControl.RegistryRights.SetValue)){
     if(writable==null)throw new UnauthorizedAccessException();return;
    }
   }
   throw new UnauthorizedAccessException();
  }}catch(UnauthorizedAccessException){throw new UnauthorizedAccessException("Sem permissão no Registro: "+op.Name+". Desmarque a opção ou use a configuração manual.");}
  catch(System.Security.SecurityException){throw new UnauthorizedAccessException("Sem permissão no Registro: "+op.Name+". Desmarque a opção ou use a configuração manual.");}
 }
 internal static bool IsPolicy(RegOp op){return op.Key.StartsWith(@"Software\Policies",StringComparison.OrdinalIgnoreCase)||op.Key.StartsWith(@"Software\Microsoft\Windows\CurrentVersion\Policies",StringComparison.OrdinalIgnoreCase);}
 static bool Same(RegOp a,RegOp b) {return a.Delete==b.Delete && (a.Delete||(a.Kind==b.Kind&&a.Data==b.Data));}
 static void RestoreValues(List<SavedValue> values) {
  foreach(var v in values.AsEnumerable().Reverse())if(!Same(Capture(v.Before).Before,v.Before))WriteValue(v.Before);
  #if TESTS
  if(TestWrite!=null)return;
#endif
  foreach(var v in values.AsEnumerable().Reverse().Where(x=>!x.KeyExisted)) {
   using(var h=Hive(v.Before.Hive)) {
    foreach(var path in (v.AbsentKeys??new[]{v.Before.Key}).OrderByDescending(k=>k.Length)){
     // A legacy backup has only KeyExisted. New backups also remember missing
     // parent keys. Only exact ancestors and only empty keys can be removed.
     if(!String.Equals(path,v.Before.Key,StringComparison.OrdinalIgnoreCase)&&!v.Before.Key.StartsWith(path+"\\",StringComparison.OrdinalIgnoreCase))throw new Exception("Caminho inválido no backup de Registro.");
     bool empty=false;using(var k=h.OpenSubKey(path,false)){empty=k!=null&&k.ValueCount==0&&k.SubKeyCount==0;}
     if(empty)h.DeleteSubKey(path,false);
    }
   }
  }
 }
 static string RunCapture(string exe,string args,bool enforce) {
  var result=ManagedCommand.Run(exe,args,180,System.Threading.CancellationToken.None);
  if(result.TimedOut||result.Cancelled)throw new TimeoutException("Tempo excedido ao executar "+Path.GetFileName(exe)+". Consulte o histórico antes de repetir. Log: "+result.LogPath);
  if(enforce&&result.ExitCode!=0)throw new Exception("Falha ("+result.ExitCode+"): "+result.Output);return result.Output;
 }
 internal static string ActivePlan() {
#if TESTS
  if(TestPlanGet!=null)return TestPlanGet();
#endif
  string output=RunCapture(SystemExe("powercfg.exe"),"/getactivescheme",true);
  var m=Regex.Match(output,"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}");
  if(!m.Success)throw new Exception("Não foi possível identificar o plano de energia atual.");return m.Value;
 }
 internal static void Apply(Item item) {
  if(item.Native){ApplyMany(new[]{item.Id});return;}
  if(!String.IsNullOrEmpty(item.Blocked)||!item.ManualAllowed)throw new Exception("Execução indisponível: "+item.ReviewLevel+". Consulte a revisão do item.");
  string compatibility=Compatibility(item,ScanHardware());if(compatibility!=null)throw new Exception(compatibility);
  if(!item.Available)throw new Exception("Arquivo indisponível.");
  if(item.Mode=="Integrado") {ApplyTransaction(new[]{item},"Integrado",item.ReviewTitle);return;}
  EnsureGroup(item,n=>WriteProgress(n,"Preparando arquivos",item.Name));VerifyGroup(item);
  var rec=NewRecord(item.Name,item.Id,item.Mode);Save(rec);
  try {
   if(item.Mode=="Energia") {
    rec.PreviousPlan=ActivePlan();rec.NewPlan=Guid.NewGuid().ToString();rec.Status="aplicando";rec.ChangesStarted=true;Save(rec);
    try {
     RunCapture(SystemExe("powercfg.exe"),"/import "+Quote(LocalAsset(item.Asset))+" "+rec.NewPlan,true);
     SetPlan(rec.NewPlan);
     if(!String.Equals(ActivePlan(),rec.NewPlan,StringComparison.OrdinalIgnoreCase))throw new Exception("O plano não foi ativado.");
    } catch {
     try{SetPlan(rec.PreviousPlan);DeleteImportedPlan(rec);rec.Status="falhou e foi desfeito";}
     catch(Exception e){rec.Status="falha na restauração";rec.Message=e.Message;}
     Save(rec);throw;
    }
    rec.Status="aplicado";rec.Message="Plano importado e ativo, confirmado por powercfg. Opções internas e ganho de desempenho não foram medidos.";
   } else if(item.Mode=="Script"||item.Type=="Programa"||item.Type=="Instalador") {
    string exe=LocalAsset(item.Asset),arguments="";
    if(item.Mode=="Script") {
     string copy=System.IO.Path.Combine(System.IO.Path.GetDirectoryName(exe),"_Luke_"+item.Id+".bat");File.Copy(exe,copy,true);
     exe=SystemExe("cmd.exe");arguments="/d /s /c \""+Quote(copy)+"\"";
    } else if(item.Type=="Instalador") {arguments="/i "+Quote(exe);exe=SystemExe("msiexec.exe");}
    rec.Status="iniciado";rec.Message="Processo externo. Sem validação interna ou desfazer automático.";Save(rec);
    using(var process=Process.Start(new ProcessStartInfo(exe,arguments){UseShellExecute=false,WorkingDirectory=System.IO.Path.GetDirectoryName(LocalAsset(item.Asset))})) {
     process.WaitForExit();rec.Status=process.ExitCode==0?"externo encerrado":"externo com erro";
     rec.Message="Código de saída: "+process.ExitCode+". O resultado de cada comando interno continua não verificado. Sem desfazer automático.";
    }
   } else throw new Exception("Use Abrir arquivo para este item.");
   Save(rec);
  }catch(Exception e) {if(rec.Status=="preparando"||rec.Status=="iniciado")rec.Status="falhou";rec.Message=e.Message+"\r\n"+rec.Message;Save(rec);throw;}
 }
 internal static void Undo(string id) {
  var rec=Json.Deserialize<Record>(AtomicStore.Read(RecordPath(id)));
  if(rec.UserSid!=Sid)throw new Exception("Este backup pertence a outro usuário.");
  var latest=History().FirstOrDefault(CanUndo);
  if(latest==null||latest.Id!=id)throw new Exception("Desfaça primeiro a alteração gerenciada mais recente.");
  if(rec.Kind=="Serviços"){RestoreOptionalServices(rec);return;}
  if(rec.Kind=="Foco"){RestoreFocus(rec);return;}
  if(rec.Kind=="Integrado"||rec.Kind=="Perfil"||rec.Kind=="Nativo") {RestoreTransaction(rec);return;}
  if(rec.Kind!="Energia")throw new Exception("Este item não tem desfazer automático.");
  string active=ActivePlan();if(!EqualGuid(active,rec.NewPlan)&&!EqualGuid(active,rec.PreviousPlan))throw new Exception("O plano ativo mudou depois da aplicação. Restauração interrompida.");
  try{rec.Status="restaurando";Save(rec);SetPlan(rec.PreviousPlan);DeleteImportedPlan(rec);rec.Status="desfeito";rec.Message="Plano anterior restaurado e conferido.";Save(rec);}
  catch(Exception e){rec.Status="falha na restauração";rec.Message=e.Message;Save(rec);throw;}
 }
 internal static void UndoLatest(){var latest=History().FirstOrDefault(CanUndo);if(latest==null)throw new Exception("Não há alteração gerenciada para desfazer.");Undo(latest.Id);}
 static void RestorePoint() {
  var rec=NewRecord("Criar ponto de restauração","restorepoint","Sistema");Save(rec);
  string script="$ErrorActionPreference='Stop'; $WarningPreference='Stop'; Checkpoint-Computer -Description 'Luke Optimizer' -RestorePointType MODIFY_SETTINGS; Write-Output 'Solicitacao concluida. Confira o ponto em Protecao do Sistema.'";
  string enc=Convert.ToBase64String(Encoding.Unicode.GetBytes(script));
  try {rec.Message=RunCapture(SystemExe("WindowsPowerShell\\v1.0\\powershell.exe"),"-NoProfile -NonInteractive -EncodedCommand "+enc,true);rec.Status="solicitação concluída";Save(rec);}
  catch(Exception e){rec.Status="falhou";rec.Message=e.Message;Save(rec);throw;}
 }
 internal static string Hardware() {
  try {
   var lines=new List<string>();
   foreach(var query in new[]{"SELECT Name FROM Win32_Processor","SELECT Name FROM Win32_VideoController","SELECT Caption,Version FROM Win32_OperatingSystem"})
    using(var search=new ManagementObjectSearcher(query))using(var results=search.Get())foreach(ManagementObject obj in results) {lines.Add(query.Contains("OperatingSystem")?Convert.ToString(obj["Caption"])+" · "+obj["Version"]:Convert.ToString(obj["Name"]));obj.Dispose();}
   return String.Join("  |  ",lines);
  }catch{return "Windows 64 bits · informações de hardware indisponíveis";}
 }
}

using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Globalization;

public class FrameStream {
 public string Key {get;set;} public string Metric {get;set;}
 public List<double> Frames=new List<double>();public int Rejected;
 public override string ToString(){return Key+" · "+Frames.Count.ToString("N0")+" quadros · "+Metric;}
}
public class FrameCapture {public string File;public List<FrameStream> Streams=new List<FrameStream>();public int Malformed;}
public class FrameSummary {
 public string File,Stream,Metric;public int Count,Invalid,Trimmed,Spikes;public double AverageFps,Low1,Low01,P50,P95,P99,Max,Seconds,Threshold,TargetFps;
 public double MinimumFps {get{return Max>0?1000.0/Max:0;}}
 public double[] Timeline;public string Definition="FPS = 1000 / média dos intervalos; 1%/0,1% low = 1000 / média dos maiores ceil(N × fração) intervalos; percentis por nearest rank. Pausas permanecem na amostra. Não mede input lag físico.";
 public string Describe(){return Path.GetFileName(File)+"\r\n"+Stream+" · "+Metric+"\r\n\r\n"+
  "FPS médio: "+AverageFps.ToString("0.0")+"     1% low: "+Low1.ToString("0.0")+"     0,1% low: "+Low01.ToString("0.0")+
  "\r\nFrametime mediano: "+P50.ToString("0.00")+" ms     P95: "+P95.ToString("0.00")+" ms     P99: "+P99.ToString("0.00")+" ms"+
  "\r\nFPS mínimo instantâneo: "+MinimumFps.ToString("0.0")+" (inverso do pior intervalo; não é 1% low)"+"\r\nPior quadro: "+Max.ToString("0.00")+" ms     Picos: "+Spikes+" (acima de "+Threshold.ToString("0.00")+" ms)"+
  "\r\n"+Count.ToString("N0")+" intervalos · "+Seconds.ToString("0.0")+" s · "+Invalid+" linhas inválidas ignoradas · "+Trimmed+" intervalos de aquecimento removidos"+
  (Count<1000?"\r\nAmostra curta: principalmente o 0,1% low tem baixa representatividade.":"")+"\r\n\r\n"+Definition;}
}
static class FrameAnalysis {
 internal static string[] ParseLine(string line,char separator){
  var fields=new List<string>();var value=new StringBuilder();bool quoted=false,ended=false;
  for(int i=0;i<line.Length;i++){
   char c=line[i];if(quoted){if(c=='"'){if(i+1<line.Length&&line[i+1]=='"'){value.Append('"');i++;}else{quoted=false;ended=true;}}else value.Append(c);}
   else if(c==separator){fields.Add(value.ToString());value.Clear();ended=false;}
   else if(c=='"'){if(value.Length!=0||ended)throw new FormatException("Aspas fora do início do campo.");quoted=true;}
   else {if(ended&&!Char.IsWhiteSpace(c))throw new FormatException("Conteúdo após aspas.");if(!ended)value.Append(c);}
  }
  if(quoted)throw new FormatException("Campo CSV multilinha não suportado.");fields.Add(value.ToString());return fields.ToArray();
 }
 internal static int Find(string[] headers,params string[] names){foreach(string name in names){int i=Array.FindIndex(headers,h=>String.Equals(h.Trim(),name,StringComparison.OrdinalIgnoreCase));if(i>=0)return i;}return -1;}
 internal static FrameCapture Load(string file){
  if(new FileInfo(file).Length>256L*1024*1024)throw new Exception("CSV maior que 256 MB. Exporte uma sessão menor.");
  using(var r=new StreamReader(file,Encoding.UTF8,true))return Read(r,file);
 }
 internal static FrameCapture Read(TextReader reader,string file){
  var result=new FrameCapture{File=file};string first=reader.ReadLine();if(String.IsNullOrWhiteSpace(first))throw new Exception("CSV vazio.");
  char sep=first.Count(c=>c==';')>first.Count(c=>c==',')?';':',';
  string[] head=ParseLine(first.TrimStart('\uFEFF'),sep);
  int interval=Find(head,"MsBetweenPresents","FrameTime","CPUFrameTime","MsCPUFrameTime","Frametime (ms)");
  if(interval<0)throw new Exception("CSV sem intervalo de quadros compatível. Use PresentMon com MsBetweenPresents, FrameTime ou CPUFrameTime. GPUTime/latência não são frametime.");
  if(head.Count(h=>String.Equals(h.Trim(),head[interval].Trim(),StringComparison.OrdinalIgnoreCase))!=1)throw new Exception("Coluna de frametime duplicada.");
  int app=Find(head,"Application","ApplicationName"),pid=Find(head,"ProcessID"),swap=Find(head,"SwapChainAddress"),type=Find(head,"FrameType");
  var streams=new Dictionary<string,FrameStream>(StringComparer.Ordinal);string line;int rows=0;
  while((line=reader.ReadLine())!=null){
   if(++rows>2000000)throw new Exception("Limite de 2 milhões de linhas. Exporte uma sessão menor.");
   if(String.IsNullOrWhiteSpace(line))continue;
   string[] cells;try{cells=ParseLine(line,sep);}catch(FormatException){result.Malformed++;continue;}
   if(cells.Length!=head.Length){result.Malformed++;continue;}
   string key=(app>=0?cells[app]:"Captura")+" | PID "+(pid>=0?cells[pid]:"não informado")+" | swap "+(swap>=0?cells[swap]:"único")+(type>=0?" | tipo "+cells[type]:"");
   FrameStream stream;if(!streams.TryGetValue(key,out stream)){if(streams.Count>=512)throw new Exception("Muitos processos/swapchains. Capture somente o jogo.");streams[key]=stream=new FrameStream{Key=key,Metric=head[interval].Trim()};}
   string raw=cells[interval].Trim();if(sep==';')raw=raw.Replace(',','.');double ms;
   if(!Double.TryParse(raw,NumberStyles.Float,CultureInfo.InvariantCulture,out ms)||Double.IsNaN(ms)||Double.IsInfinity(ms)||ms<=0||ms>86400000){stream.Rejected++;continue;}
   stream.Frames.Add(ms);
  }
  result.Streams=streams.Values.Where(s=>s.Frames.Count>0).OrderByDescending(s=>s.Frames.Count).ToList();
  if(result.Streams.Count==0)throw new Exception("Nenhum intervalo de quadro positivo e válido.");return result;
 }
 internal static double Percentile(double[] sorted,double q){return sorted[Math.Max(0,Math.Min(sorted.Length-1,(int)Math.Ceiling(q*sorted.Length)-1))];}
 internal static FrameSummary Summarize(FrameCapture capture,FrameStream stream,int targetFps,double warmup){
  if(targetFps<1||targetFps>1000||Double.IsNaN(warmup)||Double.IsInfinity(warmup)||warmup<0||warmup>3600)throw new Exception("Alvo ou aquecimento inválido.");
  int skip=0;double elapsed=0;while(skip<stream.Frames.Count&&elapsed<warmup*1000)elapsed+=stream.Frames[skip++];
  var frames=stream.Frames.Skip(skip).ToArray();if(frames.Length<2)throw new Exception("Menos de dois intervalos após o aquecimento.");
  var sorted=frames.OrderBy(x=>x).ToArray();double p50=Percentile(sorted,.5);double threshold=Math.Max(p50*2,1500.0/targetFps);
  return new FrameSummary{File=capture.File,Stream=stream.Key,Metric=stream.Metric,Count=frames.Length,Trimmed=skip,Invalid=stream.Rejected+capture.Malformed,
   AverageFps=1000/frames.Average(),Low1=1000/sorted.Skip(sorted.Length-Math.Max(1,(int)Math.Ceiling(sorted.Length*.01))).Average(),
   Low01=1000/sorted.Skip(sorted.Length-Math.Max(1,(int)Math.Ceiling(sorted.Length*.001))).Average(),
   P50=p50,P95=Percentile(sorted,.95),P99=Percentile(sorted,.99),Max=sorted.Last(),Seconds=frames.Sum()/1000,
   TargetFps=targetFps,Threshold=threshold,Spikes=frames.Count(x=>x>threshold),Timeline=frames};
 }
 internal static string Compare(FrameSummary a,FrameSummary b){
  if(a==null||b==null)return "Importe uma captura ANTES e outra DEPOIS para comparar.";
  bool comparable=String.Equals(a.Metric,b.Metric,StringComparison.OrdinalIgnoreCase)&&a.TargetFps==b.TargetFps;
  if(!comparable)return "Comparação suspensa: use a mesma coluna de frametime e o mesmo FPS alvo nas duas capturas.";
  return "Variação DEPOIS vs. ANTES: FPS "+((b.AverageFps/a.AverageFps-1)*100).ToString("+0.0;-0.0;0")+"% · 1% low "+((b.Low1/a.Low1-1)*100).ToString("+0.0;-0.0;0")+"% · P99 "+((b.P99/a.P99-1)*100).ToString("+0.0;-0.0;0")+"% (menor é melhor).\r\n"+
   "Compare o mesmo jogo, cena, resolução, duração, versão de driver e tipo de quadro. Repita 3 vezes; a variação isolada não prova causa. Picos usam um limiar próprio por captura. FPS apresentado não equivale necessariamente a FPS exibido.";
 }
}

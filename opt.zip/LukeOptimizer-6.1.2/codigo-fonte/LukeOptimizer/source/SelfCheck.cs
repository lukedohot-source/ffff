using System;
using System.Linq;
using System.Text;
using System.Threading;
using System.Collections.Generic;

// CONFERÊNCIA REAL — "quando eu aplico, muda mesmo no Windows?"
//
// Esta é a única pergunta que os testes automáticos NÃO respondem, e é importante dizer
// por quê: os testes de motor trocam a gravação no Registro por um dicionário em memória
// (App.TestWrite / App.TestCapture) e os de interface trocam a elevação por um gancho
// (TestElevation). Isso é proposital — teste não pode mexer no Windows de quem roda —,
// mas significa que eles provam a LÓGICA (backup antes de gravar, id certo, desfazer
// restaura, nada duplicado) e não provam o EFEITO.
//
// A conferência abaixo fecha essa lacuna no único lugar onde ela pode ser fechada: a
// máquina real. E faz isso pelo MESMO caminho do produto — ApplyTransaction e Undo, os
// mesmos que o botão Aplicar usa. Conferir por um caminho paralelo não provaria nada
// sobre o caminho que a pessoa usa.
//
// Para cada opção:
//
//   LER  →  APLICAR  →  LER DE NOVO  →  DESFAZER  →  LER DE NOVO
//
// e o relatório responde, por opção, quatro perguntas separadas:
//   · o Windows estava como antes de mexer?
//   · aplicar MUDOU o valor no Windows?
//   · desfazer executou?
//   · o valor VOLTOU exatamente ao que era?
//
// A quarta é a que mais importa. Uma opção que muda o Windows mas não volta é pior que
// uma que não faz nada.
public class SelfCheckRow {
 public string Id="",Name="",Group="",Before="",AfterApply="",AfterUndo="",Outcome="",Detail="";
 public bool Attempted,Changed,Undone,Restored;
}

static class SelfCheck {
 internal const string ReadOnly="leitura",Full="completo";

 // Valores de TODAS as chaves e preferências que a opção toca, num texto comparável.
 // É a leitura crua: serve para comparar antes/depois sem depender de texto de tela.
 internal static string Snapshot(Item item){
  if(item==null)return "";
  var parts=new List<string>();
  foreach(var op in item.Operations??new RegOp[0]){
   try{
    var now=App.Capture(op).Before;
    parts.Add(op.Hive+"\\"+op.Key+"\\"+op.Name+" = "+(now.Delete?"(ausente)":now.Kind+":"+now.Data));
   }catch(Exception e){parts.Add(op.Hive+"\\"+op.Key+"\\"+op.Name+" = (leitura falhou: "+e.Message+")");}
  }
  if(!String.IsNullOrEmpty(item.ActionCode)){
   foreach(string code in NativeSettings.Codes(item.ActionCode)){
    try{parts.Add(code+" = "+NativeSettings.Read(code));}
    catch(Exception e){parts.Add(code+" = (leitura falhou: "+e.Message+")");}
   }
  }
  return parts.Count==0?"":String.Join(" | ",parts.ToArray());
 }

 // Por que uma opção NÃO entra na parte que grava. Devolve o motivo, ou null.
 //
 // O critério é um só: entra o que tem caminho de volta EXATO e imediato. Uma opção que
 // eu não consiga desfazer na hora não pode ser testada assim na máquina de alguém —
 // seria transformar a conferência em alteração permanente sem pedir.
 internal static string ExcludedFromWrite(Item item){
  if(item==null)return "opção inexistente";
  if(!item.Native)return "não é função executável: o app não aplica, só explica";
  if(item.ActionCode=="power")return "troca o plano de energia do sistema inteiro; fora desta conferência por segurança";
  bool writes=(item.Operations??new RegOp[0]).Length>0||
              (!String.IsNullOrEmpty(item.ActionCode)&&NativeSettings.Codes(item.ActionCode).Length>0);
  if(!writes)return "não grava valor conferível (ação, diagnóstico ou atalho)";
  return null;
 }

 internal static List<Item> Candidates(){
  return App.Items.Where(i=>i.Native&&ExcludedFromWrite(i)==null).OrderBy(i=>i.Category,StringComparer.CurrentCulture)
          .ThenBy(i=>i.ReviewTitle,StringComparer.CurrentCulture).ToList();
 }

 // ------------------------------------------------------------------ relatório
 internal static string Report(List<SelfCheckRow> rows,string mode,string machineText){
  var b=new StringBuilder();
  b.AppendLine("CONFERÊNCIA REAL DAS OPÇÕES — o que muda de verdade neste Windows");
  b.AppendLine(new String('=',78)).AppendLine();
  b.AppendLine("Gerado em: "+DateTime.Now.ToString("dd/MM/yyyy HH:mm"));
  if(!String.IsNullOrEmpty(machineText))b.AppendLine(machineText);
  b.AppendLine("Modo: "+(mode==Full?"COMPLETO — cada opção foi aplicada e desfeita nesta máquina"
                                    :"SOMENTE LEITURA — nada foi alterado")).AppendLine();

  if(mode!=Full){
   b.AppendLine("Esta leitura mostra o estado ATUAL de cada opção. Ela não prova que aplicar");
   b.AppendLine("funciona — para isso use o modo completo, que aplica e desfaz cada uma.").AppendLine();
   foreach(var row in rows)b.AppendLine(row.Outcome.PadRight(22)+" · "+row.Name+"\r\n"+Indent(row.Before));
   return b.ToString();
  }

  int changed=rows.Count(r=>r.Changed),restored=rows.Count(r=>r.Restored),attempted=rows.Count(r=>r.Attempted);
  var broken=rows.Where(r=>r.Attempted&&r.Changed&&!r.Restored).ToList();
  var silent=rows.Where(r=>r.Attempted&&!r.Changed).ToList();

  b.AppendLine("RESUMO").AppendLine(new String('-',78));
  b.AppendLine("Opções testadas:                      "+attempted);
  b.AppendLine("Mudaram o Windows de verdade:         "+changed);
  b.AppendLine("Voltaram exatamente ao estado original:"+restored);
  b.AppendLine("Aplicaram mas NÃO voltaram:           "+broken.Count+(broken.Count>0?"   <-- PRECISA DE ATENÇÃO":""));
  b.AppendLine("Não mudaram nada ao aplicar:          "+silent.Count).AppendLine();

  if(broken.Count>0){
   b.AppendLine("ESTAS NÃO VOLTARAM AO ORIGINAL — corrija antes de usar:").AppendLine(new String('-',78));
   foreach(var row in broken){
    b.AppendLine("· "+row.Name+"  ["+row.Id+"]");
    b.AppendLine("   Antes:   "+row.Before);
    b.AppendLine("   Depois:  "+row.AfterApply);
    b.AppendLine("   Desfeito:"+row.AfterUndo);
    if(!String.IsNullOrEmpty(row.Detail))b.AppendLine("   "+row.Detail);
   }
   b.AppendLine();
  }
  if(silent.Count>0){
   b.AppendLine("ESTAS NÃO MUDARAM NADA AO APLICAR:").AppendLine(new String('-',78));
   b.AppendLine("Pode ser legítimo — o valor já estava no alvo, o Windows recusou a gravação,");
   b.AppendLine("ou a chave não existe nesta build. O motivo de cada uma está abaixo.").AppendLine();
   foreach(var row in silent){
    b.AppendLine("· "+row.Name+"  ["+row.Id+"]");
    b.AppendLine("   Antes:  "+row.Before);
    b.AppendLine("   Depois: "+row.AfterApply);
    if(!String.IsNullOrEmpty(row.Detail))b.AppendLine("   "+row.Detail);
   }
   b.AppendLine();
  }

  b.AppendLine("DETALHE, OPÇÃO POR OPÇÃO").AppendLine(new String('=',78)).AppendLine();
  string group=null;
  foreach(var row in rows){
   if(row.Group!=group){group=row.Group;b.AppendLine().AppendLine("### "+group).AppendLine();}
   b.AppendLine(Mark(row)+" "+row.Name);
   b.AppendLine("    id: "+row.Id);
   b.AppendLine("    antes ........ "+row.Before);
   if(row.Attempted){
    b.AppendLine("    ao aplicar ... "+row.AfterApply+"   "+(row.Changed?"MUDOU":"não mudou"));
    b.AppendLine("    ao desfazer .. "+row.AfterUndo+"   "+(row.Restored?"voltou ao original":"NÃO voltou"));
   }
   if(!String.IsNullOrEmpty(row.Detail))b.AppendLine("    "+row.Detail);
   b.AppendLine();
  }
  b.AppendLine(new String('=',78));
  b.AppendLine("O que este relatório NÃO diz: se a mudança melhora o desempenho. Ele prova");
  b.AppendLine("que o valor foi gravado no Windows e que voltou ao original — nada além disso.");
  return b.ToString();
 }
 static string Mark(SelfCheckRow row){
  if(!row.Attempted)return "[ -- ]";
  if(row.Changed&&row.Restored)return "[ OK ]";
  if(row.Changed&&!row.Restored)return "[FALHA]";
  return "[ ?? ]";
 }
 static string Indent(string text){
  if(String.IsNullOrEmpty(text))return "        (nada a ler)";
  return "        "+text.Replace(" | ","\r\n        ");
 }
}

public partial class MainForm {
 // Texto do aviso antes da conferência completa. Ela ALTERA o Windows de verdade, uma
 // opção por vez, e desfaz cada uma logo depois — a pessoa tem de saber disso antes.
 internal static string SelfCheckWarning(int count){
  var b=new StringBuilder();
  b.AppendLine("Esta conferência responde: quando o aplicativo aplica uma opção, o Windows MUDA MESMO?").AppendLine();
  b.AppendLine("Para responder de verdade, ela precisa alterar seu Windows. O que vai acontecer, para cada uma das "+count+" opções, uma de cada vez:").AppendLine();
  b.AppendLine("   1. lê o valor atual");
  b.AppendLine("   2. APLICA a opção (alteração real, com backup, pelo mesmo caminho do botão Aplicar)");
  b.AppendLine("   3. lê de novo e compara — foi isso que mudou?");
  b.AppendLine("   4. DESFAZ imediatamente");
  b.AppendLine("   5. lê mais uma vez — voltou exatamente ao que era?").AppendLine();
  b.AppendLine("Ao final, cada opção terá sido aplicada e desfeita. A intenção é que seu Windows termine exatamente como começou — e o relatório diz, opção por opção, se isso aconteceu.").AppendLine();
  b.AppendLine("FICAM DE FORA, por não terem volta exata e imediata: plano de energia, serviços, remoção de aplicativos, reparos de rede e qualquer ação que exija reiniciar.").AppendLine();
  b.AppendLine("Se alguma não voltar sozinha, o relatório mostra o valor original para você repor pelo Histórico. Feche jogos e trabalho aberto antes.").AppendLine();
  b.AppendLine("Requer administrador. Pode demorar alguns minutos.").AppendLine();
  b.AppendLine("Começar?");
  return b.ToString();
 }

 async System.Threading.Tasks.Task RunSelfCheck(bool full){
  if(busy||scanning||resourceScanning||easyRunning||productRunning)return;
  if(!full){
   if(!await InlineReview("Conferir estado atual",
    "Lê o estado atual de cada opção neste Windows e monta um relatório.\r\n\r\nNada é alterado: é só leitura.\r\n\r\nO relatório fica no Histórico e pode ser exportado.\r\n\r\nContinuar?",true))return;
   await Elevated("--self-check",SelfCheck.ReadOnly);
   ShowPage("Histórico");
   return;
  }
  if(!await InlineReview("Provar que aplicar funciona",SelfCheckWarning(SelfCheck.Candidates().Count),true))return;
  if(await Elevated("--self-check",SelfCheck.Full))ShowPage("Histórico");
 }
}

static partial class App {
 // Executa a conferência. payload: "leitura" (não altera nada) ou "completo".
 internal static Record RunSelfCheck(string payload,CancellationToken token){
  string mode=payload==SelfCheck.Full?SelfCheck.Full:SelfCheck.ReadOnly;
  var record=NewRecord("Conferência real das opções ("+mode+")","self-check","Diagnóstico");
  record.RequestedAdmin=mode==SelfCheck.Full;
  Save(record);
  var rows=new List<SelfCheckRow>();
  var machine=ScanHardware();
  try{
   var candidates=SelfCheck.Candidates();
   int done=0;
   foreach(var item in candidates){
    if(token.IsCancellationRequested)break;
    WriteProgress(candidates.Count==0?100:done*100/candidates.Count,"Conferindo opções",
     (done+1)+" / "+candidates.Count+" · "+item.ReviewTitle);
    done++;
    var row=new SelfCheckRow{Id=item.Id,Name=item.ReviewTitle,Group=item.Category};
    rows.Add(row);
    string why=Compatibility(item,machine);
    row.Before=SelfCheck.Snapshot(item);
    if(why!=null){row.Outcome="não compatível";row.Detail=why;continue;}
    var observed=Observe(item,machine);
    row.Outcome=observed.State;
    if(mode!=SelfCheck.Full)continue;
    if(observed.Verified){
     row.Detail="Já estava no valor que a opção grava; aplicar não teria o que mudar. Não foi alterada.";
     continue;
    }
    // ------------------------------------------------ aplica pelo caminho real
    try{
     ApplyTransaction(new[]{item},"Nativo",item.ReviewTitle);
     var applied=History().FirstOrDefault(CanUndo);
     row.AfterApply=SelfCheck.Snapshot(item);
     row.Attempted=true;
     row.Changed=row.AfterApply!=row.Before;
     if(applied==null){row.Detail="A aplicação não deixou backup restaurável; desfazer indisponível.";continue;}
     // ------------------------------------------------ desfaz pelo caminho real
     try{
      Undo(applied.Id);
      row.Undone=true;
      row.AfterUndo=SelfCheck.Snapshot(item);
      row.Restored=row.AfterUndo==row.Before;
      if(!row.Restored)row.Detail="O valor depois de desfazer não bate com o original.";
     }catch(Exception e){
      row.AfterUndo=SelfCheck.Snapshot(item);
      row.Restored=row.AfterUndo==row.Before;
      row.Detail="Desfazer falhou: "+e.Message;
     }
    }catch(Exception e){
     row.AfterApply=SelfCheck.Snapshot(item);
     row.Attempted=true;
     row.Changed=row.AfterApply!=row.Before;
     row.Detail="Aplicar falhou: "+e.Message;
    }
   }
   record.Status="consulta concluída";
   record.OutcomeCode=rows.Any(r=>r.Attempted&&r.Changed&&!r.Restored)?"RESTORE_FAILED":"OK";
  }catch(Exception e){
   record.Status="leitura indisponível";
   record.OutcomeCode=ErrorHelp.For(e).ErrorCode;
   record.Message=ErrorHelp.For(e).FriendlyError+"\r\n"+e;
   Save(record);return record;
  }
  string report=SelfCheck.Report(rows,mode,
   "Windows "+machine.Build+" · "+machine.Edition+" · "+machine.Cpu);
  record.Message=report;
  foreach(var row in rows)record.Steps.Add(new StepResult{Id=row.Id,Name=row.Name,
   Status=row.Attempted?(row.Changed&&row.Restored?"mudou e voltou":row.Changed?"mudou e NÃO voltou":"não mudou"):row.Outcome,
   Message="antes: "+row.Before+"\r\ndepois: "+row.AfterApply+"\r\ndesfeito: "+row.AfterUndo+"\r\n"+row.Detail});
  WriteProgress(100,record.Status,"Conferência concluída");
  Save(record);return record;
 }
}

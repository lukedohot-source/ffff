using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
public class ImportedOption {public string Id,Title,Category,Effect,Tradeoff,Source;public int Minimum,Maximum;public RegOp[] Operations;}
static class ImportedOptions {
 static readonly Lazy<List<ImportedOption>> CachedRules=new Lazy<List<ImportedOption>>(()=>ReadRules());
 internal static List<ImportedOption> Rules(){return CachedRules.Value;}
 static List<ImportedOption> ReadRules(){using(var s=Assembly.GetExecutingAssembly().GetManifestResourceStream("optimizer-options.json"))using(var r=new StreamReader(s))return App.Json.Deserialize<List<ImportedOption>>(r.ReadToEnd());}
 internal static List<Item> Items(){return Rules().Select(r=>new Item{Id=r.Id,Name=r.Title,ReviewTitle=r.Title,Category="-4 - "+r.Category,Path="Opções importadas / "+r.Title,Mode="Nativo",Type="Nativo",Native=true,ActionCode="importregistry",Available=true,ManualAllowed=true,MaxEligible=false,DefaultSelected=false,ReviewLevel=r.Operations.Any(App.IsPolicy)?"Manual":"Adaptado",Review=new[]{r.Effect,r.Tradeoff},Notes=new string[0],Conflicts=new string[0],SameTargets=new string[0],Operations=r.Operations,Asset="",Hash="",Text="",Url=r.Source,Blocked=""}).ToList();}
 internal static List<PerformanceEntry> LibraryEntries(){return Rules().Select(r=>new PerformanceEntry{Id=r.Id,Target=r.Id,Title=r.Title,Category=r.Category,Mode=r.Operations.Any(App.IsPolicy)?"Manual":"Opcional com backup",Action="native",Effect=r.Effect,Tradeoff=r.Tradeoff,Steps="Marque apenas se quiser esse efeito. Confira antes/solicitado/depois no Histórico. Ajustes importados não entram em Selecionar básicos.",Source=r.Source}).ToList();}
 internal static string Compatibility(Item item,Machine m){
  if(item.ActionCode!="importregistry")return null;var rule=Rules().SingleOrDefault(r=>r.Id==item.Id);if(rule==null)return "Opção importada não reconhecida.";
  if(m.Build<rule.Minimum||m.Build>rule.Maximum)return "Não disponível nesta versão do Windows.";
  foreach(var op in item.Operations){
   if(op.Key.StartsWith(@"SYSTEM\CurrentControlSet\Services\",StringComparison.OrdinalIgnoreCase)&&op.Name=="Start"){
    var state=App.Capture(op).Before;if(state.Delete)return "Serviço não instalado; nenhuma entrada será criada: "+op.Key.Split(new[]{'\\'}).Last();
   }
  }
  return null;
 }
}

using System;
using System.Collections.Generic;

static class V5InputItems {
 internal static Item Make(string code,string name,string effect,string url){return new Item{
  Id="v5-native-"+code,Name=name,ReviewTitle=name,Category="-2 - Entrada e preferências",Path="Implementação nativa / "+name,
  Mode="Nativo",Type="Nativo",Native=true,ActionCode="v5-"+code,Available=true,ManualAllowed=true,MaxEligible=false,DefaultSelected=false,
  Notes=new string[0],Operations=new RegOp[0],ReviewLevel="Revisado",Review=new[]{effect},Conflicts=new string[0],SameTargets=new string[0],Asset="",Hash="",Text="",Url=url,Blocked=""};}
 internal static List<Item> Create(){return new List<Item>{
  Make("keyrepeat","Repetição rápida do teclado","Configura atraso de repetição em 0 (aproximadamente 250 ms) e velocidade em 31 (aproximadamente 30 repetições/s). Muda a digitação ao segurar a tecla; não reduz o atraso físico do primeiro toque ou de Raw Input.","https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-systemparametersinfow"),
  Make("filter","Desativar Teclas de Filtro","Desliga apenas o bit FilterKeysOn pela API. Preserva tempos e demais flags no backup. Útil se esse recurso estiver aceitando ou repetindo teclas de forma indesejada; afeta quem depende de filtros de acessibilidade.","https://learn.microsoft.com/en-us/windows/win32/api/winuser/ns-winuser-filterkeys"),
  Make("sticky","Desativar atalho de cinco Shift","Retira apenas a ativação por atalho de StickyKeys. Preserva o estado atual das Teclas de Aderência e outras preferências. Evita acionar o recurso por engano durante um jogo; não aumenta FPS.","https://learn.microsoft.com/en-us/windows/win32/api/winuser/ns-winuser-stickykeys")
 };}
}

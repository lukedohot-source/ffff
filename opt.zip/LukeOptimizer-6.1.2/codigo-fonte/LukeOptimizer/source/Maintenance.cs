﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;

public class TempCandidate {public string Path {get;set;} public long Bytes {get;set;} public long Modified {get;set;} public long Created {get;set;}}
public class TempScan {public List<TempCandidate> Files=new List<TempCandidate>();public int Skipped;public bool Truncated;public string Root;}
static class TempCleaner {
 internal static string Root {get{return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Temp");}}
 internal static bool AllowedExtension(string path){return !String.IsNullOrEmpty(Path.GetFileName(path));}
 internal static bool OldEnough(DateTime written,DateTime created,DateTime accessed,DateTime now) {
  var cutoff=now.AddDays(-7);return written<cutoff&&created<cutoff&&accessed<cutoff;
 }
 // Root is fixed by the app, not by TEMP or a path pasted by the user. Follow no junctions/symlinks.
 internal static bool SafePath(string path,string root) {
  try {
   string basePath=Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar),full=Path.GetFullPath(path);
   if(basePath==Path.GetPathRoot(basePath).TrimEnd(Path.DirectorySeparatorChar)||!ResourceMonitor.Within(full,basePath)||String.Equals(full,basePath,StringComparison.OrdinalIgnoreCase))return false;
   for(string current=full;!String.IsNullOrEmpty(current);current=Path.GetDirectoryName(current)) {
    if((File.GetAttributes(current)&FileAttributes.ReparsePoint)!=0)return false;
    if(String.Equals(current,basePath,StringComparison.OrdinalIgnoreCase))return true;
   }
  }catch{}return false;
 }
 internal static TempScan Scan() {
  var result=new TempScan {Root=Root};if(!App.IsWindows||!Directory.Exists(Root))return result;
  var directories=new List<Tuple<string,int>>{Tuple.Create(Root,0)};int nextDirectory=0;var clock=Stopwatch.StartNew();int visited=0;
  while(nextDirectory<directories.Count) {
   if(clock.Elapsed.TotalSeconds>10||visited>=10000||result.Files.Count>=2000){result.Truncated=true;break;}
   var item=directories[nextDirectory++];
   try {
    foreach(string path in Directory.EnumerateFileSystemEntries(item.Item1)) {
     if(++visited>10000||result.Files.Count>=2000||clock.Elapsed.TotalSeconds>10){result.Truncated=true;break;}
     if(!SafePath(path,Root)){result.Skipped++;continue;}
    if(Directory.Exists(path)){if(item.Item2<4)directories.Add(Tuple.Create(path,item.Item2+1));else result.Skipped++;continue;}
     if(!AllowedExtension(path)){result.Skipped++;continue;}
     var file=new FileInfo(path);if((file.Attributes&(FileAttributes.ReadOnly|FileAttributes.System|FileAttributes.Hidden))!=0||!OldEnough(file.LastWriteTimeUtc,file.CreationTimeUtc,file.LastAccessTimeUtc,DateTime.UtcNow)){result.Skipped++;continue;}
     result.Files.Add(new TempCandidate {Path=path,Bytes=file.Length,Modified=file.LastWriteTimeUtc.Ticks,Created=file.CreationTimeUtc.Ticks});
    }
   }catch{result.Skipped++;}
  }
  return result;
 }
 internal static List<StepResult> DeleteReviewed(TempScan scan) {
  if(!App.IsWindows||scan==null||!String.Equals(scan.Root,Root,StringComparison.OrdinalIgnoreCase)||scan.Files.Count>2000)throw new Exception("Análise de temporários inválida.");
  var results=new List<StepResult>();
  foreach(var c in scan.Files) {
   var step=new StepResult {Id=c.Path,Name=Path.GetFileName(c.Path),Status="ignorado",Message=""};results.Add(step);
   try {
    if(!AllowedExtension(c.Path)||!SafePath(c.Path,Root)){step.Message="Fora do escopo ou link simbólico/junção.";continue;}
    var f=new FileInfo(c.Path);
    if(!f.Exists||f.Length!=c.Bytes||f.LastWriteTimeUtc.Ticks!=c.Modified||f.CreationTimeUtc.Ticks!=c.Created||
     (f.Attributes&(FileAttributes.ReadOnly|FileAttributes.System|FileAttributes.Hidden))!=0||!OldEnough(f.LastWriteTimeUtc,f.CreationTimeUtc,f.LastAccessTimeUtc,DateTime.UtcNow)){step.Message="Arquivo mudou, é recente ou está protegido.";continue;}
    StorageManager.DeleteLocked(new CleanupFile{Path=c.Path,Bytes=c.Bytes,Modified=c.Modified,Created=c.Created},Root);
    step.Status="removido";step.Message=c.Bytes+" bytes lógicos removidos permanentemente. "+c.Path;
   }catch(Exception e){step.Message="Em uso, inacessível ou mudou: "+e.Message;}
  }
  return results;
 }
}
static partial class App {
 internal static Record CleanTemps(TempScan scan) {
  var r=NewRecord("Limpeza de temporários revisados (> 7 dias)","temp-v3","Limpeza");Save(r);
  try {r.Status="executando";Save(r);r.Steps=TempCleaner.DeleteReviewed(scan);int count=r.Steps.Count(s=>s.Status=="removido");
   r.Status=r.Steps.Any(s=>s.Status!="removido")?"concluído com avisos":"concluído";
   r.Message=count+" arquivo(s) removido(s) permanentemente. "+(r.Steps.Count-count)+" ignorado(s). Não há desfazer. Downloads, documentos, cache de shaders, Prefetch e backups de projetos não foram selecionados.";Save(r);return r;
  }catch(Exception e){r.Status="falhou";r.Message=e.Message;Save(r);throw;}
 }
 internal static Record SaveComparison(ResourceSample before,ResourceSample after,string actions) {
  var r=NewRecord("Resultado da otimização fácil","easy-v3","Medição");r.BeforeSample=before;r.AfterSample=after;r.Status="medido";
  r.Message=actions+"\r\n\r\n"+ResourceMonitor.Compare(before,after);Save(r);return r;
 }
}

﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Threading;
using Microsoft.Win32.SafeHandles;

public class CleanupCategory {
 public string Id {get;set;} public string Name {get;set;} public string Root {get;set;} public string Pattern {get;set;}
 public string Warning {get;set;} public bool Administrator {get;set;}
}
public class CleanupFile {
 public string CategoryId {get;set;} public string Path {get;set;} public long Bytes {get;set;}
 public long Modified {get;set;} public long Created {get;set;}
}
public class CleanupPreview {
 public List<CleanupFile> Files {get;set;} public List<string> Notes {get;set;}
 public int AgeDays {get;set;} public string Time {get;set;} public bool Truncated {get;set;}
 public CleanupPreview(){Files=new List<CleanupFile>();Notes=new List<string>();}
}
static class StorageManager {
 #if TESTS
 internal static Func<List<CleanupCategory>> TestCategories;
#endif
 internal static List<CleanupCategory> Categories(){
#if TESTS
 if(TestCategories!=null)return TestCategories();
#endif
  string local=Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),windows=Environment.GetFolderPath(Environment.SpecialFolder.Windows);
  return new List<CleanupCategory>{
   new CleanupCategory{Id="user-temp",Name="Temporários do usuário (.tmp / .temp)",Root=Path.Combine(local,"Temp"),Pattern="temp",Warning="Arquivos com idade mínima. Outras extensões ficam preservadas."},
   new CleanupCategory{Id="windows-temp",Name="Temporários do Windows (.tmp / .temp)",Root=Path.Combine(windows,"Temp"),Pattern="temp",Administrator=true,Warning="Alguns arquivos exigem administrador ou estão em uso."},
   new CleanupCategory{Id="dumps",Name="Despejos de falha do usuário",Root=Path.Combine(local,"CrashDumps"),Pattern="*.dmp",Warning="Remove material de diagnóstico. Exporte antes se estiver investigando crashes."},
   new CleanupCategory{Id="wer",Name="Relatórios de falha arquivados",Root=Path.Combine(local,@"Microsoft\Windows\WER\ReportArchive"),Pattern="*",Warning="Apenas relatórios arquivados; a fila de envio permanece intacta."},
   new CleanupCategory{Id="shaders",Name="Cache de shaders DirectX",Root=Path.Combine(local,"D3DSCache"),Pattern="*",Warning="Pode causar stutter e recompilação no próximo jogo. Seleção individual; não é ganho garantido."},
   new CleanupCategory{Id="thumbnails",Name="Cache de miniaturas",Root=Path.Combine(local,@"Microsoft\Windows\Explorer"),Pattern="thumbcache_*.db",Warning="Miniaturas serão recriadas. Arquivos abertos pelo Explorer serão ignorados."},
   new CleanupCategory{Id="edge-cache",Name="Cache Edge · perfil Default",Root=Path.Combine(local,@"Microsoft\Edge\User Data\Default\Cache\Cache_Data"),Pattern="*",Warning="Feche o navegador. Cookies, senhas, histórico e dados de perfil ficam fora do escopo."},
   new CleanupCategory{Id="chrome-cache",Name="Cache Chrome · perfil Default",Root=Path.Combine(local,@"Google\Chrome\User Data\Default\Cache\Cache_Data"),Pattern="*",Warning="Feche o navegador. Somente o subdiretório de cache do perfil Default."},
   new CleanupCategory{Id="legacy-temp",Name="Temp legado do usuário",Root=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),@"Local Settings\Temp"),Pattern="temp",Warning="Compatibilidade com perfis antigos; somente temporários antigos."},
   new CleanupCategory{Id="systemdrive-temp",Name="Temp na raiz do disco",Root=Path.Combine(Path.GetPathRoot(Environment.SystemDirectory)??"C:\\", "Temp"),Pattern="temp",Warning="Somente arquivos temporários antigos; arquivos em uso e protegidos são preservados."},
   new CleanupCategory{Id="inet-cache",Name="Cache Internet do Windows",Root=Path.Combine(local,@"Microsoft\Windows\INetCache"),Pattern="*",Warning="Cache temporário; cookies e credenciais não fazem parte desta categoria."},
   new CleanupCategory{Id="rdp-cache",Name="Cache RDP",Root=Path.Combine(local,@"Microsoft\Terminal Server Client\Cache"),Pattern="*",Warning="Cache de conexões RDP; não remove credenciais nem configurações."},
   new CleanupCategory{Id="opera-cache",Name="Cache Opera",Root=Path.Combine(local,@"Opera Software\Opera Next\Cache"),Pattern="*",Warning="Feche o Opera. Somente a pasta de cache é analisada."},
   new CleanupCategory{Id="vivaldi-cache",Name="Cache Vivaldi",Root=Path.Combine(local,@"Vivaldi\User Data\Default\Cache"),Pattern="*",Warning="Feche o Vivaldi. Somente a pasta de cache é analisada."}
  };
 }
 internal static bool Matches(string path,string pattern){if(pattern=="temp")return TempCleaner.AllowedExtension(path);return System.Text.RegularExpressions.Regex.IsMatch(Path.GetFileName(path),"^"+System.Text.RegularExpressions.Regex.Escape(pattern).Replace("\\*",".*").Replace("\\?",".")+"$",System.Text.RegularExpressions.RegexOptions.IgnoreCase);}
 internal static CleanupPreview Scan(IEnumerable<string> ids,int age,CancellationToken cancel){
  if(age<0||age>3650)throw new ArgumentException("Idade deve estar entre 0 e 3650 dias.");
  var categories=Categories();var selection=ids.Distinct().Select(id=>categories.Single(c=>c.Id==id)).ToArray();
  var preview=new CleanupPreview{AgeDays=age,Time=DateTime.UtcNow.ToString("o")};var watch=Stopwatch.StartNew();int visited=0;
  foreach(var category in selection){
   if(!Directory.Exists(category.Root)){preview.Notes.Add(category.Name+": caminho ausente; ignorado.");continue;}
   var pending=new List<Tuple<string,int>>{Tuple.Create(category.Root,0)};int pendingIndex=0;
   while(pendingIndex<pending.Count&&!cancel.IsCancellationRequested){
    if(visited>=50000||preview.Files.Count>=10000||watch.Elapsed.TotalSeconds>20){preview.Truncated=true;break;}
    var dir=pending[pendingIndex++];try{foreach(string path in Directory.EnumerateFileSystemEntries(dir.Item1)){
     if(cancel.IsCancellationRequested)break;if(++visited>50000||preview.Files.Count>=10000||watch.Elapsed.TotalSeconds>20){preview.Truncated=true;break;}
     if(!TempCleaner.SafePath(path,category.Root))continue;
     var attr=File.GetAttributes(path);if((attr&FileAttributes.Directory)!=0){if(dir.Item2<8)pending.Add(Tuple.Create(path,dir.Item2+1));else preview.Truncated=true;continue;}
     if((attr&(FileAttributes.ReadOnly|FileAttributes.System|FileAttributes.Hidden))!=0||!Matches(path,category.Pattern))continue;
     var file=new FileInfo(path);var cutoff=DateTime.UtcNow.AddDays(-age);if(file.LastWriteTimeUtc>=cutoff||file.CreationTimeUtc>=cutoff||file.LastAccessTimeUtc>=cutoff)continue;
     preview.Files.Add(new CleanupFile{CategoryId=category.Id,Path=path,Bytes=file.Length,Modified=file.LastWriteTimeUtc.Ticks,Created=file.CreationTimeUtc.Ticks});
    }}catch(Exception e){preview.Notes.Add(category.Name+": "+ErrorHelp.For(e).FriendlyError+" "+e.Message);}
   }if(preview.Truncated)break;
  }
  if(cancel.IsCancellationRequested)preview.Notes.Add("Análise cancelada. A prévia contém somente os arquivos já examinados.");
  return preview;
 }
 [StructLayout(LayoutKind.Sequential)] struct FileInformation {public uint Attributes;public System.Runtime.InteropServices.ComTypes.FILETIME Created,Accessed,Written;public uint Volume,SizeHigh,SizeLow,Links,IndexHigh,IndexLow;}
 [StructLayout(LayoutKind.Sequential)] struct Disposition {public byte Delete;}
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern SafeFileHandle CreateFile(string path,uint access,uint sharing,IntPtr security,uint creation,uint flags,IntPtr template);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetFileInformationByHandle(SafeFileHandle handle,out FileInformation info);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool SetFileInformationByHandle(SafeFileHandle handle,int kind,ref Disposition data,uint size);
 static long Ticks(System.Runtime.InteropServices.ComTypes.FILETIME t){return DateTime.FromFileTimeUtc(((long)(uint)t.dwHighDateTime<<32)|(uint)t.dwLowDateTime).Ticks;}
 // Keep every parent directory open without FILE_SHARE_DELETE while validating/deleting.
 // The final file is opened with DELETE access, no sharing and OPEN_REPARSE_POINT.
 internal static void DeleteLocked(CleanupFile file,string root){
  if(!TempCleaner.SafePath(file.Path,root))throw new IOException("Caminho alterado ou link simbólico/junção.");
  var guards=new List<SafeFileHandle>();try{
   string parent=Path.GetDirectoryName(Path.GetFullPath(file.Path));while(!String.IsNullOrEmpty(parent)){
    var guard=CreateFile(parent,0,3,IntPtr.Zero,3,0x02000000|0x00200000,IntPtr.Zero);if(guard.IsInvalid){guard.Dispose();throw new Win32Exception(Marshal.GetLastWin32Error());}guards.Add(guard);
    FileInformation info;if(!GetFileInformationByHandle(guard,out info))throw new Win32Exception(Marshal.GetLastWin32Error());if((info.Attributes&0x400)!=0)throw new IOException("Junção ou link simbólico no caminho.");parent=Path.GetDirectoryName(parent);
   }
   using(var handle=CreateFile(file.Path,0x10000|0x80,0,IntPtr.Zero,3,0x00200000,IntPtr.Zero)){
    if(handle.IsInvalid)throw new Win32Exception(Marshal.GetLastWin32Error());FileInformation current;if(!GetFileInformationByHandle(handle,out current))throw new Win32Exception(Marshal.GetLastWin32Error());
    long length=((long)current.SizeHigh<<32)|current.SizeLow;
    if(length!=file.Bytes||Ticks(current.Created)!=file.Created||Ticks(current.Written)!=file.Modified||(current.Attributes&(0x400|0x10|1|4))!=0||current.Links!=1)throw new IOException("Arquivo mudou, está protegido ou possui hard links. Analise novamente.");
    var disposition=new Disposition{Delete=1};if(!SetFileInformationByHandle(handle,4,ref disposition,1))throw new Win32Exception(Marshal.GetLastWin32Error());
   }
  }finally{foreach(var guard in guards)guard.Dispose();}
 }
 internal static ExecutionReport Execute(CleanupPreview preview,bool simulation,CancellationToken cancel,Action<int,int> progress){
  DateTime created;if(preview==null||!DateTime.TryParse(preview.Time,null,System.Globalization.DateTimeStyles.RoundtripKind,out created)||DateTime.UtcNow-created>TimeSpan.FromMinutes(15)||created>DateTime.UtcNow.AddMinutes(1)||preview.Files.Count>10000||preview.AgeDays<1)throw new ArgumentException("Prévia ausente, inválida ou com mais de 15 minutos. Analise novamente.");
  var report=new ExecutionReport{Schema=1,Id=Guid.NewGuid().ToString("N"),Mode=simulation?"simulação de limpeza":"exclusão permanente",Version=App.Version,Started=DateTime.UtcNow.ToString("o"),Platform=PlatformSnapshot.Read(),Actions=new List<ActionOutcome>(),Total=preview.Files.Count};
  var categories=Categories();var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
  foreach(var file in preview.Files){if(cancel.IsCancellationRequested){report.Cancelled=true;break;}
   var result=new ActionOutcome{Id=file.Path,Name=Path.GetFileName(file.Path),Category="Armazenamento",State="ignorada",ErrorCode="FILE_CHANGED",CanUndo=false};report.Actions.Add(result);
   try{
    var category=categories.Single(c=>c.Id==file.CategoryId);result.AdministratorRequired=category.Administrator;result.AdministratorUsed=report.Platform.Administrator;
    if(!File.Exists(file.Path))throw new FileNotFoundException("Arquivo da prévia não existe mais.",file.Path);
    if(!seen.Add(Path.GetFullPath(file.Path))||!TempCleaner.SafePath(file.Path,category.Root)||!Matches(file.Path,category.Pattern))throw new ArgumentException("Arquivo fora do escopo ou duplicado.");
    var actual=new FileInfo(file.Path);if(!actual.Exists||actual.Length!=file.Bytes||actual.LastWriteTimeUtc.Ticks!=file.Modified||actual.CreationTimeUtc.Ticks!=file.Created||actual.LastWriteTimeUtc>=DateTime.UtcNow.AddDays(-preview.AgeDays)||actual.CreationTimeUtc>=DateTime.UtcNow.AddDays(-preview.AgeDays)||actual.LastAccessTimeUtc>=DateTime.UtcNow.AddDays(-preview.AgeDays))throw new IOException("Arquivo mudou ou é recente. Analise novamente.");
    if(simulation){using(var handle=new FileStream(file.Path,FileMode.Open,FileAccess.Read,FileShare.None)){if(handle.Length!=file.Bytes)throw new IOException("Arquivo mudou.");}result.State="não executada";result.ErrorCode="SIMULATION";result.Description="Arquivo elegível na prévia; nenhuma exclusão realizada.";}
    else{ExecutionHub.Log(report.Id,"Preparando exclusão permanente: "+App.Json.Serialize(file));DeleteLocked(file,category.Root);result.State="aplicada";result.ErrorCode="OK";result.Description=file.Bytes+" bytes lógicos removidos permanentemente. Sem desfazer.";}
    result.Technical=file.Path+" · "+file.Bytes+" bytes";result.Log=result.Technical;
   }catch(Exception e){var error=ErrorHelp.For(e);result.State=error.ErrorCode=="FILE_LOCKED"||error.ErrorCode=="PATH_MISSING"?"ignorada":error.State;result.ErrorCode=error.ErrorCode;result.FriendlyError=error.FriendlyError;result.Technical=error.Technical;result.Log=error.Log;}
   ExecutionHub.Log(report.Id,App.Json.Serialize(result));report.Completed++;if(progress!=null)progress(report.Completed,report.Total);
  }report.Finished=DateTime.UtcNow.ToString("o");return report;
 }
}

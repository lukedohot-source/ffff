﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

public class ControlledRequest {
 public string Id {get;set;} public string UserSid {get;set;} public string Created {get;set;}
 public string[] ItemIds {get;set;} public bool Simulation {get;set;} public bool Confirmed {get;set;}
 public bool AdvancedConfirmed {get;set;} public int TimeoutSeconds {get;set;}
}
static class ExecutionControl {
 internal static string RequestRoot {get{return Path.Combine(App.DataRoot,"fila");}}
 internal static string PathFor(string id,string extension){Guid guid;if(!Guid.TryParseExact(id,"N",out guid))throw new ArgumentException("Identificador de execução inválido.");return Path.Combine(RequestRoot,id+extension);}
 internal static ControlledRequest Create(string[] ids,bool simulation,bool advanced){var request=new ControlledRequest{Id=Guid.NewGuid().ToString("N"),UserSid=App.Sid,Created=DateTime.UtcNow.ToString("o"),ItemIds=ids,Simulation=simulation,Confirmed=true,AdvancedConfirmed=advanced,TimeoutSeconds=900};Validate(request);Directory.CreateDirectory(RequestRoot);AtomicStore.Write(PathFor(request.Id,".json"),App.Json.Serialize(request));return request;}
 internal static void Validate(ControlledRequest request){
  DateTime time;if(request==null||request.UserSid!=App.Sid||!DateTime.TryParse(request.Created,null,System.Globalization.DateTimeStyles.RoundtripKind,out time)||DateTime.UtcNow-time>TimeSpan.FromMinutes(10)||time>DateTime.UtcNow.AddMinutes(1)||request.ItemIds==null||request.ItemIds.Length==0||request.ItemIds.Length>200||request.TimeoutSeconds<10||request.TimeoutSeconds>3600)throw new ArgumentException("Solicitação ausente, expirada ou de outra conta.");
  PathFor(request.Id,".json");var chosen=LiquidProtocol.Resolve(String.Join(",",request.ItemIds));App.UniqueOperations(chosen);
  if(!request.Simulation&&!request.Confirmed)throw new ArgumentException("A aplicação exige confirmação explícita.");
  if(!request.Simulation&&!request.AdvancedConfirmed&&chosen.Any(i=>OptionInfo.For(i).Risk=="Alto"||OptionInfo.For(i).Classification=="Manual"))throw new ArgumentException("Opções de alto risco ou políticas exigem confirmação avançada.");
 }
 internal static ControlledRequest Read(string id){var request=App.Json.Deserialize<ControlledRequest>(AtomicStore.Read(PathFor(id,".json")));if(request.Id!=id)throw new ArgumentException("Solicitação inconsistente.");Validate(request);return request;}
 internal static bool NeedsAdmin(string id){var request=Read(id);return !request.Simulation&&LiquidProtocol.NeedsAdmin(LiquidProtocol.Resolve(String.Join(",",request.ItemIds)));}
 internal static int LastExitCode;
 internal static string CurrentId;static DateTime deadline;
#if TESTS
 internal static Func<bool> TestCancelled;
#endif
 internal static bool Cancelled {
  get{
#if TESTS
   if(TestCancelled!=null)return TestCancelled();
#endif
   return CurrentId!=null&&(DateTime.UtcNow>=deadline||File.Exists(PathFor(CurrentId,".cancel")));
  }
 }
 internal static void Cancel(string id){Directory.CreateDirectory(RequestRoot);AtomicStore.Write(PathFor(id,".cancel"),DateTime.UtcNow.ToString("o"));}
 internal static void Run(string id){var request=Read(id);CurrentId=id;deadline=DateTime.UtcNow.AddSeconds(request.TimeoutSeconds);try{
  if(File.Exists(PathFor(id,".used")))throw new InvalidOperationException("Esta solicitação já foi iniciada. Crie uma nova seleção; não repita uma operação sem revisar o resultado anterior.");
  AtomicStore.Write(PathFor(id,".used"),DateTime.UtcNow.ToString("o"));
  if(request.Simulation){var report=ExecutionHub.Simulate(request.ItemIds,System.Threading.CancellationToken.None,null);ExecutionHub.Persist(report);}
  else {App.ApplyIsolated(LiquidProtocol.Resolve(String.Join(",",request.ItemIds)),"Perfil controlado",new string[0],null);var record=App.History().First();LastExitCode=record.ExecutionCancelled||record.Result.Actions.Any(a=>a.State=="falhou"||a.State=="aplicada parcialmente"||a.State=="ignorada")?2:0;}
 }finally{CurrentId=null;}}
}

using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
public class ScriptReview {
 public string Id {get;set;} public string Name {get;set;} public string Status {get;set;}
 public string Integration {get;set;} public string[] Findings {get;set;}
 public string Text {get;set;} public string Hash {get;set;} public long Bytes {get;set;}
 public string[] Sources {get;set;}
}
static class ImportedScripts {
 internal static List<ScriptReview> All=new List<ScriptReview>();
 internal static void Load() {
  using(var s=Assembly.GetExecutingAssembly().GetManifestResourceStream("imported-reviews.json")) {
   if(s==null)throw new Exception("A revisão dos 14 BATs não foi incorporada. Recompile o pacote completo.");
   using(var r=new StreamReader(s))All=App.Json.Deserialize<List<ScriptReview>>(r.ReadToEnd());
  }
  if(All.Count==0||All.Select(r=>r.Id).Distinct().Count()!=All.Count)throw new Exception("Revisão dos BATs incompleta.");
 }
 internal static List<Item> AsCatalogItems() {
  return All.Select(r=>new Item {Id=r.Id,Name=r.Name,ReviewTitle=r.Name,Category="99 - Seus 14 BATs revisados",Path="Originais recebidos / "+r.Name,
   Url=(r.Sources??new string[0]).FirstOrDefault()??"",Type="BAT revisado",Mode="Consulta",Available=true,ManualAllowed=false,Native=false,MaxEligible=false,
   Blocked="Original preservado como texto, sem execução automática.",Text=r.Text,Hash=r.Hash,Bytes=r.Bytes,Asset="",Notes=new string[0],
   ReviewLevel=r.Status,Review=new[]{"NO APP: "+r.Integration}.Concat(r.Findings).ToArray(),Operations=new RegOp[0],Conflicts=new string[0],SameTargets=new string[0]}).ToList();
 }
}

using System;
using System.Linq;
using System.Collections.Generic;
static partial class App {
 internal static string[] CodesFor(Item item){return item.RestoreNative!=null?item.RestoreNative.Select(n=>n.Code).ToArray():NativeSettings.Codes(item.ActionCode);}
 internal static List<Item> RestoreSelectionItems(string payload){
  int separator=payload.IndexOf('|');if(separator<=0)throw new Exception("Selecione o backup e os ajustes para restaurar.");
  string recordId=payload.Substring(0,separator);RecordPath(recordId);
  var record=History().FirstOrDefault(CanUndo);
  if(record==null||record.Id!=recordId||record.UserSid!=Sid)throw new Exception("O backup mudou. Atualize o histórico antes de restaurar a seleção.");
  if(record.Kind!="Perfil"&&record.Kind!="Nativo")throw new Exception("Este tipo de operação precisa ser desfeito por inteiro no Histórico.");
  var chosen=LiquidProtocol.Resolve(payload.Substring(separator+1));
  if(chosen.Any(i=>!(record.ItemIds??new string[0]).Contains(i.Id)))throw new Exception("Marque somente ajustes presentes na última aplicação. Nenhuma configuração foi alterada.");
  var other=Items.Where(i=>(record.ItemIds??new string[0]).Contains(i.Id)&&!chosen.Any(c=>c.Id==i.Id)).ToArray();
  var result=new List<Item>();
  foreach(var item in chosen){
   var values=(record.Values??new List<SavedValue>()).Where(v=>(item.Operations??new RegOp[0]).Any(o=>SameTarget(o,v.After))).ToArray();
   var native=(record.NativeValues??new List<NativeSaved>()).Where(n=>CodesFor(item).Contains(n.Code)).ToArray();
   if(values.Any(v=>other.Any(i=>(i.Operations??new RegOp[0]).Any(o=>SameTarget(o,v.After))))||native.Any(v=>other.Any(i=>CodesFor(i).Contains(v.Code))))throw new Exception("Há um valor compartilhado com outro ajuste da aplicação. Selecione também a alternativa relacionada ou use Desfazer última aplicação.");
   var expected=new List<RegOp>();
   foreach(var v in values){var current=Capture(v.After).Before;if(!Same(current,v.After)&&!Same(current,v.Before))throw new Exception("Mudança posterior detectada em "+v.After.Name+". Estado atual preservado.");expected.Add(current);}
   var restoreNative=new List<NativeSaved>();foreach(var n in native){string current=NativeSettings.Read(n.Code);if(current!=n.Before&&current!=n.After)throw new Exception("Mudança posterior detectada na preferência "+n.Code);restoreNative.Add(new NativeSaved{Code=n.Code,Before=current,After=n.Before});}
   var copy=Json.Deserialize<Item>(Json.Serialize(item));copy.Name=copy.ReviewTitle="Restaurar: "+item.ReviewTitle;copy.ActionCode="restore-selection";copy.Expected=expected.ToArray();copy.Operations=values.Select(v=>v.Before).ToArray();copy.RestoreNative=restoreNative.ToArray();
   if(item.ActionCode=="power"&&!String.IsNullOrEmpty(record.NewPlan)){
    string current=ActivePlan();if(!EqualGuid(current,record.NewPlan)&&!EqualGuid(current,record.PreviousPlan))throw new Exception("O plano foi alterado depois. Estado atual preservado.");copy.ActionCode="power";copy.RestorePlan=record.PreviousPlan;
   }
   result.Add(copy);
  }
  return result;
 }
}

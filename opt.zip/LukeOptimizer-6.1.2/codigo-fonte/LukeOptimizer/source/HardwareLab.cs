using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Management;
using System.Net;
using System.Net.NetworkInformation;
using System.Threading;
using System.Threading.Tasks;

public class NetworkResult {
 public string Host;public int Sent,Received;public double Average,Min,Max,Jitter;public string Error;
 public override string ToString(){return Host+" · recebidos "+Received+"/"+Sent+" · perda "+(Sent==0?0:100.0*(Sent-Received)/Sent).ToString("0.0")+"%\r\n"+
  (Received==0?"Sem resposta ICMP. Isso também pode significar bloqueio de ping.":"RTT médio "+Average.ToString("0.0")+" ms · mínimo "+Min+" ms · máximo "+Max+" ms · variação média entre respostas consecutivas "+Jitter.ToString("0.0")+" ms")+
  "\r\n"+Error+"\r\nPing não mede input lag, bufferbloat sob carga nem a rota de um servidor de jogo diferente.";}
}
static class HardwareLab {
 internal static List<Dictionary<string,object>> Query(string query,string scope=@"\\.\root\cimv2"){
  var rows=new List<Dictionary<string,object>>();
  using(var search=new ManagementObjectSearcher(new ManagementScope(scope),new ObjectQuery(query),new System.Management.EnumerationOptions{Timeout=TimeSpan.FromSeconds(5),ReturnImmediately=true}))
  using(var result=search.Get())foreach(ManagementObject item in result)using(item){var row=new Dictionary<string,object>();foreach(PropertyData p in item.Properties)row[p.Name]=p.Value;rows.Add(row);if(rows.Count>=128)break;}return rows;
 }
 static string Get(Dictionary<string,object> row,string key){object v;return row.TryGetValue(key,out v)&&v!=null?Convert.ToString(v).Trim():"não informado";}
 static double Number(Dictionary<string,object> row,string key){double number;return Double.TryParse(Get(row,key),out number)?number:0;}
 static void Section(StringBuilder b,string title,Action action){b.AppendLine().AppendLine("── "+title+" ──");try{action();}catch(Exception e){b.AppendLine("Leitura indisponível: "+e.Message);}}
 internal static string Report(){
  var b=new StringBuilder("HARDWARE / DIAGNÓSTICO LOCAL · "+DateTime.Now.ToString("g")+"\r\nNenhuma configuração alterada. Leituras WMI podem depender do firmware/driver.\r\n");
  Section(b,"CPU e plataforma",()=>{
   foreach(var r in Query("SELECT Name,NumberOfCores,NumberOfLogicalProcessors,CurrentClockSpeed,MaxClockSpeed FROM Win32_Processor"))b.AppendLine(Get(r,"Name")+" · "+Get(r,"NumberOfCores")+" núcleos / "+Get(r,"NumberOfLogicalProcessors")+" threads · clock informado "+Get(r,"MaxClockSpeed")+" MHz; clock atual reportado: "+Get(r,"CurrentClockSpeed")+" MHz (WMI não é medição de boost por quadro)");
   foreach(var r in Query("SELECT Manufacturer,Product FROM Win32_BaseBoard"))b.AppendLine("Placa-mãe: "+Get(r,"Manufacturer")+" "+Get(r,"Product"));
   foreach(var r in Query("SELECT Manufacturer,SMBIOSBIOSVersion FROM Win32_BIOS"))b.AppendLine("BIOS: "+Get(r,"Manufacturer")+" "+Get(r,"SMBIOSBIOSVersion"));
   b.AppendLine("Temperatura e throttling: não medidos por este app. Use telemetria do fabricante durante o jogo. Diagnóstico não confirma refrigeração, VRM ou potência da fonte.");
  });
  Section(b,"RAM e memória comprometida",()=>{
   var modules=Query("SELECT DeviceLocator,Capacity,ConfiguredClockSpeed,Speed,Manufacturer,PartNumber FROM Win32_PhysicalMemory");
   foreach(var r in modules)b.AppendLine(Get(r,"DeviceLocator")+": "+(Number(r,"Capacity")/1073741824).ToString("0.0")+" GB · taxa SMBIOS configurada "+Get(r,"ConfiguredClockSpeed")+" · nominal "+Get(r,"Speed")+" · "+Get(r,"Manufacturer")+" "+Get(r,"PartNumber"));
   b.AppendLine(modules.Count+" módulo(s) reportado(s). Isso não confirma dual channel, timings nem XMP/EXPO ativo; confira no firmware e no manual da placa.");
   foreach(var r in Query("SELECT AutomaticManagedPagefile FROM Win32_ComputerSystem"))b.AppendLine("Paginação automática: "+Get(r,"AutomaticManagedPagefile"));
   foreach(var r in Query("SELECT AvailableMBytes,CommittedBytes,CommitLimit,PagesInputPersec FROM Win32_PerfFormattedData_PerfOS_Memory")){
    double used=Number(r,"CommittedBytes"),limit=Number(r,"CommitLimit");b.AppendLine("Disponível: "+Get(r,"AvailableMBytes")+" MB · comprometida: "+(used/1073741824).ToString("0.0")+" / "+(limit/1073741824).ToString("0.0")+" GB · páginas lidas/s: "+Get(r,"PagesInputPersec"));
    if(limit>0&&used/limit>.85)b.AppendLine("ATENÇÃO: memória comprometida acima de 85% do limite nesta amostra. Feche apps opcionais e revise paginação/capacidade de RAM.");
   }
  });
  Section(b,"GPU e monitores",()=>{
   foreach(var r in Query("SELECT Name,DriverVersion,CurrentHorizontalResolution,CurrentVerticalResolution,CurrentRefreshRate FROM Win32_VideoController"))b.AppendLine(Get(r,"Name")+" · driver "+Get(r,"DriverVersion")+" · modo WMI "+Get(r,"CurrentHorizontalResolution")+" × "+Get(r,"CurrentVerticalResolution")+" @ "+Get(r,"CurrentRefreshRate")+" Hz");
   b.AppendLine("WMI pode omitir telas ou informar modo indireto. Confira os Hz em Tela avançada. VRAM, uso de GPU e latência física não são inferidos desses campos.");
  });
  Section(b,"Atividade dos motores da GPU (amostra WMI)",()=>{var engines=Query("SELECT Name,UtilizationPercentage FROM Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine").Where(r=>Number(r,"UtilizationPercentage")>0).OrderByDescending(r=>Number(r,"UtilizationPercentage")).Take(12).ToArray();foreach(var r in engines)b.AppendLine(Get(r,"Name")+" · "+Get(r,"UtilizationPercentage")+"%");if(engines.Length==0)b.AppendLine("Nenhum motor ativo retornado nesta amostra; não equivale a GPU indisponível ou 0% durante o jogo.");b.AppendLine("Instâncias podem representar processos e motores diferentes. Os percentuais não são somados como uso global da GPU. Frequência, temperatura e throttling exigem telemetria do fabricante/PresentMon.");});
  Section(b,"Armazenamento",()=>{
   foreach(var d in DriveInfo.GetDrives().Where(d=>d.DriveType==DriveType.Fixed))try{if(!d.IsReady)continue;double free=100.0*d.AvailableFreeSpace/d.TotalSize;b.AppendLine(d.Name+" · "+(d.AvailableFreeSpace/1073741824.0).ToString("0.0")+" GB livres · "+free.ToString("0.0")+"%"+(free<10?" · pouco espaço: revise arquivos e tamanho dos jogos":""));}catch{}
   foreach(var r in Query("SELECT FriendlyName,MediaType,HealthStatus,Size FROM MSFT_PhysicalDisk",@"\\.\root\Microsoft\Windows\Storage")){
    string media=Get(r,"MediaType"),health=Get(r,"HealthStatus");b.AppendLine(Get(r,"FriendlyName")+" · "+(media=="4"?"SSD":media=="3"?"HDD":"tipo não informado")+" · "+(Number(r,"Size")/1073741824).ToString("0")+" GB · saúde "+(health=="0"?"normal":health=="1"?"alerta":health=="2"?"não saudável":health));
   }
   b.AppendLine("Saúde normal não é teste completo de SSD/HDD. Cache de shaders é preservado; apagá-lo pode exigir recompilação e causar engasgos.");
  });
  Section(b,"USB e dispositivos de entrada",()=>{foreach(var r in Query("SELECT Name,PNPDeviceID,Status FROM Win32_PnPEntity WHERE PNPDeviceID LIKE 'USB%' OR PNPDeviceID LIKE 'HID%'"))b.AppendLine(Get(r,"Name")+" · "+Get(r,"Status")+" · "+Get(r,"PNPDeviceID"));b.AppendLine("Inventário somente leitura. Polling rate e latência física não são medidos por WMI; confira a taxa no software do mouse e compare no jogo com Raw Input quando disponível.");});
  Section(b,"Rede",()=>{foreach(var n in NetworkInterface.GetAllNetworkInterfaces().Where(n=>n.OperationalStatus==OperationalStatus.Up)){
   b.AppendLine(n.Name+" · "+n.NetworkInterfaceType+" · link "+(n.Speed/1000000.0).ToString("0")+" Mbps");
   foreach(var gateway in n.GetIPProperties().GatewayAddresses)b.AppendLine("  Gateway: "+gateway.Address);
  }b.AppendLine("Velocidade de link não é velocidade da internet. Use a medição de ping para investigar perda e variação.");});
  Section(b,"Inicialização completa (somente leitura)",()=>{
   foreach(var r in Query("SELECT Name,Command,Location FROM Win32_StartupCommand"))b.AppendLine(Get(r,"Name")+" · "+Get(r,"Location")+"\r\n  "+Get(r,"Command"));
   b.AppendLine("Inclui mais origens que a edição de HKCU em Manutenção. Entradas não classificadas podem ser revisadas nas ferramentas oficiais do Windows.");
  });
  b.AppendLine().AppendLine("PRÓXIMO PASSO: capture o mesmo cenário no PresentMon, altere uma opção, repita e compare em FPS e stutter. Nenhuma leitura isolada identifica todos os gargalos.");return b.ToString();
 }
 internal static string Gateway(){try{return NetworkInterface.GetAllNetworkInterfaces().Where(n=>n.OperationalStatus==OperationalStatus.Up&&n.NetworkInterfaceType!=NetworkInterfaceType.Loopback).SelectMany(n=>n.GetIPProperties().GatewayAddresses).Select(g=>g.Address).First(a=>!a.Equals(IPAddress.Any)&&!a.Equals(IPAddress.IPv6Any)).ToString();}catch{return "";}}
 internal static bool ValidHost(string host){return !String.IsNullOrWhiteSpace(host)&&host.Length<=253&&host==host.Trim()&&Uri.CheckHostName(host)!=UriHostNameType.Unknown&&host.IndexOfAny(new[]{'/','\\',' ','\r','\n','"'})<0;}
 internal static async Task<NetworkResult> PingHost(string host,CancellationToken cancel){
  if(!ValidHost(host))throw new Exception("Informe somente um endereço IP ou nome de host, sem URL/porta.");
  var result=new NetworkResult{Host=host,Error=""};var times=new List<double>();var deltas=new List<double>();double? previous=null;
  using(var ping=new Ping())for(int i=0;i<12;i++){
   cancel.ThrowIfCancellationRequested();result.Sent++;
   try{var reply=await ping.SendPingAsync(host,800);if(reply.Status==IPStatus.Success){times.Add(reply.RoundtripTime);if(previous.HasValue)deltas.Add(Math.Abs(reply.RoundtripTime-previous.Value));previous=reply.RoundtripTime;}else{previous=null;result.Error="Último status sem resposta: "+reply.Status;}}
   catch(PingException e){previous=null;result.Error=e.InnerException==null?e.Message:e.InnerException.Message;}
   await Task.Delay(150,cancel);
  }
  result.Received=times.Count;if(times.Count>0){result.Average=times.Average();result.Min=times.Min();result.Max=times.Max();result.Jitter=deltas.Count>0?deltas.Average():0;}return result;
 }
}

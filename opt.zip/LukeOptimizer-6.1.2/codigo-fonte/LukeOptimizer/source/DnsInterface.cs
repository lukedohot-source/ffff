using System;
using System.Linq;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections.Generic;

// GERENCIADOR DE DNS — a tela.
//
// Linha compacta, não card gigante: rótulo, caixa de escolha, ação. Trocar DNS tem mais
// de dois estados possíveis (doze provedores e um personalizado), então é CAIXA DE
// ESCOLHA, nunca um interruptor por provedor — vários interruptores mutuamente
// exclusivos mentem sobre o que a escolha é.
//
// A tela NÃO monta comando. Ela monta um PEDIDO (provedor + índices numéricos) e o
// valida pelo mesmo caminho que o processo elevado usará. O nome do adaptador, que a
// pessoa pode renomear para qualquer coisa, não atravessa a fronteira de elevação.
public partial class MainForm {
 ComboBox dnsAdapterBox,dnsProviderBox;
 TextBox dnsCustomV4,dnsCustomV6;
 Label dnsStateLabel;
 Button dnsApplyButton;
 List<DnsAdapter> dnsAdapters=new List<DnsAdapter>();
 List<DnsProvider> dnsProviders=new List<DnsProvider>();

 Label FieldLabel(string text,int width){
  var label=Theme.Label(text,10,Theme.Text);
  label.Dock=DockStyle.None;label.Size=new Size(width,30);
  return label;
 }

 void BuildDnsPanel(TableLayoutPanel parent,int row){
  var card=new Surface{Dock=DockStyle.Fill,Padding=new Padding(16,10,16,10),Margin=new Padding(0,12,0,0)};
  parent.Controls.Add(card,0,row);
  var rows=Rows(22,22,34,34,38);card.Controls.Add(rows);

  var title=Theme.Label("Servidores DNS",12,Theme.Text,true);rows.Controls.Add(title,0,0);
  rows.Controls.Add(Theme.Label("Escolhe QUEM resolve os nomes que este PC acessa e para onde vão essas consultas. É escolha de privacidade e confiança — não aumenta a velocidade contratada.",9,Theme.Muted),0,1);

  var pick=ActionRow();rows.Controls.Add(pick,0,2);
  pick.Controls.Add(FieldLabel("Adaptador",82));
  dnsAdapterBox=Combo();dnsAdapterBox.Dock=DockStyle.None;dnsAdapterBox.Width=268;dnsAdapterBox.Name="dns-adapter";
  dnsAdapterBox.SelectedIndexChanged+=(s,e)=>ShowDnsState();
  pick.Controls.Add(dnsAdapterBox);
  pick.Controls.Add(FieldLabel("Servidor",68));
  dnsProviderBox=Combo();dnsProviderBox.Dock=DockStyle.None;dnsProviderBox.Width=282;dnsProviderBox.Name="dns-provider";
  dnsProviderBox.SelectedIndexChanged+=(s,e)=>ShowDnsState();
  pick.Controls.Add(dnsProviderBox);

  var custom=ActionRow();rows.Controls.Add(custom,0,3);
  custom.Controls.Add(FieldLabel("Endereços",82));
  dnsCustomV4=Field();dnsCustomV4.Dock=DockStyle.None;dnsCustomV4.Width=186;dnsCustomV4.Name="dns-custom-v4";dnsCustomV4.MaxLength=45;
  custom.Controls.Add(dnsCustomV4);
  dnsCustomV6=Field();dnsCustomV6.Dock=DockStyle.None;dnsCustomV6.Width=282;dnsCustomV6.Name="dns-custom-v6";dnsCustomV6.MaxLength=45;
  custom.Controls.Add(dnsCustomV6);
  productTips.SetToolTip(dnsCustomV4,"Endereço IPv4, com os quatro números. Exemplo: 9.9.9.9");
  productTips.SetToolTip(dnsCustomV6,"Endereço IPv6, opcional. Exemplo: 2620:fe::fe");

  var actions=ActionRow();rows.Controls.Add(actions,0,4);
  dnsApplyButton=V4Button("Aplicar DNS",async(s,e)=>await ApplyDnsFromUi(),true,150);
  dnsApplyButton.Name="dns-apply";actions.Controls.Add(dnsApplyButton);
  var details=V4Button("Detalhes técnicos",async(s,e)=>await ShowDnsTechnical(),false,168);
  details.Name="dns-details";actions.Controls.Add(details);
  var refresh=V4Button("Reler adaptadores",(s,e)=>RefreshDnsAdapters(),false,176);
  refresh.Name="dns-refresh";actions.Controls.Add(refresh);
  dnsStateLabel=Theme.Label("",9,Theme.Muted);dnsStateLabel.Dock=DockStyle.None;dnsStateLabel.Size=new Size(430,32);
  actions.Controls.Add(dnsStateLabel);

  dnsProviders=DnsManager.Providers();
  foreach(var provider in dnsProviders)dnsProviderBox.Items.Add(provider.Name);
  dnsProviderBox.SelectedIndex=0;
  RefreshDnsAdapters();
 }

 DnsAdapter SelectedDnsAdapter(){
  int index=dnsAdapterBox==null?-1:dnsAdapterBox.SelectedIndex;
  return index>=0&&index<dnsAdapters.Count?dnsAdapters[index]:null;
 }
 DnsProvider SelectedDnsProvider(){
  int index=dnsProviderBox==null?-1:dnsProviderBox.SelectedIndex;
  return index>=0&&index<dnsProviders.Count?dnsProviders[index]:null;
 }

 // Só entram na lista adaptadores com índice de interface: sem índice não há como
 // escrever neles, e oferecer um que não dá para alterar é botão que promete e não cumpre.
 void RefreshDnsAdapters(){
  dnsAdapters=new List<DnsAdapter>();
  try{dnsAdapters=DnsManager.Read().Where(a=>a.V4Known||a.V6Known).ToList();}
  catch(Exception e){if(dnsStateLabel!=null)dnsStateLabel.Text="Não foi possível ler os adaptadores: "+e.Message;}
  dnsAdapterBox.Items.Clear();
  foreach(var adapter in dnsAdapters)
   dnsAdapterBox.Items.Add(adapter.Name+" · "+adapter.Kind+(adapter.Up?"":" · desconectado"));
  if(dnsAdapterBox.Items.Count>0){
   int active=dnsAdapters.FindIndex(a=>a.Up);
   dnsAdapterBox.SelectedIndex=active<0?0:active;
  }
  ShowDnsState();
 }

 void ShowDnsState(){
  if(dnsStateLabel==null)return;
  var adapter=SelectedDnsAdapter();var provider=SelectedDnsProvider();
  bool custom=provider!=null&&provider.Id==DnsManager.Custom;
  if(dnsCustomV4!=null){
   dnsCustomV4.Enabled=custom;dnsCustomV6.Enabled=custom;
   if(!custom){dnsCustomV4.Text="";dnsCustomV6.Text="";}
  }
  if(adapter==null){
   dnsStateLabel.Text="Nenhum adaptador com índice de interface foi encontrado. Sem isso não há como alterar o DNS.";
   if(dnsApplyButton!=null)dnsApplyButton.Enabled=false;
   return;
  }
  dnsStateLabel.Text="DNS atual: "+DnsManager.Describe(adapter)+
   (adapter.Up?"":"   ·   este adaptador está desconectado; a alteração fica gravada e vale quando ele voltar.");
  if(dnsApplyButton!=null)dnsApplyButton.Enabled=ready&&machine.Windows&&!busy&&!scanning&&!resourceScanning&&!easyRunning&&!productRunning;
 }

 async Task ShowDnsTechnical(){
  var adapter=SelectedDnsAdapter();var provider=SelectedDnsProvider();
  if(provider==null)return;
  string text;
  try{
   var plan=adapter==null?new List<string>():DnsManager.Plan(adapter,provider,dnsCustomV4.Text,dnsCustomV6.Text);
   text=DnsManager.Technical(adapter,provider,plan);
  }catch(Exception e){
   text=DnsManager.Technical(adapter,provider,new List<string>())+
    "\r\nNenhum comando pôde ser montado com a escolha atual: "+e.Message;
  }
  await InlineReview("Detalhes técnicos — servidores DNS",text,false);
 }

 async Task ApplyDnsFromUi(){
  if(busy||scanning||resourceScanning||easyRunning||productRunning)return;
  var adapter=SelectedDnsAdapter();var provider=SelectedDnsProvider();
  if(adapter==null||provider==null)return;
  string payload=null;List<string> plan=null;
  // A prévia e o pedido são montados ANTES de qualquer confirmação: um endereço inválido
  // vira recusa explicada aqui, e não erro no meio de uma operação já elevada.
  //
  // O motivo da recusa é GUARDADO e a tela só aparece depois do catch: em C# 5 não se
  // pode esperar (await) dentro de um bloco catch. É o mesmo formato já usado em
  // FunctionalInterface.ApplyManualTuning.
  string problem=null;
  try{
   plan=DnsManager.Plan(adapter,provider,dnsCustomV4.Text,dnsCustomV6.Text);
   payload=DnsManager.PayloadFor(adapter,provider.Id,dnsCustomV4.Text,dnsCustomV6.Text);
  }catch(Exception e){problem=e.Message;}
  if(problem!=null){
   await InlineReview("DNS não alterado",problem+"\r\n\r\nNada foi executado.",false);
   return;
  }
  if(!await InlineReview("Alterar servidores DNS",DnsManager.Confirmation(adapter,provider,plan),true))return;
  if(await Elevated("--dns-apply",payload)){
   RefreshDnsAdapters();
   if(netCenterOutput!=null)netCenterOutput.Text="Servidores DNS alterados no adaptador "+adapter.Name+
    ".\r\nO resultado de cada comando e a conferência posterior estão no Histórico.\r\nPara voltar ao que era, use Desfazer no Histórico — o estado anterior foi gravado antes da mudança.";
  }
 }
}

﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.ComponentModel;
using System.Threading;
using System.Threading.Tasks;
using System.Security.Principal;
using Microsoft.Win32;

// Stable, additive wire contract. Legacy transaction/rollback records remain authoritative.
public class ActionOutcome {
 public string Id {get;set;} public string Name {get;set;} public string Category {get;set;}
 public string State {get;set;} public string Description {get;set;} public string Technical {get;set;}
 public string ErrorCode {get;set;} public string FriendlyError {get;set;} public string Log {get;set;}
 public bool CanUndo {get;set;} public bool AdministratorRequired {get;set;} public bool AdministratorUsed {get;set;}
 public bool RestartSuggested {get;set;} public string BackupId {get;set;}
}
public class ExecutionReport {
 public int Schema {get;set;} public string Id {get;set;} public string Mode {get;set;}
 public string Started {get;set;} public string Finished {get;set;} public string Version {get;set;}
 public PlatformSnapshot Platform {get;set;} public List<ActionOutcome> Actions {get;set;}
 public int Completed {get;set;} public int Total {get;set;} public bool Cancelled {get;set;}
 public string PersistenceError {get;set;}
}
public class PlatformSnapshot {
 public string Windows {get;set;} public string Edition {get;set;} public int Build {get;set;}
 public string Architecture {get;set;} public bool Administrator {get;set;}
 public bool Supported {get;set;} public bool? RestartPending {get;set;} public string DetectionNote {get;set;}
 internal static PlatformSnapshot Read(){
  var p=new PlatformSnapshot{Windows="Não identificado",Edition="Não identificada",Architecture=Environment.GetEnvironmentVariable("PROCESSOR_ARCHITEW6432")??Environment.GetEnvironmentVariable("PROCESSOR_ARCHITECTURE")??"Não identificada"};
  try{using(var identity=WindowsIdentity.GetCurrent())p.Administrator=new WindowsPrincipal(identity).IsInRole(WindowsBuiltInRole.Administrator);
   using(var root=RegistryKey.OpenBaseKey(RegistryHive.LocalMachine,RegistryView.Registry64))
   using(var key=root.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion")){
    if(key!=null){int build;Int32.TryParse(Convert.ToString(key.GetValue("CurrentBuildNumber")),out build);p.Build=build;p.Windows=(build>=22000?"Windows 11":"Windows 10")+" · build "+build+"."+Convert.ToString(key.GetValue("UBR"));p.Edition=Convert.ToString(key.GetValue("EditionID"));}
   }
   p.Supported=SupportedBuild(p.Build,Environment.Is64BitOperatingSystem);
   p.RestartPending=PendingRestart();
  }catch(Exception e){p.DetectionNote=ErrorHelp.For(e).FriendlyError;}
  return p;
 }
 internal static bool SupportedBuild(int build,bool os64){return os64&&build>=10240;}
 internal static bool? PendingRestart(){
  try{using(var root=RegistryKey.OpenBaseKey(RegistryHive.LocalMachine,RegistryView.Registry64)){
   foreach(string path in new[]{@"SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending",@"SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired"})using(var key=root.OpenSubKey(path))if(key!=null)return true;
   using(var key=root.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Session Manager"))if(key!=null&&key.GetValue("PendingFileRenameOperations")!=null)return true;
   return false;
  }}catch{return null;}
 }
}
static class ErrorHelp {
 internal static ActionOutcome For(Exception error){
  while(error is AggregateException&&error.InnerException!=null)error=error.InnerException;
  int code=error is Win32Exception?((Win32Exception)error).NativeErrorCode:error.HResult&65535;
  string id="OPERATION_FAILED",message="A operação não foi concluída. Consulte o detalhe e tente novamente após resolver a causa.";
  if(error is OperationCanceledException||code==1223){id="CANCELLED";message="Operação cancelada. As etapas já concluídas permanecem no histórico e podem ser desfeitas quando indicado.";}
  else if(error is TimeoutException||code==1460){id="TIMEOUT";message="O tempo limite foi atingido. Verifique o estado da operação antes de tentar novamente.";}
  else if(error is UnauthorizedAccessException||code==5){id="ACCESS_DENIED";message="O Windows negou acesso. Use a elevação solicitada; políticas da empresa ou proteção do sistema podem impedir esta ação mesmo como administrador.";}
  else if(code==32||code==33){id="FILE_LOCKED";message="Arquivo em uso. Feche o aplicativo correspondente e analise novamente; ele foi preservado.";}
  else if(error is FileNotFoundException||error is DirectoryNotFoundException||code==2||code==3){id="PATH_MISSING";message="Arquivo ou pasta não encontrado. Atualize a análise; nada deve ser recriado automaticamente para forçar esta ação.";}
  else if(code==1060){id="SERVICE_MISSING";message="Este serviço não existe nesta instalação do Windows. A ação não se aplica.";}
  else if(code==126||code==127){id="COMMAND_MISSING";message="O comando ou recurso não está disponível nesta versão do Windows.";}
  else if(error is System.Net.Sockets.SocketException||code==53||code==1231){id="NETWORK_UNAVAILABLE";message="Não foi possível acessar a rede. Verifique a conexão e tente o diagnóstico novamente.";}
  else if(error is NotSupportedException){id="UNSUPPORTED";message="Recurso incompatível ou não detectado. Consulte as condições de compatibilidade.";}
  else if(error is ArgumentException){id="INVALID_INPUT";message="A seleção contém um valor inválido. Revise as opções antes de continuar.";}
  return new ActionOutcome{State=id=="CANCELLED"?"ignorada":"falhou",ErrorCode=id,FriendlyError=message,Technical=error.ToString(),Log=DateTime.UtcNow.ToString("o")+" "+id+" "+error};
 }
}
static class ExecutionHub {
 static readonly SemaphoreSlim Queue=new SemaphoreSlim(1,1);
 internal static string LogsRoot {get{return Path.Combine(App.DataRoot,"logs");}}
 internal static string ReportsRoot {get{return Path.Combine(App.DataRoot,"relatorios");}}
 static readonly object LogGate=new object();
 internal static ActionOutcome FromRecord(Record r,Item item){
  var steps=r.Steps??new List<StepResult>();var evidence=r.Evidence??new List<SettingEvidence>();
  bool partial=steps.Any(s=>s.Status=="ignorado"||s.Status=="restauração pendente")||evidence.Any(e=>e.PermissionSkipped);
  string state=r.Status=="preparando"?"não executada":r.Status=="aplicando"||r.Status=="restaurando"||r.Status=="executando"?"em andamento":r.Status=="aplicado"?(partial?"aplicada parcialmente":"aplicada"):r.Status=="sem alterações"||r.Status=="cancelado"?"ignorada":r.Status=="consulta parcial"||r.Status=="concluído com avisos"||r.Status=="remoção com pendências"?"aplicada parcialmente":r.Status=="desfeito"||r.Status=="concluído"||r.Status=="medido"||r.Status=="consulta concluída"||r.Status=="remoção concluída"?"aplicada":"falhou";
  bool admin=r.RequestedAdmin??(item!=null?LiquidProtocol.NeedsAdmin(new[]{item}):CommandTools.Catalog().Any(c=>c.Id==r.ItemId&&c.Administrator)||r.Kind=="Serviços"||r.Kind=="Energia"||r.Kind=="Foco");
  bool restart=r.ChangesStarted&&item!=null&&(item.Operations??new RegOp[0]).Any(o=>o.Key.StartsWith(@"SYSTEM\",StringComparison.OrdinalIgnoreCase));
  return new ActionOutcome{Id=item==null?r.ItemId:item.Id,Name=item==null?r.Name:item.ReviewTitle,Category=item==null?r.Kind:item.Category,
   State=state,Description=r.Message,Technical=String.Join(Environment.NewLine,steps.Select(s=>s.Name+" · "+s.Status+" · "+s.Message)),
   ErrorCode=r.OutcomeCode??(state=="falhou"?"TRANSACTION_FAILED":partial?"PARTIAL":"OK"),FriendlyError=state=="falhou"?"Consulte o histórico para verificar a reversão e as etapas pendentes.":partial?"Uma ou mais etapas não foram aplicadas. Confira o resultado por item.":"",
   Log=App.Json.Serialize(new{r.Id,r.Time,r.Status,r.Message,r.FailureStage,r.FailureDetail,r.Evidence,r.Steps}),CanUndo=App.CanUndo(r),BackupId=r.Id,AdministratorRequired=admin,AdministratorUsed=r.Platform!=null&&r.Platform.Administrator,RestartSuggested=restart};
 }
 internal static ExecutionReport Project(Record r){
  var actions=new List<ActionOutcome>();
  if(r.IsolatedSteps!=null&&r.IsolatedSteps.Count>0)foreach(var child in r.IsolatedSteps)actions.Add(FromRecord(child,Find(child.ItemId)));
  else actions.Add(FromRecord(r,Find(r.ItemId)));
  if(r.IsolatedSteps!=null)foreach(var step in (r.Steps??new List<StepResult>()).Where(s=>!actions.Any(a=>a.Id==s.Id)))actions.Add(new ActionOutcome{Id=step.Id,Name=step.Name,Category=Find(step.Id)==null?r.Kind:Find(step.Id).Category,State="ignorada",Description=step.Message,Technical=step.Message,ErrorCode="PREFLIGHT_SKIPPED",FriendlyError=step.Message,Log=step.Message});
  return new ExecutionReport{Schema=1,Id=r.Id,Mode=r.Status=="desfeito"?"restauração":"aplicação",Started=r.Time,Finished=r.Updated,Version=App.Version,Platform=r.Platform,Cancelled=r.ExecutionCancelled,Actions=actions,Total=actions.Count,Completed=actions.Count(a=>a.State!="em andamento"&&a.State!="não executada")};
 }
 static Item Find(string id){return App.Items==null?null:App.Items.FirstOrDefault(i=>i.Id==id);}
 internal static void Log(string id,string message){lock(LogGate){
  Directory.CreateDirectory(LogsRoot);string path=Path.Combine(LogsRoot,"execucao.log");
  if(File.Exists(path)&&new FileInfo(path).Length>2*1024*1024){for(int n=4;n>=1;n--){string from=path+"."+n,to=path+"."+(n+1);if(File.Exists(to))File.Delete(to);if(File.Exists(from))File.Move(from,to);}File.Move(path,path+".1");}
  File.AppendAllText(path,DateTime.UtcNow.ToString("o")+" | "+App.Version+" | "+id+" | "+message+Environment.NewLine,new UTF8Encoding(false));
 }}
 internal static string Persist(ExecutionReport report){Directory.CreateDirectory(ReportsRoot);string path=Path.Combine(ReportsRoot,report.Id+".json");AtomicStore.Write(path,App.Json.Serialize(report));Log(report.Id,App.Json.Serialize(report));return path;}
 internal static string Text(ExecutionReport r){var b=new StringBuilder("LukeOptimizer "+r.Version+" · "+r.Mode+Environment.NewLine+r.Started+Environment.NewLine);if(r.Platform!=null)b.AppendLine(r.Platform.Windows+" · "+r.Platform.Edition+" · "+r.Platform.Architecture);b.AppendLine(r.Completed+" / "+r.Total+" ações concluídas");foreach(var a in r.Actions)b.AppendLine().AppendLine(a.Name+" · "+a.State+" · "+a.ErrorCode).AppendLine(a.Description).AppendLine(a.FriendlyError).AppendLine(a.Technical).AppendLine("Backup: "+(a.BackupId??"não aplicável")+" · reversão: "+a.CanUndo+" · administrador necessário: "+a.AdministratorRequired+" · reinício sugerido: "+a.RestartSuggested);return b.ToString();}
 internal static ExecutionReport Simulate(IEnumerable<string> ids,CancellationToken token,Action<int,int> progress){
  var chosen=LiquidProtocol.Resolve(String.Join(",",ids));App.UniqueOperations(chosen);
  var report=new ExecutionReport{Schema=1,Id=Guid.NewGuid().ToString("N"),Mode="simulação — nenhuma configuração alterada",Version=App.Version,Started=DateTime.UtcNow.ToString("o"),Platform=PlatformSnapshot.Read(),Actions=new List<ActionOutcome>(),Total=chosen.Count};
  var machine=App.ScanHardware();
  foreach(var item in chosen){
   if(token.IsCancellationRequested||ExecutionControl.Cancelled){report.Cancelled=true;break;}
   string why=App.PreflightItem(item,machine);var info=OptionInfo.For(item);
   report.Actions.Add(new ActionOutcome{Id=item.Id,Name=item.ReviewTitle,Category=item.Category,State=why==null?"não executada":"ignorada",Description=why??"Pré-verificação concluída. Simulação não aplica valores nem comprova ganho de desempenho.",Technical=App.Json.Serialize(new{item.Operations,item.ActionCode}),ErrorCode=why==null?"SIMULATION":"PREFLIGHT_SKIPPED",FriendlyError=why??"",Log=why??"Leitura de compatibilidade e valores; sem gravações.",AdministratorRequired=info.Admin,CanUndo=false,RestartSuggested=false});
   report.Completed++;if(progress!=null)progress(report.Completed,report.Total);
  }
  report.Finished=DateTime.UtcNow.ToString("o");return report;
 }
 internal static async Task<ExecutionReport> SimulateAsync(IEnumerable<string> ids,CancellationToken token,Action<int,int> progress){
  await Queue.WaitAsync(token);try{return await Task.Run(()=>Simulate(ids,token,progress));}finally{Queue.Release();}
 }
}

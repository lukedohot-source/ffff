using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Net;
using System.Net.NetworkInformation;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

public class NetworkCapture {
 public string Host,Address,Time,Environment,AdapterReport,DnsError;
 public double? DnsMs;public List<double?> Samples=new List<double?>();
 public int Sent {get{return Samples.Count;}}public int Received {get{return Samples.Count(x=>x.HasValue);}}
 public double Loss {get{return Sent==0?0:100.0*(Sent-Received)/Sent;}}
 public double? Average {get{return Received==0?(double?)null:Samples.Where(x=>x.HasValue).Average(x=>x.Value);}}
 public double? P95 {get{var a=Samples.Where(x=>x.HasValue).Select(x=>x.Value).OrderBy(x=>x).ToArray();return a.Length==0?(double?)null:a[(int)Math.Ceiling(a.Length*.95)-1];}}
 public double? Variation {get{var a=new List<double>();for(int i=1;i<Samples.Count;i++)if(Samples[i].HasValue&&Samples[i-1].HasValue)a.Add(Math.Abs(Samples[i].Value-Samples[i-1].Value));return a.Count==0?(double?)null:a.Average();}}
 static string Ms(double? n){return n.HasValue?n.Value.ToString("0.00")+" ms":"indisponível";}
 public override string ToString(){return Host+" → "+(Address??"não resolvido")+" · "+Time+"\r\n"+Environment+"\r\n"+
  "Resolução pelo Windows: "+Ms(DnsMs)+" "+DnsError+"\r\nRespostas: "+Received+"/"+Sent+" · perda ICMP: "+Loss.ToString("0.0")+"%\r\nRTT médio: "+Ms(Average)+" · p95: "+Ms(P95)+" · variação entre respostas consecutivas: "+Ms(Variation)+"\r\n"+
  (Received==0?"Sem resposta ICMP; o destino ou firewall pode bloquear ping.\r\n":"")+
  "O cache do Windows pode participar da resolução. RTT é ida e volta ICMP, não input lag, latência de ida nem tempo de renderização.\r\n";}
}
static class NetworkWorkbench {
 internal static string CompareLoad(NetworkCapture idle,NetworkCapture load){
  if(idle==null||load==null||idle.Environment.IndexOf("repouso",StringComparison.OrdinalIgnoreCase)<0||load.Environment.IndexOf("carga",StringComparison.OrdinalIgnoreCase)<0)return "TESTE SOB CARGA (bufferbloat)\r\n1. Sem downloads/uploads, escreva 'repouso' em Condição e clique em Medir ANTES.\r\n2. Inicie um upload/download que você já usa, escreva 'carga' e clique em Medir DEPOIS.\r\n3. Clique novamente em Repouso x carga. Use o mesmo destino externo. O app não gera tráfego pesado automaticamente.";
  if(idle.Address!=load.Address||idle.Host!=load.Host||idle.AdapterReport!=load.AdapterReport||idle.Sent!=load.Sent)return "Comparação sob carga suspensa: destino, adaptador ou amostragem mudou.";
  if(!idle.Average.HasValue||!load.Average.HasValue)return "Sem respostas suficientes nas duas condições; não é possível estimar a diferença sob carga.";
  double delta=load.Average.Value-idle.Average.Value;
  return "RESPOSTA SOB CARGA\r\nRepouso: "+idle.Average.Value.ToString("0.00")+" ms\r\nCom carga: "+load.Average.Value.ToString("0.00")+" ms\r\nDiferença: "+delta.ToString("+0.00;-0.00;0.00")+" ms\r\n\r\nAumento pode indicar filas, disputa no Wi-Fi ou congestionamento. Esta amostra manual não isola a causa nem atribui uma nota universal de bufferbloat. Repita três vezes em condições semelhantes.\r\n\r\n"+Compare(idle,load);
 }
 internal static async Task<string> Route(string host,CancellationToken token){
  if(!HardwareLab.ValidHost(host))throw new ArgumentException("Informe somente IP ou host, sem URL/porta.");token.ThrowIfCancellationRequested();IPAddress address;
  if(!IPAddress.TryParse(host,out address)){var task=Dns.GetHostAddressesAsync(host);ObserveDnsFailure(task);if(await Task.WhenAny(task,Task.Delay(5000,token))!=task){token.ThrowIfCancellationRequested();throw new TimeoutException("DNS excedeu 5 segundos.");}address=(await task).FirstOrDefault(a=>a.AddressFamily==System.Net.Sockets.AddressFamily.InterNetwork);if(address==null)throw new Exception("Esta leitura de rota requer IPv4.");}
  if(address.AddressFamily!=System.Net.Sockets.AddressFamily.InterNetwork)throw new Exception("Esta leitura de rota requer IPv4.");
  var b=new StringBuilder("ROTA ICMP até "+address+"\r\nUm salto por linha; até 20 saltos. Roteadores podem ocultar respostas.\r\n");bool reached=false;
  using(var ping=new Ping())for(int ttl=1;ttl<=20;ttl++){token.ThrowIfCancellationRequested();try{var reply=await ping.SendPingAsync(address,800,new byte[32],new PingOptions(ttl,false));b.AppendLine(ttl+" · "+(reply.Address==null?"sem resposta":reply.Address.ToString())+" · "+reply.Status);if(reply.Status==IPStatus.Success){reached=true;break;}}catch(PingException e){b.AppendLine(ttl+" · "+e.Message);}}
  token.ThrowIfCancellationRequested();return b+"\r\n"+(reached?"Destino respondeu.":"Destino não confirmado dentro do limite. Isso não comprova falha na conexão.")+" Rota ICMP pode diferir do tráfego do jogo. Não muda configurações de rede.";
 }
 internal static string Adapters(){
  var b=new StringBuilder("ADAPTADORES · somente leitura\r\n");
  foreach(var n in NetworkInterface.GetAllNetworkInterfaces().Where(n=>n.NetworkInterfaceType!=NetworkInterfaceType.Loopback))try{
   var p=n.GetIPProperties();b.AppendLine(n.Name+" · "+n.Description+"\r\n"+n.OperationalStatus+" · link "+(n.Speed/1000000.0).ToString("0")+" Mbps");
   b.AppendLine("IP: "+String.Join(", ",p.UnicastAddresses.Select(x=>x.Address.ToString())));
   b.AppendLine("Gateway: "+String.Join(", ",p.GatewayAddresses.Select(x=>x.Address.ToString()))+" · DNS: "+String.Join(", ",p.DnsAddresses.Select(x=>x.ToString())));
   var s=n.GetIPStatistics();b.AppendLine("Contadores desde a inicialização do adaptador: recebidos "+s.BytesReceived+" B · enviados "+s.BytesSent+" B · erros RX "+s.IncomingPacketsWithErrors+" · descartes RX "+s.IncomingPacketsDiscarded+"\r\n");
  }catch(Exception e){b.AppendLine(n.Name+": leitura indisponível — "+e.Message);}
  b.AppendLine("Link não é velocidade da internet. Contadores acumulados não demonstram perda durante o jogo. VPN, Wi-Fi e mudanças de rota podem alterar a comparação.");return b.ToString();
 }
 internal static string Fingerprint(){try{return String.Join("|",NetworkInterface.GetAllNetworkInterfaces().Where(n=>n.OperationalStatus==OperationalStatus.Up&&n.NetworkInterfaceType!=NetworkInterfaceType.Loopback).Select(n=>n.Id+":"+String.Join(",",n.GetIPProperties().GatewayAddresses.Select(x=>x.Address.ToString()))).OrderBy(x=>x));}catch{return "";}}
 internal static async Task<NetworkCapture> Capture(string host,string condition,CancellationToken token,Action<int> progress){
  if(!HardwareLab.ValidHost(host))throw new ArgumentException("Informe IP ou host, sem URL ou porta.");
  if(condition==null||condition.Length>160)throw new ArgumentException("Descrição da condição inválida.");
  token.ThrowIfCancellationRequested();var r=new NetworkCapture{Host=host,Time=DateTime.Now.ToString("g"),Environment=condition,AdapterReport=Fingerprint(),DnsError=""};IPAddress address;
  if(IPAddress.TryParse(host,out address)){r.Address=address.ToString();r.DnsError="IP literal: DNS não consultado.";}
  else{
   var timer=Stopwatch.StartNew();var task=Dns.GetHostAddressesAsync(host);
   // A timed-out resolver may complete later; observe its fault without using the result.
   ObserveDnsFailure(task);
   if(await Task.WhenAny(task,Task.Delay(5000,token))!=task){token.ThrowIfCancellationRequested();throw new TimeoutException("A resolução DNS excedeu 5 segundos.");}
   var addresses=await task;token.ThrowIfCancellationRequested();address=addresses.FirstOrDefault(x=>x.AddressFamily==System.Net.Sockets.AddressFamily.InterNetwork)??addresses.FirstOrDefault();
   if(address==null)throw new Exception("O host não retornou endereço IP.");r.DnsMs=timer.Elapsed.TotalMilliseconds;r.Address=address.ToString();
  }
  using(var ping=new Ping())for(int i=0;i<24;i++){
   token.ThrowIfCancellationRequested();double? value=null;
   try{var reply=await ping.SendPingAsync(address,1000,new byte[32]);if(reply.Status==IPStatus.Success)value=reply.RoundtripTime;}
   catch(PingException){}r.Samples.Add(value);progress(i+1);await Task.Delay(200,token);
  }
  token.ThrowIfCancellationRequested();return r;
 }
 static void ObserveDnsFailure(Task task){task.ContinueWith(t=>{var ignored=t.Exception;},TaskContinuationOptions.OnlyOnFaulted);}
 internal static string Compare(NetworkCapture a,NetworkCapture b){
  if(a==null||b==null)return "Grave ANTES e DEPOIS no mesmo destino para comparar. Altere uma opção de cada vez.";
  if(!String.Equals(a.Host,b.Host,StringComparison.OrdinalIgnoreCase)||a.Address!=b.Address||a.Sent!=b.Sent)return "Comparação suspensa: host, IP resolvido ou quantidade de amostras diferente.";
  var s="Variação de perda ICMP: "+(b.Loss-a.Loss).ToString("+0.0;-0.0;0.0")+" pontos percentuais.\r\n";
  if(a.Average.HasValue&&b.Average.HasValue)s+="Variação do RTT médio: "+(b.Average.Value-a.Average.Value).ToString("+0.00;-0.00;0.00")+" ms (valor negativo = menor RTT nesta amostra).\r\n";
  if(a.AdapterReport!=b.AdapterReport)s+="Adaptadores/gateways mudaram entre as capturas. O resultado inclui essa mudança.\r\n";
  return s+"24 pings são uma amostra curta; repita e confirme no jogo. Horário, servidor, Wi-Fi e tráfego concorrente também interferem. O app não gera carga de rede: para investigar filas, compare repouso e uso habitual de upload, identificando a condição.";
 }
}
public partial class MainForm {
 TextBox v5NetHost,v5NetCondition,v5NetOutput;NetworkCapture v5Before,v5After;CancellationTokenSource v5NetCancel;
 void BuildNetworkWorkbench(){
  var page=Page("Rede e latência");var root=Rows(64,42,42,48,-1,88);page.Controls.Add(root);ScrollPage(page,root,510);
  root.Controls.Add(Theme.Label("1. Escolha o destino (se não souber, use seu roteador).  2. Clique em Medir ANTES.\r\n3. Depois de mudar uma configuração, clique em Medir DEPOIS. Menor ping e menos perdas são melhores.",10,Theme.Muted),0,0);
  var hostRow=ActionRow();root.Controls.Add(hostRow,0,1);var label=Theme.Label("Endereço para testar",10,Theme.Text);label.Dock=DockStyle.None;label.Size=new Size(170,34);hostRow.Controls.Add(label);
  v5NetHost=Field();v5NetHost.Dock=DockStyle.None;v5NetHost.Width=300;v5NetHost.Text=HardwareLab.Gateway();hostRow.Controls.Add(v5NetHost);
  hostRow.Controls.Add(V4Button("Usar meu roteador",(s,e)=>v5NetHost.Text=HardwareLab.Gateway(),false,160));
  var condition=ActionRow();root.Controls.Add(condition,0,2);var cl=Theme.Label("Condição do teste",10,Theme.Text);cl.Dock=DockStyle.None;cl.Size=new Size(170,34);condition.Controls.Add(cl);
  v5NetCondition=Field();v5NetCondition.Dock=DockStyle.None;v5NetCondition.Width=470;v5NetCondition.MaxLength=160;v5NetCondition.Text="Sem downloads; usando cabo ou Wi-Fi";condition.Controls.Add(v5NetCondition);
  var actions=ActionRow();root.Controls.Add(actions,0,3);actions.Controls.Add(V4Button("Medir ANTES",async(s,e)=>await CaptureNetwork(true),false,165));actions.Controls.Add(V4Button("Medir DEPOIS",async(s,e)=>await CaptureNetwork(false),true,170));actions.Controls.Add(V4Button("Cancelar",(s,e)=>{if(v5NetCancel!=null)v5NetCancel.Cancel();},false,130));
  v5NetOutput=Theme.ReadBox();root.Controls.Add(v5NetOutput,0,4);v5NetOutput.Text="Seu primeiro resultado aparecerá aqui. Clique em Medir ANTES.\r\nPing é o tempo de ida e volta até o destino. Variação (jitter) e perdas ajudam a investigar instabilidade.\r\nDNS afeta a resolução inicial; normalmente não altera o ping de uma partida conectada.\r\n\r\n"+NetworkWorkbench.Compare(null,null);
  var tools=ActionRow();tools.WrapContents=true;tools.AutoScroll=false;root.Controls.Add(tools,0,5);tools.Controls.Add(V4Button("Ver minha conexão",(s,e)=>v5NetOutput.Text=NetworkWorkbench.Adapters(),false,180));tools.Controls.Add(V4Button("Conexões do Windows",(s,e)=>OpenSystem("control.exe","ncpa.cpl"),false,220));tools.Controls.Add(V4Button("Rota até destino",async(s,e)=>await ReadRoute(),false,175));tools.Controls.Add(V4Button("Repouso x carga",(s,e)=>v5NetOutput.Text=NetworkWorkbench.CompareLoad(v5Before,v5After),false,178));tools.Controls.Add(V4Button("Exportar resultado",(s,e)=>ExportNetwork(),false,190));
 }
 async Task ReadRoute(){string host=v5NetHost.Text.Trim();await V4Read(async()=>{v5NetCancel=new CancellationTokenSource();try{v5NetOutput.Text="Consultando a rota… use Cancelar para interromper.";v5NetOutput.Text=await NetworkWorkbench.Route(host,v5NetCancel.Token);}finally{v5NetCancel.Dispose();v5NetCancel=null;}});}
 async Task CaptureNetwork(bool before){
  string host=v5NetHost.Text.Trim(),condition=v5NetCondition.Text;
  await V4Read(async()=>{v5NetCancel=new CancellationTokenSource();v5NetHost.Enabled=v5NetCondition.Enabled=false;
   try{v5NetOutput.Text="Medindo "+host+"…";var result=await NetworkWorkbench.Capture(host,condition,v5NetCancel.Token,n=>footer.Text="Rede · "+n+"/24 amostras");if(before)v5Before=result;else v5After=result;v5NetOutput.Text=NetworkText();}
   catch(OperationCanceledException){v5NetOutput.Text="Medição cancelada. Capturas completas anteriores preservadas.\r\n\r\n"+NetworkText();throw;}
   finally{v5NetCancel.Dispose();v5NetCancel=null;v5NetHost.Enabled=v5NetCondition.Enabled=true;}
  });
 }
 string NetworkText(){return "ANTES\r\n"+(v5Before==null?"Não medido.":v5Before.ToString())+"\r\n\r\nDEPOIS\r\n"+(v5After==null?"Não medido.":v5After.ToString())+"\r\n\r\n"+NetworkWorkbench.Compare(v5Before,v5After);}
 void ExportNetwork(){using(var dialog=new SaveFileDialog{Filter="Relatório de texto|*.txt",FileName="Luke-rede.txt"})if(dialog.ShowDialog(this)==DialogResult.OK)try{File.WriteAllText(dialog.FileName,NetworkText()+"\r\n\r\n"+NetworkWorkbench.Adapters(),Encoding.UTF8);}catch(Exception e){MessageBox.Show(e.Message,Text);}}
}

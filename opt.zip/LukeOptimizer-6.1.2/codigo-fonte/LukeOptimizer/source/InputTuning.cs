using System;
using System.Linq;
using System.Runtime.InteropServices;
using System.ComponentModel;

// Only documented SystemParametersInfo preferences; never a hardware latency claim.
static class InputTuning {
 [DllImport("user32.dll",EntryPoint="SystemParametersInfoW",SetLastError=true)]
 static extern bool Spi(uint action,uint param,IntPtr value,uint flags);
 internal static bool IsCode(string code){return code=="v5-keydelay"||code=="v5-keyspeed"||code=="v5-filter"||code=="v5-sticky";}
 internal static string[] Codes(string action){return action=="v5-keyrepeat"?new[]{"v5-keydelay","v5-keyspeed"}:IsCode(action)?new[]{action}:new string[0];}
 internal static string Read(string code){
  if(!IsCode(code))throw new ArgumentException("Preferência de entrada inválida.");
  int size=code=="v5-filter"?24:code=="v5-sticky"?8:4;bool structure=size>4;
  IntPtr ptr=Marshal.AllocHGlobal(size);
  try{for(int n=0;n<size;n+=4)Marshal.WriteInt32(ptr,n,0);if(structure)Marshal.WriteInt32(ptr,size);
   uint action=code=="v5-keydelay"?0x0016u:code=="v5-keyspeed"?0x000Au:code=="v5-filter"?0x0032u:0x003Au;
   if(!Spi(action,structure?(uint)size:0u,ptr,0))throw new Win32Exception(Marshal.GetLastWin32Error());
   return String.Join(",",Enumerable.Range(structure?1:0,size/4-(structure?1:0)).Select(n=>unchecked((uint)Marshal.ReadInt32(ptr,n*4)).ToString(System.Globalization.CultureInfo.InvariantCulture)));
  }finally{Marshal.FreeHGlobal(ptr);}
 }
 internal static string Desired(string code,string before){
  if(code=="v5-keydelay")return "0";if(code=="v5-keyspeed")return "31";
  var values=Parse(code,before);values[0]&=code=="v5-filter"?~1u:~4u;
  return String.Join(",",values.Select(x=>x.ToString(System.Globalization.CultureInfo.InvariantCulture)));
 }
 internal static uint[] Parse(string code,string text){
  if(!IsCode(code))throw new ArgumentException("Código de teclado inválido.");
  var values=text.Split(new[]{','}).Select(x=>UInt32.Parse(x,System.Globalization.CultureInfo.InvariantCulture)).ToArray();
  if(values.Length!=(code=="v5-filter"?5:1))throw new ArgumentException("Backup de teclado inválido.");
  if(code=="v5-keydelay"&&values[0]>3||code=="v5-keyspeed"&&values[0]>31||code=="v5-filter"&&values.Skip(1).Any(x=>x>20000))throw new ArgumentException("Preferência de teclado fora do intervalo.");
  return values;
 }
 internal static void Write(string code,string text){
  var values=Parse(code,text);bool structure=code=="v5-filter"||code=="v5-sticky";
  uint action=code=="v5-keydelay"?0x0017u:code=="v5-keyspeed"?0x000Bu:code=="v5-filter"?0x0033u:0x003Bu;
  if(!structure){if(!Spi(action,values[0],IntPtr.Zero,3))throw new Win32Exception(Marshal.GetLastWin32Error());return;}
  int size=(values.Length+1)*4;IntPtr ptr=Marshal.AllocHGlobal(size);
  try{Marshal.WriteInt32(ptr,size);for(int n=0;n<values.Length;n++)Marshal.WriteInt32(ptr,(n+1)*4,unchecked((int)values[n]));
   if(!Spi(action,(uint)size,ptr,3))throw new Win32Exception(Marshal.GetLastWin32Error());
  }finally{Marshal.FreeHGlobal(ptr);}
 }
}

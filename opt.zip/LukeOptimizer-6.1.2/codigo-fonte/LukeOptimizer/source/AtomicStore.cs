using System;
using System.IO;
using System.Text;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Threading;

static class AtomicStore {
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]
 static extern bool MoveFileEx(string existing,string destination,uint flags);
 internal static FileStream Acquire(string path){
  string gate=Path.GetFullPath(path)+".lock";var elapsed=Stopwatch.StartNew();
  while(true){
   try{return new FileStream(gate,FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);}
   catch(IOException error){int code=error.HResult&0xffff;if((code!=32&&code!=33)||elapsed.ElapsedMilliseconds>=5000)throw;Thread.Sleep(20);}
  }
  // The empty lock file persists: deleting it would let separate processes open
  // different lock objects for the same data path.
 }
 internal static string Read(string path){
  // Coordinate across the normal UI and elevated worker. Some Windows file
  // systems refuse replacement even when the reader grants FileShare.Delete.
  using(var gate=Acquire(path))
  using(var file=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read|FileShare.Delete))
  using(var reader=new StreamReader(file,Encoding.UTF8,true))return reader.ReadToEnd();
 }
 internal static void Write(string path,string text){
  string target=Path.GetFullPath(path);string temp=target+"."+Guid.NewGuid().ToString("N")+".pending";
  using(var gate=Acquire(target)){
  try{
   byte[] bytes=new UTF8Encoding(false).GetBytes(text);
   using(var file=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None,4096,FileOptions.WriteThrough)){file.Write(bytes,0,bytes.Length);file.Flush(true);}
   // Same-directory rename replaces the complete file atomically without a delete gap.
   // Unlike ReplaceFile, it does not need to merge ACL/alternate-stream metadata.
   if(App.IsWindows){if(!MoveFileEx(temp,target,0x1|0x8))throw new Win32Exception(Marshal.GetLastWin32Error(),"Não foi possível salvar o arquivo completo: "+Path.GetFileName(target));}
   else if(File.Exists(target))File.Replace(temp,target,null);else File.Move(temp,target);
  }finally{if(File.Exists(temp))try{File.Delete(temp);}catch{}}
  }
 }
}

@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0VALIDAR-5.4.ps1" -OnlyTest
exit /b %ERRORLEVEL%

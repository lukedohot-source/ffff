﻿param([switch]$OnlyTest)
$ErrorActionPreference = 'Stop'
Push-Location -LiteralPath $PSScriptRoot
try {
    $taskCompiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
    if (-not (Test-Path -LiteralPath $taskCompiler)) { throw '.NET Framework 4.x x64 nao encontrado.' }
    $taskRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
    $taskResults = Join-Path $taskRoot 'verificacao\atual'
    New-Item -ItemType Directory -Force -Path $taskResults | Out-Null
    function Build([string[]]$BuildArguments,[string]$LogName) {
        & $taskCompiler @BuildArguments *> (Join-Path $taskResults $LogName)
        if ($LASTEXITCODE -ne 0) { throw "Compilacao falhou: $LogName" }
    }
    Copy-Item -LiteralPath 'source\app.config' -Destination 'LukeOptimizer-Engine.new.exe.config' -Force
    Copy-Item -LiteralPath 'source\app.config' -Destination 'UiSmoke.exe.config' -Force
    Build @('/target:winexe','/win32manifest:source\app.manifest','/out:LukeOptimizer-Engine.new.exe','@compilacao.rsp') 'build.log'
    Build @('/target:exe','/out:ProcessFixture.exe','tests\ProcessFixture.cs') 'fixture-build.log'
    Build @('/define:TESTS','/target:exe','/main:EngineTests','/out:LukeOptimizer-Testes.exe','@compilacao.rsp','tests\EngineTests.cs','tests\V3Tests.cs','tests\V4Tests.cs','tests\V5Tests.cs','tests\V52Tests.cs','tests\V53Tests.cs','tests\V54Tests.cs','tests\RegressionTests.cs','tests\V6Tests.cs') 'tests-build.log'
    & .\LukeOptimizer-Testes.exe *> (Join-Path $taskResults 'tests.log')
    if ($LASTEXITCODE -ne 0) { throw 'Testes de logica falharam. Executavel principal preservado.' }
    Build @('/define:TESTS','/target:exe','/main:UiSmoke','/out:UiSmoke.exe','@compilacao.rsp','tests\UiSmoke.cs','tests\UnifiedUiTests.cs','tests\FunctionalUiTests.cs','tests\ProductUiTests.cs') 'ui-build.log'
    & .\UiSmoke.exe (Join-Path $taskResults 'interface') *> (Join-Path $taskResults 'ui.log')
    if ($LASTEXITCODE -ne 0) { throw 'Testes de interface falharam. Executavel principal preservado.' }
    if (-not $OnlyTest) {
        Copy-Item -LiteralPath 'source\app.config' -Destination 'LukeOptimizer-Engine.exe.config' -Force
        Copy-Item -LiteralPath 'source\app.config' -Destination (Join-Path $taskRoot 'native\LukeOptimizer-Engine.exe.config') -Force
        Copy-Item -LiteralPath 'source\app.config' -Destination (Join-Path $taskRoot 'native\LukeOptimizer-v5.exe.config') -Force
        Copy-Item -LiteralPath '.\LukeOptimizer-Engine.new.exe' -Destination '.\LukeOptimizer-Engine.exe' -Force
        Copy-Item -LiteralPath '.\LukeOptimizer-Engine.new.exe' -Destination (Join-Path $taskRoot 'native\LukeOptimizer-Engine.exe') -Force
        Copy-Item -LiteralPath '.\LukeOptimizer-Engine.new.exe' -Destination (Join-Path $taskRoot 'native\LukeOptimizer-v5.exe') -Force
    }
    & (Join-Path $taskRoot 'ATUALIZAR-HASHES.ps1')
    Get-Content -LiteralPath (Join-Path $taskResults 'tests.log') -Tail 1
    Get-Content -LiteralPath (Join-Path $taskResults 'ui.log') -Tail 1
    Write-Output 'Validacao concluida. Nenhuma otimizacao ou desinstalacao real foi executada.'
} finally { Pop-Location }

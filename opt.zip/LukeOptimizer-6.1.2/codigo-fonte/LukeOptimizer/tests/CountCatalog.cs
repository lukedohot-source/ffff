using System;
using System.Linq;
class CountCatalog { static void Main(){Console.WriteLine("original="+PerformanceLibrary.OriginalItems().Count+" lib="+PerformanceLibrary.Load().Count+" native="+CatalogIds.NativeItems().Count);foreach(var id in ExtremeProfile.Groups().SelectMany(g=>g.Items)){var i=CatalogIds.NativeItems().Single(x=>x.Id==id);Console.WriteLine(id+" "+ExtremeProfile.IsReviewed(i)+" "+i.ManualAllowed+" "+String.Join(";",i.Operations.Select(o=>o.Hive+"\\"+o.Key)));}}}

﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
partial class EngineTests {
 static Dictionary<string,RegOp> registry;static Dictionary<string,string> native;static int checks;static string active;static bool failWrite,failReadback,failRollback;
 static string Key(RegOp op){return (op.Hive+"\\"+op.Key+"\\"+op.Name).ToLowerInvariant();}
 static RegOp Copy(RegOp op){return new RegOp{Hive=op.Hive,Key=op.Key,Name=op.Name,Kind=op.Kind,Data=op.Data,Delete=op.Delete};}
 static void Assert(bool ok,string message){checks++;if(!ok)throw new Exception("FAILED: "+message);Console.WriteLine("PASS "+message);}
 // Um teste cuja PREMISSA nao existe neste sistema nao pode virar PASS nem sumir: vira
 // SKIP com o motivo, e o total final diz quantos foram pulados. Afrouxar a asseracao
 // para ela passar no Linux seria apagar a garantia que vale no Windows.
 static readonly List<string> skips=new List<string>();
 static void Skip(string message,string why){skips.Add(message+" ("+why+")");Console.WriteLine("SKIP "+message+" -- "+why);}
 // No Windows, um leitor com FileShare.Read impede MoveFileEx de substituir o arquivo.
 // Em POSIX nao ha trava obrigatoria: o rename sempre vence e nenhum leitor bloqueia
 // nada. Em vez de supor a plataforma, mede-se o comportamento real deste runtime.
 // GameProfiles exige caminho com letra de unidade (full[1]==':') e arquivo existente.
 // Fora do Windows nao existe "C:\", entao a fixture nao pode ser construida. Medimos
 // a capacidade em vez de supor a plataforma.
 static bool WindowsDrivePaths(){
  try{string full=Path.GetFullPath(Path.Combine(App.DataRoot,"x.exe"));return full.Length>3&&full[1]==':';}catch{return false;}
 }
 static bool ReplacementBlockedByReaders(){
  string probe=Path.Combine(App.DataRoot,"lock-probe.tmp");
  try{
   AtomicStore.Write(probe,"a");
   using(new FileStream(probe,FileMode.Open,FileAccess.Read,FileShare.Read)){
    try{AtomicStore.Write(probe,"b");return false;}catch{return true;}
   }
  }catch{return true;}
  finally{foreach(string leftover in new[]{probe,probe+".lock"})try{File.Delete(leftover);}catch{}}
 }
 static void Reset(){
  foreach(string p in Directory.GetFiles(App.RecordsRoot,"*.json"))File.Delete(p);
  registry=new Dictionary<string,RegOp>();native=new Dictionary<string,string>{{"window","1"},{"client","1"},{"menuanim","1"},{"combo","1"},{"list","1"},{"tooltip","1"},{"selection","1"},{"menu","400"},{"mouse","6,10,1"}};
  active="381b4222-f694-41f0-9685-ff5bb260df2e";failWrite=failReadback=failRollback=false;
  App.TestAccess=null;App.Items=Builtins.Create();App.TestMachine=new Machine{Windows=true,Build=26100,OnAC=true,NoBattery=true,PowerKnown=true,Plans=App.HighPlan,ActiveGuid=active};
  App.TestCapture=op=>{RegOp value;if(!registry.TryGetValue(Key(op),out value))value=new RegOp{Hive=op.Hive,Key=op.Key,Name=op.Name,Data="",Kind="String",Delete=true};return new SavedValue{Before=Copy(value),After=Copy(op),KeyExisted=!value.Delete};};
  App.TestWrite=op=>{
   if(failWrite&&op.Name=="AutoGameModeEnabled"&&!op.Delete)throw new Exception("simulated write failure");
   if(failRollback&&op.Delete)throw new Exception("simulated rollback failure");
   if(failReadback&&op.Name=="AutoGameModeEnabled"&&!op.Delete)return;
   if(op.Delete)registry.Remove(Key(op));else registry[Key(op)]=Copy(op);
  };
  App.TestNativeRead=code=>native[code];App.TestNativeWrite=(code,v)=>native[code]=v;
  App.TestPlanGet=()=>active;App.TestPlanSet=guid=>active=guid;
 }
 static Record Last(){return App.History().First();}
 static void ExpectFailure(Action a,string label){bool failed=false;try{a();}catch{failed=true;}Assert(failed,label);}
 static int Main(){try{
  Directory.CreateDirectory(App.RecordsRoot);Reset();
  var conflict1=Builtins.Create().Single(i=>i.ActionCode=="capture");var conflict2=Builtins.Create().Single(i=>i.ActionCode=="capture");conflict2.Operations[0].Data="1";
  ExpectFailure(()=>App.UniqueOperations(new[]{conflict1,conflict2}),"contradictory settings rejected before mutation");
  Assert(App.UniqueOperations(new[]{conflict1,conflict1}).Count==3,"identical registry writes deduplicated");
  Assert(NativeSettings.Desired("menu","0")=="0"&&NativeSettings.Desired("menu","50")=="50"&&NativeSettings.Desired("menu","400")=="100","menu profile preserves already faster values");
  ExpectFailure(()=>App.ApplyMaximum(new[]{"not-a-profile-item"}),"external / unknown item cannot enter maximum profile");
  ExpectFailure(()=>App.ApplyMaximum(new[]{"native-window","native-window"}),"duplicate profile IDs rejected");
  Assert(App.Items.Count(i=>i.DefaultSelected)==6,"six defaults; power and mouse are opt-in");
  Assert(NativeSettings.BoolParameter("0")==IntPtr.Zero&&NativeSettings.BoolParameter("1")==new IntPtr(1),"SPI SET uses BOOL value, not address of BOOL");
  ExpectFailure(()=>NativeSettings.BoolParameter("2"),"invalid SPI boolean rejected");
  App.ApplyMaximum(App.Items.Where(i=>i.DefaultSelected||i.ActionCode=="power").Select(i=>i.Id).ToArray());
  var record=Last();Assert(record.Status=="aplicado","full profile completes");Assert(registry.Count==6&&native["window"]=="0"&&native["menu"]=="100"&&active==App.HighPlan,"registry, native preferences and power applied");
  Assert(record.Values.Count==6&&record.NativeValues.Count==8&&record.PreviousPlan=="381b4222-f694-41f0-9685-ff5bb260df2e","all original values captured for batch undo");
  App.Undo(record.Id);Assert(Last().Status=="desfeito"&&registry.Count==0&&native["window"]=="1"&&native["menu"]=="400"&&active=="381b4222-f694-41f0-9685-ff5bb260df2e","full undo restores exact pre-profile state");
  Reset();App.ApplyMaximum(new[]{"native-capture"});int writes=registry.Count;App.ApplyMaximum(new[]{"native-capture"});Assert(Last().Status=="sem alterações"&&registry.Count==writes,"second apply is idempotent and preserves undo record");Assert(App.History().Count(App.CanUndo)==1,"no-op does not hide the meaningful backup");
  Reset();failWrite=true;var legacyBatch=App.Items.Where(i=>new[]{"native-window","native-capture","native-gamemode","native-power"}.Contains(i.Id)).ToList();ExpectFailure(()=>App.ApplyTransaction(legacyBatch,"Perfil","teste de falha"),"mid-batch registry failure propagates");Assert(Last().Status=="falhou e foi desfeito"&&registry.Count==0&&native["window"]=="1","failure rolls back earlier native and registry writes");
  Reset();failReadback=true;legacyBatch=App.Items.Where(i=>new[]{"native-capture","native-gamemode"}.Contains(i.Id)).ToList();ExpectFailure(()=>App.ApplyTransaction(legacyBatch,"Perfil","teste de leitura"),"silent write failure detected by readback");Assert(registry.Count==0&&Last().Status=="falhou e foi desfeito","readback failure restores previous values");
  Reset();failWrite=true;failRollback=true;legacyBatch=App.Items.Where(i=>new[]{"native-capture","native-gamemode"}.Contains(i.Id)).ToList();ExpectFailure(()=>App.ApplyTransaction(legacyBatch,"Perfil","teste de restauração"),"rollback failure is reported");record=Last();Assert(record.Status=="falha na restauração"&&App.CanUndo(record),"incomplete rollback keeps recoverable backup");failWrite=false;failRollback=false;App.Undo(record.Id);Assert(registry.Count==0&&Last().Status=="desfeito","retry completes interrupted restore");
  Reset();App.ApplyMaximum(new[]{"native-transparency"});record=Last();registry.Values.First().Data="2";ExpectFailure(()=>App.Undo(record.Id),"undo refuses later external modification");Assert(registry.Values.First().Data=="2","later user change is not overwritten");
  Reset();App.ApplyMaximum(new[]{"native-window"});record=Last();record.Status="aplicando";App.Save(record);Assert(App.CanUndo(Last()),"interrupted transaction is recoverable");App.Undo(record.Id);Assert(native["window"]=="1","recovery restores durable snapshot");
  Reset();App.ApplyMaximum(new[]{"native-window"});var first=Last();App.ApplyMaximum(new[]{"native-transparency"});ExpectFailure(()=>App.Undo(first.Id),"undo order prevents older backup overwriting newer changes");
  Reset();App.TestMachine.NoBattery=false;App.ApplyMaximum(new[]{"native-power","native-window"});record=Last();Assert(record.Steps.Single(x=>x.Id=="native-power").Status=="ignorado"&&active!=""&&active!=App.HighPlan,"power step skipped on battery-equipped device");Assert(record.Status=="aplicado"&&native["window"]=="0","compatible stages still run when power is skipped");
  Reset();App.TestMachine.Plans="";App.ApplyMaximum(new[]{"native-power"});Assert(Last().Status=="sem alterações"&&Last().Values.Count==0,"missing power scheme never imported or forced");
  Reset();App.ApplyMaximum(new[]{"native-capture"});var observed=App.Observe(App.Items.Single(i=>i.ActionCode=="capture"),App.TestMachine);Assert(observed.State=="Valores conferidos"&&observed.Match==3,"status reports stored values without claiming performance");registry.Remove(registry.Keys.First());observed=App.Observe(App.Items.Single(i=>i.ActionCode=="capture"),App.TestMachine);Assert(observed.State=="Parcial"&&observed.Match==2,"partial configuration correctly detected");
  Reset();App.TestCapture=op=>{throw new UnauthorizedAccessException("test access denied");};legacyBatch=App.Items.Where(i=>new[]{"native-window","native-capture"}.Contains(i.Id)).ToList();ExpectFailure(()=>App.ApplyTransaction(legacyBatch,"Perfil","teste de snapshot"),"unreadable registry aborts before mutation");Assert(native["window"]=="1"&&Last().Status=="falhou antes de alterar","snapshot failure makes no changes");
  Reset();App.ApplyMaximum(new[]{"native-mouse"});record=Last();Assert(native["mouse"]=="0,0,0","optional mouse acceleration uses its own snapshot");App.Undo(record.Id);Assert(native["mouse"]=="6,10,1","all mouse acceleration parameters restored exactly");
  RunV3Tests();RunV4Tests();RunV5Tests();RunV52Tests();RunV53Tests();RunV54Tests();RunRegressionTests();RunV6Tests();RunFoundationTests();RunNamingTests();RunDnsTests();RunReferenceTests();
  Console.WriteLine("TOTAL: "+checks+" checks passed, "+skips.Count+" skipped (logic only; not an FPS or live Windows mutation test)");
  foreach(string s in skips)Console.WriteLine("  skipped: "+s);
  return 0;
 }catch(Exception e){Console.Error.WriteLine(e);return 1;}}
}

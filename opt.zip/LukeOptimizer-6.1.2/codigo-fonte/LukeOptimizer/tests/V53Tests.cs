using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
partial class EngineTests {
 static void FullCatalog(){Reset();App.Items=CatalogIds.NativeItems();App.TestMachine.Edition="Professional";V5Options.TestBrowserMajor=x=>200;V5Options.TestFeature=x=>true;native["v5-keydelay"]="2";native["v5-keyspeed"]="12";native["v5-filter"]="59,0,200,15,0";native["v5-sticky"]="511";native[ExtraSettings.Compression]="1";native["dragoutline"]="1";native["cursorshadow"]="1";}
 static void RunV53Tests(){
  FullCatalog();CatalogIds.Validate();Assert(App.Items.Count==127,"all 125 pre-existing native IDs preserved");
  var originals=PerformanceLibrary.OriginalItems();var lib=PerformanceLibrary.Load();Assert(originals.Count==546&&lib.Count==780,"all 532 originals plus 14 BATs accessible alongside the 228 previous library entries and 6 additions");
  Assert(originals.All(i=>lib.Any(e=>e.Action=="catalog"&&e.Target==i.Id)),"every original catalog item has a main-screen entry");
  Assert(lib.All(e=>new[]{"native","link","settings","system","page","catalog"}.Contains(e.Action)),"every library action has a UI handler");
  foreach(var alias in CatalogIds.Aliases())Assert(LiquidProtocol.Resolve(alias.Key).Single().Id==alias.Value,"accepted alias "+alias.Key+" -> "+alias.Value);
  ExpectFailure(()=>LiquidProtocol.Resolve("v5-option-unknown"),"prefix alone never creates a native action");
  ExpectFailure(()=>LiquidProtocol.Resolve("v5-option-theme-dark,v5-native-theme-dark"),"alias plus canonical duplicate rejected before writes");
  var request=Guid.NewGuid().ToString("N");Assert(LiquidProtocol.Run(new[]{"--liquid","apply","v5-option-theme-dark",App.Sid,request})==0,"apply route accepts old display IDs");Assert(Last().IdMigrations.Single()=="v5-option-theme-dark -> v5-native-theme-dark"&&ChangeAudit.Report(Last()).Contains("Compatibilidade de ID"),"ID migration persisted in history");
  FullCatalog();var imported=App.Items.Single(i=>i.Id=="opt-disablestartmenuads");App.Apply(imported);Assert(Last().Status=="aplicado","individual imported option no longer enters the obsolete eight-item profile");App.Undo(Last().Id);Assert(registry.Count==0,"individual imported option restores absent values");
  FullCatalog();App.ApplyMaximum(new[]{"v5-option-theme-dark"});Assert(Last().Status=="aplicado","legacy max route uses same canonical resolver");
  var allowed=ExtremeProfile.Groups().SelectMany(g=>g.Items).ToArray();Assert(allowed.Length==allowed.Distinct().Count()&&allowed.All(id=>App.Items.Any(i=>i.Id==id)),"extreme plan has only unique implemented IDs");
  Assert(!allowed.Any(id=>OptionInfo.For(App.Items.Single(i=>i.Id==id)).Risk=="Alto"),"extreme excludes high-risk system security switches");
  ExpectFailure(()=>ExtremeProfile.Resolve("opt-disablesmartscreen"),"extreme endpoint refuses smuggled risky option");ExpectFailure(()=>ExtremeProfile.Resolve("extra-memory-compression"),"extreme endpoint refuses experimental memory setting");
  foreach(string edition in new[]{"Core","Professional","Enterprise","Education"})foreach(int build in new[]{19045,22631,26200}){
   FullCatalog();App.TestMachine.Edition=edition;App.TestMachine.Build=build;
   foreach(var item in App.Items)foreach(var op in item.Operations??new RegOp[0])if(op.Key.StartsWith(@"SYSTEM\CurrentControlSet\Services\",StringComparison.OrdinalIgnoreCase)){var before=Copy(op);before.Data="3";registry[Key(op)]=before;}
   var beforeRegistry=registry.ToDictionary(x=>x.Key,x=>Copy(x.Value));var beforeNative=new Dictionary<string,string>(native);
   var profile=ExtremeProfile.Resolve(String.Join(",",allowed));App.UniqueOperations(profile);App.ApplyTransaction(profile,"Perfil","Teste extremo "+edition+build);var record=Last();
   Assert(record.Status=="aplicado"&&record.Steps.Count==allowed.Length,"all extreme steps logged on "+edition+build);
   App.Undo(record.Id);Assert(registry.Count==beforeRegistry.Count&&beforeRegistry.All(x=>registry[x.Key].Data==x.Value.Data)&&beforeNative.All(x=>native[x.Key]==x.Value),"extreme exact undo on "+edition+build);
  }
  FullCatalog();bool backupBeforeWrite=false;var writer=App.TestWrite;App.TestWrite=o=>{backupBeforeWrite=App.History().Any(r=>r.ChangesStarted&&r.Values.Count>0);writer(o);};App.ApplyMany(new[]{"native-capture"});Assert(backupBeforeWrite,"durable backup exists before first registry write");
  FullCatalog();failReadback=true;ExtremeProfile.Apply("native-window,native-gamemode,native-capture");Assert(Last().Status=="aplicado"&&native["window"]=="0"&&registry.Count==3,"extreme failure restores only failing option, preserving successes");
  FullCatalog();App.ApplyMany(new[]{"native-window","native-capture","native-transparency"});var prior=Last();var restore=App.RestoreSelectionItems(prior.Id+"|native-window,native-capture");App.ApplyTransaction(restore,"Perfil","Restaurar seleção");var restoration=Last();Assert(native["window"]=="1"&&registry.Count==1&&registry.Values.Single().Name=="EnableTransparency","selective restore changes only selected settings");App.Undo(restoration.Id);Assert(native["window"]=="0"&&registry.Count==4,"selective restore is itself reversible");
  App.Undo(prior.Id);Assert(registry.Count==0&&native["window"]=="1","original full backup remains usable after undoing selective restoration");
  FullCatalog();App.ApplyMany(new[]{"native-capture"});prior=Last();registry.Values.First().Data="123";ExpectFailure(()=>App.RestoreSelectionItems(prior.Id+"|native-capture"),"selective restore protects later external values");Assert(registry.Values.Any(x=>x.Data=="123"),"later external value preserved");
  ExpectFailure(()=>App.RestoreSelectionItems(prior.Id+"|native-window"),"restore rejects settings absent from selected backup");
  FullCatalog();App.ApplyMany(new[]{"native-power","native-window"});prior=Last();App.TestMachine.NoBattery=false;App.ApplyTransaction(App.RestoreSelectionItems(prior.Id+"|native-power"),"Perfil","Restaurar energia");Assert(active!=""&&active!=App.HighPlan,"power restoration does not force high-performance compatibility rules");
  FullCatalog();foreach(var i in App.Items){var m=OptionInfo.For(i);Assert(!String.IsNullOrWhiteSpace(m.Risk)&&!String.IsNullOrWhiteSpace(m.Undo)&&!String.IsNullOrWhiteSpace(m.Restart),"metadata complete: "+i.Id);}
  FullCatalog();var selected=ExtremeProfile.Resolve("native-window");var skipped=ExtremeProfile.Skipped(selected);Assert(skipped.Count==779&&skipped.All(x=>x.Status=="ignorado"&&!String.IsNullOrWhiteSpace(x.Message)),"every nonselected catalog entry has an explicit skipped reason");
  ExtremeProfile.Apply("native-window");Assert(Last().Steps.Count==780&&Last().Steps.Count(x=>x.Status=="ignorado")==779,"extreme persists ignored entries alongside applied result");
  var idle=new NetworkCapture{Host="test",Address="192.0.2.1",AdapterReport="a",Environment="repouso",Samples=new List<double?>{10,20}};var load=new NetworkCapture{Host="test",Address="192.0.2.1",AdapterReport="a",Environment="carga",Samples=new List<double?>{50,60}};
  Assert(NetworkWorkbench.CompareLoad(idle,load).Contains("+40"),"loaded latency comparison derives actual difference");load.AdapterReport="changed";Assert(NetworkWorkbench.CompareLoad(idle,load).Contains("suspensa"),"loaded latency comparison rejects changed adapter");Assert(NetworkWorkbench.CompareLoad(null,null).Contains("não gera tráfego pesado"),"bufferbloat instructions disclose manually generated load");
  ExpectFailure(()=>NetworkWorkbench.Route("https://example.com",System.Threading.CancellationToken.None).GetAwaiter().GetResult(),"route rejects URL before probing");ExpectFailure(()=>NetworkWorkbench.Route("127.0.0.1",new System.Threading.CancellationToken(true)).GetAwaiter().GetResult(),"cancelled route does not send packets");
  Assert(Summary(10,20,40).MinimumFps==25,"minimum instantaneous FPS is inverse worst frametime");
  Reset();
 }
}

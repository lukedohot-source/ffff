﻿using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Windows.Forms;
public partial class MainForm {
 internal void TestProduct(string folder){
  if(pages.Count!=27||nav.Count!=9||homeChecks.Count!=131||App.Items.Count!=673)throw new Exception("v6 preserved inventory mismatch");
  if(memoryAutomatic.Checked||storageCategories.CheckedItems.Count!=0)throw new Exception("v6 new operations must be opt-in");
  footer.Text="TESTE DE INTERFACE · sem otimizações reais";
  // Era "!=8", número congelado quando havia 8 categorias; hoje StorageManager traz 14
  // e o teste falhava por desatualização. A invariante é a grade refletir o catálogo.
  if(storageCategories.Items.Count!=StorageManager.Categories().Count||memoryInterval.Minimum<1)throw new Exception("v6 module controls missing");
  TestVisibility();
  string[] targets={"Painel","Memory Manager","Temporários","Avançado / Alto Impacto","Resultados","Configurações"};
  foreach(var size in new[]{new Size(1080,720),new Size(1920,1080),new Size(2560,1440)}){
   Size=size;foreach(string target in targets){ShowPage(target);PerformLayout();Application.DoEvents();if(pages[target].ClientSize.Width<700||pages[target].Height<460)throw new Exception("v6 collapsed page "+target);
    foreach(var control in pages[target].Controls.Cast<Control>())if(control.Width<=0||control.Height<=0)throw new Exception("v6 invisible root "+target);
    using(var bitmap=new Bitmap(Width,Height)){DrawToBitmap(bitmap,new Rectangle(Point.Empty,Size));bitmap.Save(Path.Combine(folder,"v6-"+size.Width+"-"+Array.IndexOf(targets,target)+".png"));}
   }
  }
  ShowPage("Configurações");homeChecks["native-window"].Checked=true;((Button)Controls.Find("profile-save",true).Single()).PerformClick();homeChecks["native-window"].Checked=false;((Button)Controls.Find("profile-load",true).Single()).PerformClick();if(!homeChecks["native-window"].Checked)throw new Exception("v6 saved selection not restored");
  homeSearch.Text="mouse";if(homeChecks.Count!=131||!homeChecks["native-window"].Checked)throw new Exception("v6 search loses selections");homeSearch.Clear();homeRisk.SelectedItem="Alto";if(homeChecks.Count!=131)throw new Exception("v6 risk filter removes options");homeRisk.SelectedIndex=0;
  productPrefs.Compact=false;BuildHomeCards();if(homeChecks.Count!=131||!homeChecks["native-window"].Checked)throw new Exception("v6 density rebuild loses choices");productPrefs.Compact=true;BuildHomeCards();
  ShowPage("Avançado / Alto Impacto");var advanced=(CatalogList)Controls.Find("advanced-options",true).Single();advanced.Items[0].Selected=true;Application.DoEvents();if(!advancedInfo.Text.Contains("Backup:")||!advancedInfo.Text.Contains("Reversão:")||!advancedInfo.Text.Contains("Risco:"))throw new Exception("v6 advanced explanation missing");
  // Exercise WinForms layout scaling separately from real monitor DPI, which requires a VM/manual test.
  Size=new Size(1920,1080);Scale(new SizeF(1.25f,1.25f));PerformLayout();ShowPage("Temporários");Application.DoEvents();if(storageFiles.Height<100)throw new Exception("v6 scaled cleanup preview collapsed");
  using(var bitmap=new Bitmap(Width,Height)){DrawToBitmap(bitmap,new Rectangle(Point.Empty,Size));bitmap.Save(Path.Combine(folder,"v6-layout-scale125.png"));}
  Console.WriteLine("V6 UI passed: six new pages; 1080x720, 1920x1080, 2560x1440; synthetic layout scale 125%; profiles, density, opt-in and advanced descriptions. Actual monitor DPI requires manual validation.");
 }
 // Contar controles na árvore — como o teste de inventário faz — não detecta um pai com
 // Visible=false, que foi exatamente como a grade de 131 opções sumiu em 6.1.2.
 //
 // Control.Visible é EFETIVO: percorre os pais até o Form. A janela do smoke test nunca
 // é exibida, então uma asserção absoluta daria falso negativo para tudo. A comparação
 // é feita contra um controle-referência da mesma página que nunca foi escondido: se a
 // referência está visível, os demais têm de estar. Quando a janela não está realizada
 // a referência também é falsa e a checagem não acusa nada — nunca há falso positivo.
 // A asserção absoluta exige exibir a janela no UiSmoke; validar isso no Windows antes.
 static void SameVisibility(Control baseline,Control control,string message){
  if(baseline.Visible&&!control.Visible)throw new Exception(message);
 }
 internal void TestVisibility(){
  ShowPage("Otimizações");PerformLayout();Application.DoEvents();
  var reference=(Button)Controls.Find("home-apply",true).Single();   // nunca teve Visible=false
  SameVisibility(reference,homeFlow,"6.2 a grade de opções está invisível (regressão de 6.1.2)");
  SameVisibility(reference,homeSearch,"6.2 a busca de opções está invisível");
  SameVisibility(reference,homeRisk,"6.2 o filtro de risco está invisível");
  SameVisibility(reference,homeCount,"6.2 o contador de seleção está invisível");
  SameVisibility(reference,homeAdvanced,"6.2 a caixa de opções avançadas está invisível");

  // Independente de a janela estar exibida: o filtro é estado próprio, não Control.Visible.
  bool advancedBefore=homeAdvanced.Checked;
  homeAdvanced.Checked=false;PerformLayout();Application.DoEvents();
  int curated=homeChecks.Count-hiddenHome.Count;
  if(curated<8)throw new Exception("6.2 apenas "+curated+" opção(ões) na lista curada");
  if(hiddenHome.Count==0)throw new Exception("6.2 a caixa de opções avançadas não filtra nada");
  homeAdvanced.Checked=true;PerformLayout();Application.DoEvents();
  int all=homeChecks.Count-hiddenHome.Count;
  if(all!=homeChecks.Count)throw new Exception("6.2 opções avançadas marcadas ainda escondem itens ("+all+")");
  if(all<=curated)throw new Exception("6.2 a caixa de opções avançadas não amplia a lista ("+curated+" -> "+all+")");
  homeAdvanced.Checked=advancedBefore;PerformLayout();Application.DoEvents();

  ShowPage("Temporários");PerformLayout();Application.DoEvents();
  reference=(Button)Controls.Find("cleanup-oneclick",true).Single();
  SameVisibility(reference,cleanupAge,"6.2 o seletor de idade mínima está invisível");
  SameVisibility(reference,storageFiles,"6.2 a prévia de limpeza está invisível");
  if(cleanupAge.Value<1)throw new Exception("6.2 a limpeza de um clique ficou sem filtro de idade");
  int categoryChecks=CountChecks(pages["Temporários"],reference.Visible);
  if(categoryChecks<StorageManager.Categories().Count)throw new Exception("6.2 as categorias de limpeza estão invisíveis ("+categoryChecks+")");

  ShowPage("Memory Manager");PerformLayout();Application.DoEvents();
  reference=(Button)Controls.Find("memory-oneclick",true).Single();
  SameVisibility(reference,memoryList,"6.2 a lista de processos está invisível");
  SameVisibility(reference,memoryInterval,"6.2 o intervalo do modo automático está invisível");
 }
 // Com a janela realizada exige visibilidade efetiva; sem ela, conta a presença na árvore.
 static int CountChecks(Control parent,bool realized){
  int total=0;
  if(parent is CheckBox&&(!realized||parent.Visible))total++;
  foreach(Control child in parent.Controls)total+=CountChecks(child,realized);
  return total;
 }
}

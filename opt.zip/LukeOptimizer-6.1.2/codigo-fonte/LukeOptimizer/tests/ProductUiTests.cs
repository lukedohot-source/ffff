﻿using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Windows.Forms;
public partial class MainForm {
 internal void TestProduct(string folder){
  if(pages.Count!=27||nav.Count!=9||homeChecks.Count!=131||App.Items.Count!=673)throw new Exception("v6 preserved inventory mismatch");
  if(memoryAutomatic.Checked||storageCategories.CheckedItems.Count!=0)throw new Exception("v6 new operations must be opt-in");
  footer.Text="TESTE DE INTERFACE · sem otimizações reais";
  if(storageCategories.Items.Count!=8||memoryInterval.Minimum<1)throw new Exception("v6 module controls missing");
  string[] targets={"Painel","Memory Manager","Temporários","Avançado / Alto Impacto","Resultados","Configurações"};
  foreach(var size in new[]{new Size(1080,720),new Size(1920,1080),new Size(2560,1440)}){
   Size=size;foreach(string target in targets){ShowPage(target);PerformLayout();Application.DoEvents();if(pages[target].ClientSize.Width<700||pages[target].Height<460)throw new Exception("v6 collapsed page "+target);
    foreach(var control in pages[target].Controls.Cast<Control>())if(control.Width<=0||control.Height<=0)throw new Exception("v6 invisible root "+target);
    using(var bitmap=new Bitmap(Width,Height)){DrawToBitmap(bitmap,new Rectangle(Point.Empty,Size));bitmap.Save(Path.Combine(folder,"v6-"+size.Width+"-"+Array.IndexOf(targets,target)+".png"));}
   }
  }
  ShowPage("Configurações");homeChecks["native-window"].Checked=true;((Button)Controls.Find("profile-save",true).Single()).PerformClick();homeChecks["native-window"].Checked=false;((Button)Controls.Find("profile-load",true).Single()).PerformClick();if(!homeChecks["native-window"].Checked)throw new Exception("v6 saved selection not restored");
  homeSearch.Text="mouse";if(homeChecks.Count!=131||!homeChecks["native-window"].Checked)throw new Exception("v6 search loses selections");homeSearch.Clear();homeRisk.SelectedItem="Alto";if(homeChecks.Count!=131)throw new Exception("v6 risk filter removes options");homeRisk.SelectedIndex=0;
  productPrefs.Compact=false;BuildHomeCards();if(homeChecks.Count!=131||!homeChecks["native-window"].Checked)throw new Exception("v6 density rebuild loses choices");productPrefs.Compact=true;BuildHomeCards();
  ShowPage("Avançado / Alto Impacto");var advanced=(CatalogList)Controls.Find("advanced-options",true).Single();advanced.Items[0].Selected=true;Application.DoEvents();if(!advancedInfo.Text.Contains("Backup:")||!advancedInfo.Text.Contains("Reversão:")||!advancedInfo.Text.Contains("Risco:"))throw new Exception("v6 advanced explanation missing");
  // Exercise WinForms layout scaling separately from real monitor DPI, which requires a VM/manual test.
  Size=new Size(1920,1080);Scale(new SizeF(1.25f,1.25f));PerformLayout();ShowPage("Temporários");Application.DoEvents();if(storageFiles.Height<100)throw new Exception("v6 scaled cleanup preview collapsed");
  using(var bitmap=new Bitmap(Width,Height)){DrawToBitmap(bitmap,new Rectangle(Point.Empty,Size));bitmap.Save(Path.Combine(folder,"v6-layout-scale125.png"));}
  Console.WriteLine("V6 UI passed: six new pages; 1080x720, 1920x1080, 2560x1440; synthetic layout scale 125%; profiles, density, opt-in and advanced descriptions. Actual monitor DPI requires manual validation.");
 }
}

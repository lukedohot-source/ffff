using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

// FASE 2 — testes da fundação.
//
// Dois tipos de teste aqui. Os primeiros conferem REGRAS (dedução de evidência, motor de
// compatibilidade, acúmulo de reinício) com dados construídos à mão. Os últimos conferem
// INVARIANTES sobre o catálogo real que o produto carrega — é o que impede um cadastro
// novo de entrar sem fonte, sem custo declarado ou marcado como automático sendo
// experimental.
partial class EngineTests {
 static MachineProfile Pc(){
  return new MachineProfile{
   Windows=true,Build=26100,Is64=true,
   CpuName="AMD Ryzen 7 5800X",CpuVendor="AMD",PhysicalCores=8,LogicalCores=16,CoresKnown=true,Smt=true,SmtKnown=true,
   GpuName="NVIDIA GeForce RTX 4070",GpuVendor="NVIDIA",
   RamBytes=34359738368L,RamTier="alta",RamKnown=true,
   SystemDriveMedia="NVMe",StorageKnown=true,
   Portable=false,PortableKnown=true,Chassis="Desktop",
   OnAC=true,BatteryPresent=false,PowerKnown=true
  };
 }
 static OptimizationDescriptor Desc(OptimizationRequirements r,string stage){
  return new OptimizationDescriptor{Id="fixture",Title="Fixture",Effect="e",Tradeoff="t",
   EvidenceLevel=Evidence.Microsoft,Confidence=Evidence.High,StageName=stage??Stage.Stable,
   Restart=RestartScope.None,Requirements=r??new OptimizationRequirements(),
   BackupStrategy="SavedValue",Source="https://learn.microsoft.com/"};
 }

 static void RunFoundationTests(){
  Reset();

  // ---------------------------------------------------------------- evidência
  // O nível sai da fonte declarada no item. Mesma URL, sempre o mesmo nível.
  Func<string,string,Item> item=delegate(string id,string url){return new Item{Id=id,Name=id,ReviewTitle=id,Native=true,Url=url,Operations=new RegOp[0],Review=new[]{"efeito","custo"}};};
  Assert(Evidence.Level(item("a","https://learn.microsoft.com/x"),null)==Evidence.Microsoft,"Microsoft Learn is recognized as Microsoft documentation");
  Assert(Evidence.Level(item("b","https://support.microsoft.com/x"),null)==Evidence.Microsoft,"Microsoft support article is Microsoft documentation");
  Assert(Evidence.Level(item("c","https://www.nvidia.com/x"),null)==Evidence.Vendor,"NVIDIA documentation is vendor documentation");
  Assert(Evidence.Level(item("d","https://chromeenterprise.google/policies/x"),null)==Evidence.Vendor,"browser vendor policy documentation is vendor documentation");
  // O ponto que mais importa: projeto de terceiro no GitHub NÃO vira "tecnicamente
  // justificada". Ele recebe rótulo próprio, porque é isso que ele é.
  Assert(Evidence.Level(item("e","https://github.com/algum/optimizer"),null)==Evidence.OpenSource,"third-party GitHub project gets its own evidence label, not a flattering one");
  Assert(Evidence.Level(item("f","https://github.com/microsoft/WindowsDeveloperConfig"),null)==Evidence.Microsoft,"Microsoft publishing code on GitHub is still Microsoft documentation");
  Assert(Evidence.Level(item("g",""),null)==Evidence.Convenience,"an option without a source is convenience, never technical justification");
  Assert(Evidence.Level(item("opt-disablenetworkthrottling","https://learn.microsoft.com/x"),null)==Evidence.Experimental,"a Microsoft source does not make NetworkThrottlingIndex measured");
  Assert(Evidence.Level(item("opt-disablesmartscreen","https://learn.microsoft.com/x"),null)==Evidence.NotRecommended,"a Microsoft source does not make disabling SmartScreen recommended");

  // Confiança e risco são eixos diferentes: um item bem documentado pode ser perigoso.
  Assert(Evidence.Confidence(Evidence.Microsoft)==Evidence.High&&Evidence.Confidence(Evidence.NotRecommended)==Evidence.Medium,"confidence describes the evidence, not the damage");
  Assert(Evidence.Confidence(Evidence.Experimental)==Evidence.Low,"an experimental option never claims high confidence");
  Assert(Evidence.Levels.Distinct().Count()==Evidence.Levels.Length,"evidence levels are unique");

  // ---------------------------------------------------------------- estágio
  Assert(Stage.AutomaticAllowed(Stage.Stable)&&!Stage.AutomaticAllowed(Stage.Beta)&&!Stage.AutomaticAllowed(Stage.Experimental)&&!Stage.AutomaticAllowed(Stage.Developer),"only a stable option may enter an automatic profile");
  Assert(Stage.Of(Evidence.Experimental)==Stage.Experimental&&Stage.Of(Evidence.NotRecommended)==Stage.Developer&&Stage.Of(Evidence.Microsoft)==Stage.Stable,"stage follows evidence");

  // ---------------------------------------------------------------- compatibilidade
  var pc=Pc();
  Assert(CompatibilityEngine.Evaluate(Desc(null,null),pc).State==CompatibilityEngine.Compatible,"an option without requirements is compatible on a detected PC");
  Assert(CompatibilityEngine.Evaluate(Desc(null,null),null).State==CompatibilityEngine.Undetected,"without a machine reading nothing is declared compatible");
  Assert(CompatibilityEngine.Evaluate(Desc(null,null),new MachineProfile()).State==CompatibilityEngine.Undetected,"a profile without Windows is undetected, not incompatible");

  Assert(CompatibilityEngine.Evaluate(Desc(new OptimizationRequirements{MinBuild=22000},null),pc).State==CompatibilityEngine.Compatible,"build 26100 satisfies a Windows 11 requirement");
  var win10=Pc();win10.Build=19045;
  Assert(CompatibilityEngine.Evaluate(Desc(new OptimizationRequirements{MinBuild=22000},null),win10).State==CompatibilityEngine.Incompatible,"a Windows 11 option is incompatible on Windows 10");
  Assert(CompatibilityEngine.Evaluate(Desc(new OptimizationRequirements{MaxBuild=21999},null),pc).State==CompatibilityEngine.Incompatible,"an option removed in Windows 11 is incompatible there");
  var noBuild=Pc();noBuild.Build=0;
  Assert(CompatibilityEngine.Evaluate(Desc(new OptimizationRequirements{MinBuild=22000},null),noBuild).State==CompatibilityEngine.Undetected,"an unread build is undetected, never assumed good");

  // "Não detectado" é a resposta central deste motor: NUNCA vira compatível por otimismo.
  var noVendor=Pc();noVendor.GpuVendor="";
  Assert(CompatibilityEngine.Evaluate(Desc(new OptimizationRequirements{GpuVendor="NVIDIA"},null),noVendor).State==CompatibilityEngine.Undetected,"an unidentified GPU vendor is undetected, not compatible");
  Assert(CompatibilityEngine.Evaluate(Desc(new OptimizationRequirements{GpuVendor="AMD"},null),pc).State==CompatibilityEngine.Incompatible,"an AMD-only option is incompatible on an NVIDIA PC");
  Assert(CompatibilityEngine.Evaluate(Desc(new OptimizationRequirements{CpuVendor="AMD"},null),pc).State==CompatibilityEngine.Compatible,"a CPU vendor requirement matches the detected vendor");

  var hdd=Pc();hdd.SystemDriveMedia="HD";
  Assert(CompatibilityEngine.Evaluate(Desc(new OptimizationRequirements{StorageMedia="SSD"},null),hdd).State==CompatibilityEngine.Incompatible,"an SSD option is incompatible on a mechanical drive");
  var unknownMedia=Pc();unknownMedia.SystemDriveMedia="";
  Assert(CompatibilityEngine.Evaluate(Desc(new OptimizationRequirements{StorageMedia="SSD"},null),unknownMedia).State==CompatibilityEngine.Undetected,"an unrecognized media type never passes as SSD");

  var laptop=Pc();laptop.Portable=true;laptop.Chassis="Notebook";
  Assert(CompatibilityEngine.Evaluate(Desc(new OptimizationRequirements{RequiresDesktop=true},null),laptop).State==CompatibilityEngine.Incompatible,"a desktop-only option is refused on a notebook");
  var battery=Pc();battery.OnAC=false;
  Assert(CompatibilityEngine.Evaluate(Desc(new OptimizationRequirements{RequiresAC=true},null),battery).State==CompatibilityEngine.Incompatible,"an option that requires mains power is refused on battery");
  var smallRam=Pc();smallRam.RamBytes=4294967296L;
  Assert(CompatibilityEngine.Evaluate(Desc(new OptimizationRequirements{MinRamBytes=8589934592L},null),smallRam).State==CompatibilityEngine.Incompatible,"a RAM requirement is enforced");

  // Compatível não é recomendado: experimental continua experimental no PC perfeito.
  var experimental=CompatibilityEngine.Evaluate(Desc(null,Stage.Experimental),pc);
  Assert(experimental.State==CompatibilityEngine.Experimental&&experimental.Reason.Contains("sem medição"),"an experimental option stays experimental even on a fully compatible PC");
  Assert(!CompatibilityEngine.Evaluate(Desc(new OptimizationRequirements{RequiresDesktop=true},null),laptop).Executable(),"an incompatible option cannot be executed");
  Assert(!CompatibilityEngine.Evaluate(Desc(new OptimizationRequirements{GpuVendor="NVIDIA"},null),noVendor).Executable(),"an undetected requirement blocks execution just like an incompatible one");
  Assert(CompatibilityEngine.Evaluate(Desc(null,Stage.Experimental),pc).Executable(),"an experimental option may still be executed when explicitly chosen");

  // ---------------------------------------------------------------- perfil da máquina
  Assert(App.CpuVendorOf("AMD Ryzen 7 5800X")=="AMD"&&App.CpuVendorOf("Intel(R) Core(TM) i7-12700K")=="Intel","CPU vendor read from the product name");
  Assert(App.CpuVendorOf("")==""&&App.CpuVendorOf("Processador Genérico")=="","an unrecognized CPU has no vendor instead of a guessed one");
  Assert(App.GpuVendorOf("NVIDIA GeForce RTX 4070")=="NVIDIA"&&App.GpuVendorOf("AMD Radeon RX 7800 XT")=="AMD"&&App.GpuVendorOf("Intel(R) UHD Graphics 770")=="Intel","GPU vendor read from the product name");
  Assert(App.GpuVendorOf("Adaptador de Vídeo Básico")=="","an unrecognized GPU has no vendor instead of a guessed one");
  Assert(App.RamTierOf(0)==""&&App.RamTierOf(4294967296L)=="baixa"&&App.RamTierOf(17179869184L)=="média"&&App.RamTierOf(34359738368L)=="alta","RAM tier boundaries; unread RAM has no tier");
  // MediaType 0 e 1 significam "não especificado"/"desconhecido" e NÃO podem virar SSD.
  Assert(App.MediaTypeName(4,0)=="SSD"&&App.MediaTypeName(3,0)=="HD"&&App.MediaTypeName(3,17)=="NVMe","documented MSFT_PhysicalDisk media and bus types");
  Assert(App.MediaTypeName(0,0)==""&&App.MediaTypeName(1,0)=="","unspecified or unknown media type never becomes SSD");
  Assert(App.PortableChassisType(10)&&App.PortableChassisType(31)&&!App.PortableChassisType(3)&&!App.PortableChassisType(7),"SMBIOS chassis codes distinguish portable from desktop");
  var empty=new MachineProfile();
  Assert(!empty.CpuIsIntel()&&!empty.CpuIsAmd()&&!empty.GpuIsNvidia()&&!empty.SolidState(),"an empty profile claims nothing");
  string report=App.ProfileReport(empty);
  Assert(report.Contains("não detectado")&&!report.Contains("não detectadonão"),"the profile report says what was not detected instead of leaving a blank");
  Assert(App.ProfileReport(pc).Contains("8 núcleos / 16 threads")&&App.ProfileReport(pc).Contains("NVMe"),"the profile report states what was actually read");

  // ---------------------------------------------------------------- reinício
  Assert(RestartScope.For(new Item{Operations=new[]{new RegOp{Hive="HKEY_LOCAL_MACHINE",Key=@"SYSTEM\CurrentControlSet\Control\X",Name="n"}}})==RestartScope.Windows,"a write under HKLM\\SYSTEM requires restarting Windows");
  Assert(RestartScope.For(new Item{Operations=new[]{new RegOp{Hive="HKEY_CURRENT_USER",Key=@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced",Name="n"}}})==RestartScope.Explorer,"an Explorer write needs Explorer reopened");
  Assert(RestartScope.For(new Item{Operations=new RegOp[0]})==RestartScope.None,"an option with no registry write declares no restart");
  var plan=RestartScope.Aggregate(new[]{
   new OptimizationDescriptor{Restart=RestartScope.Explorer},
   new OptimizationDescriptor{Restart=RestartScope.Windows},
   new OptimizationDescriptor{Restart=RestartScope.SignOut}});
  // O ponto do item 43: pedir reinício UMA vez, pelo escopo mais forte, não uma vez por opção.
  Assert(plan.WindowsRestart&&plan.Text().Contains("Reinicie o Windows")&&!plan.Text().Contains("Explorador"),"a mixed batch asks for the strongest restart once, not once per option");
  Assert(!RestartScope.Aggregate(new OptimizationDescriptor[0]).Any()&&RestartScope.Aggregate(null).Text().Contains("Nenhum"),"an empty batch asks for no restart");

  // ---------------------------------------------------------------- catálogo real
  FullCatalog();
  OptimizationRegistry.Invalidate();
  OptimizationRegistry.Validate();
  Assert(true,"every registered optimization satisfies the contract invariants");
  var all=OptimizationRegistry.All();
  Assert(all.Count==CatalogIds.NativeItems().Count(),"one descriptor per executable optimization, no more and no less");
  Assert(all.All(d=>d.Reversible&&d.BackupStrategy.Length>0),"a reversible optimization cannot exist without a backup strategy");
  Assert(all.All(d=>d.Source.StartsWith("https://")||d.EvidenceLevel==Evidence.Convenience),"every optimization beyond plain convenience carries a technical source");
  Assert(all.All(d=>!String.IsNullOrWhiteSpace(d.Effect)&&!String.IsNullOrWhiteSpace(d.Tradeoff)),"every optimization states both what it does and what it costs");
  Assert(!all.Any(d=>d.AutomaticEligible&&(d.EvidenceLevel==Evidence.Experimental||d.EvidenceLevel==Evidence.NotRecommended)),"no experimental or discouraged optimization is part of an automatic profile");
  Assert(all.Count(d=>d.EvidenceLevel==Evidence.OpenSource)>0,"options adapted from an open-source project are labelled as such and counted");
  Assert(all.Any(d=>d.Tags.Contains("experimental"))&&all.Any(d=>d.Tags.Contains("administrador")),"search tags are derived from the option itself");

  // A tabela de requisitos não repete números: ela lê os que ImportedOptions e V5Options
  // já declaram. Se alguém mudar a faixa lá, isto acompanha sozinho.
  var importedRule=ImportedOptions.Rules().FirstOrDefault(r=>r.Minimum>10240);
  if(importedRule!=null){
   var mirrored=OptimizationRegistry.For(importedRule.Id);
   Assert(mirrored!=null&&mirrored.Requirements.MinBuild==importedRule.Minimum,"a build requirement is read from the rule that already declares it, not retyped");
  }

  // O perfil automático coincide com os grupos marcados — e nenhum grupo vazio promete nada.
  foreach(var group in ExtremeProfile.Groups())
   Assert(!(group.Empty()&&group.Selected),"an Ultra group with no eligible option can never come selected: "+group.Id);
  Assert(ExtremeProfile.Groups().Any(g=>g.Empty()),"groups kept to explain an absence still exist");
  foreach(var group in ExtremeProfile.Groups().Where(g=>g.Empty()))
   Assert(group.Effect.StartsWith("NENHUMA opção"),"an empty group states the absence in its own text: "+group.Id);

  // Score é contagem de recomendações, jamais nota de desempenho.
  string none=OptimizationRegistry.Score(Pc(),delegate(string id){return false;});
  string every=OptimizationRegistry.Score(Pc(),delegate(string id){return true;});
  Assert(none.Contains("NÃO é benchmark")||none.Contains("não é uma nota"),"the score always says it is not a benchmark");
  Assert(every.Contains("/")&&every.Split(new[]{'/'})[0]!="0","applied recommendations are counted");
  Assert(OptimizationRegistry.Score(null,null).Length>0,"the score never throws without a machine reading");

  // Ficha do botão "O que isso faz?": tudo que o pedido exige, em um texto só.
  string details=OptimizationRegistry.Details("native-window",Pc());
  foreach(string required in new[]{"O que muda","Possível desvantagem","Evidência","Confiança","Risco","Compatibilidade neste PC","administrador","Reinício","Como será restaurado","Fonte técnica","ID preservado"})
   Assert(details.Contains(required),"the details sheet answers: "+required);
  Assert(OptimizationRegistry.Details("nao-existe",Pc()).Contains("não encontrada"),"an unknown id is reported instead of throwing");

  // O catálogo importado de .reg/.bat é REVISÃO, não execução: os tweaks de placebo
  // conhecidos (LargeSystemCache, DisablePagingExecutive, IoPageLockLimit, TcpAckFrequency,
  // SvcHostSplitThresholdInKB, HwSchMode) aparecem lá e NÃO viram opção executável.
  var executableNames=new HashSet<string>(CatalogIds.NativeItems()
   .SelectMany(i=>i.Operations??new RegOp[0]).Select(o=>o.Name??"").Where(n=>n.Length>0),StringComparer.OrdinalIgnoreCase);
  foreach(string placebo in new[]{"LargeSystemCache","DisablePagingExecutive","IoPageLockLimit","TcpAckFrequency","TCPNoDelay","SvcHostSplitThresholdInKB","HwSchMode","Win32PrioritySeparation","SystemResponsiveness"})
   Assert(!executableNames.Contains(placebo),"a well-known placebo tweak is catalogued for reading but never executable: "+placebo);
  Assert(executableNames.Contains("NetworkThrottlingIndex"),"NetworkThrottlingIndex is executable, which is exactly why it must be labelled experimental");
  Assert(OptimizationRegistry.For("opt-disablenetworkthrottling").EvidenceLevel==Evidence.Experimental,"the one executable throttling tweak carries the experimental label");

  Reset();
 }
}

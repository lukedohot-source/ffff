using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
class ReadOnlySmoke {
 static int Main(string[] args){
  try{
   string directory=Path.GetFullPath(args.Length==0?"read-only-smoke":args[0]);Directory.CreateDirectory(directory);
   var machine=App.ScanHardware();Console.WriteLine("Windows build detected: "+machine.Build+"; CPU/GPU/RAM metadata queried.");
   string plan=App.ActivePlan();int ok=0;foreach(var option in PowerTuning.Options)try{string state=PowerTuning.Read(PowerTuning.Code(plan,option.Id));Console.WriteLine("READ AC "+option.Id+" = "+state);ok++;}catch(Exception e){Console.WriteLine("READ unavailable "+option.Id+": "+e.Message);}
   var sample=ResourceMonitor.Measure(300);if(!sample.CpuKnown||!sample.MemoryKnown)throw new Exception("CPU/RAM measurement unavailable");Console.WriteLine("Read-only CPU and RAM measurement succeeded.");
   var report=HardwareLab.Report();File.WriteAllText(Path.Combine(directory,"hardware-local.txt"),report,new UTF8Encoding(false));Console.WriteLine("Hardware diagnostic sections generated: "+report.Split(new[]{"──"},StringSplitOptions.None).Length+" delimiters.");
   Console.WriteLine("Read-only smoke complete; "+ok+"/6 AC indexes readable. No registry writes, no power writes, no app closure, no ping, no service changes.");return 0;
  }catch(Exception e){Console.WriteLine(e);return 1;}
 }
}

﻿using System;
using System.Linq;
using System.Collections.Generic;
partial class EngineTests {
 static void RunV54Tests(){
  FullCatalog();CatalogIds.Validate();
  // 127 nativos antes da integração das referências; ela só acrescenta, nunca remove.
  Assert(CatalogIds.NativeItems().Count==127+WindowsSettings.AsCatalogItems().Count,"the 127 original native IDs are retained and the integration only adds");
  foreach(var item in App.Items.Where(i=>(i.Operations??new RegOp[0]).Any(App.IsPolicy)))Assert(OptionInfo.For(item).Classification=="Manual"&&!OptionInfo.For(item).Automatic,"policy manual and never automatic: "+item.Id);
  Assert(!ExtremeProfile.Groups().SelectMany(g=>g.Items).Select(id=>App.Items.Single(i=>i.Id==id)).Any(i=>(i.Operations??new RegOp[0]).Any(o=>App.IsPolicy(o)||o.Hive=="HKEY_LOCAL_MACHINE")),"extreme allowlist has no protected policy or machine registry/service writes");
  ExpectFailure(()=>ExtremeProfile.Resolve("opt-disablefaxservice"),"extreme rejects legacy optional service");
  FullCatalog();App.TestAccess=o=>{if(o.Key==@"Software\Microsoft\GameBar")throw new UnauthorizedAccessException("ACL denied");};
  ExtremeProfile.Apply("native-window,native-gamemode,native-capture");var record=Last();
  Assert(record.Status=="aplicado"&&native["window"]=="0"&&registry.Count==3,"preflight skips denied item and applies compatible items");
  Assert(!record.Evidence.Any(e=>e.ItemId=="native-gamemode"&&e.WriteAttempted)&&record.Steps.Single(s=>s.Id=="native-gamemode").Status=="ignorado","denied item never starts writes and has a skipped history entry");
  App.Undo(record.Id);Assert(native["window"]=="1"&&registry.Count==0,"one undo restores whole successful isolated batch");
  FullCatalog();App.TestAccess=o=>{if(o.Key==@"Software\Microsoft\GameBar")throw new UnauthorizedAccessException("ACL denied");};
  App.ApplyMany(new[]{"native-window","native-gamemode","native-capture"});record=Last();
  Assert(record.Status=="aplicado"&&native["window"]=="0"&&registry.Count==3,"custom transaction skips denied item and applies compatible items");
  Assert(record.Steps.Single(s=>s.Id=="native-gamemode").Status=="ignorado"&&record.ChangesStarted,"custom transaction records denied item and continues");
  App.Undo(record.Id);Assert(native["window"]=="1"&&registry.Count==0,"custom transaction undo restores successful changes");
  FullCatalog();failReadback=true;ExtremeProfile.Apply("native-window,native-gamemode,native-capture");record=Last();
  Assert(record.Status=="aplicado"&&native["window"]=="0"&&registry.Count==3,"silent refusal rolls back only failing child and continues");
  Assert(record.IsolatedSteps.Count==3&&record.IsolatedSteps[1].Status=="falhou e foi desfeito","original transaction audit retained for each child");
  Assert(App.History().Count==1&&record.Steps.Select(s=>s.Id).Distinct().Count()==record.Steps.Count,"one durable history record with unique step IDs");
  App.Undo(record.Id);Assert(native["window"]=="1"&&registry.Count==0,"exact undo after partial success");
  FullCatalog();failWrite=true;failRollback=true;ExtremeProfile.Apply("native-window,native-gamemode,native-capture");record=Last();
  Assert(record.Status=="falha na restauração"&&App.CanUndo(record)&&native["window"]=="0"&&registry.Count>0,"failed child rollback remains recoverable without reverting successes");
  failWrite=failRollback=false;App.Undo(record.Id);Assert(registry.Count==0&&native["window"]=="1","retry recovers failed child and successful siblings");
  FullCatalog();bool durable=true;var writer=App.TestWrite;App.TestWrite=o=>{var disk=Last();durable&=disk.IsolatedSteps!=null&&disk.Values.Any(v=>App.SameTarget(v.After,o))&&disk.ChangesStarted;writer(o);};
  ExtremeProfile.Apply("native-capture");Assert(durable,"parent contains child backup before every registry write");record=Last();record.Status="aplicando";App.Save(record);App.Undo(record.Id);Assert(registry.Count==0,"interrupted parent recovers using durable flattened values");
  FullCatalog();ExtremeProfile.Apply("native-window,native-capture");record=Last();registry.Values.First().Data="93";ExpectFailure(()=>App.Undo(record.Id),"isolated undo protects later user changes");Assert(native["window"]=="0"&&registry.Values.Any(v=>v.Data=="93"),"undo preflight checks whole parent before any restore");
  FullCatalog();foreach(var item in ReviewedFeatures.Items()){
   native[item.ActionCode]="1";App.ApplyMany(new[]{item.Id});record=Last();Assert(record.NativeValues.Single().Before=="1"&&native[item.ActionCode]=="0",item.Id+" backs up and verifies documented API");App.Undo(record.Id);Assert(native[item.ActionCode]=="1",item.Id+" exact API undo");
  }
  Assert(ReviewedDiagnostics.TcpDelta(10,10,2,2,20,20).Contains("Sem segmentos"),"idle TCP sample makes no latency claim");Assert(ReviewedDiagnostics.TcpDelta(10,9,2,2,20,20).Contains("reiniciados"),"TCP counter reset is not a negative result");Assert(ReviewedDiagnostics.TcpDelta(10,20,2,5,20,24).Contains("Retransmitidos: 3"),"TCP sample reports actual delta");
  ExpectFailure(()=>ReviewedDiagnostics.Read("powercfg /setactive"),"diagnostics reject command injection");
  FullCatalog();failReadback=true;int result=LiquidProtocol.Run(new[]{"--liquid","extreme","native-window,native-gamemode,native-capture",App.Sid,Guid.NewGuid().ToString("N")});
  Assert(result==0&&Last().IsolatedSteps.Count==3&&native["window"]=="0"&&registry.Count==3,"legacy Liquid extreme route uses same isolated runner");
  FullCatalog();App.ApplyMany(new[]{"native-capture"});record=Last();record.Schema=3;record.Evidence=null;record.IsolatedSteps=null;App.Save(record);App.Undo(record.Id);Assert(registry.Count==0,"legacy schema without new fields remains exactly reversible");
  Reset();
 }
}

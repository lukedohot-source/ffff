using System;
using System.Text;
using System.Linq;
class ExportCatalog {static int Main(){Console.OutputEncoding=new UTF8Encoding(false);var items=Builtins.Create().Concat(V5Options.Items()).Concat(V5InputItems.Create()).Concat(ImportedOptions.Items()).Concat(ExtraSettings.Items()).ToList();Console.Write(App.Json.Serialize(new{library=PerformanceLibrary.Load(),items=items,metadata=items.Select(OptionInfo.For).ToArray(),aliases=CatalogIds.Aliases(),extreme=ExtremeProfile.Groups().Select(g=>new{id=g.Id,title=g.Title,effect=g.Effect,tradeoff=g.Tradeoff,selected=g.Selected,items=g.Items}).ToArray()}));return 0;}}

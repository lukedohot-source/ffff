using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
partial class EngineTests {
 static ProcessToken Token(string name="chrome") {return new ProcessToken {Pid=50001,Started=123456,Session=7,UserSid=App.Sid,Name=name,Path=@"C:\Apps\"+name+".exe"};}
 static void RunV3Tests() {
  var token=Token();Assert(ResourceMonitor.Protection(token,123,7,@"C:\Windows")=="","known user app is selectable");
  foreach(string name in new[]{"svchost","lsass","csrss","explorer","MsMpEng","System","audiodg","cs2","steam","OneDrive","EasyAntiCheat","RuntimeBroker","SearchIndexer"})
   Assert(ResourceMonitor.Protection(Token(name),123,7,@"C:\Windows")!="","protected process cannot be closed: "+name);
  token=Token();token.Pid=123;Assert(ResourceMonitor.Protection(token,123,7,@"C:\Windows")!="","optimizer cannot terminate itself");
  token=Token();token.Session=8;Assert(ResourceMonitor.Protection(token,123,7,@"C:\Windows")!="","other Windows session protected");
  token=Token();token.UserSid="S-1-5-18";Assert(ResourceMonitor.Protection(token,123,7,@"C:\Windows")!="","SYSTEM-owned process protected even with recognized name");
  token=Token();token.Path=@"C:\Windows\System32\chrome.exe";Assert(ResourceMonitor.Protection(token,123,7,@"C:\Windows")!="","Windows directory protected despite app-like filename");
  token=Token();token.Path="";Assert(ResourceMonitor.Protection(token,123,7,@"C:\Windows")!="","unreadable executable never eligible");
  var a=Token();var b=Token();Assert(ResourceMonitor.SameIdentity(a,b),"identical captured process accepted");b.Started++;Assert(!ResourceMonitor.SameIdentity(a,b),"PID reuse rejected by start time");
  b=Token();b.Path=@"C:\Other\chrome.exe";Assert(!ResourceMonitor.SameIdentity(a,b),"changed executable rejected");b=Token();b.UserSid="different";Assert(!ResourceMonitor.SameIdentity(a,b),"changed owner rejected");
  var group=new ProcessGroup {Name="chrome",Processes=new List<ProcessToken>{Token(),Token()}};group.Processes[0].Protection="";group.Processes[1].Protection="Protected";
  Assert(!group.CanClose,"mixed protected group cannot be selected");
  Assert(ResourceMonitor.Cpu(20,100,40,200)==80,"CPU percentage uses system-time delta");
  Assert(ResourceMonitor.Cpu(20,100,30,100)<0,"zero interval is unknown, not fabricated zero load");
  Assert(ResourceMonitor.Cpu(20,100,10,200)<0,"counter reset is unknown");
  Assert(ResourceMonitor.Cpu(0,100,200,200)<0,"invalid CPU counter relationship rejected");
  Assert(ResourceMonitor.Compare(new ResourceSample{MemoryKnown=true,AvailableMB=100},new ResourceSample{MemoryKnown=true,AvailableMB=90}).Contains("-10"),"negative RAM delta is retained, not hidden");
  Assert(ResourceMonitor.Compare(null,null).Contains("não comparável"),"missing samples never reported as improvement");
  Assert(ResourceMonitor.Focusable.Contains("cs2")&&!ResourceMonitor.Closable.Contains("cs2"),"gaming focus allowlist is separate from closure allowlist");
  Assert(!ResourceMonitor.Closable.Contains("OneDrive"),"sync client preserved by RAM closure");
  Assert(App.StartupExecutable(@"""C:\Program Files\Spotify\Spotify.exe"" --minimized")==@"C:\Program Files\Spotify\Spotify.exe","quoted startup executable parsed without running it");
  Assert(App.StartupExecutable("cmd.exe /c anything")=="","nonabsolute startup launcher rejected");
  Assert(!App.StartupAllowed(@"C:\Windows\System32\cmd.exe /c Spotify.exe"),"shell wrapper not authorized for startup changes");
  Assert(!App.StartupAllowed(@"""C:\Apps\Update.exe"" --processStart Discord.exe"),"ambiguous updater wrapper preserved");
  Assert(App.StartupAllowed(@"""C:\Program Files\Spotify\Spotify.exe"" --minimized"),"recognized startup entry allowed");
  Assert(!App.StartupAllowed(@"""C:\Apps\Unknown.exe"""),"unknown startup entry preserved");
  Assert(!App.StartupAllowed("C:\\Apps\\Spotify.exe\r\nanything"),"multiline startup entry rejected");
  var now=DateTime.UtcNow;
  Assert(TempCleaner.OldEnough(now.AddDays(-9),now.AddDays(-10),now.AddDays(-8),now),"only old unused temporaries eligible");
  Assert(!TempCleaner.OldEnough(now.AddDays(-9),now,now.AddDays(-8),now),"recently created file preserved");
  Assert(!TempCleaner.OldEnough(now.AddDays(-9),now.AddDays(-10),now,now),"recently accessed file preserved");
  foreach(string suffix in new[]{".bak",".sv$",".ac$",".dwl",".json",".db",".exe",".log"})Assert(!TempCleaner.AllowedExtension("file"+suffix),"cleanup excludes "+suffix);
  Assert(TempCleaner.AllowedExtension("old.TMP")&&TempCleaner.AllowedExtension("old.temp"),"temporary extension allowlist case-insensitive");
  Assert(!TempCleaner.SafePath(@"C:\Windows\System32\kernel32.dll",@"C:\Users\Luke\AppData\Local\Temp"),"cleanup cannot escape its fixed root");
  ExpectFailure(()=>App.RequestPath("../../auth"),"request traversal rejected");
  string request=App.SaveRequest(new OperationRequest());Assert(App.ReadRequest(request).Sid==App.Sid,"fresh request bound to current user");
  var expired=new OperationRequest {Sid=App.Sid,Created=DateTime.UtcNow.AddHours(-1).ToString("o")};
  File.WriteAllText(App.RequestPath(request),App.Json.Serialize(expired));ExpectFailure(()=>App.ReadRequest(request),"expired request rejected");
  expired.Created=DateTime.UtcNow.ToString("o");expired.Sid="another-user";File.WriteAllText(App.RequestPath(request),App.Json.Serialize(expired));ExpectFailure(()=>App.ReadRequest(request),"cross-user request rejected");
  Reset();var startOp=new RegOp {Hive="HKEY_CURRENT_USER",Key=App.RunKey,Name="Spotify",Kind="String",Data=@"""C:\Apps\Spotify.exe"" --minimized"};
  registry[Key(startOp)]=Copy(startOp);var deletion=Copy(startOp);deletion.Delete=true;
  var startItem=new Item {Id="startup-test",Name="Test startup",ReviewTitle="Test startup",Native=false,ActionCode="startup",Text="",Path="test",Operations=new[]{deletion}};
  App.ApplyTransaction(new[]{startItem},"Integrado","Startup test");var startupRecord=Last();Assert(!registry.ContainsKey(Key(startOp)),"selected startup entry removed with captured original");
  App.Undo(startupRecord.Id);Assert(registry[Key(startOp)].Data==startOp.Data,"startup undo restores exact command string");
  registry[Key(startOp)].Data="new command";ExpectFailure(()=>App.ApplyTransaction(new[]{startItem},"Integrado","Stale startup test"),"stale startup command rejected before deletion");Assert(registry[Key(startOp)].Data=="new command","later startup command preserved");
  Reset();ExpectFailure(()=>App.DisableOptionalServices(new[]{"WinDefend"}),"Defender not in service allowlist");Assert(App.History().Count==0,"unauthorized service request creates no transaction");
  foreach(string name in new[]{"wuauserv","BITS","Audiosrv","Dhcp","WlanSvc","SysMain","BFE","MpsSvc","Vanguard"})ExpectFailure(()=>App.ServiceStart(name),"critical service never configurable: "+name);
  ExpectFailure(()=>App.DisableOptionalServices(new[]{"Spooler","spooler"}),"duplicate service names rejected case-insensitively");
  Reset();var serviceStates=new Dictionary<string,ServiceState>();
  foreach(string name in App.OptionalServices.Keys){var op=App.ServiceStart(name);var old=Copy(op);old.Data=name=="Spooler"?"2":"3";registry[Key(op)]=old;serviceStates[name]=new ServiceState {State=name=="Spooler"?"Running":"Stopped",CanStop=true};}
  App.TestServiceRead=name=>serviceStates[name];App.TestServiceChange=(name,run)=>serviceStates[name].State=run?"Running":"Stopped";
  App.DisableOptionalServices(new[]{"Spooler","WSearch"});var saved=Last();Assert(saved.Status=="aplicado"&&serviceStates["Spooler"].State=="Stopped","service stop and disable are verified");
  Assert(registry[Key(App.ServiceStart("Spooler"))].Data=="4","service startup disabled");App.Undo(saved.Id);
  Assert(registry[Key(App.ServiceStart("Spooler"))].Data=="2"&&serviceStates["Spooler"].State=="Running","service undo restores exact startup and previous running state");
  Assert(registry[Key(App.ServiceStart("WSearch"))].Data=="3"&&serviceStates["WSearch"].State=="Stopped","previously stopped service stays stopped after undo");
  serviceStates["Spooler"].DependentsRunning=true;ExpectFailure(()=>App.DisableOptionalServices(new[]{"Spooler"}),"active service dependents block changes");Assert(registry[Key(App.ServiceStart("Spooler"))].Data=="2","dependent-service rejection preserves initial setting");serviceStates["Spooler"].DependentsRunning=false;
  App.TestServiceChange=(name,run)=>{if(name=="WSearch"&&!run)throw new Exception("simulated stop refusal");serviceStates[name].State=run?"Running":"Stopped";};
  ExpectFailure(()=>App.DisableOptionalServices(new[]{"Spooler","WSearch"}),"service failure propagates");
  Assert(registry[Key(App.ServiceStart("Spooler"))].Data=="2"&&serviceStates["Spooler"].State=="Running","partial service failure rolls back earlier service");
  App.TestServiceChange=(name,run)=>serviceStates[name].State=run?"Running":"Stopped";
  App.DisableOptionalServices(new[]{"Spooler"});saved=Last();registry[Key(App.ServiceStart("Spooler"))].Data="3";ExpectFailure(()=>App.Undo(saved.Id),"undo protects a later service startup change");
  Assert(registry[Key(App.ServiceStart("Spooler"))].Data=="3","later service choice preserved");
  App.TestServiceRead=null;App.TestServiceChange=null;
  ImportedScripts.Load();Assert(ImportedScripts.All.Count==14,"all 14 uploaded BATs embedded as read-only reviews");
  Assert(ImportedScripts.AsCatalogItems().All(i=>!i.Native&&!i.MaxEligible&&!i.ManualAllowed&&i.Operations.Length==0),"none of the original BAT commands execute in maximum mode");
  Assert(ImportedScripts.All.All(i=>i.Hash.Length==64&&i.Text.Length>0&&i.Findings.Length>0),"every imported BAT has content, digest and findings");
  Reset();ExpectFailure(()=>App.ApplyMaximum(new[]{ImportedScripts.All[0].Id}),"uploaded BAT cannot be smuggled into native profile");
 }
}

﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using System.Collections.Generic;

class UiSmoke {
 [STAThread] static int Main(string[] args){
  Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
  int result=1;
  using(var context=new ApplicationContext())using(var timer=new System.Windows.Forms.Timer{Interval=1}){
   timer.Tick+=(s,e)=>{timer.Stop();result=RunTests(args);context.ExitThread();};timer.Start();Application.Run(context);
  }
  return result;
 }
 static int RunTests(string[] args){
  try{
   using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("catalog.json"))using(var r=new StreamReader(stream,Encoding.UTF8))App.Items=App.Json.Deserialize<List<Item>>(r.ReadToEnd());
   App.Items.AddRange(Builtins.Create());App.Items.AddRange(V5Options.Items());App.Items.AddRange(V5InputItems.Create());App.Items.AddRange(ImportedOptions.Items());App.Items.AddRange(ExtraSettings.Items());App.Items.AddRange(ReviewedFeatures.Items());ImportedScripts.Load();App.Items.AddRange(ImportedScripts.AsCatalogItems());Directory.CreateDirectory(App.RecordsRoot);
   string folder=Path.GetFullPath(args.Length==0?"ui-smoke":args[0]);Directory.CreateDirectory(folder);
   App.TestUiRendering=true;using(var form=new MainForm()){form.TestRender(folder);form.TestUnified(folder);form.TestFunctional(folder);form.TestProduct(folder);form.Close();form.Dispose();}
   // O modo embutido acopla a janela a um host por HWND e avisa por PostMessage do
   // user32. Sem Windows nao ha essa mensagem; pular em voz alta em vez de fingir.
   if(App.IsWindows){
    App.ToolMode=true;App.TestMachine=new Machine{Windows=true,Build=26200,Edition="Professional"};
    using(var parent=new Form()){parent.CreateControl();EmbeddedInterface.Parent=parent.Handle;using(var form=new MainForm())form.TestEmbeddedRender(folder);EmbeddedInterface.Parent=IntPtr.Zero;}
   }else Console.WriteLine("SKIP UI embedded tool-mode render -- acoplamento por HWND e PostMessage do user32 so existem no Windows");
   Console.WriteLine("UI smoke passed: navigation, filtering, forms, chart and offscreen rendering. No system settings changed.");return 0;
  }catch(Exception e){Console.WriteLine(e.ToString());return 1;}
 }
}
public partial class MainForm {
 internal void TestEmbeddedRender(string directory){
  Show();Application.DoEvents();machine=App.TestMachine;scanning=false;resourceScanning=false;SetActions();footer.Text="PRÉVIA: nenhum ajuste aplicado";
  foreach(var size in new[]{new Size(1024,740),new Size(970,570)}){
   Size=size;
   for(int n=0;n<EmbeddedInterface.Pages.Length;n++){
    ShowPage(EmbeddedInterface.Pages[n]);PerformLayout();Application.DoEvents();
    if(pages[EmbeddedInterface.Pages[n]].Width<650)throw new Exception("Embedded content lost width to a second sidebar.");
    using(var bitmap=new Bitmap(Width,Height)){DrawToBitmap(bitmap,new Rectangle(0,0,Width,Height));bitmap.Save(Path.Combine(directory,"embedded-"+size.Width+"-"+n+".png"));}
   }
  }
  var review=InlineReview("Conferir seleção — TESTE","Nenhuma alteração real. Confirmação dentro da janela.",true);
  if(review.IsCompleted||!EmbeddedBusy())throw new Exception("Review did not wait for user input.");
  var cancel=(Button)Controls.Find("inline-cancel",true).Single();cancel.PerformClick();
  if(!review.IsCompleted||review.Result||inlineOverlay!=null)throw new Exception("Cancel failed to close review without applying.");
  review=InlineReview("TESTE","Confirmação simulada, sem operação associada.",true);
  ((Button)Controls.Find("inline-accept",true).Single()).PerformClick();
  if(!review.IsCompleted||!review.Result||inlineOverlay!=null)throw new Exception("Confirm failed to return selection.");
  Console.WriteLine("Embedded UI passed: 10 tools, 2 sizes, inline confirm/cancel, no second sidebar.");
 }
 internal void TestRender(string directory){
  var targets=new[]{"Otimizações","Ferramentas","Central de desempenho","Perfis de jogos","Energia avançada","FPS e stutter","Hardware e rede","Apps e RAM","Manutenção","Otimização máxima","Histórico","Rede","Rede e latência","Arquivos e referências"};
  ShowInTaskbar=false;Opacity=0;StartPosition=FormStartPosition.Manual;Location=new Point(-20000,-20000);Show();Application.DoEvents();
  machine=new Machine{Windows=true,Build=26200};progress.Visible=false;SetActions();footer.Text="TESTE DE INTERFACE · sem alterações no Windows";
  performanceSearch.Text="Reflex";if(performanceList.Items.Count<2)throw new Exception("Library search failed");performanceSearch.Clear();
  if(performanceList.Items.Count!=PerformanceLibrary.Load().Count)throw new Exception("Library entries missing");
  var capture=FrameAnalysis.Read(new StringReader("FrameTime\n10\n11\n10\n45\n10\n11\n10\n10\n10"),"AMOSTRA SINTÉTICA DE TESTE.csv");beforeFrames=FrameAnalysis.Summarize(capture,capture.Streams[0],144,0);UpdateFrames();
  foreach(var size in new[]{new Size(1360,900),new Size(1080,720)}){
   Size=size;PerformLayout();
   foreach(string page in targets){ShowPage(page);pages[page].CreateControl();pages[page].PerformLayout();PerformLayout();Application.DoEvents();
    if(page=="FPS e stutter"&&frameText.Height<85)throw new Exception("Frame statistics area collapsed");
    using(var bitmap=new Bitmap(Width,Height)){DrawToBitmap(bitmap,new Rectangle(0,0,Width,Height));bitmap.Save(Path.Combine(directory,size.Width+"-"+Array.IndexOf(targets,page)+".png"));}
   }
  }
  // Subiu de 27 para 28 com a Central de Rede. O número cru continua aqui de propósito:
  // uma página que some por engano é exatamente o defeito que este teste pega.
  if(pages.Count!=28||powerChecks.Count!=6)throw new Exception("Navigation/control count mismatch");
  // A contagem de servicos deixou de ser fixa (era 10, hoje 41). O numero cru envelhece
  // a cada catalogo novo; o que precisa valer sempre e a tela renderizar exatamente um
  // controle por servico opcional -- nem um a menos (opcao invisivel), nem um a mais.
  if(servicePicks.Count!=App.OptionalServices.Count)throw new Exception("Service page must render exactly one control per optional service");
 }
}

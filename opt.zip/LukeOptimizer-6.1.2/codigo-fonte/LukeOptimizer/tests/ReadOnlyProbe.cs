using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using System.Text;

class ReadOnlyProbe {
 [STAThread] static int Main(){
  try{
   using(var s=Assembly.GetExecutingAssembly().GetManifestResourceStream("catalog.json"))using(var r=new StreamReader(s,Encoding.UTF8))App.Items=App.Json.Deserialize<List<Item>>(r.ReadToEnd());
   App.Items.AddRange(Builtins.Create());App.Items.AddRange(V5Options.Items());App.Items.AddRange(V5InputItems.Create());
   Directory.CreateDirectory(App.RecordsRoot);var id=Guid.NewGuid().ToString("N");
   int code=LiquidProtocol.Run(new[]{"--liquid","scan","-",App.Sid,id});
   if(code!=0)throw new Exception("Read-only scan returned an error.");
   var rows=File.ReadAllLines(LiquidProtocol.ResponsePath(id)).Select(x=>x.Split('\t').Select(Uri.UnescapeDataString).ToArray()).ToList();
   var states=rows.Where(x=>x[0]=="state").ToList();
   if(states.Count!=35||states.Select(x=>x[1]).Distinct().Count()!=35)throw new Exception("Not all 35 options returned a unique state.");
   if(!rows.Any(x=>x[0]=="pc"&&x.Length==6))throw new Exception("Hardware response missing.");
   if(App.History().Count!=0)throw new Exception("A read-only scan created mutation history.");
   Console.WriteLine("Real Windows read-only probe: 35/35 option states; hardware response valid; no change records.");
   Console.WriteLine("Compatible readings: "+states.Count(x=>x[4]=="")+"; conditional/unavailable: "+states.Count(x=>x[4]!="")+".");
   foreach(var group in states.GroupBy(x=>x[2]))Console.WriteLine(group.Key+": "+group.Count());
   return 0;
  }catch(Exception e){Console.Error.WriteLine(e.Message);return 1;}
 }
}

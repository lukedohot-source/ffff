using System;
using System.Linq;
using System.Collections.Generic;

// REGRA DE NOMES — o usuário nunca vê nome de arquivo, chave de Registro ou comando
// como NOME de uma função. Isto aqui é o que impede a regra de se perder no próximo
// cadastro: sem teste, ela é um parágrafo de documentação que envelhece em silêncio.
partial class EngineTests {
 static void RunNamingTests(){
  Reset();
  FullCatalog();

  // ------------------------------------------------------------------ a regra
  foreach(string bad in new[]{
   "Net speed.reg","SrWindowsTech.bat","Otimizar Internet.cmd","script.ps1","Optimizer.exe",
   "HKLM\\Software\\X","HKCU tweak","reg add HKLM","netsh int ip reset","ipconfig /flushdns",
   "powercfg -duplicatescheme","regedit tweak","DISM RestoreHealth","sfc /scannow"})
   Assert(FeatureNaming.Violation(bad)!=null,"a technical or file name is rejected as a feature name: "+bad);

  foreach(string good in new[]{
   "Limpar cache DNS","Renovar endereço IP","Reparar Windows","Modo jogo","Desempenho máximo",
   "Criar ponto de restauração","Reduzir processos do Windows","Agendamento de GPU",
   "Prioridade de programas em primeiro plano","Limpar arquivos temporários"})
   Assert(FeatureNaming.Violation(good)==null,"a plain-language name is accepted: "+good);

  // O token tem de casar como TEXTO, não como palavra solta: "Editar.registro" também
  // é nome de arquivo. E maiúsculas não podem servir de escape.
  Assert(FeatureNaming.Violation("LIMPAR.BAT")!=null&&FeatureNaming.Violation("hklm")!=null,"the rule ignores letter case");
  Assert(FeatureNaming.Violation(null)==null&&FeatureNaming.Violation("")==null,"an empty name is not reported as a violation");

  // ------------------------------------------- o que vale para o catálogo real
  // As 127 funções EXECUTÁVEIS: nenhuma pode ter nome técnico. Hoje nenhuma tem —
  // e é exatamente por isso que o teste existe, para continuar assim.
  var executable=CatalogIds.NativeItems().ToArray();
  foreach(var item in executable){
   string offense=FeatureNaming.Violation(item.ReviewTitle);
   Assert(offense==null,"executable optimization has a human name, not a file or key: "+item.Id+" -> "+item.ReviewTitle+(offense==null?"":" (contém '"+offense+"')"));
  }
  Assert(executable.Length>100,"the naming rule is checked against the whole executable catalog, not a sample");

  // O detalhe técnico CONTINUA existindo — a regra é sobre o nome, não sobre esconder
  // informação. Se Detalhes parasse de citar o alvo real, o usuário avançado perderia
  // a auditoria, que é o outro lado do mesmo pedido.
  var withRegistry=executable.FirstOrDefault(i=>(i.Operations??new RegOp[0]).Length>0);
  Assert(withRegistry!=null,"there is at least one optimization backed by a registry write");
  string details=OptimizationRegistry.Details(withRegistry.Id,null);
  Assert(details.Contains("Fonte técnica")&&details.Contains("ID preservado"),"the details sheet still exposes the technical source and the stable id");

  // ------------------------------------------------------- inventário é exceção
  // 546 entradas do catálogo NÃO são funções: são os arquivos que a pessoa enviou e
  // instaladores de terceiros. Para elas o nome do arquivo É a identidade — renomear
  // "Optimizer-16.7.exe" impediria a pessoa de achar o arquivo na própria pasta.
  // O harness de engine carrega só as executáveis (App.Items == 127). O inventário
  // revisado vive em PerformanceLibrary.OriginalItems(): 546 arquivos, os 532 do
  // catálogo mais os 14 BATs. É ele que o Catálogo mostra no aplicativo real.
  var inventory=PerformanceLibrary.OriginalItems().Where(FeatureNaming.IsInventory).ToArray();
  Assert(inventory.Length>0,"the catalogue still carries the reviewed inventory");
  Assert(inventory.All(i=>!i.Native),"inventory is never executable; it is read and explained, never applied");
  Assert(inventory.Any(i=>FeatureNaming.Violation(i.ReviewTitle)!=null),"inventory keeps the real file name, which is what makes it findable on disk");
  // A separação que importa: nenhum item de inventário pode ser aplicado por engano.
  Assert(!inventory.Any(i=>ExtremeProfile.IsReviewed(i)),"no inventory entry can enter an automatic profile");

  // ------------------------------------------------------------- categorias
  // Aqui estava o vazamento real: ".Bats", "Regedits" e prefixos numéricos iam crus
  // para o seletor de categorias da tela Catálogo.
  var everything=PerformanceLibrary.OriginalItems().Concat(CatalogIds.NativeItems()).ToList();
  var groups=FeatureNaming.Groups(everything);
  Assert(groups.Count>0,"categories are grouped for display");
  foreach(var group in groups){
   Assert(FeatureNaming.Violation(group.Key)==null,"category name carries no file extension or registry key: "+group.Key);
   Assert(!System.Text.RegularExpressions.Regex.IsMatch(group.Key,@"^\s*-?\d"),"category name carries no numeric prefix: "+group.Key);
  }
  Assert(groups.Any(g=>g.Key=="Arquivos que você enviou"),"the files the user supplied are named for what they are");
  Assert(!groups.Any(g=>g.Key.IndexOf("Bats",StringComparison.OrdinalIgnoreCase)>=0||g.Key.IndexOf("Regedit",StringComparison.OrdinalIgnoreCase)>=0),"no category is named after a file type");

  // Unificação: categorias repetidas sob prefixos diferentes viram UMA. É o que o
  // pedido chama de normalização, e sem isto a tela listava a mesma coisa duas vezes.
  Assert(FeatureNaming.Category("-3 - Personalização")==FeatureNaming.Category("-4 - Personalização"),"the same category under different prefixes collapses into one");
  Assert(FeatureNaming.Category("-3 - Windows leve")==FeatureNaming.Category("-4 - Windows leve"),"duplicate categories are unified");
  Assert(FeatureNaming.Category("2 - .Bats")==FeatureNaming.Category("3 - Regedits"),"supplied files share one honest category");
  Assert(groups.Count<everything.Select(i=>i.Category).Distinct().Count(),"grouping actually reduces the number of visible categories");

  // Cobertura: TODA categoria bruta cai em algum grupo, nenhuma some da tela.
  var covered=new HashSet<string>(groups.SelectMany(g=>g.Value),StringComparer.Ordinal);
  foreach(var raw in everything.Select(i=>i.Category??"").Distinct())
   Assert(covered.Contains(raw),"every raw category reaches a visible group, none is silently dropped: "+raw);

  // Ordem: inventário e referência por último; uma categoria desconhecida não é
  // empurrada para o fim nem escondida.
  Assert(FeatureNaming.Rank("Jogos")<FeatureNaming.Rank("Arquivos que você enviou"),"features are listed before the supplied-files inventory");
  Assert(FeatureNaming.Rank("Categoria inventada")<FeatureNaming.Rank("Arquivos que você enviou"),"an unmapped category is not hidden at the bottom");
  Assert(FeatureNaming.Category("42 - Categoria nova")=="Categoria nova","an unmapped category still loses its numeric prefix");
  Assert(FeatureNaming.StripPrefix("-4 - Privacidade opcional")=="Privacidade opcional"&&FeatureNaming.StripPrefix("Sem prefixo")=="Sem prefixo","prefix stripping handles negative numbers and names without a prefix");

  Reset();
 }
}

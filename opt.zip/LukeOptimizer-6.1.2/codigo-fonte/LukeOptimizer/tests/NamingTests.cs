using System;
using System.Linq;
using System.Collections.Generic;

// REGRA DE NOMES — o usuário nunca vê nome de arquivo, chave de Registro ou comando
// como NOME de uma função. Isto aqui é o que impede a regra de se perder no próximo
// cadastro: sem teste, ela é um parágrafo de documentação que envelhece em silêncio.
partial class EngineTests {
 static void RunNamingTests(){
  Reset();
  FullCatalog();

  // ------------------------------------------------------------------ a regra
  foreach(string bad in new[]{
   "Net speed.reg","SrWindowsTech.bat","Otimizar Internet.cmd","script.ps1","Optimizer.exe",
   "HKLM\\Software\\X","HKCU tweak","reg add HKLM","netsh int ip reset","ipconfig /flushdns",
   "powercfg -duplicatescheme","regedit tweak","DISM RestoreHealth","sfc /scannow"})
   Assert(FeatureNaming.Violation(bad)!=null,"a technical or file name is rejected as a feature name: "+bad);

  foreach(string good in new[]{
   "Limpar cache DNS","Renovar endereço IP","Reparar Windows","Modo jogo","Desempenho máximo",
   "Criar ponto de restauração","Reduzir processos do Windows","Agendamento de GPU",
   "Prioridade de programas em primeiro plano","Limpar arquivos temporários"})
   Assert(FeatureNaming.Violation(good)==null,"a plain-language name is accepted: "+good);

  // O token tem de casar como TEXTO, não como palavra solta: "Editar.registro" também
  // é nome de arquivo. E maiúsculas não podem servir de escape.
  Assert(FeatureNaming.Violation("LIMPAR.BAT")!=null&&FeatureNaming.Violation("hklm")!=null,"the rule ignores letter case");
  Assert(FeatureNaming.Violation(null)==null&&FeatureNaming.Violation("")==null,"an empty name is not reported as a violation");

  // ------------------------------------------- o que vale para o catálogo real
  // As 127 funções EXECUTÁVEIS: nenhuma pode ter nome técnico. Hoje nenhuma tem —
  // e é exatamente por isso que o teste existe, para continuar assim.
  var executable=CatalogIds.NativeItems().ToArray();
  foreach(var item in executable){
   string offense=FeatureNaming.Violation(item.ReviewTitle);
   Assert(offense==null,"executable optimization has a human name, not a file or key: "+item.Id+" -> "+item.ReviewTitle+(offense==null?"":" (contém '"+offense+"')"));
  }
  Assert(executable.Length>100,"the naming rule is checked against the whole executable catalog, not a sample");

  // O detalhe técnico CONTINUA existindo — a regra é sobre o nome, não sobre esconder
  // informação. Se Detalhes parasse de citar o alvo real, o usuário avançado perderia
  // a auditoria, que é o outro lado do mesmo pedido.
  var withRegistry=executable.FirstOrDefault(i=>(i.Operations??new RegOp[0]).Length>0);
  Assert(withRegistry!=null,"there is at least one optimization backed by a registry write");
  string details=OptimizationRegistry.Details(withRegistry.Id,null);
  Assert(details.Contains("Fonte técnica")&&details.Contains("ID preservado"),"the details sheet still exposes the technical source and the stable id");

  // ------------------------------------------------------- inventário é exceção
  // 546 entradas do catálogo NÃO são funções: são os arquivos que a pessoa enviou e
  // instaladores de terceiros. Para elas o nome do arquivo É a identidade — renomear
  // "Optimizer-16.7.exe" impediria a pessoa de achar o arquivo na própria pasta.
  // O harness de engine carrega só as executáveis (App.Items == 127). O inventário
  // revisado vive em PerformanceLibrary.OriginalItems(): 546 arquivos, os 532 do
  // catálogo mais os 14 BATs. É ele que o Catálogo mostra no aplicativo real.
  var inventory=PerformanceLibrary.OriginalItems().Where(FeatureNaming.IsInventory).ToArray();
  Assert(inventory.Length>0,"the catalogue still carries the reviewed inventory");
  Assert(inventory.All(i=>!i.Native),"inventory is never executable; it is read and explained, never applied");
  Assert(inventory.Any(i=>FeatureNaming.Violation(i.ReviewTitle)!=null),"inventory keeps the real file name, which is what makes it findable on disk");
  // A separação que importa: nenhum item de inventário pode ser aplicado por engano.
  Assert(!inventory.Any(i=>ExtremeProfile.IsReviewed(i)),"no inventory entry can enter an automatic profile");

  // ------------------------------------------------------------- categorias
  // Aqui estava o vazamento real: ".Bats", "Regedits" e prefixos numéricos iam crus
  // para o seletor de categorias da tela Catálogo.
  var everything=PerformanceLibrary.OriginalItems().Concat(CatalogIds.NativeItems()).ToList();
  var groups=FeatureNaming.Groups(everything);
  Assert(groups.Count>0,"categories are grouped for display");
  foreach(var group in groups){
   Assert(FeatureNaming.Violation(group.Key)==null,"category name carries no file extension or registry key: "+group.Key);
   Assert(!System.Text.RegularExpressions.Regex.IsMatch(group.Key,@"^\s*-?\d"),"category name carries no numeric prefix: "+group.Key);
  }
  Assert(groups.Any(g=>g.Key=="Arquivos que você enviou"),"the files the user supplied are named for what they are");
  Assert(!groups.Any(g=>g.Key.IndexOf("Bats",StringComparison.OrdinalIgnoreCase)>=0||g.Key.IndexOf("Regedit",StringComparison.OrdinalIgnoreCase)>=0),"no category is named after a file type");

  // Unificação: categorias repetidas sob prefixos diferentes viram UMA. É o que o
  // pedido chama de normalização, e sem isto a tela listava a mesma coisa duas vezes.
  Assert(FeatureNaming.Category("-3 - Personalização")==FeatureNaming.Category("-4 - Personalização"),"the same category under different prefixes collapses into one");
  Assert(FeatureNaming.Category("-3 - Windows leve")==FeatureNaming.Category("-4 - Windows leve"),"duplicate categories are unified");
  Assert(FeatureNaming.Category("2 - .Bats")==FeatureNaming.Category("3 - Regedits"),"supplied files share one honest category");
  Assert(groups.Count<everything.Select(i=>i.Category).Distinct().Count(),"grouping actually reduces the number of visible categories");

  // Cobertura: TODA categoria bruta cai em algum grupo, nenhuma some da tela.
  var covered=new HashSet<string>(groups.SelectMany(g=>g.Value),StringComparer.Ordinal);
  foreach(var raw in everything.Select(i=>i.Category??"").Distinct())
   Assert(covered.Contains(raw),"every raw category reaches a visible group, none is silently dropped: "+raw);

  // Ordem: inventário e referência por último; uma categoria desconhecida não é
  // empurrada para o fim nem escondida.
  Assert(FeatureNaming.Rank("Jogos")<FeatureNaming.Rank("Arquivos que você enviou"),"features are listed before the supplied-files inventory");
  Assert(FeatureNaming.Rank("Categoria inventada")<FeatureNaming.Rank("Arquivos que você enviou"),"an unmapped category is not hidden at the bottom");
  Assert(FeatureNaming.Category("42 - Categoria nova")=="Categoria nova","an unmapped category still loses its numeric prefix");
  Assert(FeatureNaming.StripPrefix("-4 - Privacidade opcional")=="Privacidade opcional"&&FeatureNaming.StripPrefix("Sem prefixo")=="Sem prefixo","prefix stripping handles negative numbers and names without a prefix");

  // ------------------------------------------ a experiência NORMAL não mostra script
  // Esta é a garantia que o pedido cobra: nada com nome de arquivo pode aparecer como
  // função para quem só quer usar o programa. Modo desenvolvedor é opt-in e nunca liga
  // sozinho, então o padrão conferido aqui é o padrão que a pessoa recebe.
  bool previous=App.DeveloperMode;
  try{
   App.DeveloperMode=false;
   var visible=FeatureNaming.ForUser(everything).ToArray();
   Assert(visible.Length>0,"the normal experience still shows the integrated features");
   Assert(visible.All(i=>i.Native),"the normal experience shows only executable features, never supplied files");
   foreach(var i in visible){
    string offense=FeatureNaming.Violation(i.ReviewTitle);
    Assert(offense==null,"nothing in the normal experience is titled after a file or key: "+i.ReviewTitle);
   }
   foreach(string banned in new[]{"BATs","enviou","Regedits"})
    Assert(!visible.Any(i=>(i.Category??"").IndexOf(banned,StringComparison.OrdinalIgnoreCase)>=0),"no category in the normal experience is named after the supplied files: "+banned);
   foreach(var g in FeatureNaming.Groups(visible))
    Assert(FeatureNaming.Violation(g.Key)==null&&g.Key.IndexOf("enviou",StringComparison.OrdinalIgnoreCase)<0&&g.Key.IndexOf("BAT",StringComparison.OrdinalIgnoreCase)<0,"normal category is a real category: "+g.Key);

   // Modo desenvolvedor devolve a auditoria INTEIRA, sem renomear nada: lá o nome do
   // arquivo é a identidade e tem de continuar sendo.
   App.DeveloperMode=true;
   var audit=FeatureNaming.ForUser(everything).ToArray();
   Assert(audit.Length==everything.Count,"developer mode gets the whole audit back, nothing discarded");
   Assert(audit.Any(i=>FeatureNaming.Violation(i.ReviewTitle)!=null),"the audit keeps the real file names, which is what makes a file findable on disk");
  }finally{App.DeveloperMode=previous;}
  Assert(!App.DeveloperMode,"developer mode is off by default and never enables itself");

  // ------------------------------------------------- Ferramentas são ferramentas
  // A tela criava um botão por arquivo .bat recebido. Agora abre ferramenta do Windows.
  var tools=WindowsTools.All();
  Assert(tools.Count>0&&tools.Select(t=>t.Id).Distinct().Count()==tools.Count,"every Windows tool has a unique id");
  foreach(var tool in tools){
   Assert(FeatureNaming.Violation(tool.Name)==null,"a Windows tool is named for what it opens, not for its executable: "+tool.Name);
   Assert(!String.IsNullOrWhiteSpace(tool.Description),"every Windows tool explains what it is for: "+tool.Id);
   Assert(!String.IsNullOrWhiteSpace(tool.Target),"no Windows tool is an empty button: "+tool.Id);
   Assert(new[]{"exe","settings","url","folder"}.Contains(tool.Kind),"a Windows tool declares a known launch kind: "+tool.Id);
   if(tool.Kind=="exe")Assert(tool.Target.EndsWith(".exe",StringComparison.OrdinalIgnoreCase)&&tool.Target.IndexOf('\\')<0&&tool.Target.IndexOf('/')<0,"an executable tool is resolved by name in System32, never by a path: "+tool.Id);
  }
  ExpectFailure(()=>WindowsTools.Resolve("nao-existe"),"an unknown Windows tool is rejected");
  Assert(WindowsTools.Resolve("godmode").Name.IndexOf("Painel",StringComparison.OrdinalIgnoreCase)>=0,"God Mode is offered under a name a person understands");

  // ------------------------------------------------------ CENTRAL DE REDE
  // A regra "sem botão vazio": toda tarefa aponta para ação ou diagnóstico que existe
  // de verdade na allowlist. Uma tarefa que não executasse nada passaria despercebida
  // numa revisão visual; aqui ela derruba o build.
  var tasks=NetworkCenter.Tasks();
  Assert(tasks.Count>0&&tasks.Select(t=>t.Id).Distinct().Count()==tasks.Count,"every network task has a unique id");
  foreach(var task in tasks){
   Assert(FeatureNaming.Violation(task.Name)==null,"a network task is named for the problem it solves, not for its command: "+task.Name);
   Assert(!String.IsNullOrWhiteSpace(task.Summary)&&!String.IsNullOrWhiteSpace(task.Detail),"every network task explains itself in plain language: "+task.Id);
   Assert(task.Actions.Length>0||task.Diagnostic.Length>0,"no network task is an empty button: "+task.Id);
   // Cada id tem de existir na allowlist. Resolve lança se não existir.
   foreach(string id in task.Actions)NetworkTools.Resolve(id);
   if(task.Diagnostic.Length>0)Assert(NetworkTools.IsDiagnostic(task.Diagnostic),"a reading task points at a real diagnostic: "+task.Id);
   // Uma tarefa é leitura OU alteração, nunca as duas — senão o aviso mente sobre o risco.
   Assert(!(task.Actions.Length>0&&task.Diagnostic.Length>0),"a task either reads or changes, never both: "+task.Id);
  }
  Assert(tasks.Any(t=>NetworkCenter.IsRead(t))&&tasks.Any(t=>!NetworkCenter.IsRead(t)),"the network centre offers both readings and repairs");
  ExpectFailure(()=>NetworkCenter.Resolve("nao-existe"),"an unknown network task is rejected");

  // As bandeiras de risco são DERIVADAS das ações, não escritas à mão: se uma ação passar
  // a derrubar a conexão, o aviso da tarefa acompanha sozinho.
  var repair=NetworkCenter.Resolve("net-task-repair");
  Assert(repair.NeedsRestart&&repair.Disconnects&&repair.Administrator,"the heavy repair inherits restart, disconnect and elevation from its actions");
  var refresh=NetworkCenter.Resolve("net-task-refresh");
  Assert(refresh.Disconnects&&!refresh.NeedsRestart,"renewing the address declares the drop but not a restart");
  var reading=NetworkCenter.Resolve("net-task-test");
  Assert(!reading.Disconnects&&!reading.NeedsRestart&&!reading.Administrator&&NetworkCenter.IsRead(reading),"a measurement changes nothing and needs no elevation");

  // A confirmação diz o custo ANTES, em português, e lista o que vai rodar.
  string confirmation=NetworkCenter.Confirmation(repair);
  foreach(string required in new[]{"EXIGE REINICIAR","A CONEXÃO PODE CAIR","NÃO tem desfazer","Executar agora?"})
   Assert(confirmation.Contains(required),"the confirmation states the cost up front: "+required);
  Assert(!NetworkCenter.Confirmation(reading).Contains("desfazer"),"a read-only task does not threaten with undo warnings it does not need");

  // Detalhes técnicos é o ÚNICO lugar onde o comando aparece — e ele tem de aparecer.
  string technical=NetworkCenter.Technical(repair);
  Assert(technical.Contains("netsh.exe")&&technical.Contains("Fonte:")&&technical.Contains("Backup antes:"),"technical details expose the real command, its source and the backup taken first");
  Assert(FeatureNaming.Violation(repair.Name)==null&&technical.Contains("netsh"),"the command lives in the details, never in the name");
  Assert(NetworkCenter.Technical(reading).Contains("Nenhuma configuração é alterada"),"the details of a reading say plainly that nothing changes");

  // O verbo composto valida TODOS os ids antes de elevar: um id inválido no meio da
  // sequência não pode chegar ao processo já elevado.
  Assert(App.ActionNeedsAdmin("--network-actions","net-flushdns,net-renew"),"a composite network task requests elevation once for the whole sequence");
  ExpectFailure(()=>App.ActionNeedsAdmin("--network-actions","net-flushdns,calc.exe"),"one bad id in the sequence is rejected before any elevation");
  ExpectFailure(()=>App.ActionNeedsAdmin("--network-actions",""),"an empty sequence is rejected");
  foreach(var task in tasks.Where(t=>t.Actions.Length>0))
   Assert(App.ActionNeedsAdmin("--network-actions",String.Join(",",task.Actions)),"every changing task is gated behind elevation: "+task.Id);

  Reset();
 }
}

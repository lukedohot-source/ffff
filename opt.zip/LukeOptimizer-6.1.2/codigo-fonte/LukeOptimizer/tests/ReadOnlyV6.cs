using System;
using System.IO;
using System.Linq;
using System.Threading;
class ReadOnlyV6 {
 static int Main(string[] args){try{
  Directory.CreateDirectory(App.RecordsRoot);App.Items=CatalogIds.NativeItems();
  var platform=PlatformSnapshot.Read();var data=SystemTelemetry.Read(CancellationToken.None);
  var result=new{Version=App.Version,Platform=platform,Time=data.Time,Memory=data.Memory,CPU=data.CpuPercent,NetworkReceive=data.NetworkReceiveBytesPerSecond,NetworkSend=data.NetworkSendBytesPerSecond,Storage=data.Storage,Power=data.PowerPlan,GPU=data.Gpu,Startup=data.StartupCount,StartupScope=data.StartupCoverage,Health=data.HealthScore,HealthMethod=data.HealthExplanation,Notes=data.Note,ProcessCount=data.TopProcesses.Count,Changes=App.History().Count};
  File.WriteAllText(args[0],App.Json.Serialize(result));if(data.Memory==null||App.History().Count!=0)throw new Exception("Read-only probe incomplete or unexpected change record.");
  Console.WriteLine("PASS: actual Windows read-only telemetry; no optimizations. "+platform.Windows+"; "+platform.Architecture+"; "+data.TopProcesses.Count+" process samples. Changes=0.");return 0;
 }catch(Exception e){Console.WriteLine(e);return 1;}}
}

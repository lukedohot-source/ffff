using System;
using System.Linq;
using System.Collections.Generic;

// INTEGRAÇÃO DAS REFERÊNCIAS — testes.
//
// O risco desta fase não é errar uma chave de Registro: é a MESMA função virar quatro
// features porque quatro projetos a chamam de quatro jeitos. O pedido proíbe isso com
// todas as letras ("Proibido: Game Mode Sophia / Game Mode Winhance / Game Mode NXT /
// Game Mode Luke"). Estes testes fazem a proibição valer no build.
partial class EngineTests {
 static string OpKey(RegOp op){
  return (op.Hive??"").ToUpperInvariant()+"|"+(op.Key??"").Trim('\\').Replace("/","\\").ToLowerInvariant()+"|"+(op.Name??"").ToLowerInvariant();
 }

 static void RunReferenceTests(){
  Reset();
  FullCatalog();

  var settings=WindowsSettings.All();
  Assert(settings.Count>0,"the reference integration actually added settings");
  Assert(settings.Select(s=>s.Id).Distinct().Count()==settings.Count,"every integrated setting has a unique id");

  foreach(var setting in settings){
   Assert(!String.IsNullOrWhiteSpace(setting.Name)&&!String.IsNullOrWhiteSpace(setting.Summary),"every setting says what it does, in plain language: "+setting.Id);
   // O nome é o da FUNÇÃO, nunca o da chave nem o do projeto de onde veio a ideia.
   Assert(FeatureNaming.Violation(setting.Name)==null,"a setting is named for what it does, not for its registry key: "+setting.Name);
   foreach(string banned in new[]{"Winhance","Sophia","Win11Debloat","optimizerNXT","WinUtil","Chris Titus"})
    Assert(setting.Name.IndexOf(banned,StringComparison.OrdinalIgnoreCase)<0&&setting.Summary.IndexOf(banned,StringComparison.OrdinalIgnoreCase)<0,
     "no reference project is named in what the user reads: "+setting.Id+" / "+banned);
   Assert(setting.Source.StartsWith("https://learn.microsoft.com")||setting.Source.StartsWith("https://support.microsoft.com"),
    "every setting points at official documentation, not at the project it was found in: "+setting.Id);
   Assert(!String.IsNullOrWhiteSpace(setting.Technical),"the technical detail exists for whoever wants to audit: "+setting.Id);
   Assert(new[]{"recomendado","opcional","avançado","experimental","segurança"}.Contains(setting.Risk),"every setting declares a risk level: "+setting.Id);
   // Sem botão vazio: interruptor tem operação, escolha tem opções.
   if(setting.IsChoice){
    Assert(setting.On.Length==0,"a choice setting does not also carry a toggle payload: "+setting.Id);
    Assert(setting.Choices.Length>=2,"a choice offers at least two options; with two states it would be a switch: "+setting.Id);
    Assert(setting.Choices.All(c=>c.Ops.Length>0&&!String.IsNullOrWhiteSpace(c.Label)),"every option of a choice writes something and has a label: "+setting.Id);
    // Opções de uma mesma escolha têm de ser MUTUAMENTE EXCLUSIVAS: mesmo valor,
    // conteúdos diferentes. Senão duas opções poderiam ficar "ativas" ao mesmo tempo.
    var targets=setting.Choices.SelectMany(c=>c.Ops).Select(OpKey).Distinct().ToArray();
    Assert(targets.Length==setting.Choices[0].Ops.Length,"all options of a choice write the same values, so they cannot both be active: "+setting.Id);
    Assert(setting.Choices.Select(c=>String.Join(";",c.Ops.Select(o=>o.Data).ToArray())).Distinct().Count()==setting.Choices.Length,
     "two options of the same choice never write identical data: "+setting.Id);
   }else{
    Assert(setting.On.Length>0,"a switch with nothing to write would be an empty button: "+setting.Id);
   }
  }

  // ------------------------------------------------------------------ DEDUPLICAÇÃO
  // A regra central do pedido. Percorre o catálogo INTEIRO — o que já existia e o que
  // acabou de entrar — e falha se dois ids diferentes gravarem o mesmo valor da mesma
  // chave. É isto que impede o mesmo ajuste existir em quatro versões.
  var writers=new Dictionary<string,List<string>>(StringComparer.Ordinal);
  foreach(var item in App.Items.Where(i=>i.Native&&i.Operations!=null)){
   foreach(var op in item.Operations){
    string key=OpKey(op)+"|"+(op.Data??"")+"|"+op.Delete;
    List<string> ids;
    if(!writers.TryGetValue(key,out ids)){ids=new List<string>();writers[key]=ids;}
    if(!ids.Contains(item.Id))ids.Add(item.Id);
   }
  }
  var duplicated=writers.Where(w=>w.Value.Count>1).ToArray();
  foreach(var pair in duplicated)
   Console.WriteLine("DUPLICADO: "+pair.Key+" <- "+String.Join(", ",pair.Value.ToArray()));
  Assert(duplicated.Length==0,"no two catalogue ids write the same value to the same registry key — one function, one id");

  // O mesmo para as opções de escolha: nenhuma opção nova pode colidir com item existente.
  var settingIds=new HashSet<string>(WindowsSettings.AsCatalogItems().Select(i=>i.Id),StringComparer.Ordinal);
  Assert(settingIds.Count==WindowsSettings.AsCatalogItems().Count,"each integrated setting produces uniquely identified catalogue entries");
  Assert(App.Items.Select(i=>i.Id).Distinct().Count()==App.Items.Count,"the whole catalogue has no repeated id after the integration");

  // ------------------------------------------------------------- ajustes que já existiam
  // Prova de que a deduplicação foi feita de verdade: estes ajustes aparecem nos quatro
  // projetos de referência e continuam com UM id só, o que já existia antes desta fase.
  foreach(var pair in new[]{
   new[]{"native-capture","System\\GameConfigStore","GameDVR_Enabled"},
   new[]{"native-gamemode","Software\\Microsoft\\GameBar","AutoGameModeEnabled"},
   new[]{"v5-native-file-extensions","Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced","HideFileExt"},
   new[]{"opt-aligntaskbartoleft","Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced","TaskbarAl"}}){
   var owners=App.Items.Where(i=>i.Native&&i.Operations!=null&&i.Operations.Any(o=>
    String.Equals((o.Key??"").Trim('\\'),pair[1],StringComparison.OrdinalIgnoreCase)&&
    String.Equals(o.Name,pair[2],StringComparison.OrdinalIgnoreCase))).Select(i=>i.Id).ToArray();
   Assert(owners.Length==1&&owners[0]==pair[0],"a setting implemented by all four reference projects has exactly one owner here: "+pair[2]+" -> "+String.Join(",",owners));
  }

  // ------------------------------------------------------------------------ busca
  // O pedido: quem digita "HAGS" encontra "Agendamento de GPU"; quem digita
  // "Win32PrioritySeparation" encontra "Prioridade de programas em primeiro plano".
  var hags=WindowsSettings.Resolve("set-gaming-hags");
  foreach(string term in new[]{"HAGS","HwSchMode","agendamento","GPU"})
   Assert(WindowsSettings.Matches(hags,term),"technical and plain terms both find the feature: "+term);
  Assert(WindowsSettings.Matches(WindowsSettings.Resolve("set-gaming-foreground-priority"),"Win32PrioritySeparation"),"a technical name finds the feature that carries it");
  Assert(!WindowsSettings.Matches(hags,"impressora"),"an unrelated term does not match");

  // ------------------------------------------------------- classificação e segurança
  // Nada experimental ou avançado entra em perfil automático. O pedido é explícito
  // (item 187): o perfil seguro não pode carregar ajuste agressivo em silêncio.
  foreach(var item in WindowsSettings.AsCatalogItems()){
   Assert(!item.DefaultSelected,"no integrated setting is selected by default: "+item.Id);
   Assert(!item.MaxEligible,"no integrated setting joins the automatic maximum profile: "+item.Id);
   Assert(item.Review!=null&&item.Review.Length==2&&item.Review[1].Contains("Desfazer"),"every integrated setting states how it is undone: "+item.Id);
  }
  foreach(var setting in settings.Where(s=>s.Risk=="experimental"))
   Assert(setting.Summary.IndexOf("EXPERIMENTAL",StringComparison.Ordinal)>=0,"an experimental setting says so in the text the user reads: "+setting.Id);

  // Toda opção entra no catálogo e é resolvível pelo motor que aplica.
  foreach(var item in WindowsSettings.AsCatalogItems()){
   Assert(App.ById(item.Id)!=null,"every integrated setting is reachable in the catalogue: "+item.Id);
   Assert(item.Operations.Length>0,"no integrated setting is an empty button: "+item.Id);
   foreach(var op in item.Operations){
    Assert(op.Hive=="HKEY_CURRENT_USER"||op.Hive=="HKEY_LOCAL_MACHINE","an integrated setting only writes to the two supported hives: "+item.Id);
    Assert(!String.IsNullOrWhiteSpace(op.Key)&&!String.IsNullOrWhiteSpace(op.Name),"an integrated setting names the value it writes: "+item.Id);
   }
  }
  ExpectFailure(()=>WindowsSettings.Resolve("nao-existe"),"an unknown setting id is rejected");

  Reset();
 }
}

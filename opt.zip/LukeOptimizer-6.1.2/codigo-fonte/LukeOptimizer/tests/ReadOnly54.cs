using System;
using System.IO;
class ReadOnly54 {
 static int Main(){try{
  foreach(var item in ReviewedFeatures.Items()){Console.WriteLine("API read "+item.Id+": "+NativeSettings.Read(item.ActionCode));}
  foreach(var id in ReviewedDiagnostics.Ids){string result=ReviewedDiagnostics.Read(id);if(String.IsNullOrWhiteSpace(result))throw new Exception("Empty diagnostic: "+id);Console.WriteLine(id+": nonempty response ("+result.Length+" characters)");}
  var key=@"Software\LukeOptimizer-Preflight-"+Guid.NewGuid().ToString("N")+@"\One\Two";
  var op=new RegOp{Hive="HKEY_CURRENT_USER",Key=key,Name="test",Kind="DWord",Data="1"};
  var before=App.Capture(op);try{App.CheckWriteAccess(op);}catch(UnauthorizedAccessException){Console.WriteLine("Permission preflight was denied by this environment; verifying absence of mutation.");}var after=App.Capture(op);
  if(before.KeyExisted||after.KeyExisted)throw new Exception("Permission preflight created a key");
  Console.WriteLine("PASS: real Windows preflight created no registry keys.");
  Console.WriteLine("PASS: Windows read-only APIs and diagnostics. No optimization was applied.");return 0;
 }catch(Exception e){Console.WriteLine(e);return 1;}}
}

using System;
using System.Linq;
using System.Collections.Generic;
partial class EngineTests {
 static void RunV5Tests(){
  Assert(InputTuning.Desired("v5-filter","59,0,200,15,0")=="58,0,200,15,0","FilterKeys removes only enabled bit, keeping all timing and accessibility settings");
  Assert(InputTuning.Desired("v5-sticky","511")=="507","StickyKeys change removes only hotkey flag");
  Assert(InputTuning.Desired("v5-filter","58,0,200,15,0")=="58,0,200,15,0","already disabled FilterKeys idempotent");
  Assert(InputTuning.Desired("v5-keydelay","3")=="0"&&InputTuning.Desired("v5-keyspeed","10")=="31","repeat settings are within documented API ranges");
  ExpectFailure(()=>InputTuning.Parse("v5-filter","1,2"),"malformed FilterKeys backup rejected");
  ExpectFailure(()=>InputTuning.Parse("v5-filter","1,20001,1,1,1"),"out-of-range FilterKeys time rejected");
  ExpectFailure(()=>InputTuning.Parse("v5-keyspeed","32"),"invalid keyboard repeat speed rejected");
  ExpectFailure(()=>InputTuning.Parse("unknown","1"),"unknown keyboard API code rejected");
  Reset();App.Items.AddRange(V5InputItems.Create());native["v5-keydelay"]="2";native["v5-keyspeed"]="12";native["v5-filter"]="59,0,200,15,0";native["v5-sticky"]="511";
  foreach(var item in V5InputItems.Create()){
   var before=new Dictionary<string,string>(native);App.Apply(item);var r=Last();Assert(r.Status=="aplicado"&&r.NativeValues.Count>0,item.Id+" uses durable native backup");App.Undo(r.Id);Assert(before.All(x=>native[x.Key]==x.Value),item.Id+" restores exact native parameters");
  }
  Reset();App.Items.AddRange(V5Options.Items());App.TestMachine.Edition="Professional";V5Options.TestBrowserMajor=x=>200;V5Options.TestFeature=x=>true;
  foreach(var item in V5Options.Items()){
   Assert(!item.DefaultSelected&&!item.MaxEligible&&item.Native&&item.Id.StartsWith("v5-"),item.Id+" explicit individual selection");
   if(V5Options.Compatibility(item,App.TestMachine)!=null)continue;
   registry.Clear();foreach(var op in item.Operations){var before=Copy(op);before.Delete=false;before.Data=op.Delete?"1":op.Kind=="DWord"?"17":"original fixture";registry[Key(before)]=before;}
   var expected=registry.ToDictionary(x=>x.Key,x=>Copy(x.Value));App.Apply(item);var r=Last();Assert(r.Status=="aplicado",item.Id+" applied in isolated registry");App.Undo(r.Id);Assert(expected.Count==registry.Count&&expected.All(x=>registry.ContainsKey(x.Key)&&registry[x.Key].Data==x.Value.Data&&registry[x.Key].Kind==x.Value.Kind),item.Id+" undo restores original values and types");
  }
  var a=new NetworkCapture{Host="example.com",Address="192.0.2.1",AdapterReport="a",Samples=new List<double?>{10,20,null,50,40}};
  Assert(a.Sent==5&&a.Received==4&&a.Loss==20&&a.Average==30&&a.P95==50&&a.Variation==10,"network loss percentiles and consecutive variation handle missing replies");
  var b=new NetworkCapture{Host=a.Host,Address=a.Address,AdapterReport="a",Samples=new List<double?>{5,10,null,25,20}};
  Assert(NetworkWorkbench.Compare(a,b).Contains("-15"),"network comparison computes measured delta");b.Address="192.0.2.2";Assert(NetworkWorkbench.Compare(a,b).Contains("suspensa"),"DNS destination change prevents misleading comparison");b.Address=a.Address;b.Samples.RemoveAt(0);Assert(NetworkWorkbench.Compare(a,b).Contains("suspensa"),"unequal capture sizes rejected");
  var empty=new NetworkCapture{Samples=new List<double?>{null,null}};Assert(empty.Average==null&&empty.Variation==null&&empty.P95==null&&empty.Loss==100,"no ping replies never reported as zero latency");
  Assert(new NetworkCapture{Samples=new List<double?>{1,null,10}}.Variation==null,"jitter does not bridge dropped ping packets");
  ExpectFailure(()=>NetworkWorkbench.Capture("https://example.com","test",System.Threading.CancellationToken.None,n=>{}).GetAwaiter().GetResult(),"network rejects URL before any probe");
  var cancelled=new System.Threading.CancellationToken(true);ExpectFailure(()=>NetworkWorkbench.Capture("127.0.0.1","test",cancelled,n=>{}).GetAwaiter().GetResult(),"cancelled network capture makes no probe");
  Assert(App.ReadUiArguments(new[]{"--ui-page","rede"})&&App.UiPage=="rede","native bridge selects valid network tool without elevation");
  ExpectFailure(()=>App.ReadUiArguments(new[]{"--ui-page","cmd.exe"}),"native bridge cannot launch arbitrary tool");
  ExpectFailure(()=>App.ReadUiArguments(new[]{"--ui-option","native-unknown"}),"native bridge rejects unreviewed option");
  Assert(App.ReadUiArguments(new[]{"--ui-option","v5-input-filter"})&&App.UiOption=="v5-input-filter","native bridge resolves library option for user review");
  Assert(App.ReadUiArguments(new[]{"--ui-option","v5-native-filter"}),"native bridge also resolves native option id");
  App.ToolMode=false;App.UiPage=App.UiOption=null;
  var library=PerformanceLibrary.Load();Assert(library.Select(x=>x.Id).Distinct().Count()==library.Count,"library IDs unique");
  var nativeItems=Builtins.Create().Concat(V5Options.Items()).Concat(V5InputItems.Create()).ToList();
  var trusted=nativeItems.Concat(ImportedOptions.Items()).Concat(ExtraSettings.Items()).Concat(ReviewedFeatures.Items()).Concat(WindowsSettings.AsCatalogItems()).ToList();
  Assert(library.Where(x=>x.Action=="native").All(x=>trusted.Any(i=>i.Id==x.Target)),"every direct library option resolves to actual engine implementation");
  Reset();App.Items.AddRange(V5Options.Items());App.Items.AddRange(V5InputItems.Create());
  Assert(LiquidProtocol.Resolve("v5-option-theme-dark").Single().Id=="v5-native-theme-dark","known display ID converts to canonical target");
  Assert(LiquidProtocol.Resolve("native-window,v5-native-theme-dark").Count==2,"Liquid resolves mixed checkboxes to actual implementations");
  ExpectFailure(()=>LiquidProtocol.Resolve("native-window,native-window"),"Liquid rejects duplicate selection");
  ExpectFailure(()=>LiquidProtocol.Resolve("native-window,unknown.exe"),"Liquid rejects unknown executable before any writes");
  try{LiquidProtocol.Resolve("v5-native-theme-dark,v5-native-theme-light");throw new Exception("expected conflict");}catch(Exception e){Assert(e.Message.Contains("tema dos aplicativos"),"Liquid explains the theme conflict in Portuguese before backup or mutation");}
  Assert(!LiquidProtocol.NeedsAdmin(LiquidProtocol.Resolve("native-window,v5-native-theme-dark")),"user preferences do not unnecessarily request UAC");
  Assert(LiquidProtocol.NeedsAdmin(LiquidProtocol.Resolve("v5-native-edge-background")),"machine policy requires elevation");
  ExpectFailure(()=>LiquidProtocol.ResponsePath("../outside"),"Liquid reply path cannot escape fixed directory");
  Assert(LiquidProtocol.Row("a\tb","line1\nline2","ação %").Split('\n').Length==2,"wire format preserves tabs and newlines without injecting rows");
  var request=Guid.NewGuid().ToString("N");
  Assert(LiquidProtocol.Run(new[]{"--liquid","apply","native-window,v5-native-theme-dark",App.Sid,request})==0,"Liquid headless apply succeeds with isolated Windows backends");
  var reply=System.IO.File.ReadAllText(LiquidProtocol.ResponsePath(request));var applied=Last();
  Assert(reply.Contains("result\taplicado")&&native["window"]=="0"&&applied.ItemIds.Length==2,"headless response reflects actual transaction and both checked options");
  Assert(App.History().Count==1,"one selection creates one reversible transaction");
  Assert(LiquidProtocol.HistoryRows().Contains(applied.Id),"Liquid history returns the actual backup ID");
  request=Guid.NewGuid().ToString("N");
  Assert(LiquidProtocol.Run(new[]{"--liquid","undo",applied.Id,App.Sid,request})==0&&native["window"]=="1"&&registry.Count==0,"headless undo restores exact original state");
  request=Guid.NewGuid().ToString("N");
  Assert(LiquidProtocol.Run(new[]{"--liquid","apply","native-window","wrong-user",request})==1&&native["window"]=="1","Liquid rejects cross-account mutation");
  request=Guid.NewGuid().ToString("N");failWrite=true;
  Assert(LiquidProtocol.Run(new[]{"--liquid","apply","native-window,native-gamemode",App.Sid,request})==0,"headless operation preserves compatible stages after individual failure");
  reply=System.IO.File.ReadAllText(LiquidProtocol.ResponsePath(request));
  Assert(reply.Contains("ok\t1")&&native["window"]=="0"&&Last().IsolatedSteps.Any(r=>r.Status=="falhou e foi desfeito"),"headless reply retains failed child audit and successful sibling");failWrite=false;
  Assert(LiquidProtocol.Resolve(String.Join(",",nativeItems.Select(x=>x.Id).Where(x=>x!="v5-native-theme-light"))).Count==34,"complete native selection accepts more than the old 32-item limit");
  V5Options.TestBrowserMajor=null;V5Options.TestFeature=null;Reset();
 }
}

using System;
using System.IO;
using System.Diagnostics;
using System.Threading;
class ProcessFixture {
 static int Main(string[] args){
  var memory=new byte[32*1024*1024];for(int n=0;n<memory.Length;n+=4096)memory[n]=1;
  if(args.Length==2&&args[0]=="spawn")using(var child=Process.Start(new ProcessStartInfo(Process.GetCurrentProcess().MainModule.FileName,"child "+args[1]){UseShellExecute=false,CreateNoWindow=true})){File.WriteAllText(args[1],child.Id.ToString());Thread.Sleep(30000);}
  else Thread.Sleep(30000);
  GC.KeepAlive(memory);return 0;
 }
}

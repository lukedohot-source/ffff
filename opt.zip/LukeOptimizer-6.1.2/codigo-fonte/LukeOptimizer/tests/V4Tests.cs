using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;

partial class EngineTests {
 static FrameCapture Csv(string text){return FrameAnalysis.Read(new StringReader(text),"test.csv");}
 static FrameSummary Summary(params double[] values){var c=new FrameCapture{File="test.csv"};var stream=new FrameStream{Key="game",Metric="FrameTime",Frames=values.ToList()};c.Streams.Add(stream);return FrameAnalysis.Summarize(c,stream,100,0);}
 static void RunV4Tests(){
  string atomicFile=Path.Combine(App.DataRoot,"atomic-store.txt");AtomicStore.Write(atomicFile,"original");
  // A premissa deste bloco -- um leitor aberto impedir a substituicao -- so existe onde
  // o sistema tem trava obrigatoria de arquivo. Em POSIX o rename sempre vence. Medimos
  // o runtime em vez de supor a plataforma, e pulamos em voz alta em vez de afrouxar.
  if(ReplacementBlockedByReaders()){
   using(var locked=new FileStream(atomicFile,FileMode.Open,FileAccess.Read,FileShare.Read))ExpectFailure(()=>AtomicStore.Write(atomicFile,"replacement"),"locked history file causes atomic save to fail");
   Assert(File.ReadAllText(atomicFile)=="original","failed atomic save preserves the complete previous file");
   Assert(Directory.GetFiles(App.DataRoot,"*.pending").Length==0,"failed atomic write cleans only its own temporary file");
  }else Skip("locked history file causes atomic save to fail","este sistema nao tem trava obrigatoria de arquivo; a garantia vale no Windows e nao pode ser conferida aqui");
  AtomicStore.Write(atomicFile,"replacement");Assert(File.ReadAllText(atomicFile)=="replacement","atomic replacement succeeds after lock release");
  Task concurrentWrite;
  using(var gate=AtomicStore.Acquire(atomicFile))using(var sharedFile=new FileStream(atomicFile,FileMode.Open,FileAccess.Read,FileShare.Read|FileShare.Delete))using(var reader=new StreamReader(sharedFile)){
   concurrentWrite=Task.Run(()=>AtomicStore.Write(atomicFile,"next version"));Assert(!concurrentWrite.Wait(100),"history writer waits while a coordinated reader owns the file");
   Assert(reader.ReadToEnd()=="replacement","open history reader keeps coherent previous version");
  }
  Assert(concurrentWrite.Wait(5000)&&AtomicStore.Read(atomicFile)=="next version","history writer commits after reader releases the file");
  var library=PerformanceLibrary.Load();Assert(library.Count>=70&&library.Select(x=>x.Id).Distinct().Count()==library.Count,"original performance library preserved and unique");
  Assert(library.All(x=>(x.Action=="catalog"||x.Source.StartsWith("https://"))&&!String.IsNullOrWhiteSpace(x.Effect)&&!String.IsNullOrWhiteSpace(x.Tradeoff)),"every option identifies effects, limits and reference");
  Assert(library.Where(x=>x.Action=="native").All(x=>Builtins.Create().Concat(V5Options.Items()).Concat(V5InputItems.Create()).Concat(ImportedOptions.Items()).Concat(ExtraSettings.Items()).Concat(ReviewedFeatures.Items()).Concat(WindowsSettings.AsCatalogItems()).Any(i=>i.Id==x.Target)),"library native actions resolve to trusted items");
  // A contagem deixou de ser fixa (era 10, hoje 41). O que precisa continuar valendo é
  // que nada essencial entre na lista, que todo serviço tenha nível e descrição, e que
  // a lista protegida e a opcional nunca se cruzem — é o que ValidateServiceCatalog confere.
  App.ValidateServiceCatalog();
  Assert(App.OptionalServices.Count>=10&&!App.OptionalServices.Keys.Any(x=>App.ProtectedServices.Contains(x)),"optional service list never contains a protected service");
  Assert(new[]{"WinDefend","wuauserv","BITS","Audiosrv","Dhcp","SysMain","Dnscache","PlugPlay","CryptSvc","VSS","Schedule","Themes"}.All(x=>App.ProtectedServices.Contains(x)&&!App.OptionalServices.ContainsKey(x)),"security, update, network, audio and core services stay out of reach");
  Assert(App.ServicesInTier("leve").All(n=>App.ServiceTier(n)=="leve")&&App.ServicesInTier("agressivo").All(n=>App.ServiceTier(n)!="extremo")&&App.ServicesInTier("extremo").Length==App.OptionalServices.Count,"service tiers nest: leve subset of agressivo subset of extremo");
  Assert(App.ServicesInTier("leve").Length>0&&App.ServicesInTier("leve").Length<App.ServicesInTier("agressivo").Length&&App.ServicesInTier("agressivo").Length<App.ServicesInTier("extremo").Length,"each service tier adds services");
  ExpectFailure(()=>App.ServicesInTier("tudo"),"unknown service tier rejected");
  ExpectFailure(()=>App.DisableOptionalServices(new[]{"Dnscache"}),"protected service rejected by tier-aware allowlist");
  // Launchers e sincronização passaram a ser fecháveis, mas só nos níveis 2 e 3, nunca
  // no nível 1 nem na ação de um clique. O shell continua fora de qualquer nível.
  Assert(ResourceMonitor.Closable.Count>=40&&!ResourceMonitor.Closable.Contains("explorer")&&!ResourceMonitor.Closable.Contains("csrss")&&!ResourceMonitor.Closable.Contains("dwm"),"shell and session processes are never closable");
  Assert(ResourceMonitor.Tier("OneDrive")=="agressivo"&&ResourceMonitor.Tier("steam")=="extremo"&&ResourceMonitor.Tier("chrome")=="leve"&&ResourceMonitor.Tier("explorer")=="","synchronization, launcher and user apps are tiered, shell has no tier");
  Assert(!ResourceMonitor.WithinTier("steam","leve")&&!ResourceMonitor.WithinTier("steam","agressivo")&&ResourceMonitor.WithinTier("steam","extremo"),"launcher only reachable at the extreme tier");
  Assert(!ResourceMonitor.WithinTier("OneDrive","leve")&&ResourceMonitor.WithinTier("OneDrive","agressivo"),"synchronization only reachable from the aggressive tier up");
  Assert(!ResourceMonitor.WithinTier("explorer","extremo"),"a process outside the allowlist belongs to no tier");
  Assert(new[]{"leve","agressivo","extremo"}.All(t=>!String.IsNullOrWhiteSpace(ResourceMonitor.TierWarning(t))&&!String.IsNullOrWhiteSpace(App.ServiceTierWarning(t))),"every tier states what is lost");
  // Um nome genérico casa com processo alheio: "Agent" é backup, monitoramento e EDR
  // corporativo; "Sync" é meia dúzia de produtos. Nada disso pode virar app fechável.
  Assert(!ResourceMonitor.Closable.Contains("Agent")&&!ResourceMonitor.Closable.Contains("Sync")&&!ResourceMonitor.Closable.Contains("Update")&&!ResourceMonitor.Closable.Contains("Service")&&!ResourceMonitor.Closable.Contains("Host")&&!ResourceMonitor.Closable.Contains("Client"),"generic process names never enter the closable list");
  // Closable já é um HashSet, então comparar com Distinct não provaria nada: um nome
  // repetido entre níveis seria absorvido em silêncio e ficaria com o nível errado.
  // Somar os arrays de origem é o que expõe a sobreposição.
  Assert(ResourceMonitor.TierSourceCount("leve")+ResourceMonitor.TierSourceCount("agressivo")+ResourceMonitor.TierSourceCount("extremo")==ResourceMonitor.Closable.Count,"the three process tiers do not overlap");
  ExpectFailure(()=>ResourceMonitor.TierSourceCount("tudo"),"unknown process tier rejected");
  ReopenTests();
  NetworkToolsTests();
  FrameworkSurfaceTests();
  PathShapeTests();
  var parts=FrameAnalysis.ParseLine("\"a,b\",\"x\"\"y\",3",',');Assert(parts.SequenceEqual(new[]{"a,b","x\"y","3"}),"CSV parser handles quoted delimiters and escaped quotes");
  ExpectFailure(()=>FrameAnalysis.ParseLine("\"unfinished",','),"unclosed CSV quotes rejected");
  ExpectFailure(()=>Csv("Application,GPUTime\ngame,8"),"GPU duration is not falsely treated as frame interval");
  ExpectFailure(()=>Csv("FrameTime,FrameTime\n10,12"),"ambiguous duplicate metric rejected");
  ExpectFailure(()=>Csv("FrameTime\nNaN\nInfinity\n0\n-5"),"nonfinite and nonpositive samples rejected");
  var c=Csv("Application,ProcessID,SwapChainAddress,FrameType,MsBetweenPresents\ngame,1,0x1,Rendered,10\ngame,1,0x1,Rendered,20\ngame,1,0x2,Rendered,5\ngame,1,0x1,Generated,5\nother,2,0x1,Rendered,9");
  Assert(c.Streams.Count==4&&c.Streams.First().Frames.Count==2,"different processes, swapchains and generated frames never merged");
  c=Csv("Application;FrameTime\n\"jogo; teste\";16,5\n\"jogo; teste\";17,5\n\"jogo; teste\";NA\ninvalid");
  Assert(c.Streams.Single().Frames.SequenceEqual(new[]{16.5,17.5})&&c.Streams[0].Rejected==1&&c.Malformed==1,"semicolon CSV supports decimal comma and reports invalid rows");
  var stats=Summary(10,10,10,10,60);Assert(Math.Abs(stats.AverageFps-50)<.00001&&stats.P50==10&&stats.P99==60&&stats.Spikes==1,"FPS uses total duration and percentiles preserve spikes");
  Assert(Math.Abs(stats.Low1-1000.0/60)<.00001&&stats.Low01==stats.Low1,"small-sample low definitions use ceiling and preserve worst interval");
  var values=Enumerable.Repeat(10.0,990).Concat(Enumerable.Repeat(50.0,10)).ToArray();stats=Summary(values);
  Assert(stats.Low1==20&&stats.P99==10&&stats.Low01==20,"1 percent low differs correctly from percentile reciprocal");
  stats=Summary(10,2000,10);Assert(stats.Max==2000&&stats.Seconds==2.02,"long stutters and loading pauses are never silently removed");
  c=Csv("FrameTime\n10\n20\n30\n40");stats=FrameAnalysis.Summarize(c,c.Streams[0],100,.03);Assert(stats.Trimmed==2&&stats.Count==2&&stats.Seconds==.07,"warmup trimmed by accumulated time");
  ExpectFailure(()=>FrameAnalysis.Summarize(c,c.Streams[0],100,10),"warmup that removes capture rejected");
  var a=Summary(10,10);var b=Summary(5,5);Assert(FrameAnalysis.Compare(a,b).Contains("+100"),"before/after FPS delta calculated");b.Metric="CPUFrameTime";Assert(FrameAnalysis.Compare(a,b).Contains("suspensa"),"incomparable metrics do not claim gains");
  Assert(HardwareLab.ValidHost("192.168.1.1")&&HardwareLab.ValidHost("example.com")&&!HardwareLab.ValidHost("https://example.com")&&!HardwareLab.ValidHost("host & cmd"),"network input accepts hosts and rejects URLs and shell syntax");
  Reset();var powerValues=PowerTuning.Options.ToDictionary(o=>PowerTuning.Code(active,o.Id),o=>o.Id=="epp"?"50":o.Id=="min"?"100":o.Id=="max"?"90":o.Id=="boost"?"0":"2");
  PowerTuning.TestRead=code=>powerValues[code];PowerTuning.TestWrite=(code,value)=>powerValues[code]=value;
  var req=App.SaveRequest(new OperationRequest{PowerScheme=active,PowerOptions=new[]{"epp","max","min"}});App.ApplyPowerOptions(req);
  var record=Last();Assert(record.Status=="aplicado"&&record.NativeValues.Count==3&&record.NativeValues.All(v=>v.Code.Contains(active)),"power snapshot stores original scheme and exact AC values");
  Assert(powerValues[PowerTuning.Code(active,"epp")]=="25"&&powerValues[PowerTuning.Code(active,"min")]=="5","requested power changes applied in isolated backend");
  App.Undo(record.Id);Assert(powerValues[PowerTuning.Code(active,"epp")]=="50"&&powerValues[PowerTuning.Code(active,"min")]=="100","power undo restores exact original indexes");
  App.ApplyPowerOptions(req);Assert(Last().Status=="aplicado","power profile reapplies after undo");App.ApplyPowerOptions(req);Assert(Last().Status=="sem alterações","power profile idempotent");App.Undo(App.History().First(App.CanUndo).Id);
  App.TestMachine.OnAC=false;ExpectFailure(()=>App.ApplyPowerOptions(req),"power application blocked on battery");Assert(powerValues[PowerTuning.Code(active,"epp")]=="50","battery rejection leaves values unchanged");App.TestMachine.OnAC=true;
  ExpectFailure(()=>App.ApplyPowerOptions(App.SaveRequest(new OperationRequest{PowerScheme=Guid.NewGuid().ToString(),PowerOptions=new[]{"epp"}})),"changed active plan rejected before power mutation");
  ExpectFailure(()=>App.ApplyPowerOptions(App.SaveRequest(new OperationRequest{PowerScheme=active,PowerOptions=new[]{"unknown"}})),"unknown power option rejected");
  PowerTuning.TestWrite=(code,value)=>{if(code.EndsWith("|max")&&value=="100")throw new Exception("simulated power failure");powerValues[code]=value;};
  ExpectFailure(()=>App.ApplyPowerOptions(req),"partial power failure propagates");Assert(powerValues[PowerTuning.Code(active,"epp")]=="50"&&Last().Status=="falhou e foi desfeito","partial power failure rolls back earlier options");
  PowerTuning.TestWrite=(code,value)=>powerValues[code]=value;App.ApplyPowerOptions(req);record=Last();powerValues[PowerTuning.Code(active,"epp")]="75";ExpectFailure(()=>App.Undo(record.Id),"power undo preserves a subsequent user change");powerValues[PowerTuning.Code(active,"epp")]="25";App.Undo(record.Id);
  string originalScheme=active,newScheme=Guid.NewGuid().ToString();PowerTuning.TestWrite=(code,value)=>{powerValues[code]=value;if(code.EndsWith("|epp")&&value=="25")active=newScheme;};
  ExpectFailure(()=>App.ApplyPowerOptions(req),"plan switch during power transaction aborts remaining steps");
  Assert(active==newScheme&&powerValues[PowerTuning.Code(originalScheme,"epp")]=="50","rollback restores original scheme values without switching away from user-selected scheme");
  active=originalScheme;PowerTuning.TestWrite=(code,value)=>powerValues[code]=value;
  Guid plan;ExpectFailure(()=>PowerTuning.Decode("powerac|bad|epp",out plan),"malformed power scheme rejected");
  PowerTuning.TestRead=null;PowerTuning.TestWrite=null;
  Assert(GameProfiles.SetGpuToken("Other=1;GpuPreference=1;")=="Other=1;GpuPreference=2;","GPU setting preserves unrelated preferences");
  Assert(GameProfiles.SetGpuToken("GpuPreference=1;gpupreference=0;")=="GpuPreference=2;","duplicate GPU preference tokens normalized");
  Assert(GameProfiles.AddFullscreenToken("~ HIGHDPIAWARE")=="~ HIGHDPIAWARE DISABLEDXMAXIMIZEDWINDOWEDMODE","fullscreen option preserves unrelated compatibility flags");
  Assert(GameProfiles.AddFullscreenToken("~ DISABLEDXMAXIMIZEDWINDOWEDMODE")=="~ DISABLEDXMAXIMIZEDWINDOWEDMODE","fullscreen token idempotent");
  ExpectFailure(()=>GameProfiles.ValidateExecutable(@"\\server\share\game.exe",false),"UNC game paths rejected");
  ExpectFailure(()=>GameProfiles.ValidateExecutable(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),"System32","cmd.exe"),false),"Windows system executable excluded from game profile");
  ExpectFailure(()=>GameProfiles.ValidateExecutable("game.exe",false),"relative game path rejected");
  // O perfil por jogo exige caminho com letra de unidade e arquivo real; a fixture so
  // pode ser montada no Windows. Pular em voz alta, nunca relaxar ValidateExecutable.
  if(WindowsDrivePaths()){
   Reset();string gameExe=Path.Combine(App.DataRoot,"fake-game.exe");File.WriteAllText(gameExe,"test fixture: never executed");
   var game=new GameProfile{Id=Guid.NewGuid().ToString("N"),Name="Fixture",Executable=gameExe,TargetFps=144,HighGpu=true,DisableFullscreen=true,Notes="teste",CloseApps=new[]{"chrome"}};
   GameProfiles.Save(game);Assert(GameProfiles.Load().Any(p=>p.Id==game.Id&&p.CloseApps[0]=="chrome"),"game profile local persistence round trip");
   var gpuOp=GameProfiles.StringOp(@"Software\Microsoft\DirectX\UserGpuPreferences",gameExe,"Other=1;GpuPreference=1;");registry[Key(gpuOp)]=Copy(gpuOp);
   App.ApplyGameProfile(App.SaveRequest(new OperationRequest{Game=game}));record=Last();Assert(record.Status=="aplicado"&&record.Values.Count==2,"per-game preferences applied as a backed-up transaction");
   Assert(registry[Key(gpuOp)].Data=="Other=1;GpuPreference=2;","per-game transaction keeps existing GPU fields");App.Undo(record.Id);Assert(registry.Count==1&&registry[Key(gpuOp)].Data==gpuOp.Data,"per-game undo restores original values and removes previously absent flags");
   var expected=new List<RegOp>();var operations=GameProfiles.Operations(game,expected);registry[Key(gpuOp)].Data="Other=2;";
   ExpectFailure(()=>App.ApplyTransaction(new[]{new Item{Id="test-game",Name="Game",ReviewTitle="Game",Native=true,ActionCode="gameprofile",Operations=operations.ToArray(),Expected=expected.ToArray()}},"Integrado","Game"),"per-game race detected before overwriting a newer preference");
   Assert(registry[Key(gpuOp)].Data=="Other=2;","newer GPU preference preserved");
   game.CloseApps=new[]{"explorer"};ExpectFailure(()=>GameProfiles.Save(game),"profile cannot add protected process to closing list");
   game.CloseApps=new string[0];game.TargetFps=1001;ExpectFailure(()=>GameProfiles.Save(game),"invalid target FPS rejected");
  }else Skip("per-game profile persistence, transaction, undo and validation","este sistema nao tem caminhos com letra de unidade; a fixture do jogo so existe no Windows");
  Reset();
 }
 // Sobrecargas que EXISTEM no compilador mas NÃO no .NET Framework 4.8.
 //
 // String.Trim/TrimStart/TrimEnd(char) só entraram no .NET Core 2.0. Compilando com um
 // Roslyn moderno contra assemblies de referência novos, a chamada liga na sobrecarga de
 // char e o binário quebra em tempo de execução com MissingMethodException — foi o que
 // aconteceu no executável distribuído: "Método não encontrado: String.TrimEnd(Char)"
 // derrubava a varredura de processos e a tela mostrava "Medição incompleta".
 //
 // O código agora usa TrimEnd(new[]{c}), que liga na sobrecarga params char[] em qualquer
 // compilador. Estas chamadas rodam de verdade: se alguém reintroduzir a forma de um char
 // e o binário for compilado assim, o teste estoura aqui em vez de na mão do usuário.
 // Forma de caminho: a mesma resposta em qualquer plataforma, de proposito.
 // Path.GetInvalidPathChars() varia por sistema (no Windows inclui aspas, |, < e >;
 // fora dele quase nada), entao uma checagem baseada nele significaria coisas
 // diferentes em cada lado e nao poderia ser testada de verdade.
 static void PathShapeTests(){
  foreach(string bad in new[]{"C:\\Apps\\x.exe\" --flag","C:\\Apps\\a|b.exe","C:\\Apps\\a<b.exe","C:\\Apps\\a>b.exe","C:\\Apps\\a*b.exe","C:\\Apps\\a?b.exe","C:\\Apps\\a\rb.exe","C:\\Apps\\a\nb.exe","C:\\Apps\\a\tb.exe"})
   Assert(!App.PathShapeSafe(bad),"a path carrying a shell or quoting character is refused: "+bad.Replace("\r","\\r").Replace("\n","\\n").Replace("\t","\\t"));
  Assert(!App.PathShapeSafe(null)&&!App.PathShapeSafe("")&&!App.PathShapeSafe("   "),"an empty or blank path is never a safe shape");
  foreach(string good in new[]{"C:\\Apps\\chrome.exe","C:\\Program Files\\App\\a b.exe","\\\\server\\share\\app.exe","/usr/bin/app"})
   Assert(App.PathShapeSafe(good),"an ordinary path passes the shape check: "+good);
  // O ponto do conserto: a checagem e string pura e NUNCA lanca, entao pode vir antes
  // de qualquer API de caminho. Se ela lancasse, o bug voltaria pela porta dos fundos.
  foreach(string hostile in new[]{"\"","|","<",">","\0"}){
   bool threw=false;try{App.PathShapeSafe(hostile);}catch{threw=true;}
   Assert(!threw,"the shape check never throws, which is why it can run first");
  }
 }
 static void FrameworkSurfaceTests(){
  // Within normaliza separadores e corta a barra final com TrimEnd -- e essa chamada
  // que quebrava em tempo de execucao. Caminhos literais, nunca pastas do sistema: o
  // teste precisa exercitar a mesma linha em qualquer plataforma.
  Assert(ResourceMonitor.Within(@"C:\Windows\system32\x.exe",@"C:\Windows\"),"ResourceMonitor.Within executes on this runtime, trailing separator included");
  Assert(ResourceMonitor.Within("C:/Windows/system32/x.exe",@"C:\Windows"),"ResourceMonitor.Within normalizes separators before comparing");
  Assert(!ResourceMonitor.Within(@"C:\Apps\fora.exe",@"C:\Windows"),"ResourceMonitor.Within rejects a path outside the folder");
  Assert(!ResourceMonitor.Within(@"C:\WindowsApps\x.exe",@"C:\Windows"),"ResourceMonitor.Within does not match a sibling folder by name prefix");
  // SafePath usa o mesmo TrimEnd e e a ultima barreira antes de excluir arquivo.
  string sandbox=Path.Combine(Path.GetTempPath(),"lo-safepath-"+Guid.NewGuid().ToString("N"));
  Directory.CreateDirectory(sandbox);
  try{
   string inner=Path.Combine(sandbox,"a.tmp");File.WriteAllText(inner,"x");
   Assert(TempCleaner.SafePath(inner,sandbox),"TempCleaner.SafePath executes and accepts a file inside its own root");
   Assert(!TempCleaner.SafePath(sandbox,sandbox),"TempCleaner.SafePath refuses the root directory itself");
   Assert(!TempCleaner.SafePath(Path.Combine(sandbox,"..","fora.tmp"),sandbox),"TempCleaner.SafePath refuses an escape through the parent directory");
  }finally{try{Directory.Delete(sandbox,true);}catch{}}
  string volume=Path.GetPathRoot(Path.GetFullPath(Path.GetTempPath()));
  Assert(!TempCleaner.SafePath(volume,volume),"TempCleaner.SafePath refuses the volume root");
  // As mesmas sobrecargas em forma de asseracao direta, uma por uso real no projeto.
  Assert("a\\".TrimEnd(new[]{'\\'})=="a","TrimEnd(params char[]) is the overload this build binds to");
  Assert("\uFEFFms".TrimStart(new[]{'\uFEFF'})=="ms","TrimStart(params char[]) is the overload this build binds to");
 }
 // Rede: o cliente escolhe um Id, nunca um executável ou argumento. E o catálogo tem de
 // declarar honestamente quem derruba a conexão e quem exige reiniciar, porque é isso
 // que a confirmação mostra antes de executar.
 static void NetworkToolsTests(){
  ExpectFailure(()=>NetworkTools.Resolve("netsh int ip reset"),"network action outside the allowlist rejected");
  ExpectFailure(()=>NetworkTools.Resolve("net-flushdns ; calc.exe"),"network action id with injection rejected");
  ExpectFailure(()=>NetworkTools.Resolve(""),"empty network action id rejected");
  var actions=NetworkTools.Actions();
  Assert(actions.Select(a=>a.Id).Distinct().Count()==actions.Count,"network action ids are unique");
  Assert(actions.All(a=>a.Executable=="ipconfig.exe"||a.Executable=="netsh.exe"),"network actions only run ipconfig or netsh");
  Assert(actions.All(a=>a.Executable.IndexOf('\\')<0&&a.Executable.IndexOf('/')<0),"network executables are resolved by App.SystemExe, never by path");
  Assert(actions.All(a=>a.Arguments.IndexOfAny(new[]{'&','|','>','<','^','"'})<0),"network arguments carry no shell metacharacters");
  Assert(actions.All(a=>a.TimeoutSeconds>0&&a.TimeoutSeconds<=3600),"every network action has a usable timeout");
  Assert(actions.All(a=>a.Administrator),"every network action declares that it needs administrator");
  Assert(actions.All(a=>!String.IsNullOrWhiteSpace(a.Effect)&&!String.IsNullOrWhiteSpace(a.Tradeoff)&&a.Source.StartsWith("https://learn.microsoft.com/")),"every network action states effect, cost and an official source");
  // As duas destrutivas têm de estar marcadas, senão a confirmação mente.
  var winsock=NetworkTools.Resolve("net-winsock");var reset=NetworkTools.Resolve("net-ipreset");
  Assert(winsock.NeedsRestart&&winsock.Disconnects&&!String.IsNullOrEmpty(winsock.BackupArguments),"winsock reset declares restart, disconnect and a backup dump");
  Assert(reset.NeedsRestart&&reset.Disconnects&&!String.IsNullOrEmpty(reset.BackupArguments),"tcp/ip reset declares restart, disconnect and a backup dump");
  Assert(!NetworkTools.Resolve("net-flushdns").NeedsRestart&&!NetworkTools.Resolve("net-flushdns").Disconnects,"flushing the dns cache claims neither restart nor disconnect");
  Assert(NetworkTools.Resolve("net-renew").Disconnects&&!NetworkTools.Resolve("net-renew").NeedsRestart,"renewing the address declares the drop but not a restart");
  Assert(actions.Count(a=>a.NeedsRestart)==2,"only the two repairs require a restart");
  // Nenhuma ação de rede entra na cadeia de desfazer: não há como reverter estes comandos.
  Assert(!App.CanUndo(new Record{Kind="Rede",Status="aplicado",Values=new List<SavedValue>{new SavedValue()}}),"network actions stay out of the undo chain");
  // Elevação: ações pedem administrador, diagnósticos não.
  Assert(App.ActionNeedsAdmin("--network-action","net-winsock"),"network action requests elevation");
  Assert(!App.ActionNeedsAdmin("--network-diagnostic","netdiag-mtu"),"read-only network diagnostic never elevates");
  ExpectFailure(()=>App.ActionNeedsAdmin("--network-diagnostic","netdiag-inventado"),"unknown network diagnostic rejected before elevation");
  ExpectFailure(()=>App.ActionNeedsAdmin("--network-action","netsh firewall set opmode disable"),"unknown network action rejected before elevation");
  // MTU: carga útil + 28 bytes de cabeçalho IPv4+ICMP, e a faixa sondada é a válida.
  Assert(NetworkTools.MtuFromPayload(1472)==1500&&NetworkTools.MtuFromPayload(1464)==1492,"mtu arithmetic adds the 28 header bytes");
  Assert(NetworkTools.MaxPayload==1472&&NetworkTools.MinPayload==548&&NetworkTools.HeaderBytes==28,"mtu probe stays inside the valid ipv4 range");
  Assert(NetworkTools.Diagnostics.All(NetworkTools.IsDiagnostic)&&!NetworkTools.IsDiagnostic("net-winsock"),"diagnostics and actions are different sets");
  Assert(NetworkTools.Diagnostics.All(d=>!String.IsNullOrWhiteSpace(NetworkTools.DiagnosticTitle(d))&&NetworkTools.DiagnosticDetail(d).Length>80),"every network diagnostic explains what it does and does not measure");
  ExpectFailure(()=>NetworkTools.DiagnosticTitle("netdiag-inventado"),"unknown diagnostic title rejected");
 }
 // Reabrir apps fechados nunca deve virar "execute este caminho porque o registro mandou".
 // Todo caminho é revalidado contra a mesma allowlist que autorizou o fechamento.
 static void ReopenTests(){
  Reset();
  ExpectFailure(()=>App.ReopenClosedApps("nao-e-um-guid"),"reopen with malformed record id rejected");
  ExpectFailure(()=>App.ReopenClosedApps(Guid.NewGuid().ToString("N")),"reopen of a missing record rejected");

  Func<List<ClosedApp>,string,Record> store=(apps,kind)=>{
   var r=new Record{Id=Guid.NewGuid().ToString("N"),ItemId="apps",Name="fixture",Time=DateTime.UtcNow.ToString("o"),
    Kind=kind,Status="concluído",Message="",UserSid=App.Sid,Values=new List<SavedValue>(),
    NativeValues=new List<NativeSaved>(),Steps=new List<StepResult>(),Schema=3,ClosedApps=apps};
   App.Save(r);return r;
  };

  var wrongKind=store(new List<ClosedApp>{new ClosedApp{Name="chrome",Path=@"C:\Apps\chrome.exe",Tier="leve"}},"Serviços");
  ExpectFailure(()=>App.ReopenClosedApps(wrongKind.Id),"reopen refuses a record that did not close applications");

  var empty=store(new List<ClosedApp>(),"Apps e RAM");
  ExpectFailure(()=>App.ReopenClosedApps(empty.Id),"reopen refuses a record with nothing to reopen");

  var foreign=store(new List<ClosedApp>{new ClosedApp{Name="chrome",Path=@"C:\Apps\chrome.exe",Tier="leve"}},"Apps e RAM");
  foreign.UserSid="S-1-0-0";App.Save(foreign);
  ExpectFailure(()=>App.ReopenClosedApps(foreign.Id),"reopen refuses another account's record");

  // Um registro adulterado não consegue lançar nada: cada entrada é recusada por um
  // motivo próprio e o resultado fica "falhou", sem nenhum processo iniciado.
  var tampered=store(new List<ClosedApp>{
   new ClosedApp{Name="evil",Path=@"C:\Temp\evil.exe",Tier="leve"},                      // fora da allowlist
   new ClosedApp{Name="chrome",Path=@"..\..\chrome.exe",Tier="leve"},                    // caminho relativo
   new ClosedApp{Name="chrome",Path="C:\\Apps\\chrome.exe\" --disable-web-security",Tier="leve"}, // aspas no caminho
   new ClosedApp{Name="chrome",Path=@"C:\Apps\payload.bat",Tier="leve"},                 // não é .exe
   new ClosedApp{Name="chrome",Path=@"C:\Apps\naoexiste.exe",Tier="leve"}                // não existe
  },"Apps e RAM");
  var result=App.ReopenClosedApps(tampered.Id);
  // A garantia que importa e esta, e nao depende de rotulo nenhum: NADA foi iniciado.
  // Fica separada para que uma mudanca de texto de status jamais possa mascarar um
  // lancamento real.
  Assert(!result.Steps.Any(s=>s.Status=="reaberto"),"a tampered record launches no process at all");
  Assert(result.Status=="falhou"&&result.Steps.Count==5,"every tampered entry is reported, and the record fails as a whole");
  // E a recusa tem de ser LIMPA. Antes, o caminho com aspas estourava ArgumentException
  // dentro de Path.IsPathRooted -- no Windows aspas sao caractere invalido de caminho --
  // e saia pelo catch como "nao reaberto" com a mensagem crua do .NET. Nada era
  // executado, mas o usuario via erro de framework em vez do motivo. Fora do Windows
  // aspas sao validas, IsPathRooted nao lancava, e o defeito ficava invisivel aqui.
  Assert(result.Steps.All(s=>s.Status=="ignorado"),"each tampered entry is refused cleanly, not through an exception");
  Assert(result.Steps[2].Message.Contains("Caminho inv"),"a quoted path is reported as an invalid path, in plain language");
  // O motivo exato das entradas 2 a 5 depende da plataforma (Path.IsPathRooted trata
  // "C:\..." como relativo fora do Windows), então só a recusa pela allowlist é fixada.
  Assert(result.Steps[0].Message.Contains("fora da lista"),"a process outside the allowlist is refused by name, before any path check");
  Assert(result.Steps.All(s=>!String.IsNullOrWhiteSpace(s.Message)),"every refused reopen states a reason");
  Assert(!App.CanUndo(result)&&!App.CanUndo(tampered),"closing and reopening apps stay outside the undo chain");
  Reset();
 }
}

using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;

partial class EngineTests {
 static FrameCapture Csv(string text){return FrameAnalysis.Read(new StringReader(text),"test.csv");}
 static FrameSummary Summary(params double[] values){var c=new FrameCapture{File="test.csv"};var stream=new FrameStream{Key="game",Metric="FrameTime",Frames=values.ToList()};c.Streams.Add(stream);return FrameAnalysis.Summarize(c,stream,100,0);}
 static void RunV4Tests(){
  string atomicFile=Path.Combine(App.DataRoot,"atomic-store.txt");AtomicStore.Write(atomicFile,"original");
  using(var locked=new FileStream(atomicFile,FileMode.Open,FileAccess.Read,FileShare.Read))ExpectFailure(()=>AtomicStore.Write(atomicFile,"replacement"),"locked history file causes atomic save to fail");
  Assert(File.ReadAllText(atomicFile)=="original","failed atomic save preserves the complete previous file");
  Assert(Directory.GetFiles(App.DataRoot,"*.pending").Length==0,"failed atomic write cleans only its own temporary file");
  AtomicStore.Write(atomicFile,"replacement");Assert(File.ReadAllText(atomicFile)=="replacement","atomic replacement succeeds after lock release");
  Task concurrentWrite;
  using(var gate=AtomicStore.Acquire(atomicFile))using(var sharedFile=new FileStream(atomicFile,FileMode.Open,FileAccess.Read,FileShare.Read|FileShare.Delete))using(var reader=new StreamReader(sharedFile)){
   concurrentWrite=Task.Run(()=>AtomicStore.Write(atomicFile,"next version"));Assert(!concurrentWrite.Wait(100),"history writer waits while a coordinated reader owns the file");
   Assert(reader.ReadToEnd()=="replacement","open history reader keeps coherent previous version");
  }
  Assert(concurrentWrite.Wait(5000)&&AtomicStore.Read(atomicFile)=="next version","history writer commits after reader releases the file");
  var library=PerformanceLibrary.Load();Assert(library.Count>=70&&library.Select(x=>x.Id).Distinct().Count()==library.Count,"original performance library preserved and unique");
  Assert(library.All(x=>(x.Action=="catalog"||x.Source.StartsWith("https://"))&&!String.IsNullOrWhiteSpace(x.Effect)&&!String.IsNullOrWhiteSpace(x.Tradeoff)),"every option identifies effects, limits and reference");
  Assert(library.Where(x=>x.Action=="native").All(x=>Builtins.Create().Concat(V5Options.Items()).Concat(V5InputItems.Create()).Concat(ImportedOptions.Items()).Concat(ExtraSettings.Items()).Concat(ReviewedFeatures.Items()).Any(i=>i.Id==x.Target)),"library native actions resolve to trusted items");
  // A contagem deixou de ser fixa (era 10, hoje 41). O que precisa continuar valendo é
  // que nada essencial entre na lista, que todo serviço tenha nível e descrição, e que
  // a lista protegida e a opcional nunca se cruzem — é o que ValidateServiceCatalog confere.
  App.ValidateServiceCatalog();
  Assert(App.OptionalServices.Count>=10&&!App.OptionalServices.Keys.Any(x=>App.ProtectedServices.Contains(x)),"optional service list never contains a protected service");
  Assert(new[]{"WinDefend","wuauserv","BITS","Audiosrv","Dhcp","SysMain","Dnscache","PlugPlay","CryptSvc","VSS","Schedule","Themes"}.All(x=>App.ProtectedServices.Contains(x)&&!App.OptionalServices.ContainsKey(x)),"security, update, network, audio and core services stay out of reach");
  Assert(App.ServicesInTier("leve").All(n=>App.ServiceTier(n)=="leve")&&App.ServicesInTier("agressivo").All(n=>App.ServiceTier(n)!="extremo")&&App.ServicesInTier("extremo").Length==App.OptionalServices.Count,"service tiers nest: leve subset of agressivo subset of extremo");
  Assert(App.ServicesInTier("leve").Length>0&&App.ServicesInTier("leve").Length<App.ServicesInTier("agressivo").Length&&App.ServicesInTier("agressivo").Length<App.ServicesInTier("extremo").Length,"each service tier adds services");
  ExpectFailure(()=>App.ServicesInTier("tudo"),"unknown service tier rejected");
  ExpectFailure(()=>App.DisableOptionalServices(new[]{"Dnscache"}),"protected service rejected by tier-aware allowlist");
  // Launchers e sincronização passaram a ser fecháveis, mas só nos níveis 2 e 3, nunca
  // no nível 1 nem na ação de um clique. O shell continua fora de qualquer nível.
  Assert(ResourceMonitor.Closable.Count>=40&&!ResourceMonitor.Closable.Contains("explorer")&&!ResourceMonitor.Closable.Contains("csrss")&&!ResourceMonitor.Closable.Contains("dwm"),"shell and session processes are never closable");
  Assert(ResourceMonitor.Tier("OneDrive")=="agressivo"&&ResourceMonitor.Tier("steam")=="extremo"&&ResourceMonitor.Tier("chrome")=="leve"&&ResourceMonitor.Tier("explorer")=="","synchronization, launcher and user apps are tiered, shell has no tier");
  Assert(!ResourceMonitor.WithinTier("steam","leve")&&!ResourceMonitor.WithinTier("steam","agressivo")&&ResourceMonitor.WithinTier("steam","extremo"),"launcher only reachable at the extreme tier");
  Assert(!ResourceMonitor.WithinTier("OneDrive","leve")&&ResourceMonitor.WithinTier("OneDrive","agressivo"),"synchronization only reachable from the aggressive tier up");
  Assert(!ResourceMonitor.WithinTier("explorer","extremo"),"a process outside the allowlist belongs to no tier");
  Assert(new[]{"leve","agressivo","extremo"}.All(t=>!String.IsNullOrWhiteSpace(ResourceMonitor.TierWarning(t))&&!String.IsNullOrWhiteSpace(App.ServiceTierWarning(t))),"every tier states what is lost");
  // Um nome genérico casa com processo alheio: "Agent" é backup, monitoramento e EDR
  // corporativo; "Sync" é meia dúzia de produtos. Nada disso pode virar app fechável.
  Assert(!ResourceMonitor.Closable.Contains("Agent")&&!ResourceMonitor.Closable.Contains("Sync")&&!ResourceMonitor.Closable.Contains("Update")&&!ResourceMonitor.Closable.Contains("Service")&&!ResourceMonitor.Closable.Contains("Host")&&!ResourceMonitor.Closable.Contains("Client"),"generic process names never enter the closable list");
  // Closable já é um HashSet, então comparar com Distinct não provaria nada: um nome
  // repetido entre níveis seria absorvido em silêncio e ficaria com o nível errado.
  // Somar os arrays de origem é o que expõe a sobreposição.
  Assert(ResourceMonitor.TierSourceCount("leve")+ResourceMonitor.TierSourceCount("agressivo")+ResourceMonitor.TierSourceCount("extremo")==ResourceMonitor.Closable.Count,"the three process tiers do not overlap");
  ExpectFailure(()=>ResourceMonitor.TierSourceCount("tudo"),"unknown process tier rejected");
  ReopenTests();
  var parts=FrameAnalysis.ParseLine("\"a,b\",\"x\"\"y\",3",',');Assert(parts.SequenceEqual(new[]{"a,b","x\"y","3"}),"CSV parser handles quoted delimiters and escaped quotes");
  ExpectFailure(()=>FrameAnalysis.ParseLine("\"unfinished",','),"unclosed CSV quotes rejected");
  ExpectFailure(()=>Csv("Application,GPUTime\ngame,8"),"GPU duration is not falsely treated as frame interval");
  ExpectFailure(()=>Csv("FrameTime,FrameTime\n10,12"),"ambiguous duplicate metric rejected");
  ExpectFailure(()=>Csv("FrameTime\nNaN\nInfinity\n0\n-5"),"nonfinite and nonpositive samples rejected");
  var c=Csv("Application,ProcessID,SwapChainAddress,FrameType,MsBetweenPresents\ngame,1,0x1,Rendered,10\ngame,1,0x1,Rendered,20\ngame,1,0x2,Rendered,5\ngame,1,0x1,Generated,5\nother,2,0x1,Rendered,9");
  Assert(c.Streams.Count==4&&c.Streams.First().Frames.Count==2,"different processes, swapchains and generated frames never merged");
  c=Csv("Application;FrameTime\n\"jogo; teste\";16,5\n\"jogo; teste\";17,5\n\"jogo; teste\";NA\ninvalid");
  Assert(c.Streams.Single().Frames.SequenceEqual(new[]{16.5,17.5})&&c.Streams[0].Rejected==1&&c.Malformed==1,"semicolon CSV supports decimal comma and reports invalid rows");
  var stats=Summary(10,10,10,10,60);Assert(Math.Abs(stats.AverageFps-50)<.00001&&stats.P50==10&&stats.P99==60&&stats.Spikes==1,"FPS uses total duration and percentiles preserve spikes");
  Assert(Math.Abs(stats.Low1-1000.0/60)<.00001&&stats.Low01==stats.Low1,"small-sample low definitions use ceiling and preserve worst interval");
  var values=Enumerable.Repeat(10.0,990).Concat(Enumerable.Repeat(50.0,10)).ToArray();stats=Summary(values);
  Assert(stats.Low1==20&&stats.P99==10&&stats.Low01==20,"1 percent low differs correctly from percentile reciprocal");
  stats=Summary(10,2000,10);Assert(stats.Max==2000&&stats.Seconds==2.02,"long stutters and loading pauses are never silently removed");
  c=Csv("FrameTime\n10\n20\n30\n40");stats=FrameAnalysis.Summarize(c,c.Streams[0],100,.03);Assert(stats.Trimmed==2&&stats.Count==2&&stats.Seconds==.07,"warmup trimmed by accumulated time");
  ExpectFailure(()=>FrameAnalysis.Summarize(c,c.Streams[0],100,10),"warmup that removes capture rejected");
  var a=Summary(10,10);var b=Summary(5,5);Assert(FrameAnalysis.Compare(a,b).Contains("+100"),"before/after FPS delta calculated");b.Metric="CPUFrameTime";Assert(FrameAnalysis.Compare(a,b).Contains("suspensa"),"incomparable metrics do not claim gains");
  Assert(HardwareLab.ValidHost("192.168.1.1")&&HardwareLab.ValidHost("example.com")&&!HardwareLab.ValidHost("https://example.com")&&!HardwareLab.ValidHost("host & cmd"),"network input accepts hosts and rejects URLs and shell syntax");
  Reset();var powerValues=PowerTuning.Options.ToDictionary(o=>PowerTuning.Code(active,o.Id),o=>o.Id=="epp"?"50":o.Id=="min"?"100":o.Id=="max"?"90":o.Id=="boost"?"0":"2");
  PowerTuning.TestRead=code=>powerValues[code];PowerTuning.TestWrite=(code,value)=>powerValues[code]=value;
  var req=App.SaveRequest(new OperationRequest{PowerScheme=active,PowerOptions=new[]{"epp","max","min"}});App.ApplyPowerOptions(req);
  var record=Last();Assert(record.Status=="aplicado"&&record.NativeValues.Count==3&&record.NativeValues.All(v=>v.Code.Contains(active)),"power snapshot stores original scheme and exact AC values");
  Assert(powerValues[PowerTuning.Code(active,"epp")]=="25"&&powerValues[PowerTuning.Code(active,"min")]=="5","requested power changes applied in isolated backend");
  App.Undo(record.Id);Assert(powerValues[PowerTuning.Code(active,"epp")]=="50"&&powerValues[PowerTuning.Code(active,"min")]=="100","power undo restores exact original indexes");
  App.ApplyPowerOptions(req);Assert(Last().Status=="aplicado","power profile reapplies after undo");App.ApplyPowerOptions(req);Assert(Last().Status=="sem alterações","power profile idempotent");App.Undo(App.History().First(App.CanUndo).Id);
  App.TestMachine.OnAC=false;ExpectFailure(()=>App.ApplyPowerOptions(req),"power application blocked on battery");Assert(powerValues[PowerTuning.Code(active,"epp")]=="50","battery rejection leaves values unchanged");App.TestMachine.OnAC=true;
  ExpectFailure(()=>App.ApplyPowerOptions(App.SaveRequest(new OperationRequest{PowerScheme=Guid.NewGuid().ToString(),PowerOptions=new[]{"epp"}})),"changed active plan rejected before power mutation");
  ExpectFailure(()=>App.ApplyPowerOptions(App.SaveRequest(new OperationRequest{PowerScheme=active,PowerOptions=new[]{"unknown"}})),"unknown power option rejected");
  PowerTuning.TestWrite=(code,value)=>{if(code.EndsWith("|max")&&value=="100")throw new Exception("simulated power failure");powerValues[code]=value;};
  ExpectFailure(()=>App.ApplyPowerOptions(req),"partial power failure propagates");Assert(powerValues[PowerTuning.Code(active,"epp")]=="50"&&Last().Status=="falhou e foi desfeito","partial power failure rolls back earlier options");
  PowerTuning.TestWrite=(code,value)=>powerValues[code]=value;App.ApplyPowerOptions(req);record=Last();powerValues[PowerTuning.Code(active,"epp")]="75";ExpectFailure(()=>App.Undo(record.Id),"power undo preserves a subsequent user change");powerValues[PowerTuning.Code(active,"epp")]="25";App.Undo(record.Id);
  string originalScheme=active,newScheme=Guid.NewGuid().ToString();PowerTuning.TestWrite=(code,value)=>{powerValues[code]=value;if(code.EndsWith("|epp")&&value=="25")active=newScheme;};
  ExpectFailure(()=>App.ApplyPowerOptions(req),"plan switch during power transaction aborts remaining steps");
  Assert(active==newScheme&&powerValues[PowerTuning.Code(originalScheme,"epp")]=="50","rollback restores original scheme values without switching away from user-selected scheme");
  active=originalScheme;PowerTuning.TestWrite=(code,value)=>powerValues[code]=value;
  Guid plan;ExpectFailure(()=>PowerTuning.Decode("powerac|bad|epp",out plan),"malformed power scheme rejected");
  PowerTuning.TestRead=null;PowerTuning.TestWrite=null;
  Assert(GameProfiles.SetGpuToken("Other=1;GpuPreference=1;")=="Other=1;GpuPreference=2;","GPU setting preserves unrelated preferences");
  Assert(GameProfiles.SetGpuToken("GpuPreference=1;gpupreference=0;")=="GpuPreference=2;","duplicate GPU preference tokens normalized");
  Assert(GameProfiles.AddFullscreenToken("~ HIGHDPIAWARE")=="~ HIGHDPIAWARE DISABLEDXMAXIMIZEDWINDOWEDMODE","fullscreen option preserves unrelated compatibility flags");
  Assert(GameProfiles.AddFullscreenToken("~ DISABLEDXMAXIMIZEDWINDOWEDMODE")=="~ DISABLEDXMAXIMIZEDWINDOWEDMODE","fullscreen token idempotent");
  ExpectFailure(()=>GameProfiles.ValidateExecutable(@"\\server\share\game.exe",false),"UNC game paths rejected");
  ExpectFailure(()=>GameProfiles.ValidateExecutable(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),"System32","cmd.exe"),false),"Windows system executable excluded from game profile");
  ExpectFailure(()=>GameProfiles.ValidateExecutable("game.exe",false),"relative game path rejected");
  Reset();string gameExe=Path.Combine(App.DataRoot,"fake-game.exe");File.WriteAllText(gameExe,"test fixture: never executed");
  var game=new GameProfile{Id=Guid.NewGuid().ToString("N"),Name="Fixture",Executable=gameExe,TargetFps=144,HighGpu=true,DisableFullscreen=true,Notes="teste",CloseApps=new[]{"chrome"}};
  GameProfiles.Save(game);Assert(GameProfiles.Load().Any(p=>p.Id==game.Id&&p.CloseApps[0]=="chrome"),"game profile local persistence round trip");
  var gpuOp=GameProfiles.StringOp(@"Software\Microsoft\DirectX\UserGpuPreferences",gameExe,"Other=1;GpuPreference=1;");registry[Key(gpuOp)]=Copy(gpuOp);
  App.ApplyGameProfile(App.SaveRequest(new OperationRequest{Game=game}));record=Last();Assert(record.Status=="aplicado"&&record.Values.Count==2,"per-game preferences applied as a backed-up transaction");
  Assert(registry[Key(gpuOp)].Data=="Other=1;GpuPreference=2;","per-game transaction keeps existing GPU fields");App.Undo(record.Id);Assert(registry.Count==1&&registry[Key(gpuOp)].Data==gpuOp.Data,"per-game undo restores original values and removes previously absent flags");
  var expected=new List<RegOp>();var operations=GameProfiles.Operations(game,expected);registry[Key(gpuOp)].Data="Other=2;";
  ExpectFailure(()=>App.ApplyTransaction(new[]{new Item{Id="test-game",Name="Game",ReviewTitle="Game",Native=true,ActionCode="gameprofile",Operations=operations.ToArray(),Expected=expected.ToArray()}},"Integrado","Game"),"per-game race detected before overwriting a newer preference");
  Assert(registry[Key(gpuOp)].Data=="Other=2;","newer GPU preference preserved");
  game.CloseApps=new[]{"explorer"};ExpectFailure(()=>GameProfiles.Save(game),"profile cannot add protected process to closing list");
  game.CloseApps=new string[0];game.TargetFps=1001;ExpectFailure(()=>GameProfiles.Save(game),"invalid target FPS rejected");
  Reset();
 }
 // Reabrir apps fechados nunca deve virar "execute este caminho porque o registro mandou".
 // Todo caminho é revalidado contra a mesma allowlist que autorizou o fechamento.
 static void ReopenTests(){
  Reset();
  ExpectFailure(()=>App.ReopenClosedApps("nao-e-um-guid"),"reopen with malformed record id rejected");
  ExpectFailure(()=>App.ReopenClosedApps(Guid.NewGuid().ToString("N")),"reopen of a missing record rejected");

  Func<List<ClosedApp>,string,Record> store=(apps,kind)=>{
   var r=new Record{Id=Guid.NewGuid().ToString("N"),ItemId="apps",Name="fixture",Time=DateTime.UtcNow.ToString("o"),
    Kind=kind,Status="concluído",Message="",UserSid=App.Sid,Values=new List<SavedValue>(),
    NativeValues=new List<NativeSaved>(),Steps=new List<StepResult>(),Schema=3,ClosedApps=apps};
   App.Save(r);return r;
  };

  var wrongKind=store(new List<ClosedApp>{new ClosedApp{Name="chrome",Path=@"C:\Apps\chrome.exe",Tier="leve"}},"Serviços");
  ExpectFailure(()=>App.ReopenClosedApps(wrongKind.Id),"reopen refuses a record that did not close applications");

  var empty=store(new List<ClosedApp>(),"Apps e RAM");
  ExpectFailure(()=>App.ReopenClosedApps(empty.Id),"reopen refuses a record with nothing to reopen");

  var foreign=store(new List<ClosedApp>{new ClosedApp{Name="chrome",Path=@"C:\Apps\chrome.exe",Tier="leve"}},"Apps e RAM");
  foreign.UserSid="S-1-0-0";App.Save(foreign);
  ExpectFailure(()=>App.ReopenClosedApps(foreign.Id),"reopen refuses another account's record");

  // Um registro adulterado não consegue lançar nada: cada entrada é recusada por um
  // motivo próprio e o resultado fica "falhou", sem nenhum processo iniciado.
  var tampered=store(new List<ClosedApp>{
   new ClosedApp{Name="evil",Path=@"C:\Temp\evil.exe",Tier="leve"},                      // fora da allowlist
   new ClosedApp{Name="chrome",Path=@"..\..\chrome.exe",Tier="leve"},                    // caminho relativo
   new ClosedApp{Name="chrome",Path="C:\\Apps\\chrome.exe\" --disable-web-security",Tier="leve"}, // aspas no caminho
   new ClosedApp{Name="chrome",Path=@"C:\Apps\payload.bat",Tier="leve"},                 // não é .exe
   new ClosedApp{Name="chrome",Path=@"C:\Apps\naoexiste.exe",Tier="leve"}                // não existe
  },"Apps e RAM");
  var result=App.ReopenClosedApps(tampered.Id);
  Assert(result.Status=="falhou"&&result.Steps.Count==5&&result.Steps.All(s=>s.Status=="ignorado"),"tampered reopen record launches nothing");
  // O motivo exato das entradas 2 a 5 depende da plataforma (Path.IsPathRooted trata
  // "C:\..." como relativo fora do Windows), então só a recusa pela allowlist é fixada.
  Assert(result.Steps[0].Message.Contains("fora da lista"),"a process outside the allowlist is refused by name, before any path check");
  Assert(result.Steps.All(s=>!String.IsNullOrWhiteSpace(s.Message)),"every refused reopen states a reason");
  Assert(!App.CanUndo(result)&&!App.CanUndo(tampered),"closing and reopening apps stay outside the undo chain");
  Reset();
 }
}

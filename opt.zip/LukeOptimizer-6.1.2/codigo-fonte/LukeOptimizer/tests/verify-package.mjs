import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..');
const manifest=JSON.parse(fs.readFileSync(path.join(root,'MANIFESTO-SHA256.json'),'utf8').replace(/^\uFEFF/,''));
let checks=0;
for(const [name,expected] of Object.entries(manifest)) {
  const absolute=path.resolve(root,name);
  if(!absolute.startsWith(root+path.sep))throw new Error('Unsafe path: '+name);
  const actual=crypto.createHash('sha256').update(fs.readFileSync(absolute)).digest('hex');
  if(actual!==expected)throw new Error('Hash mismatch: '+name);
  checks++;
}
if(!checks)throw new Error('Empty manifest');
const sums=fs.readFileSync(path.join(root,'SHA256SUMS.txt'),'utf8').trim().split(/\r?\n/);
if(sums.length!==checks)throw new Error('SHA256SUMS count mismatch');
for(const line of sums){const match=line.match(/^([a-f0-9]{64})  (.+)$/);if(!match||manifest[match[2]]!==match[1])throw new Error('Manifests disagree');}
console.log(`PASS: ${checks} files; both SHA256 manifests agree. No live optimization executed.`);

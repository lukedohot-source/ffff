using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading;

// GERENCIADOR DE DNS — testes.
//
// A parte crítica aqui não é a lista de provedores: é a VALIDAÇÃO. Este é o único lugar
// do programa que monta uma linha de comando com administrador para mexer em rede, e o
// adaptador tem nome que a pessoa controla. Os testes abaixo existem para garantir que
// texto controlado pelo usuário nunca chega à linha de comando.
partial class EngineTests {
 static DnsAdapter Nic(int v4,int v6){
  return new DnsAdapter{Name="Ethernet",Kind="Ethernet",Up=true,
   IndexV4=v4,IndexV6=v6,V4Known=v4>0,V6Known=v6>0};
 }

 // Adaptador de mentira que OBEDECE aos comandos. Sem isso, "aplicar" seria testado
 // contra um eco: o teste veria a sequência de comandos e nada mais. Aqui cada comando
 // muda o estado lido pela chamada seguinte, então a etapa de conferência é exercitada
 // de verdade — inclusive quando ela tem de acusar que não conferiu.
 class FakeNic {
  internal DnsAdapter State;
  internal List<string> Commands=new List<string>();
  internal int FailAt;          // falha no enésimo comando (1-based); 0 = nunca falha
  internal bool Ignore;         // comando "dá certo" e não altera nada: simula troca que não vale
  internal FakeNic(int v4,int v6){State=Nic(v4,v6);}

  internal List<DnsAdapter> Read(){
   var copy=new DnsAdapter{Name=State.Name,Kind=State.Kind,Up=State.Up,
    IndexV4=State.IndexV4,IndexV6=State.IndexV6,V4Known=State.V4Known,V6Known=State.V6Known};
   copy.V4Servers.AddRange(State.V4Servers);copy.V6Servers.AddRange(State.V6Servers);
   return new List<DnsAdapter>{copy};
  }
  internal int Run(string step){
   Commands.Add(step);
   if(FailAt>0&&Commands.Count==FailAt)return 1;
   if(Ignore)return 0;
   bool six=step.IndexOf(" ipv6 ",StringComparison.Ordinal)>=0;
   var servers=six?State.V6Servers:State.V4Servers;
   if(step.IndexOf("source=dhcp",StringComparison.Ordinal)>=0){servers.Clear();return 0;}
   string address=DnsManager.AddressesIn(new List<string>{step}).FirstOrDefault();
   if(address==null)return 0;
   if(step.IndexOf(" primary",StringComparison.Ordinal)>=0){servers.Clear();servers.Add(address);}
   else servers.Add(address);
   return 0;
  }
  internal void Install(){App.TestDnsRead=Read;App.TestDnsCommand=Run;}
  internal static void Uninstall(){App.TestDnsRead=null;App.TestDnsCommand=null;}
 }

 static void RunDnsTests(){
  Reset();

  // ------------------------------------------------------------- catálogo
  var providers=DnsManager.Providers();
  Assert(providers.Count>=10,"the DNS catalogue offers a real choice, not two options");
  Assert(providers.Select(p=>p.Id).Distinct().Count()==providers.Count,"DNS provider ids are unique");
  Assert(providers.All(p=>!String.IsNullOrWhiteSpace(p.Name)&&!String.IsNullOrWhiteSpace(p.Description)),"every DNS provider explains what it is");
  foreach(var p in providers)Assert(FeatureNaming.Violation(p.Name)==null,"a DNS provider is named for who it is: "+p.Name);
  Assert(providers.Count(p=>p.Automatic)==1,"there is exactly one way back to the router's DNS");
  Assert(providers.Any(p=>p.Id==DnsManager.Custom),"a custom option exists for addresses the catalogue does not carry");
  // Todo provedor fixo tem endereço v4 E v6 conferidos — meia troca deixaria metade das
  // consultas indo para o resolvedor antigo.
  foreach(var p in providers.Where(x=>!x.Automatic&&x.Id!=DnsManager.Custom)){
   Assert(DnsManager.ValidAddress(p.V4Primary,false)&&DnsManager.ValidAddress(p.V4Secondary,false),"provider carries two usable IPv4 servers: "+p.Id);
   Assert(DnsManager.ValidAddress(p.V6Primary,true)&&DnsManager.ValidAddress(p.V6Secondary,true),"provider carries two usable IPv6 servers: "+p.Id);
   Assert(p.Doh.StartsWith("https://"),"provider declares its DNS-over-HTTPS endpoint: "+p.Id);
  }
  ExpectFailure(()=>DnsManager.Resolve("dns-inventado"),"a provider outside the catalogue is rejected");

  // ------------------------------------------------------------- validação
  foreach(string good in new[]{"1.1.1.1","8.8.4.4","208.67.222.222","94.140.14.14"})
   Assert(DnsManager.ValidAddress(good,false),"a real IPv4 resolver is accepted: "+good);
  foreach(string good in new[]{"2606:4700:4700::1111","2001:4860:4860::8888","2620:fe::fe"})
   Assert(DnsManager.ValidAddress(good,true),"a real IPv6 resolver is accepted: "+good);

  // Endereço que deixaria o PC sem resolver nome nenhum.
  foreach(string bad in new[]{"0.0.0.0","127.0.0.1","127.5.5.5","224.0.0.1","239.1.2.3","255.255.255.255"})
   Assert(!DnsManager.ValidAddress(bad,false),"an address that would leave the PC unable to resolve is refused: "+bad);
  Assert(!DnsManager.ValidAddress("::1",true)&&!DnsManager.ValidAddress("::",true)&&!DnsManager.ValidAddress("ff02::1",true),"loopback, any and multicast are refused in IPv6 too");

  // Família trocada: um endereço v6 no campo v4 não pode passar.
  Assert(!DnsManager.ValidAddress("1.1.1.1",true)&&!DnsManager.ValidAddress("2606:4700:4700::1111",false),"an address must match the family it is being written into");

  // Lixo, vazio e — o que mais importa — tentativa de injeção.
  foreach(string bad in new[]{"","   ",null,"não é um ip","1.1.1.1.1","1.1.1.256","1.1.1.-1","1.1.1.1a"})
   Assert(!DnsManager.ValidAddress(bad,false),"malformed input is refused: "+(bad??"(nulo)"));
  // IPAddress.TryParse aceita as formas abreviadas de inet_addr: "1.1.1" vira 1.1.0.1 e
  // "8" vira 0.0.0.8. Quem digitasse isso veria o endereço ser "aceito" e ficaria sem
  // resolver nome nenhum. Exigir os quatro octetos é o que fecha essa porta.
  foreach(string shorthand in new[]{"1.1.1","1.1","8","0x1010101","1.1.1."})
   Assert(!DnsManager.ValidAddress(shorthand,false),"a shorthand form that TryParse would accept is refused: "+shorthand);
  foreach(string hostile in new[]{"1.1.1.1 & calc.exe","1.1.1.1\" primary","1.1.1.1 | netsh","1.1.1.1;shutdown","1.1.1.1\r\nnetsh"})
   Assert(!DnsManager.ValidAddress(hostile,false),"an address carrying a command is refused: "+hostile.Replace("\r","\\r").Replace("\n","\\n"));

  Assert(DnsManager.ValidIndex(1)&&DnsManager.ValidIndex(14),"a real interface index is accepted");
  Assert(!DnsManager.ValidIndex(0)&&!DnsManager.ValidIndex(-1)&&!DnsManager.ValidIndex(100000),"an impossible interface index is refused");

  // ---------------------------------------------------- linha de comando montada
  // A garantia central: o comando é feito de número e endereço validados. O NOME do
  // adaptador — texto que a pessoa pode renomear para o que quiser — nunca entra.
  string command=DnsManager.SetArguments("ipv4",14,"1.1.1.1",true);
  Assert(command.Contains("name=14")&&command.Contains("1.1.1.1")&&command.Contains("primary"),"the command identifies the adapter by index and carries the address");
  Assert(command.IndexOfAny(new[]{'"','&','|','<','>','^','\r','\n'})<0,"the built command carries no quoting or shell character");
  var hostileNic=Nic(14,14);hostileNic.Name="Ethernet\" & calc.exe";
  var builtPlan=DnsManager.Plan(hostileNic,DnsManager.Resolve("dns-cloudflare"),null,null);
  foreach(string step in builtPlan){
   Assert(step.IndexOf("calc.exe",StringComparison.OrdinalIgnoreCase)<0,"a hostile adapter name never reaches the command line");
   Assert(step.IndexOfAny(new[]{'"','&','|','<','>','^','\r','\n'})<0,"no plan step carries a shell character");
  }
  ExpectFailure(()=>DnsManager.SetArguments("ipv4",0,"1.1.1.1",true),"an invalid index is refused before a command exists");
  ExpectFailure(()=>DnsManager.SetArguments("ipv4",14,"0.0.0.0",true),"an unusable address is refused before a command exists");
  ExpectFailure(()=>DnsManager.SetArguments("telnet",14,"1.1.1.1",true),"an unknown address family is refused");
  Assert(DnsManager.ResetArguments("ipv4",14).Contains("source=dhcp"),"going back to automatic asks the adapter to take DHCP again");

  // ---------------------------------------------------------------- plano
  var nic=Nic(14,14);
  var plan=DnsManager.Plan(nic,DnsManager.Resolve("dns-cloudflare"),null,null);
  Assert(plan.Count==4,"a full provider writes both servers of both families");
  Assert(plan.Count(s=>s.Contains("ipv4"))==2&&plan.Count(s=>s.Contains("ipv6"))==2,"IPv4 and IPv6 are both written; leaving one behind would send half the queries to the old resolver");
  Assert(plan[0].Contains("primary")&&!plan[1].Contains("primary"),"the first server is primary and the second is not");

  // Adaptador sem IPv6: escreve só o que existe, em vez de falhar ou inventar índice.
  var v4Only=Nic(14,0);
  var v4Plan=DnsManager.Plan(v4Only,DnsManager.Resolve("dns-quad9"),null,null);
  Assert(v4Plan.Count==2&&v4Plan.All(s=>s.Contains("ipv4")),"an adapter without IPv6 gets only the IPv4 servers");
  ExpectFailure(()=>DnsManager.Plan(Nic(0,0),DnsManager.Resolve("dns-quad9"),null,null),"an adapter that exposes no index cannot be changed");

  // Automático devolve as duas famílias ao DHCP.
  var autoPlan=DnsManager.Plan(nic,DnsManager.Resolve(DnsManager.Automatic),null,null);
  Assert(autoPlan.Count==2&&autoPlan.All(s=>s.Contains("source=dhcp")),"automatic returns both families to the router");

  // Personalizado passa pela MESMA validação.
  var custom=DnsManager.Resolve(DnsManager.Custom);
  var customPlan=DnsManager.Plan(nic,custom,"9.9.9.9",null);
  Assert(customPlan.Count==1&&customPlan[0].Contains("9.9.9.9"),"a custom IPv4 address is written on its own");
  ExpectFailure(()=>DnsManager.Plan(nic,custom,"127.0.0.1",null),"a custom address gets the same refusal as a catalogue one");
  ExpectFailure(()=>DnsManager.Plan(nic,custom,"1.1.1.1 && calc",null),"a custom address carrying a command is refused");
  ExpectFailure(()=>DnsManager.Plan(nic,custom,null,null),"an empty custom choice applies nothing");

  // ------------------------------------------------------- backup e desfazer
  // Desfazer tem de devolver EXATAMENTE o que havia, inclusive "automático".
  var stat=Nic(14,14);stat.V4Servers.AddRange(new[]{"8.8.8.8","8.8.4.4"});stat.V6Servers.Add("2001:4860:4860::8888");
  var backup=DnsManager.Capture(stat);
  Assert(!backup.WasDhcp&&backup.V4Servers.Count==2&&backup.V6Servers.Count==1,"the backup records exactly what was configured");
  var restore=DnsManager.RestorePlan(backup);
  Assert(restore.Count==3&&restore[0].Contains("8.8.8.8")&&restore[0].Contains("primary"),"restoring rewrites the previous servers in the original order");
  Assert(restore.Any(s=>s.Contains("ipv6")&&s.Contains("2001:4860:4860::8888")),"restoring covers IPv6 too");

  var wasAuto=Nic(14,14);
  var autoBackup=DnsManager.Capture(wasAuto);
  Assert(autoBackup.WasDhcp,"an adapter with no servers is recorded as automatic");
  var autoRestore=DnsManager.RestorePlan(autoBackup);
  Assert(autoRestore.Count==2&&autoRestore.All(s=>s.Contains("source=dhcp")),"undo returns an automatic adapter to automatic, not to a guessed server");
  ExpectFailure(()=>DnsManager.RestorePlan(null),"restoring without a backup is refused instead of doing nothing quietly");

  // ------------------------------------------------------------ confirmação
  string confirmation=DnsManager.Confirmation(stat,DnsManager.Resolve("dns-cloudflare-family"),plan);
  foreach(string required in new[]{"DNS atual","privacidade","Desfazer","administrador","Aplicar agora?"})
   Assert(confirmation.Contains(required),"the confirmation states what changes and what it costs: "+required);
  Assert(!confirmation.Contains("mais rápida")&&!confirmation.Contains("acelera"),"the confirmation never sells DNS as a speed gain");
  Assert(DnsManager.Describe(wasAuto).Contains("automático"),"an adapter without servers is described as automatic, not as blank");
  Assert(DnsManager.Describe(stat).Contains("8.8.8.8")&&DnsManager.Describe(stat).Contains("IPv6"),"the description shows what is configured in both families");

  // A leitura roda sem elevação e sem lançar, mesmo onde não há rede.
  var read=DnsManager.Read();
  Assert(read!=null,"reading the adapters never throws, even with no network");

  RunDnsApplyTests();
  Reset();
 }

 // ------------------------------------------------------------------ pedido elevado
 static void RunDnsApplyTests(){
  Reset();

  // ---------------------------------------------------------- pedido (payload)
  // O que atravessa para o processo elevado é número e id de catálogo. O NOME do
  // adaptador — texto que a pessoa controla — não entra no pedido.
  var nic=Nic(14,14);nic.Name="Ethernet\" & calc.exe";
  string payload=DnsManager.PayloadFor(nic,"dns-quad9",null,null);
  Assert(payload=="dns-quad9|14|14||","the request carries the provider and two numbers, nothing else: "+payload);
  Assert(payload.IndexOf("calc.exe",StringComparison.OrdinalIgnoreCase)<0&&payload.IndexOf("Ethernet",StringComparison.Ordinal)<0,"a hostile adapter name never reaches the elevated request");
  var parsed=DnsManager.Parse(payload);
  Assert(parsed.Provider.Id=="dns-quad9"&&parsed.IndexV4==14&&parsed.IndexV6==14,"the elevated side parses back exactly what the screen built");
  Assert(DnsManager.PayloadFor(Nic(14,0),"dns-google",null,null)=="dns-google|14|0||","an adapter without IPv6 declares zero for that family");
  Assert(DnsManager.Parse("dns-custom|14|0|9.9.9.9|").CustomV4=="9.9.9.9","a custom request carries the address it will write");
  ExpectFailure(()=>DnsManager.Parse("dns-quad9|14|14"),"a truncated request is rejected");
  ExpectFailure(()=>DnsManager.Parse("dns-quad9|14|14|1.1.1.1|"),"a catalogue provider may not smuggle an address of its own");
  ExpectFailure(()=>DnsManager.Parse("dns-custom|14|14||"),"a custom request with no address applies nothing");
  ExpectFailure(()=>DnsManager.Parse("dns-custom|14|14|127.0.0.1|"),"a custom request gets the same address refusal as the catalogue");
  ExpectFailure(()=>DnsManager.Parse("dns-quad9|0|0||"),"an adapter with no interface index cannot be requested");
  ExpectFailure(()=>DnsManager.Parse("dns-quad9|-14|14||"),"a negative index is rejected");
  ExpectFailure(()=>DnsManager.Parse("dns-quad9| 14|14||"),"an index with padding is rejected instead of silently parsed");
  ExpectFailure(()=>DnsManager.Parse("calc.exe|14|14||"),"a provider outside the catalogue is rejected at the elevation gate");
  Assert(App.ActionNeedsAdmin("--dns-apply","dns-quad9|14|14||"),"changing DNS is gated behind administrator");
  ExpectFailure(()=>App.ActionNeedsAdmin("--dns-apply","dns-quad9|14|14|1.1.1.1|"),"a malformed request is refused BEFORE any elevation");

  // ---------------------------------------------------------- localizar adaptador
  var pair=new List<DnsAdapter>{Nic(14,14),Nic(3,9)};
  Assert(DnsManager.Locate(pair,14,14).IndexV4==14,"the elevated side finds the adapter by index");
  Assert(DnsManager.Locate(pair,3,9).IndexV6==9,"each adapter is found by its own pair of indexes");
  ExpectFailure(()=>DnsManager.Locate(pair,14,9),"an adapter must match EVERY family the request declares; a half match is refused");
  ExpectFailure(()=>DnsManager.Locate(pair,77,77),"an adapter that no longer exists is refused instead of guessed");
  ExpectFailure(()=>DnsManager.Locate(new List<DnsAdapter>{Nic(14,14),Nic(14,14)},14,14),"two adapters on the same index refuse the change rather than pick one");

  // ---------------------------------------------------------- aplicar de verdade
  var fake=new FakeNic(14,14);
  fake.State.V4Servers.Add("192.168.0.1");        // DNS do roteador, como é comum
  fake.Install();
  var record=App.ApplyDns("dns-cloudflare|14|14||",CancellationToken.None);
  Assert(record.Kind=="DNS"&&record.Status=="aplicado"&&record.OutcomeCode=="OK","a real DNS change ends applied and verified");
  Assert(fake.Commands.Count==4,"both servers of both families were written");
  Assert(fake.State.V4Servers.SequenceEqual(new[]{"1.1.1.1","1.0.0.1"}),"the adapter ended with the chosen IPv4 servers, in order");
  Assert(fake.State.V6Servers.SequenceEqual(new[]{"2606:4700:4700::1111","2606:4700:4700::1001"}),"the adapter ended with the chosen IPv6 servers, in order");
  Assert(record.DnsValue!=null&&record.DnsValue.Before.V4Servers.SequenceEqual(new[]{"192.168.0.1"}),"the record keeps exactly what was configured before");
  Assert(record.Steps.Any(s=>s.Id=="dns-backup"&&s.Status=="gravado"),"the backup is a step of its own, before the writes");
  Assert(record.Steps.Any(s=>s.Id=="dns-verify"&&s.Status=="conferido"),"the change is read back and confirmed");
  Assert(record.Steps.All(s=>FeatureNaming.Violation(s.Name)==null),"no step is NAMED after the command it runs");
  Assert(record.Steps.Any(s=>s.Message.Contains("netsh.exe")),"the command itself stays in the body of the step, where an audit looks");
  Assert(App.CanUndo(record),"a DNS change is undoable from the history");
  Assert(App.ActionNeedsAdmin("--undo",record.Id),"undoing a DNS change asks for administrator; without it netsh would be refused");

  // O backup existe no DISCO antes da primeira gravação. Este é o ponto que separa
  // "tem desfazer" de "promete desfazer": se o processo morrer no primeiro comando, o
  // estado anterior já está gravado.
  var early=new FakeNic(14,14);early.State.V4Servers.Add("8.8.8.8");
  string savedBefore=null;bool startedBefore=false;
  App.TestDnsRead=early.Read;
  App.TestDnsCommand=delegate(string step){
   if(early.Commands.Count==0){
    var onDisk=App.History().FirstOrDefault(r=>r.Kind=="DNS"&&r.DnsValue!=null&&r.DnsValue.Before.V4Servers.Contains("8.8.8.8"));
    savedBefore=onDisk==null?null:onDisk.Id;startedBefore=onDisk!=null&&onDisk.ChangesStarted;
   }
   return early.Run(step);
  };
  App.ApplyDns("dns-google|14|14||",CancellationToken.None);
  Assert(savedBefore!=null,"the previous DNS is on disk BEFORE the first command runs");
  Assert(startedBefore,"the record is marked as started before writing, so an interrupted run is recoverable");

  // ---------------------------------------------------------- falha no meio volta
  var broken=new FakeNic(14,14);broken.State.V4Servers.Add("192.168.0.1");broken.FailAt=3;broken.Install();
  var failed=App.ApplyDns("dns-adguard|14|14||",CancellationToken.None);
  Assert(failed.Status=="falhou e foi desfeito","a command that fails mid-plan rolls the adapter back");
  Assert(failed.OutcomeCode=="COMMAND_FAILED","the record says the command failed, not that it worked");
  Assert(broken.State.V4Servers.SequenceEqual(new[]{"192.168.0.1"}),"the adapter is back on the servers it had; no half-written state");
  Assert(broken.State.V6Servers.Count==0,"the IPv6 side is back to automatic, as it was");
  Assert(failed.Steps.Any(s=>s.Id.StartsWith("dns-rollback")),"the rollback is written down step by step");
  Assert(!App.CanUndo(failed),"a change that was undone does not offer undo again");

  // ---------------------------------------------------------- conferência honesta
  // Comando "dá certo" mas nada muda: é o caso em que um app mente dizendo "aplicado".
  var silent=new FakeNic(14,14);silent.State.V4Servers.Add("192.168.0.1");silent.Ignore=true;silent.Install();
  var unverified=App.ApplyDns("dns-quad9|14|14||",CancellationToken.None);
  Assert(unverified.OutcomeCode=="VERIFY_FAILED","a change that cannot be confirmed is NOT reported as confirmed");
  Assert(unverified.Status=="aplicado"&&App.CanUndo(unverified),"an unconfirmed change still offers the way back");
  Assert(unverified.Steps.Any(s=>s.Id=="dns-verify"&&s.Status=="não confere"),"the failed verification is a visible step");
  Assert(unverified.Message.Contains("ATENÇÃO"),"the message says plainly that the reading did not confirm");
  Assert(silent.State.V4Servers.SequenceEqual(new[]{"192.168.0.1"}),"a failed verification does NOT silently change the DNS a second time");

  // ---------------------------------------------------------- desfazer
  var undoable=new FakeNic(14,14);undoable.State.V4Servers.Add("192.168.0.1");undoable.Install();
  var applied=App.ApplyDns("dns-mullvad|14|14||",CancellationToken.None);
  Assert(undoable.State.V4Servers.SequenceEqual(new[]{"194.242.2.2","194.242.2.3"}),"the change really happened before undo is measured");
  App.RestoreDns(applied);
  Assert(applied.Status=="desfeito","undo finishes as undone");
  Assert(undoable.State.V4Servers.SequenceEqual(new[]{"192.168.0.1"}),"undo puts back exactly the servers that were there");
  Assert(undoable.State.V6Servers.Count==0,"undo returns the untouched family to automatic instead of inventing a server");

  // Adaptador que estava em automático volta para automático, não para um chute.
  var wasAuto=new FakeNic(14,14);wasAuto.Install();
  var fromAuto=App.ApplyDns("dns-opendns|14|14||",CancellationToken.None);
  Assert(wasAuto.State.V4Servers.Count==2,"the automatic adapter received the chosen servers");
  App.RestoreDns(fromAuto);
  Assert(wasAuto.State.V4Servers.Count==0&&wasAuto.State.V6Servers.Count==0,"undo returns an automatic adapter to automatic");

  // Mudança POSTERIOR feita fora do app interrompe o desfazer, em vez de sobrescrevê-la.
  var drifted=new FakeNic(14,14);drifted.State.V4Servers.Add("192.168.0.1");drifted.Install();
  var toUndo=App.ApplyDns("dns-cloudflare|14|14||",CancellationToken.None);
  drifted.State.V4Servers.Clear();drifted.State.V4Servers.Add("8.8.8.8");   // alguém trocou depois
  ExpectFailure(()=>App.RestoreDns(toUndo),"undo refuses to overwrite a DNS someone changed afterwards");
  Assert(drifted.State.V4Servers.SequenceEqual(new[]{"8.8.8.8"}),"the newer choice survives the refused undo");

  // ---------------------------------------------------------- recusa antes de gravar
  var absent=new FakeNic(14,14);absent.Install();
  var missing=App.ApplyDns("dns-quad9|77|77||",CancellationToken.None);
  Assert(missing.Status=="falhou antes de alterar"&&!missing.ChangesStarted,"an adapter that vanished stops the change before any write");
  Assert(absent.Commands.Count==0,"nothing was executed for an adapter that is not there");
  Assert(!App.CanUndo(missing),"a change that never started offers no undo");

  var unknown=new FakeNic(14,14);unknown.Install();
  ExpectFailure(()=>App.ApplyDns("dns-inventado|14|14||",CancellationToken.None),"a provider outside the catalogue never reaches a command");
  Assert(unknown.Commands.Count==0,"nothing was executed for an unknown provider");

  // Backup sem caminho de volta não autoriza alteração nenhuma.
  ExpectFailure(()=>DnsManager.RestorePlan(new DnsBackup()),"a backup that describes no adapter is refused instead of becoming a silent no-op undo");

  FakeNic.Uninstall();
  Reset();
 }
}

﻿using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
public partial class MainForm {
 internal void TestUnified(string folder){
  ShowPage("Otimizações");machine=new Machine{Windows=true,Build=26200};scanning=resourceScanning=busy=easyRunning=false;ready=true;SetActions();
  if(homeChecks.Count!=131||homeCards.Count!=9)throw new Exception("Missing primary/advanced checkboxes or categories");
  // 9 -> 10 com a entrada "Rede". O teste existe para pegar entrada da barra lateral
  // que some por engano, então o número continua explícito.
  if(nav.Count!=10+WindowsSettings.Panels().Length||!pages.ContainsKey("Catálogo")||!pages.ContainsKey("Rede"))throw new Exception("Legacy tools lost during navigation simplification: "+nav.Count);
  homeAdvanced.Checked=true;PerformLayout();Application.DoEvents();
  foreach(var pair in homeChecks){
   var check=pair.Value;check.Checked=false;
   typeof(CheckBox).GetMethod("OnClick",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(check,new object[]{EventArgs.Empty});
   if(!check.Checked)throw new Exception("Checkbox click failed: "+pair.Key);
   typeof(CheckBox).GetMethod("OnClick",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(check,new object[]{EventArgs.Empty});
   if(check.Checked)throw new Exception("Checkbox uncheck failed: "+pair.Key);
  }
  ((Button)Controls.Find("home-select-all",true).Single()).PerformClick();
  if(homeChecks.Count(x=>x.Value.Checked)<8||homeChecks.Where(x=>x.Value.Checked).Any(x=>!homeOptions[x.Key].Diagnostic&&OptionInfo.For(App.Items.Single(i=>i.Id==x.Key)).Classification=="Manual"))throw new Exception("Select all includes manual or misses reviewed choices");
  ((Button)Controls.Find("home-clear",true).Single()).PerformClick();if(homeChecks.Any(x=>x.Value.Checked))throw new Exception("Clear leaves hidden selections");
  int applied=0;TestHomeApply=(extreme,ids,diagnostics)=>{applied++;if(!extreme&&(ids.Length!=1||ids[0]!="native-window"||diagnostics.Length!=1))throw new Exception("Apply selection routing");if(extreme&&ids.Any(id=>!ExtremeProfile.Groups().SelectMany(g=>g.Items).Contains(id)))throw new Exception("Extreme allowed unsafe item");return Task.FromResult(true);};
  homeChecks["native-window"].Checked=true;homeChecks["diag54-tcp"].Checked=true;
  ((Button)Controls.Find("home-apply",true).Single()).PerformClick();
  var policy=App.Items.First(i=>i.Native&&(i.Operations??new RegOp[0]).Any(App.IsPolicy));homeChecks[policy.Id].Checked=true;
  ((Button)Controls.Find("home-extreme",true).Single()).PerformClick();if(applied!=2)throw new Exception("Apply/extreme click handlers missing");TestHomeApply=null;
  int undos=0;TestHomeUndo=()=>undos++;var undo=(Button)Controls.Find("home-undo",true).Single();undo.Enabled=true;undo.PerformClick();if(undos!=1)throw new Exception("Undo route failed");TestHomeUndo=null;
  var details=(Button)Controls.Find("home-details-native-window",true).Single();details.PerformClick();if(inlineOverlay==null)throw new Exception("Details missing");((Button)Controls.Find("inline-cancel",true).Single()).PerformClick();if(inlineOverlay!=null)throw new Exception("Details close failed");
  SetHomeSelection(false);homeAdvanced.Checked=false;SetHomeSelection(true);
  foreach(var size in new[]{new Size(1360,900),new Size(1080,720),new Size(1600,1000)}){
   Size=size;ShowPage("Otimizações");PerformLayout();Application.DoEvents();
   if(homeCards.Any(c=>c.Width<280))throw new Exception("Collapsed category");
   if(homeActions.Any(b=>b.Visible&&b.Width<130))throw new Exception("Collapsed action");
   using(var bitmap=new Bitmap(Width,Height)){DrawToBitmap(bitmap,new Rectangle(Point.Empty,Size));bitmap.Save(Path.Combine(folder,"home-"+size.Width+".png"));}
  }
  Console.WriteLine("Unified UI passed: 131 checkbox click/uncheck pairs; select all/clear/apply/extreme/undo/details; all 16 original pages; 3 sizes.");
 }
}

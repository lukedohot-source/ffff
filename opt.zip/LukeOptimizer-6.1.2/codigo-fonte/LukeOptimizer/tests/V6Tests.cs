﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

partial class EngineTests {
 static void RunV6Tests(){
  Reset();
  var diagnosticResult=ExecutionHub.FromRecord(new Record{Id=Guid.NewGuid().ToString("N"),ItemId="sfc-verify",Kind="Diagnóstico",Status="leitura indisponível",OutcomeCode="TIMEOUT"},null);Assert(diagnosticResult.AdministratorRequired&&diagnosticResult.ErrorCode=="TIMEOUT","v6 official diagnostic keeps correct privilege and timeout code");
  var mapped=new Dictionary<Exception,string>{{new UnauthorizedAccessException(),"ACCESS_DENIED"},{new Win32Exception(1223),"CANCELLED"},{new Win32Exception(32),"FILE_LOCKED"},{new Win32Exception(1060),"SERVICE_MISSING"},{new FileNotFoundException(),"PATH_MISSING"},{new DirectoryNotFoundException(),"PATH_MISSING"},{new TimeoutException(),"TIMEOUT"},{new Win32Exception(127),"COMMAND_MISSING"},{new NotSupportedException(),"UNSUPPORTED"},{new System.Net.Sockets.SocketException(10051),"NETWORK_UNAVAILABLE"},{new ArgumentException(),"INVALID_INPUT"}};
  foreach(var error in mapped){var result=ErrorHelp.For(error.Key);Assert(result.ErrorCode==error.Value&&!String.IsNullOrEmpty(result.FriendlyError)&&!String.IsNullOrEmpty(result.Log),"v6 friendly structured error: "+error.Value);}
  foreach(int build in new[]{10240,19045,22000,22631,26100,26200})Assert(PlatformSnapshot.SupportedBuild(build,true),"v6 compatibility matrix build "+build);
  Assert(!PlatformSnapshot.SupportedBuild(9600,true)&&!PlatformSnapshot.SupportedBuild(26100,false),"v6 older Windows and 32-bit rejected");
  var memory=SystemTelemetry.Memory();Assert(memory.TotalBytes>0&&memory.AvailableBytes>=0&&memory.AvailableBytes<=memory.TotalBytes&&memory.UsedBytes+memory.AvailableBytes==memory.TotalBytes,"v6 real read-only memory quantities consistent");
  Assert(memory.CompressedBytes==null&&memory.StandbyBytes==null&&memory.FreeBytes==null,"v6 unavailable memory details never invented");
  var telemetry=new TelemetrySnapshot();SystemTelemetry.Score(telemetry);Assert(!telemetry.HealthScore.HasValue,"v6 no health score without measurements");telemetry.Memory=new MemorySnapshot{TotalBytes=1000,AvailableBytes=50};telemetry.CpuPercent=95;telemetry.RestartPending=true;SystemTelemetry.Score(telemetry);Assert(telemetry.HealthScore==40&&telemetry.HealthExplanation.Contains("não benchmark"),"v6 documented health formula and scope");
  int progressCount=0;var simulated=ExecutionHub.Simulate(new[]{"native-window","native-capture"},CancellationToken.None,(completed,total)=>{Assert(completed==++progressCount&&total==2,"v6 real item progress");});
  Assert(simulated.Completed==2&&simulated.Actions.All(a=>a.State=="não executada"&&!a.CanUndo)&&registry.Count==0&&native["window"]=="1"&&App.History().Count==0,"v6 simulation reads but never applies or creates undo");
  ExecutionHub.Persist(simulated);Assert(File.Exists(Path.Combine(ExecutionHub.ReportsRoot,simulated.Id+".json"))&&ExecutionHub.Text(simulated).Contains("simulação"),"v6 JSON and TXT structured reports");
  using(var cancel=new CancellationTokenSource()){cancel.Cancel();var cancelled=ExecutionHub.Simulate(new[]{"native-window"},cancel.Token,null);Assert(cancelled.Cancelled&&cancelled.Completed==0,"v6 cancelled simulation executes zero items");}
  Reset();App.ApplyMany(new[]{"native-window","native-capture"});var record=Last();Assert(record.Result!=null&&record.Platform!=null&&record.Result.Actions.Count==2&&record.Result.Actions.All(a=>a.CanUndo&&a.State=="aplicada"),"v6 legacy backup gains per-action structured results");App.Undo(record.Id);Assert(Last().Result.Mode=="restauração"&&native["window"]=="1"&&registry.Count==0,"v6 structured record preserves exact rollback");
  Reset();bool cancellation=false;var write=App.TestNativeWrite;App.TestNativeWrite=(code,value)=>{write(code,value);if(value=="0")cancellation=true;};ExecutionControl.TestCancelled=()=>cancellation;
  App.ApplyMany(new[]{"native-window","native-capture"});record=Last();Assert(native["window"]=="0"&&registry.Count==0&&record.Steps.Any(s=>s.Id=="native-capture"&&s.Status=="ignorado"),"v6 cancel mid-batch preserves finished item and skips next");ExecutionControl.TestCancelled=null;App.Undo(record.Id);Assert(native["window"]=="1","v6 rollback after mid-batch cancellation");
  Reset();ExecutionControl.TestCancelled=()=>true;App.ApplyMany(new[]{"native-window","native-capture"});Assert(!Last().ChangesStarted&&native["window"]=="1"&&registry.Count==0,"v6 cancellation before first mutation");ExecutionControl.TestCancelled=null;
  var request=ExecutionControl.Create(new[]{"native-window"},true,false);Assert(!ExecutionControl.NeedsAdmin(request.Id),"v6 simulation request needs no elevation");ExecutionControl.Run(request.Id);ExpectFailure(()=>ExecutionControl.Run(request.Id),"v6 request replay blocked");request.UserSid="S-1-0-0";ExpectFailure(()=>ExecutionControl.Validate(request),"v6 other-account request rejected");request.UserSid=App.Sid;request.Created=DateTime.UtcNow.AddHours(-1).ToString("o");ExpectFailure(()=>ExecutionControl.Validate(request),"v6 expired request rejected");
  Reset();var pref=new ProductPreferences();pref.Profiles["Teste"]=new[]{"native-window","native-capture"};pref.Save();Assert(ProductPreferences.Load().Profiles["Teste"].Length==2&&ProductPreferences.Load().Compact,"v6 profile and preferences round trip");pref.MemoryIntervalMinutes=0;ExpectFailure(()=>pref.Save(),"v6 invalid automatic memory interval rejected");
  using(var self=Process.GetCurrentProcess()){var token=ResourceMonitor.Identify(self);var result=MemoryManager.Trim(new[]{token,token},false,CancellationToken.None);Assert(result.Count==1&&result[0].State=="ignorada"&&result[0].ErrorCode=="PROCESS_PROTECTED","v6 optimizer self-process protected; duplicate PID suppressed");token.Started--;result=MemoryManager.Trim(new[]{token},true,CancellationToken.None);Assert(result[0].State=="falhou","v6 reused process identity refused");}
  CleanupV6Tests();
  string fixture=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"ProcessFixture.exe");
  using(var child=Process.Start(new ProcessStartInfo(fixture){UseShellExecute=false,CreateNoWindow=true})){
   try{Thread.Sleep(500);var selected=ResourceMonitor.Identify(child);ResourceMonitor.Closable.Add(selected.Name);try{var trimmed=MemoryManager.Trim(new[]{selected},false,CancellationToken.None);Assert(trimmed[0].State=="aplicada"&&trimmed[0].BeforeBytes.HasValue&&trimmed[0].AfterBytes.HasValue,"v6 working-set API applied only to an owned disposable test process");}finally{ResourceMonitor.Closable.Remove(selected.Name);}}
   finally{if(!child.HasExited){child.Kill();child.WaitForExit(5000);}}
  }
  string childPid=Path.Combine(App.DataRoot,"job-child.txt");var nested=ManagedCommand.Run(fixture,"spawn "+App.Quote(childPid),2,CancellationToken.None);Assert(nested.TimedOut&&File.Exists(childPid),"v6 owned child spawned inside managed job");bool descendantRunning=false;try{using(var descendant=Process.GetProcessById(Int32.Parse(File.ReadAllText(childPid))))descendantRunning=!descendant.HasExited;}catch(ArgumentException){}Assert(!descendantRunning,"v6 timeout also terminates descendant; no orphan");
  Assert(CommandTools.Catalog().Count==8&&CommandTools.Catalog().All(c=>c.TimeoutSeconds>0&&c.Source.StartsWith("https://learn.microsoft.com/")),"v6 all official diagnostics have timeout and technical source");
  ExpectFailure(()=>CommandTools.Resolve("cmd /c anything"),"v6 command injection outside allowlist rejected");
  var command=ManagedCommand.Run(App.SystemExe("cmd.exe"),"/d /c echo LukeOptimizer-test",5,CancellationToken.None);Assert(command.ExitCode==0&&command.Output.Contains("LukeOptimizer-test")&&File.Exists(command.LogPath),"v6 real owned child output captured with job object");
  command=ManagedCommand.Run(App.SystemExe("ping.exe"),"-n 30 127.0.0.1",1,CancellationToken.None);Assert(command.TimedOut&&command.ExitCode!=0,"v6 timeout terminates owned diagnostic process");
  using(var cancel=new CancellationTokenSource()){cancel.CancelAfter(300);command=ManagedCommand.Run(App.SystemExe("ping.exe"),"-n 30 127.0.0.1",5,cancel.Token);Assert(command.Cancelled&&!command.TimedOut,"v6 cancellation terminates owned process");}
  int handlesBefore;using(var self=Process.GetCurrentProcess())handlesBefore=self.HandleCount;for(int n=0;n<8;n++)ManagedCommand.Run(App.SystemExe("cmd.exe"),"/d /c echo repeat",5,CancellationToken.None);GC.Collect();GC.WaitForPendingFinalizers();using(var self=Process.GetCurrentProcess())Assert(self.HandleCount<=handlesBefore+8,"v6 repeated command execution has bounded handle count");
  Directory.CreateDirectory(ExecutionHub.LogsRoot);string log=Path.Combine(ExecutionHub.LogsRoot,"execucao.log");File.WriteAllText(log,new string('x',2100000));ExecutionHub.Log("rotation","test");Assert(File.Exists(log+".1")&&new FileInfo(log).Length<10000,"v6 execution log rotates at 2 MiB");
  Reset();
 }
 static void CleanupV6Tests(){
  string root=Path.Combine(App.DataRoot,"cleanup-fixture");Directory.CreateDirectory(root);string outside=Path.Combine(App.DataRoot,"personal-document.txt");File.WriteAllText(outside,"preserve");
  StorageManager.TestCategories=()=>new List<CleanupCategory>{new CleanupCategory{Id="test",Name="Fixture",Root=root,Pattern="temp"}};
  try{
   Action<string> create=name=>{string path=Path.Combine(root,name);File.WriteAllText(path,"fixture");File.SetCreationTimeUtc(path,DateTime.UtcNow.AddDays(-30));File.SetLastWriteTimeUtc(path,DateTime.UtcNow.AddDays(-30));File.SetLastAccessTimeUtc(path,DateTime.UtcNow.AddDays(-30));};create("old.tmp");create("locked.tmp");create("preserve.docx");File.WriteAllText(Path.Combine(root,"new.tmp"),"recent");
   var preview=StorageManager.Scan(new[]{"test"},7,CancellationToken.None);Assert(preview.Files.Count==2&&preview.Files.All(f=>f.Path.EndsWith(".tmp")),"v6 preview excludes documents and recent files");
   using(var locked=new FileStream(Path.Combine(root,"locked.tmp"),FileMode.Open,FileAccess.ReadWrite,FileShare.None)){
    var result=StorageManager.Execute(preview,true,CancellationToken.None,null);Assert(result.Actions.Count(a=>a.ErrorCode=="FILE_LOCKED")==1&&File.Exists(Path.Combine(root,"old.tmp")),"v6 simulated cleanup detects locked file without deleting");
    preview=StorageManager.Scan(new[]{"test"},7,CancellationToken.None);result=StorageManager.Execute(preview,false,CancellationToken.None,null);Assert(result.Actions.Count(a=>a.State=="aplicada")==1&&result.Actions.Count(a=>a.State=="ignorada")==1&&!File.Exists(Path.Combine(root,"old.tmp"))&&File.Exists(Path.Combine(root,"locked.tmp")),"v6 permanent cleanup deletes fixture only, skips locked file");
   }
   var repeat=StorageManager.Execute(preview,false,CancellationToken.None,null);Assert(repeat.Actions.Any(a=>a.ErrorCode=="PATH_MISSING"||a.ErrorCode=="OPERATION_FAILED"),"v6 repeat cleanup reports vanished file without corruption");
   Assert(File.Exists(outside)&&File.Exists(Path.Combine(root,"preserve.docx"))&&File.Exists(Path.Combine(root,"new.tmp")),"v6 personal files, wrong extensions and recent files preserved");
   create("changed.tmp");preview=StorageManager.Scan(new[]{"test"},7,CancellationToken.None);File.AppendAllText(Path.Combine(root,"changed.tmp"),"changed");var changed=StorageManager.Execute(preview,false,CancellationToken.None,null);Assert(changed.Actions.Any(a=>a.PathName()=="changed.tmp"&&a.State!="aplicada")&&File.Exists(Path.Combine(root,"changed.tmp")),"v6 changed file refused after preview");
   preview.Time=DateTime.UtcNow.AddHours(-1).ToString("o");ExpectFailure(()=>StorageManager.Execute(preview,false,CancellationToken.None,null),"v6 stale cleanup preview rejected");
   Assert(!TempCleaner.SafePath(outside,root)&&!TempCleaner.SafePath(root,root),"v6 traversal and root deletion refused");
   preview=new CleanupPreview{Time=DateTime.UtcNow.ToString("o"),AgeDays=7,Files=new List<CleanupFile>{new CleanupFile{CategoryId="test",Path=outside}}};var invalid=StorageManager.Execute(preview,false,CancellationToken.None,null);Assert(invalid.Actions[0].ErrorCode=="INVALID_INPUT"&&File.Exists(outside),"v6 forged path outside category cannot be deleted");
  }finally{StorageManager.TestCategories=null;}
 }
}
static class V6OutcomeTestExtensions {internal static string PathName(this ActionOutcome result){return Path.GetFileName(result.Id);}}

using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections.Generic;

// PAINÉIS COMPACTOS — testes de interface.
//
// O que pode dar errado aqui não é o desenho: é a tela mandar para o processo elevado
// algo diferente do que a pessoa marcou. Estes testes conferem a FRONTEIRA — quantas
// alterações ficaram pendentes, o que a revisão mostra e quais ids são enviados.
public partial class MainForm {
 internal void TestSettingsPanels(string directory){
  ready=true;busy=scanning=resourceScanning=easyRunning=productRunning=false;
  machine=new Machine{Windows=true,Build=26200,Edition="Professional"};SetActions();

  var panels=WindowsSettings.Panels();
  CheckUi(panels.Length>=3,"the integration produced more than one compact panel");
  foreach(string panel in panels)CheckUi(pages.ContainsKey(panel),"the compact panel has its own page: "+panel);

  int requests=0;string lastAction=null,lastPayload=null;
  TestElevation=(action,payload)=>{requests++;lastAction=action;lastPayload=payload;return Task.FromResult(true);};

  // Toda configuração declarada tem controle na tela, e todo controle tem o ⓘ ao lado.
  foreach(var setting in WindowsSettings.All()){
   ShowPage(setting.Panel);
   var control=Controls.Find(setting.IsChoice?"settings-pick-"+setting.Id:"settings-toggle-"+setting.Id,true);
   CheckUi(control.Length==1,"every declared setting has exactly one control on screen: "+setting.Id);
   CheckUi(Controls.Find("settings-info-"+setting.Id,true).Length==1,"every setting offers its details on demand: "+setting.Id);
   if(setting.IsChoice){
    var combo=(ComboBox)control[0];
    CheckUi(combo.DropDownStyle==ComboBoxStyle.DropDownList&&combo.Items.Count==setting.Choices.Length+1,
     "a setting with more than two states is a single list, plus \"do not change\": "+setting.Id);
    CheckUi(combo.SelectedIndex==0,"a choice starts at \"do not change\" — nothing is pre-selected: "+setting.Id);
   }else{
    CheckUi(control[0] is ToggleSwitch&&!((CheckBox)control[0]).Checked,"a two-state setting is a switch, and starts off: "+setting.Id);
   }
   // A ficha responde tudo que o pedido exige, sem precisar sair da tela.
   string sheet=SettingSheet(setting);
   foreach(string required in new[]{"O QUE FAZ","ESTADO ATUAL","CLASSIFICAÇÃO","Reinício","Administrador","Compatibilidade","COMO VOLTAR ATRÁS","DETALHES TÉCNICOS","Fonte"})
    CheckUi(sheet.Contains(required),"the details sheet of "+setting.Id+" answers: "+required);
  }

  // ---------------------------------------------------- alterações pendentes
  string target="Personalizar Windows";
  ShowPage(target);
  var pending=(Label)Controls.Find("settings-pending-"+target,true).Single();
  var apply=(Button)Controls.Find("settings-apply-"+target,true).Single();
  CheckUi(pending.Text.Contains("Nenhuma"),"a freshly opened panel has nothing pending");

  var taskview=(ToggleSwitch)Controls.Find("settings-toggle-set-taskbar-taskview",true).Single();
  var seconds=(ToggleSwitch)Controls.Find("settings-toggle-set-taskbar-seconds",true).Single();
  taskview.Checked=true;Application.DoEvents();
  CheckUi(pending.Text.Contains("1 ALTERAÇÃO PENDENTE"),"one switch makes one pending change");
  seconds.Checked=true;Application.DoEvents();
  CheckUi(pending.Text.Contains("2 ALTERAÇÕES PENDENTES")&&apply.Text.Contains("2"),"the bottom bar counts what is pending and says so on the button");

  var combine=(ComboBox)Controls.Find("settings-pick-set-taskbar-combine",true).Single();
  combine.SelectedIndex=2;Application.DoEvents();
  CheckUi(pending.Text.Contains("3 ALTERAÇÕES"),"a choice counts as a pending change too");

  // Revisar NÃO aplica nada e NÃO eleva.
  ((Button)Controls.Find("settings-review-"+target,true).Single()).PerformClick();Application.DoEvents();
  CheckUi(inlineOverlay!=null&&requests==0,"review opens a summary and launches nothing");
  FinishDialog(false);
  CheckUi(PanelSelection(target).Length==3,"closing the review keeps the pending selection intact");

  // Aplicar: revisa primeiro; cancelar não eleva.
  apply.PerformClick();Application.DoEvents();
  CheckUi(inlineOverlay!=null&&requests==0,"applying waits for confirmation");
  FinishDialog(false);
  CheckUi(requests==0,"a cancelled confirmation launches nothing");

  // Confirmar envia EXATAMENTE os ids marcados — nem mais, nem menos.
  apply.PerformClick();Application.DoEvents();FinishDialog(true);
  WaitUi(()=>requests==1);
  CheckUi(lastAction=="--apply-many","the compact panel uses the same backend as the rest of the product");
  var sent=new HashSet<string>(lastPayload.Split(new[]{','}));
  CheckUi(sent.SetEquals(new[]{"set-taskbar-taskview","set-taskbar-seconds","set-taskbar-combine-2"}),
   "exactly the marked settings are sent, and the choice sends the chosen option: "+lastPayload);
  foreach(string id in sent)CheckUi(App.ById(id)!=null&&App.ById(id).Operations.Length>0,"every sent id is a real catalogue entry that writes something: "+id);
  CheckUi(PanelSelection(target).Length==0,"a successful apply clears the pending list");

  // Descartar devolve tudo ao estado neutro.
  taskview.Checked=true;combine.SelectedIndex=1;Application.DoEvents();
  ((Button)Controls.Find("settings-discard-"+target,true).Single()).PerformClick();Application.DoEvents();
  CheckUi(PanelSelection(target).Length==0&&!taskview.Checked&&combine.SelectedIndex==0,"discard clears switches and choices at once");

  // Aplicar sem nada marcado avisa, em vez de elevar à toa.
  apply.PerformClick();Application.DoEvents();
  CheckUi(inlineOverlay!=null&&requests==1,"applying with nothing pending explains instead of elevating");FinishDialog(false);

  // ------------------------------------------------------------ filtros e busca
  ShowPage("Jogos");
  var advanced=(ToggleSwitch)Controls.Find("settings-advanced-Jogos",true).Single();
  var search=(TextBox)Controls.Find("settings-search-Jogos",true).Single();
  var hagsRow=Controls.Find("settings-row-set-gaming-hags",true).Single().Parent;
  var experimental=Controls.Find("settings-row-set-gaming-responsiveness",true).Single().Parent;
  CheckUi(!advanced.Checked,"advanced and experimental settings are hidden by default");
  FilterPanel("Jogos");
  // Control.Visible é EFETIVO e a janela do smoke test não é exibida; a comparação é
  // feita contra uma linha da MESMA página que nunca é escondida pelo filtro.
  var alwaysShown=Controls.Find("settings-row-set-gaming-gamebar-startup",true).Single().Parent;
  if(alwaysShown.Visible){
   CheckUi(!experimental.Visible,"an experimental setting stays hidden until asked for");
   CheckUi(!hagsRow.Visible,"an advanced setting stays hidden until asked for");
  }else SkipUi("advanced/experimental rows hidden by default","a janela do smoke test nao e exibida, entao Visible e falso para tudo");
  advanced.Checked=true;Application.DoEvents();
  if(alwaysShown.Visible)CheckUi(experimental.Visible&&hagsRow.Visible,"the filter reveals advanced and experimental settings");

  // Item 175: quem digita o nome técnico encontra o nome simples.
  search.Text="HAGS";Application.DoEvents();
  if(hagsRow.Visible)CheckUi(!alwaysShown.Visible,"searching a technical name narrows down to the feature that carries it");
  CheckUi(WindowsSettings.Matches(WindowsSettings.Resolve("set-gaming-hags"),"HAGS"),"the technical alias matches the feature that owns it");
  search.Clear();advanced.Checked=false;Application.DoEvents();

  TestElevation=null;
  foreach(var size in new[]{new Size(1200,800),new Size(1600,1000)})
   foreach(string panel in panels){
    Size=size;ShowPage(panel);PerformLayout();Application.DoEvents();
    using(var bitmap=new Bitmap(Width,Height)){DrawToBitmap(bitmap,new Rectangle(Point.Empty,Size));
     bitmap.Save(Path.Combine(directory,"painel-"+size.Width+"-"+Array.IndexOf(panels,panel)+".png"));}
   }
  Console.WriteLine("Compact panels UI passed: "+panels.Length+" panels, "+WindowsSettings.All().Count+" settings, pending/review/apply/discard, filters and technical search. No system setting changed.");
 }
}

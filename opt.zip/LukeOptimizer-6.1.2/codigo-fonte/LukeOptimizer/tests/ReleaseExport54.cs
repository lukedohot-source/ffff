using System;
using System.IO;
using System.Linq;
class ReleaseExport54 {
 static int Main(string[] args){
  App.Items=PerformanceLibrary.OriginalItems().Concat(CatalogIds.NativeItems()).ToList();CatalogIds.Validate();
  if(App.Items.Select(i=>i.Id).Distinct().Count()!=App.Items.Count)throw new Exception("Duplicate full catalog IDs");
  var native=CatalogIds.NativeItems();var ids=ExtremeProfile.Groups().SelectMany(g=>g.Items).ToArray();
  if(ids.Any(id=>!ExtremeProfile.IsReviewed(native.Single(i=>i.Id==id))))throw new Exception("Unsafe extreme profile");
  File.WriteAllText(args[0],App.Json.Serialize(new{Version=App.Version,FullCatalogIds=App.Items.Select(i=>i.Id).ToArray(),NativeIds=native.Select(i=>i.Id).ToArray(),NativeActions=native,LibraryIds=PerformanceLibrary.Load().Select(i=>i.Id).ToArray(),ExtremeAllowed=ids,ExtremeDefaults=ExtremeProfile.Groups().Where(g=>g.Selected).SelectMany(g=>g.Items).ToArray(),Policies=native.Where(i=>(i.Operations??new RegOp[0]).Any(App.IsPolicy)).Select(i=>new{i.Id,Classification=OptionInfo.For(i).Classification}).ToArray()}));
  Console.WriteLine("PASS: "+App.Items.Count+" unique catalog IDs; "+native.Count+" native IDs; "+PerformanceLibrary.Load().Count+" unique library IDs; "+ids.Length+" extreme allowlist entries.");return 0;
 }
}

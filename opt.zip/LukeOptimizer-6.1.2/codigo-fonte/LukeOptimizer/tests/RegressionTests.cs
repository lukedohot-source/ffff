using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
partial class EngineTests {
 static void RunRegressionTests(){
  FullCatalog();App.ApplyMany(new[]{"native-window"});var previous=Last();
  App.TestAccess=o=>{throw new UnauthorizedAccessException("Simulated denial");};App.ApplyMany(new[]{"native-gamemode"});var denied=Last();
  Assert(denied.Status=="sem alterações"&&!denied.ChangesStarted&&!App.CanUndo(denied)&&denied.Values.Count==0,"denied-only apply never creates a reversible change");
  Assert(denied.Evidence.All(e=>e.Requested=="DWord = 1"&&e.Outcome=="Ignorado por falta de permissão"&&!e.WriteAttempted),"denied evidence retains original request and reason, never claims already configured");
  App.UndoLatest();Assert(native["window"]=="1"&&App.History().Single(r=>r.Id==previous.Id).Status=="desfeito","undo after a denied no-op restores the previous actual change");
  denied.Status="aplicado";denied.ChangesStarted=true;Assert(!App.CanUndo(denied),"old empty applied records cannot hide real backups");
  foreach(bool multiple in new[]{false,true}){
   FullCatalog();App.TestAccess=o=>{if(o.Name=="GameDVR_Enabled")throw new UnauthorizedAccessException("Simulated partial denial");};
   App.ApplyMany(multiple?new[]{"native-capture","native-window"}:new[]{"native-capture"});var record=Last();
   Assert(record.Evidence.Count(e=>e.ItemId=="native-capture"&&e.WriteAttempted)==2&&record.Evidence.Single(e=>e.PermissionSkipped).Requested=="DWord = 0","partial permission applies remaining values consistently, multiple="+multiple);
   Assert(record.Status=="aplicado"&&record.Evidence.Single(e=>e.PermissionSkipped).Outcome=="Ignorado por falta de permissão","partial apply accurately reports denied target, multiple="+multiple);
   App.Undo(record.Id);Assert(registry.Count==0&&native["window"]=="1","partial permission undo restores all changed values, multiple="+multiple);
  }
  FullCatalog();App.ApplyMany(new[]{"native-window"});previous=Last();App.TestAccess=o=>{throw new UnauthorizedAccessException("Simulated denial");};
  App.ApplyMany(new[]{"native-capture","native-gamemode"});Assert(Last().Status=="sem alterações"&&!App.CanUndo(Last()),"fully denied multi-selection remains a no-op");App.UndoLatest();Assert(native["window"]=="1","fully denied batch preserves previous undo target");
  Assert(ReviewedDiagnostics.StabilityArguments("System").Contains("/rd:true"),"stability diagnostic requests newest events first");ExpectFailure(()=>ReviewedDiagnostics.StabilityArguments("System & cmd"),"stability query rejects arbitrary logs");
  ExpectFailure(()=>App.ValidateRemovalPayload("debloat-000|../outside"),"removal cancellation request cannot escape its directory");
  ExpectFailure(()=>App.ValidateRemovalPayload("unknown|"+Guid.NewGuid().ToString("N")),"removal route validates selected apps before launching");
  string token=Guid.NewGuid().ToString("N");Assert(App.ValidateRemovalPayload("debloat-000|"+token)[1]==token,"removal worker accepts exact catalog IDs and a unique cancellation token");
  FullCatalog();Assert(App.ActionNeedsAdmin("--extreme","native-power"),"explicit high-performance power selection requests required elevation");Assert(!App.ActionNeedsAdmin("--extreme","native-window"),"ordinary extreme user settings do not request elevation");
  Reset();
 }
}

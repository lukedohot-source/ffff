using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Security.AccessControl;
using Microsoft.Win32;

// Changes only a newly generated HKCU test namespace, never Windows settings.
class RegistryFixture54 {
 static int Main(){string root=@"Software\LukeOptimizer-Fixture-"+Guid.NewGuid().ToString("N");bool createdFixture=false;
  try{
   Directory.CreateDirectory(App.RecordsRoot);App.TestMachine=new Machine{Windows=true,Build=26200};
   var kinds=new[]{RegistryValueKind.DWord,RegistryValueKind.QWord,RegistryValueKind.String,RegistryValueKind.ExpandString,RegistryValueKind.MultiString,RegistryValueKind.Binary,RegistryValueKind.None};
   object[] data={17,1234567890123L,"antes","%TEMP%\\literal",new[]{"a","b"},new byte[]{0,1,255},new byte[]{23,5}};
   using(var hive=RegistryKey.OpenBaseKey(RegistryHive.CurrentUser,RegistryView.Registry64)){
    using(var prior=hive.OpenSubKey(root)){if(prior!=null)throw new Exception("Test namespace already exists");}
    using(var key=hive.CreateSubKey(root+@"\Existing")){createdFixture=true;for(int n=0;n<kinds.Length;n++)key.SetValue("Value"+n,data[n],kinds[n]);}
   }
   var ops=kinds.Select((kind,n)=>new RegOp{Hive="HKEY_CURRENT_USER",Key=root+@"\Existing",Name="Value"+n,Kind="DWord",Data="9"}).ToList();
   ops.Add(new RegOp{Hive="HKEY_CURRENT_USER",Key=root+@"\Missing\Nested",Name="NewValue",Kind="String",Data="new"});
   var snapshots=ops.Select(App.Capture).ToArray();
   var item=new Item{Id="fixture54",Name="Isolated registry fixture",ReviewTitle="Isolated registry fixture",Native=true,ActionCode="fixture",Operations=ops.ToArray(),ManualAllowed=true};
   App.ApplyTransaction(new[]{item},"Nativo",item.Name);var record=App.History().First();if(record.Status!="aplicado")throw new Exception("Fixture apply failed");App.Undo(record.Id);
   for(int n=0;n<ops.Count;n++){var now=App.Capture(ops[n]);if(now.Before.Kind!=snapshots[n].Before.Kind||now.Before.Data!=snapshots[n].Before.Data||now.Before.Delete!=snapshots[n].Before.Delete)throw new Exception("Typed undo mismatch: "+n);}
   using(var hive=RegistryKey.OpenBaseKey(RegistryHive.CurrentUser,RegistryView.Registry64))using(var key=hive.OpenSubKey(root+@"\Missing"))if(key!=null)throw new Exception("Undo left a newly created empty ancestor");
   Console.WriteLine("PASS: real HKCU fixture restores DWORD, QWORD, String, ExpandString, MultiString, Binary, None, absent values and absent parent keys.");
   string protectedKey=root+@"\Denied";RegistrySecurity original;
   using(var hive=RegistryKey.OpenBaseKey(RegistryHive.CurrentUser,RegistryView.Registry64)){
    using(var created=hive.CreateSubKey(protectedKey)){created.SetValue("Value",11);}
    using(var key=hive.OpenSubKey(protectedKey,RegistryKeyPermissionCheck.ReadWriteSubTree,RegistryRights.FullControl)){
     original=key.GetAccessControl();var denied=key.GetAccessControl();denied.AddAccessRule(new RegistryAccessRule(new System.Security.Principal.SecurityIdentifier(App.Sid),RegistryRights.SetValue,AccessControlType.Deny));key.SetAccessControl(denied);
     try{
      var op=new RegOp{Hive="HKEY_CURRENT_USER",Key=protectedKey,Name="Value",Kind="DWord",Data="0"};bool rejected=false;try{App.CheckWriteAccess(op);}catch(UnauthorizedAccessException){rejected=true;}
      if(!rejected||App.Capture(op).Before.Data!="11")throw new Exception("Denied access was not detected without mutation");
     }finally{var restored=new RegistrySecurity();restored.SetSecurityDescriptorBinaryForm(original.GetSecurityDescriptorBinaryForm(),AccessControlSections.Access);key.SetAccessControl(restored);}
    }
   }
   Console.WriteLine("PASS: real ACL denial is detected by read-only preflight; test ACL restored.");return 0;
  }catch(Exception e){Console.WriteLine(e);return 1;}
  finally{
   if(!root.StartsWith(@"Software\LukeOptimizer-Fixture-",StringComparison.Ordinal)||root.Length!=63)throw new Exception("Unexpected cleanup namespace");
   if(createdFixture)using(var hive=RegistryKey.OpenBaseKey(RegistryHive.CurrentUser,RegistryView.Registry64))CleanFixture(hive,root,root);
   Console.WriteLine("Isolated HKCU fixture removed. No Windows optimization settings changed.");
  }
 }
 static void CleanFixture(RegistryKey hive,string path,string root){
  if(path!=root&&!path.StartsWith(root+"\\",StringComparison.Ordinal))throw new Exception("Fixture boundary");
  string[] children;using(var key=hive.OpenSubKey(path,false)){if(key==null)return;children=key.GetSubKeyNames();}
  foreach(var child in children)CleanFixture(hive,path+"\\"+child,root);
  hive.DeleteSubKey(path,false);
 }
}

﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Drawing;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections.Generic;

public partial class MainForm {
 void CheckUi(bool value,string message){if(!value)throw new Exception(message);Console.WriteLine("PASS UI "+message);}
 // Um teste de interface cuja premissa e um comportamento do WinForms do Windows nao
 // pode virar PASS nem sumir: vira SKIP com o motivo escrito.
 void SkipUi(string message,string why){Console.WriteLine("SKIP UI "+message+" -- "+why);}
 // ListView.ItemCheck com veto (e.NewValue=Unchecked) e comportamento do WinForms do
 // Windows; outras implementacoes podem nem levantar o evento em atribuicao direta.
 // Medimos com uma lista descartavel em vez de supor a plataforma.
 bool ItemCheckVetoHonoured(){
  using(var probe=new ListView{CheckBoxes=true}){
   probe.Items.Add(new ListViewItem("probe"));
   probe.ItemCheck+=(s,e)=>{e.NewValue=CheckState.Unchecked;};
   probe.Items[0].Checked=true;
   return !probe.Items[0].Checked;
  }
 }
 void FinishDialog(bool accept){((Button)Controls.Find(accept?"inline-accept":"inline-cancel",true).Single()).PerformClick();Application.DoEvents();}
 void WaitUi(Func<bool> done){var until=DateTime.UtcNow.AddSeconds(8);while(!done()&&DateTime.UtcNow<until){Application.DoEvents();Thread.Sleep(10);}CheckUi(done(),"async UI operation completed within timeout");}
 internal void TestFunctional(string directory){
  ready=true;busy=scanning=resourceScanning=easyRunning=false;machine=new Machine{Windows=true,Build=26200};SetActions();
  CheckUi(pages.ContainsKey("Remover apps")&&pages.ContainsKey("Ajustes manuais"),"removal and manual pages are reachable");
  CheckUi(removalList is CheckableList&&removalList.Items.Count==141&&removalChecked.Count==0,"all 141 app definitions have visible checkboxes and no defaults");
  int requests=0;string lastAction=null,lastPayload=null;TestElevation=(action,payload)=>{requests++;lastAction=action;lastPayload=payload;return Task.FromResult(true);};
  var apps=AppRemoval.Catalog();TestRemovalScan=()=>apps.Select((a,n)=>new AppRemovalState{App=a,Known=true,Installed=n<2,CanRemove=n==0,State=n==0?"Instalado":n==1?"Protegido pelo Windows":"Não instalado"}).ToList();
  ShowPage("Remover apps");removalScanButton.PerformClick();CheckUi(removalStates.Count(s=>s.CanRemove)==1,"app scan updates individual eligibility");
  // O que PROTEGE o app nao e a caixa: e removalChecked (fonte da verdade da tela), o
  // filtro por CanRemove antes de elevar e a releitura do estado dentro do processo
  // elevado. Essa parte e conferida sempre; so o veto visual depende da plataforma.
  removalList.Items[1].Checked=true;
  CheckUi(removalChecked.Count==0,"protected app never enters the selection that reaches elevation");
  if(ItemCheckVetoHonoured())CheckUi(!removalList.Items[1].Checked,"protected app cannot be selected");
  else SkipUi("protected app checkbox is visually refused","este WinForms nao honra o veto de ListView.ItemCheck em atribuicao direta");
  removalList.Items[1].Checked=false;
  removalList.Items[0].Checked=true;CheckUi(removalChecked.SetEquals(new[]{apps[0].Id}),"only explicitly checked removable app enters selection");
  removalSearch.Text=apps.Last().Name;removalSearch.Clear();CheckUi(removalChecked.Count==1&&removalList.Items[0].Checked,"filtering preserves explicit app selection");
  removalApplyButton.PerformClick();CheckUi(inlineOverlay!=null&&requests==0,"removal requires review before worker launch");FinishDialog(false);CheckUi(requests==0,"removal cancellation launches no worker");
  removalApplyButton.PerformClick();FinishDialog(true);CheckUi(requests==1&&lastAction=="--remove-apps"&&App.ValidateRemovalPayload(lastPayload)[0]==apps[0].Id,"confirmed removal launches only selected app IDs");
  removalRequest=Guid.NewGuid().ToString("N");SetActions();removalCancelButton.PerformClick();CheckUi(File.Exists(App.RemovalCancelPath(removalRequest)),"stop button writes cancellation for its own request");removalRequest=null;
  ShowPage("Ajustes manuais");CheckUi(!manualPicks.Values.Any(p=>p.Checked)&&!manualApplyButton.Enabled,"manual tuning requires explicit field selection");
  manualPicks["priority"].Checked=true;manualValues["priority"].Value=38;manualApplyButton.PerformClick();CheckUi(inlineOverlay!=null&&requests==1,"manual tuning waits for review");FinishDialog(true);CheckUi(requests==2&&lastAction=="--apply-custom"&&lastPayload=="priority=38","manual apply sends selected decimal field only");
  manualPicks["priority"].Checked=false;
  var record=new Record{Id=Guid.NewGuid().ToString("N"),ItemId="native-window",ItemIds=new[]{"native-window"},Name="UI fixture",Time=DateTime.UtcNow.ToString("o"),UserSid=App.Sid,Kind="Nativo",Status="aplicado",ChangesStarted=true,Values=new List<SavedValue>(),NativeValues=new List<NativeSaved>{new NativeSaved{Code="window",Before="1",After="0"}},Steps=new List<StepResult>()};App.Save(record);App.TestNativeRead=code=>"0";RefreshHistory();
  ShowPage("Otimizações");SetHomeSelection(false);homeChecks["native-window"].Checked=true;((Button)Controls.Find("home-restore-selection",true).Single()).PerformClick();CheckUi(inlineOverlay!=null&&requests==2,"selective restore reviews captured backup before launch");FinishDialog(true);CheckUi(requests==3&&lastAction=="--restore-selection"&&lastPayload==record.Id+"|native-window","selective restore binds exact backup and chosen settings");
  ShowPage("Histórico");RefreshHistory();history.Items[0].Selected=true;Application.DoEvents();SetActions();string original=File.ReadAllText(App.RecordPath(record.Id));historyVerifyButton.PerformClick();WaitUi(()=>inlineOverlay!=null);CheckUi(File.ReadAllText(App.RecordPath(record.Id))==original,"verify current does not rewrite previous history");FinishDialog(false);
  historyExportButton.PerformClick();CheckUi(inlineOverlay!=null&&File.Exists(Path.Combine(App.DataRoot,"logs",record.Id+".txt")),"history export writes an actual TXT log");FinishDialog(false);
  // ------------------------------------------------------------------ DNS
  // O painel de DNS é o único lugar da tela que monta um pedido para um processo
  // elevado. O que se confere aqui é justamente a fronteira: o que a tela ENVIA.
  ShowPage("Rede");
  App.TestDnsRead=()=>new List<DnsAdapter>{
   new DnsAdapter{Name="Ethernet \" & calc.exe",Kind="Ethernet",Up=true,IndexV4=14,IndexV6=14,V4Known=true,V6Known=true}};
  RefreshDnsAdapters();
  CheckUi(dnsProviderBox.Items.Count==DnsManager.Providers().Count&&dnsAdapterBox.Items.Count==1,"the DNS panel lists the whole catalogue and the adapters actually read");
  CheckUi(dnsProviderBox.DropDownStyle==ComboBoxStyle.DropDownList,"DNS is a single choice list, not a pile of mutually exclusive switches");
  CheckUi(!dnsCustomV4.Enabled&&!dnsCustomV6.Enabled,"the address fields stay closed until the custom option is chosen");
  int before=requests;
  dnsProviderBox.SelectedIndex=dnsProviderBox.Items.IndexOf("Personalizado");Application.DoEvents();
  CheckUi(dnsCustomV4.Enabled&&dnsCustomV6.Enabled,"choosing the custom option opens the address fields");
  dnsApplyButton.PerformClick();Application.DoEvents();
  CheckUi(inlineOverlay!=null&&requests==before,"an empty custom choice is refused on screen, with nothing launched");FinishDialog(false);
  dnsCustomV4.Text="1.1.1.1 && calc.exe";dnsApplyButton.PerformClick();Application.DoEvents();
  CheckUi(inlineOverlay!=null&&requests==before,"an address carrying a command is refused before any elevation");FinishDialog(false);
  dnsCustomV4.Text="";
  dnsProviderBox.SelectedIndex=dnsProviderBox.Items.IndexOf("Cloudflare");Application.DoEvents();
  dnsApplyButton.PerformClick();Application.DoEvents();
  CheckUi(inlineOverlay!=null&&requests==before,"changing DNS waits for a review that states the cost");
  FinishDialog(true);WaitUi(()=>requests==before+1);
  CheckUi(lastAction=="--dns-apply"&&lastPayload=="dns-cloudflare|14|14||","the screen sends provider and interface numbers only");
  CheckUi(lastPayload.IndexOf("calc.exe",StringComparison.OrdinalIgnoreCase)<0&&lastPayload.IndexOf("Ethernet",StringComparison.Ordinal)<0,"a renamed adapter never reaches the elevated command line");
  App.TestDnsRead=null;RefreshDnsAdapters();

  App.TestNativeRead=null;TestElevation=null;TestRemovalScan=null;record.Status="desfeito";App.Save(record);RefreshHistory();
  foreach(var size in new[]{new Size(1080,720),new Size(1360,900)})foreach(string page in new[]{"Remover apps","Ajustes manuais","Histórico","Otimizações"}){
   Size=size;ShowPage(page);PerformLayout();Application.DoEvents();using(var bitmap=new Bitmap(Width,Height)){DrawToBitmap(bitmap,new Rectangle(Point.Empty,Size));bitmap.Save(Path.Combine(directory,"functional-"+size.Width+"-"+Array.IndexOf(new[]{"Remover apps","Ajustes manuais","Histórico","Otimizações"},page)+".png"));}
  }
  Console.WriteLine("Functional UI passed: removal scan/select/protection/review/cancel; manual tuning; selective restore; history verify/export; 2 sizes. No system setting changed.");
 }
}

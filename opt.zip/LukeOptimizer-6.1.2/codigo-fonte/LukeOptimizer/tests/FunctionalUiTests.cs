﻿using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections.Generic;

public partial class MainForm {
 void CheckUi(bool value,string message){if(!value)throw new Exception(message);Console.WriteLine("PASS UI "+message);}
 void FinishDialog(bool accept){((Button)Controls.Find(accept?"inline-accept":"inline-cancel",true).Single()).PerformClick();Application.DoEvents();}
 void WaitUi(Func<bool> done){var until=DateTime.UtcNow.AddSeconds(8);while(!done()&&DateTime.UtcNow<until){Application.DoEvents();Thread.Sleep(10);}CheckUi(done(),"async UI operation completed within timeout");}
 internal void TestFunctional(string directory){
  ready=true;busy=scanning=resourceScanning=easyRunning=false;machine=new Machine{Windows=true,Build=26200};SetActions();
  CheckUi(pages.ContainsKey("Remover apps")&&pages.ContainsKey("Ajustes manuais"),"removal and manual pages are reachable");
  CheckUi(removalList is CheckableList&&removalList.Items.Count==141&&removalChecked.Count==0,"all 141 app definitions have visible checkboxes and no defaults");
  int requests=0;string lastAction=null,lastPayload=null;TestElevation=(action,payload)=>{requests++;lastAction=action;lastPayload=payload;return Task.FromResult(true);};
  var apps=AppRemoval.Catalog();TestRemovalScan=()=>apps.Select((a,n)=>new AppRemovalState{App=a,Known=true,Installed=n<2,CanRemove=n==0,State=n==0?"Instalado":n==1?"Protegido pelo Windows":"Não instalado"}).ToList();
  ShowPage("Remover apps");removalScanButton.PerformClick();CheckUi(removalStates.Count(s=>s.CanRemove)==1,"app scan updates individual eligibility");
  removalList.Items[1].Checked=true;CheckUi(!removalList.Items[1].Checked&&removalChecked.Count==0,"protected app cannot be selected");
  removalList.Items[0].Checked=true;CheckUi(removalChecked.SetEquals(new[]{apps[0].Id}),"only explicitly checked removable app enters selection");
  removalSearch.Text=apps.Last().Name;removalSearch.Clear();CheckUi(removalChecked.Count==1&&removalList.Items[0].Checked,"filtering preserves explicit app selection");
  removalApplyButton.PerformClick();CheckUi(inlineOverlay!=null&&requests==0,"removal requires review before worker launch");FinishDialog(false);CheckUi(requests==0,"removal cancellation launches no worker");
  removalApplyButton.PerformClick();FinishDialog(true);CheckUi(requests==1&&lastAction=="--remove-apps"&&App.ValidateRemovalPayload(lastPayload)[0]==apps[0].Id,"confirmed removal launches only selected app IDs");
  removalRequest=Guid.NewGuid().ToString("N");SetActions();removalCancelButton.PerformClick();CheckUi(File.Exists(App.RemovalCancelPath(removalRequest)),"stop button writes cancellation for its own request");removalRequest=null;
  ShowPage("Ajustes manuais");CheckUi(!manualPicks.Values.Any(p=>p.Checked)&&!manualApplyButton.Enabled,"manual tuning requires explicit field selection");
  manualPicks["priority"].Checked=true;manualValues["priority"].Value=38;manualApplyButton.PerformClick();CheckUi(inlineOverlay!=null&&requests==1,"manual tuning waits for review");FinishDialog(true);CheckUi(requests==2&&lastAction=="--apply-custom"&&lastPayload=="priority=38","manual apply sends selected decimal field only");
  manualPicks["priority"].Checked=false;
  var record=new Record{Id=Guid.NewGuid().ToString("N"),ItemId="native-window",ItemIds=new[]{"native-window"},Name="UI fixture",Time=DateTime.UtcNow.ToString("o"),UserSid=App.Sid,Kind="Nativo",Status="aplicado",ChangesStarted=true,Values=new List<SavedValue>(),NativeValues=new List<NativeSaved>{new NativeSaved{Code="window",Before="1",After="0"}},Steps=new List<StepResult>()};App.Save(record);App.TestNativeRead=code=>"0";RefreshHistory();
  ShowPage("Otimizações");SetHomeSelection(false);homeChecks["native-window"].Checked=true;((Button)Controls.Find("home-restore-selection",true).Single()).PerformClick();CheckUi(inlineOverlay!=null&&requests==2,"selective restore reviews captured backup before launch");FinishDialog(true);CheckUi(requests==3&&lastAction=="--restore-selection"&&lastPayload==record.Id+"|native-window","selective restore binds exact backup and chosen settings");
  ShowPage("Histórico");RefreshHistory();history.Items[0].Selected=true;Application.DoEvents();SetActions();string original=File.ReadAllText(App.RecordPath(record.Id));historyVerifyButton.PerformClick();WaitUi(()=>inlineOverlay!=null);CheckUi(File.ReadAllText(App.RecordPath(record.Id))==original,"verify current does not rewrite previous history");FinishDialog(false);
  historyExportButton.PerformClick();CheckUi(inlineOverlay!=null&&File.Exists(Path.Combine(App.DataRoot,"logs",record.Id+".txt")),"history export writes an actual TXT log");FinishDialog(false);
  App.TestNativeRead=null;TestElevation=null;TestRemovalScan=null;record.Status="desfeito";App.Save(record);RefreshHistory();
  foreach(var size in new[]{new Size(1080,720),new Size(1360,900)})foreach(string page in new[]{"Remover apps","Ajustes manuais","Histórico","Otimizações"}){
   Size=size;ShowPage(page);PerformLayout();Application.DoEvents();using(var bitmap=new Bitmap(Width,Height)){DrawToBitmap(bitmap,new Rectangle(Point.Empty,Size));bitmap.Save(Path.Combine(directory,"functional-"+size.Width+"-"+Array.IndexOf(new[]{"Remover apps","Ajustes manuais","Histórico","Otimizações"},page)+".png"));}
  }
  Console.WriteLine("Functional UI passed: removal scan/select/protection/review/cancel; manual tuning; selective restore; history verify/export; 2 sizes. No system setting changed.");
 }
}

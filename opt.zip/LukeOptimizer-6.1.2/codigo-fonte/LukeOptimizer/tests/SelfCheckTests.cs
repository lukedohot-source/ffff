using System;
using System.Linq;
using System.Threading;
using System.Collections.Generic;

// CONFERÊNCIA REAL — testes.
//
// Há um limite honesto aqui: estes testes rodam contra o registro SIMULADO, então eles
// provam que a conferência detecta corretamente mudou/não mudou/voltou/não voltou — e
// NÃO provam que gravar no Registro do Windows funciona. Provar isso é justamente o
// trabalho da conferência quando ela roda na máquina de verdade.
//
// O que se testa aqui, e é o que pode dar errado no código: a conferência precisa
// ACUSAR quando o valor não muda e quando não volta. Uma conferência que diz "tudo certo"
// para tudo seria pior que nenhuma.
partial class EngineTests {
 static void RunSelfCheckTests(){
  Reset();
  FullCatalog();

  // ------------------------------------------------------------- quem entra
  var candidates=SelfCheck.Candidates();
  Assert(candidates.Count>0,"the verification has options to check");
  Assert(candidates.All(i=>i.Native),"only executable functions are verified");
  Assert(candidates.All(i=>SelfCheck.ExcludedFromWrite(i)==null),"every candidate passes the exclusion rule");
  // O plano de energia troca configuração do sistema inteiro e não tem volta imediata
  // exata: fica de fora por segurança, e o motivo é escrito.
  var power=App.Items.First(i=>i.ActionCode=="power");
  Assert(SelfCheck.ExcludedFromWrite(power)!=null,"the power plan is kept out of the write verification");
  Assert(SelfCheck.ExcludedFromWrite(power).Contains("energia"),"the exclusion says why, in plain language");
  Assert(!candidates.Any(i=>i.ActionCode=="power"),"the excluded option never reaches the candidate list");
  Assert(SelfCheck.ExcludedFromWrite(null)!=null,"a missing item is refused instead of crashing");

  // ---------------------------------------------------------------- leitura
  var target=App.ById("native-capture");
  string before=SelfCheck.Snapshot(target);
  Assert(before.Length>0,"the snapshot reads the values the option touches");
  Assert(before.Contains("GameDVR_Enabled"),"the snapshot names each value it read");
  Assert(SelfCheck.Snapshot(null)=="","a snapshot of nothing is empty, not an exception");

  // ------------------------------------------------- modo leitura não altera
  string registryBefore=String.Join(";",registry.OrderBy(x=>x.Key).Select(x=>x.Key+"="+x.Value.Data).ToArray());
  var readOnly=App.RunSelfCheck(SelfCheck.ReadOnly,CancellationToken.None);
  Assert(String.Join(";",registry.OrderBy(x=>x.Key).Select(x=>x.Key+"="+x.Value.Data).ToArray())==registryBefore,
   "the read-only verification changes NOTHING");
  Assert(readOnly.Status=="consulta concluída"&&readOnly.Message.Contains("SOMENTE LEITURA"),"the read-only report says plainly that nothing was changed");
  Assert(readOnly.Steps.Count==SelfCheck.Candidates().Count,"the read-only report covers every candidate");

  // ------------------------------------------------ ciclo completo: bom caso
  Reset();FullCatalog();
  var full=App.RunSelfCheck(SelfCheck.Full,CancellationToken.None);
  Assert(full.Status=="consulta concluída","the full verification finishes");
  Assert(full.Message.Contains("COMPLETO"),"the report says which mode ran");
  Assert(full.OutcomeCode=="OK","with a working backend nothing is reported as failing to restore");
  // A prova que importa: o registro voltou ao estado inicial depois de aplicar e desfazer
  // TODAS as opções. Se o desfazer não funcionasse, isto acusaria.
  Assert(registry.Count==0,"after applying and undoing every option, the registry is back to where it started");
  Assert(native["window"]=="1"&&native["menu"]=="400","the API preferences are back to their original values too");
  Assert(full.Message.Contains("Mudaram o Windows de verdade"),"the report answers the question that was asked");
  Assert(full.Steps.Any(s=>s.Status=="mudou e voltou"),"at least one option is reported as changed and restored");
  Assert(!full.Steps.Any(s=>s.Status=="mudou e NÃO voltou"),"no option is reported as unrestored on a healthy backend");

  // ------------------------------------- acusa quando a gravação NÃO tem efeito
  // failReadback faz a gravação de AutoGameModeEnabled não valer: é exatamente o caso
  // "o app disse que aplicou e o Windows não mudou". A conferência tem de perceber.
  Reset();FullCatalog();failReadback=true;
  var silent=App.RunSelfCheck(SelfCheck.Full,CancellationToken.None);
  failReadback=false;
  Assert(silent.Message.Contains("NÃO MUDARAM NADA AO APLICAR"),"the report calls out options whose write had no effect");
  Assert(silent.Steps.Any(s=>s.Status=="não mudou"),"an option that did not change is reported as such, never as applied");

  // --------------------------------------- acusa quando NÃO volta ao original
  // failRollback quebra a restauração. O relatório tem de destacar isso em primeiro
  // lugar: uma opção que muda e não volta é pior que uma que não faz nada.
  Reset();FullCatalog();failRollback=true;
  var broken=App.RunSelfCheck(SelfCheck.Full,CancellationToken.None);
  failRollback=false;
  Assert(broken.OutcomeCode=="RESTORE_FAILED","a failed restore changes the outcome code of the whole run");
  Assert(broken.Message.Contains("PRECISA DE ATENÇÃO")&&broken.Message.Contains("NÃO VOLTARAM AO ORIGINAL"),
   "the report puts the unrestored options at the top, with a warning");
  Assert(broken.Message.Contains("Antes:"),"the report shows the original value, so it can be put back by hand");

  // ------------------------------------------------------------- honestidade
  Assert(full.Message.Contains("NÃO diz")&&full.Message.Contains("melhora o desempenho"),
   "the report states its own limit: it proves the value was written, not that it made anything faster");
  Assert(App.ActionNeedsAdmin("--self-check",SelfCheck.Full),"the full verification asks for administrator");
  Assert(!App.ActionNeedsAdmin("--self-check",SelfCheck.ReadOnly),"the read-only verification does not ask for administrator it does not need");

  Reset();
 }
}

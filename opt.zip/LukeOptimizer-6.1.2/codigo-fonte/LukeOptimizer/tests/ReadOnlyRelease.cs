using System;
using System.IO;
using System.Linq;
class ReadOnlyRelease {
 static int Main(){try{
  Directory.CreateDirectory(App.RecordsRoot);App.Items=CatalogIds.NativeItems();
  var machine=App.ScanHardware();Console.WriteLine("Windows recognized: "+machine.Windows+"; build="+machine.Build+"; native options="+App.Items.Count);
  var observations=App.Items.Select(i=>App.Observe(i,machine)).ToArray();
  foreach(var group in observations.GroupBy(o=>o.State))Console.WriteLine("Setting reads: "+group.Key+" = "+group.Count());
  var apps=AppRemoval.Scan();Console.WriteLine("App definitions checked: "+apps.Count+"; confirmed="+apps.Count(a=>a.Known)+"; unavailable="+apps.Count(a=>!a.Known));
  foreach(string id in ReviewedDiagnostics.Ids){var result=ReviewedDiagnostics.Read(id);Console.WriteLine(id+": "+(result.Contains("indisponível")||result.Contains("excedeu")?"partial/unavailable":"read completed")+"; chars="+result.Length);}
  if(observations.Length!=127||apps.Count!=141)throw new Exception("Missing catalog entries");
  if(App.History().Count!=0)throw new Exception("Read-only scan created change records");
  Console.WriteLine("PASS: actual Windows read-only queries return a result or an explicit limitation; no optimizations, removals or change records.");return 0;
 }catch(Exception e){Console.WriteLine(e);return 1;}}
}

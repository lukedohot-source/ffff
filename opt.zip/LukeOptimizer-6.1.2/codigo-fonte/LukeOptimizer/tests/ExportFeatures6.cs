using System;
using System.IO;
using System.Linq;
class ExportFeatures6 {
 static int Main(string[] args){
  var data=new{Version=App.Version,OfficialDiagnostics=CommandTools.Catalog(),CleanupCategories=StorageManager.Categories().Select(c=>new{c.Id,c.Name,c.Pattern,c.Warning,c.Administrator}).ToArray(),MemoryApi="EmptyWorkingSet",MemoryAutomaticDefault=false,GlobalStandbyPurge=false,Pages=new[]{"Painel","Memory Manager","Temporários","Avançado / Alto Impacto","Diagnósticos oficiais","Resultados","Configurações"},Sources=new[]{"https://learn.microsoft.com/en-us/windows/win32/api/psapi/nf-psapi-emptyworkingset","https://learn.microsoft.com/en-us/windows/win32/api/psapi/ns-psapi-performance_information","https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects"}};
  File.WriteAllText(args[0],App.Json.Serialize(data));Console.WriteLine("PASS: 8 official diagnostics, 8 cleanup categories and 7 new pages exported from compiled code.");return 0;
 }
}

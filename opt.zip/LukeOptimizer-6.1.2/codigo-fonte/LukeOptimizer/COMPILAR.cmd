@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0VALIDAR-5.4.ps1"
exit /b %ERRORLEVEL%

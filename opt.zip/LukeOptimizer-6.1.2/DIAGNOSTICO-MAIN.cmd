@echo off
setlocal
pushd "%~dp0" >nul 2>&1
native\LukeOptimizer-main-diagnostico.exe
set "RC=%ERRORLEVEL%"
echo.
echo Codigo de saida: %RC%
pause
popd
exit /b %RC%
